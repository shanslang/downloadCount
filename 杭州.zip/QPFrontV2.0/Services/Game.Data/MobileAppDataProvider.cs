﻿using Game.Entity.MobileApp;
using Game.Francis;
using Game.IData;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.Common;
using Game.Type;

namespace Game.Data
{
    public class MobileAppDataProvider : DBHelper, IMobileAppDataProvider
    {
        #region 构造方法
        public MobileAppDataProvider(string connString)
            : base(connString)
        {

        }
        #endregion

        #region 游戏场次数据

        /// <summary>
        /// 获取登陆服务器地址
        /// </summary>
        /// <returns></returns>
        public IList<AppServerAddressCFG> GetLogonServerAddress(int versionid, int userid)
        {
            StringBuilder sbCache = new StringBuilder();
            if (userid == 0)
            {
                return ExecSqlForObjectList<AppServerAddressCFG>(@"SELECT top 1 * FROM [QPMobileAppDB].[dbo].[AppServerAddressCFG] as a where a.IsEnabled=1  and IsDefense=0 and VersionID=0 
 union all
select * from[QPMobileAppDB].[dbo].[AppServerAddressCFG] where IsEnabled = 1 and IsDefense = 1 and VersionID =0");
            }
            sbCache.Append(string.Format(@"
SELECT a.* FROM [QPMobileAppDB].[dbo].[AppServerAddressCFG] as a left join [THAccountsDB].[dbo].[AccountsInfo] as b on a.IsVip=b.[VipServer] where a.IsEnabled=1 and [UserID]={0} and IsDefense=0 and VersionID={1}
 union all
select * from [QPMobileAppDB].[dbo].[AppServerAddressCFG] where IsEnabled=1 and IsDefense=1 and VersionID={1}", userid, versionid));

            //  select* from AppServerAddressCFG(NOLOCK) where IsEnabled = 1 and VersionID = { 0 }

            var datalist = ExecSqlForObjectList<AppServerAddressCFG>(sbCache.ToString());
            if (datalist != null && datalist.Count > 0)
            {
                return datalist;
            }
            else
            {
                return ExecSqlForObjectList<AppServerAddressCFG>(string.Format(@"SELECT a.* FROM [QPMobileAppDB].[dbo].[AppServerAddressCFG] as a left join [THAccountsDB].[dbo].[AccountsInfo] as b on a.IsVip=b.[VipServer] where a.IsEnabled=1 and [UserID]={0} and IsDefense=0 and VersionID=0
 union all
select * from[QPMobileAppDB].[dbo].[AppServerAddressCFG] where IsEnabled = 1 and IsDefense = 1 and VersionID =0", userid));
            }
        }
        /// <summary>
        /// 获取接口访问地址
        /// </summary>
        /// <returns></returns>
        public AppVisitAddressCFG GetAppVisitAddress(int versionid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(string.Format("select top 1 [VersionID],[Appweb_url],[AppFileRec],[AppUpdate_url],IsEnble from AppVisitAddressCFG(NOLOCK) where VersionID={0} or VersionID=0 order by VersionID desc", versionid));
            return ExecSqlForObject<AppVisitAddressCFG>(sbCache.ToString());
        }

        /// <summary>
        /// 获取app游戏渠道配置
        /// </summary> 
        public DataSet GetGameAppUrlCFG(int gameID, int chanelID, int userId)
        {
            string sql = "";
            var parms = new List<DbParameter>();
            if (userId > 0)
            {
                sql = @"SELECT A.*,B.*, 
                        CASE WHEN B.RewardType=1 THEN '金币：'+CONVERT(NVARCHAR(120),RewardValue)
                        WHEN B.RewardType=2 then '奖牌：'+CONVERT(NVARCHAR(120),RewardValue) 
                        WHEN B.RewardType=3 then '道具：'+ (SELECT Name FROM QPGamePropertyDB.dbo.PropertyCFG(NOLOCK) WHERE PID=RewardValue-65536)+' x '+CONVERT(NVARCHAR(120),Num) else '' end AS Awardinfo,
                        (SELECT COUNT(UserID) FROM RecordDownRewardHistory(NOLOCK) WHERE UserID=@UserID AND DownGameID=A.GameId) AS Received
                        FROM [QPMobileAppDB].[dbo].[GameAppUrlCFG](NOLOCK) AS A
                        INNER JOIN GameDownloadReward(NOLOCK) AS B
                        ON A.GameID =B.GameID AND A.ChanelID=@ChanelID AND A.IsDisable=0 ";
                parms.Add(MakeInParam("UserID", userId));
                parms.Add(MakeInParam("ChanelID", chanelID));
            }
            else
            {
                sql = "SELECT TOP 1 [GameID],[ChanelID],[AppURL],[EngineVersion],[Description],[IsDisable],[UpdateInFo],[ApkMD5] FROM [QPMobileAppDB].[dbo].[GameAppUrlCFG](NOLOCK) WHERE [GameID]=@GameID AND [ChanelID]=@ChanelID";
                parms.Add(MakeInParam("GameID", gameID));
                parms.Add(MakeInParam("ChanelID", chanelID));
            }



            return ExecSqlForDataSet(sql, parms);
        }

        /// <summary>
        /// 新增手游戏渠道配置
        /// </summary> 
        public void AddGameAppUrlCFG(string GameID, string ChanelID, string AppURL, string EngineVersion, string Description, string UpdateInFo, string ApkMD5)
        {
            string sql = "";
            var parms = new List<DbParameter>();

            sql = @"IF EXISTS(SELECT 1 FROM [QPMobileAppDB].[dbo].[GameAppUrlCFG](NOLOCK) WHERE [GameID]=@GameID AND [ChanelID]=@ChanelID)
                    BEGIN
	                    UPDATE [QPMobileAppDB].[dbo].[GameAppUrlCFG]
	                    SET [AppURL]=@AppURL,[EngineVersion]=@EngineVersion,[Description]=@Description,[UpdateInFo]=@UpdateInFo,[ApkMD5]=@ApkMD5
	                    WHERE [GameID]=@GameID AND [ChanelID]=@ChanelID
                    END
                    ELSE
                    BEGIN
	                    INSERT INTO [QPMobileAppDB].[dbo].[GameAppUrlCFG](
	                        [GameID],[ChanelID],[AppURL],[EngineVersion],[Description],[IsDisable],[UpdateInFo],[ApkMD5])
	                    VALUES(@GameID,@ChanelID,@AppURL,@EngineVersion,@Description,0,@UpdateInFo,@ApkMD5) 
                    END";
            parms.Add(MakeInParam("GameID", GameID));
            parms.Add(MakeInParam("ChanelID", ChanelID));
            parms.Add(MakeInParam("AppURL", AppURL));
            parms.Add(MakeInParam("EngineVersion", EngineVersion));
            parms.Add(MakeInParam("Description", Description));
            parms.Add(MakeInParam("UpdateInFo", UpdateInFo));
            parms.Add(MakeInParam("ApkMD5", ApkMD5));

            ExecSqlNonQuery(sql, parms);
        }
        /// <summary>
        /// 获取游戏下载地址(IOS AppID)
        /// </summary>
        /// <param name="SerType"></param>
        /// <returns></returns>
        public GameAppIDInfo APPIDInfoGet(AppSerType SerType)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT * FROM GameAppIDInfo(NOLOCK) where SerType=" + (int)SerType);
            return ExecSqlForObject<GameAppIDInfo>(sbCache.ToString());
        }
        /// <summary>
        ///获取游戏场次数据
        /// </summary>
        /// <returns></returns>
        public IList<GameScreenings> GameScreeningsList(string wherecase, string orderbywhere)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT [Id],[Name],[Slogans],[AccessGold],[CTime],[ETime],SerType,SortID  FROM [QPMobileAppDB].[dbo].[GameScreenings] WHERE 1=1 ");
            if (wherecase.Trim().Length > 0)
            {
                sbCache.Append(wherecase);
            }
            if (orderbywhere.Trim().Length == 0)
            {
                sbCache.Append(" order By ETime DESC ");
            }
            return ExecSqlForObjectList<GameScreenings>(sbCache.ToString());
        }
        /// <summary>
        /// 游戏场次信息房间数据
        /// </summary>
        /// <param name="ScreenID"></param>
        /// <returns></returns>
        public IList<GameScreeningsSerCFG> GameScreenServerList(int ScreenID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(" select * from GameScreeningsSerCFG where [Disable]=0 AND ScreenID=" + ScreenID);
            return ExecSqlForObjectList<GameScreeningsSerCFG>(sbCache.ToString());
        }
        /// <summary>
        /// 获取多个房间准入金币信息
        /// </summary>
        /// <param name="wherecase"></param>
        /// <returns></returns>
        public DataSet GameScreenServerList(string wherecase)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT A.*,r.MinTableScore from GameScreeningsSerCFG(NOLOCK) AS A 
                            LEFT JOIN QPPlatformDB.dbo.GameRoomInfo(NOLOCK) AS r
                            ON A.ServerID=r.ServerID
                            WHERE A.[Disable]=0 " + wherecase);
            return ExecSqlForDataSet(sbCache.ToString());
        }

        public DataSet GetAppVerfilterList(string GameId, string Version)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("GameId", GameId));
            parms.Add(MakeInParam("Version", Version));

            string sbCache = @"SELECT [Id],[GameId],[Version] ,[InsertTine]
                               FROM [QPMobileAppDB].[dbo].[AppVerfilter](NOLOCK)
                               WHERE [GameId]=@GameId AND [Version]=@Version";
            return ExecSqlForDataSet(sbCache, parms);
        }
        #endregion

        #region 更多游戏数据
        /// <summary>
        /// 获取更多游戏数据信息
        /// </summary>
        /// <param name="whereCase"></param>
        /// <returns></returns>
        public DataSet MoreGameList(string whereCase, int UserID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(string.Format(@"SELECT A.*,B.*,C.IconName,C.IconUrl,C.IconMd5,
                                        CASE WHEN B.RewardType=1 THEN '金币：'+CONVERT(NVARCHAR(120),RewardValue)
                                        WHEN B.RewardType=2 then '奖牌：'+CONVERT(NVARCHAR(120),RewardValue) 
                                        WHEN B.RewardType=3 then '道具：'+ (SELECT Name FROM QPGamePropertyDB.dbo.PropertyCFG(NOLOCK) WHERE PID=RewardValue-65536)+' x '+CONVERT(NVARCHAR(120),Num) else '' end AS Awardinfo,
                                        (SELECT COUNT(UserID) FROM RecordDownRewardHistory WHERE UserID={0} AND DownGameID=A.GameId) AS Received
                                        FROM [QPMobileAppDB].[dbo].[GameMoreCFG] AS A
                                        INNER JOIN GameDownloadReward(NOLOCK) AS B
                                        ON A.GameID =B.GameID
                                        LEFT JOIN AppIcon(NOLOCK) AS C
                                        ON A.IconId=C.iconID
                                        WHERE 1=1 ", UserID));
            if (whereCase.Trim().Length > 0)
            {
                sbCache.Append(whereCase);
            }
            return ExecSqlForDataSet(sbCache.ToString());
        }
        /// <summary>
        /// 领取奖励(更多游戏下载)
        /// </summary>
        /// <param name="RewardID"></param>
        /// <returns></returns>
        public Message MoreGameReward(int GameID, int UserID)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("GameID", GameID));
            parms.Add(MakeInParam("UserID", UserID));
            parms.Add(MakeOutParam("ErrorMsg", DbType.String, 127));
            return ExecProcForMessageDataSet("[proc_ReceiveGameDownloadReward]", parms);
        }
        #endregion

        #region 公告信息
        /// <summary>
        /// 获取最新公告信息
        /// </summary>
        /// <returns></returns>
        public NoticeCFG AppNoticeCFGInfo()
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT A.*,ISNULL(B.Title,'公告') AS Title FROM [QPMobileAppDB].[dbo].[NoticeCFG](NOLOCK) AS A left join NoticeInfo(NOLOCK) AS B  on A.NoticeID=B.ID");
            return ExecSqlForObject<NoticeCFG>(sbCache.ToString());
        }
        /// <summary>
        /// 最近一次获奖记录
        /// </summary>
        /// <returns></returns>
        public string AppNoticeReword()
        {
            object omsg = ExecProcScalar("proc_NoticeReword");
            if (omsg == null) { return ""; }
            return omsg.ToString();
        }
        /// <summary>
        /// 获取公告列表
        /// </summary>
        /// <param name="wherecase"></param>
        /// <returns></returns>
        public DataSet NoticeList(string wherecase)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("select * from NoticeInfo where 1=1 ");
            if (wherecase.Trim().Length > 0)
            {
                sbCache.Append(wherecase);
            }
            return ExecSqlForDataSet(sbCache.ToString(), null);
        }
        #endregion

        #region 排行数据
        /// <summary>
        /// 获取某个用户的排名名次
        /// </summary>
        /// <param name="Userid"></param>
        /// <returns></returns>
        public DataSet RakingDataByUser(int Userid)
        {
            var param = new List<DbParameter>();
            param.Add(MakeInParam("UserID", Userid));
            return ExecProcForDataSet("proc_RankData", param);
        }


        /// <summary>
        /// 财富榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingScoreDataList(int RankCounts)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT top ").Append(RankCounts).Append(@" u.UserID,u.Accounts,(case when WeiXinName ='' then u.NickName else WeiXinName end) as NickName,FaceID,(s.Score+s.InsureScore) as AllScore,u.CustomID
	                         FROM QPAccountsDB.dbo.AccountsInfo(NOLOCK) AS u
	                         inner join QPTreasureDB.dbo.GameScoreInfo(NOLOCK) as s
	                         on s.UserID=u.UserID 
                             where u.IsAndroid=0 and u.IsShowRanking=1 and Nullity=0
	                         Order by (Score+InsureScore) DESC"
                           );
            return ExecSqlForDataSet(sbCache.ToString());
        }

        /// <summary>
        /// 战绩榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingRecordDataList(int RankCounts)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT top ").Append(RankCounts).Append(@" u.UserID,u.Accounts,(case when WeiXinName ='' then u.NickName else WeiXinName end) as NickName,FaceID,(s.Score+s.InsureScore)-(L.Score+L.BankScore) as DifferenceScore,u.CustomID
	                        FROM QPAccountsDB.dbo.AccountsInfo(NOLOCK) AS u
	                        inner join QPGameLogDB.dbo.ScoreDayLog(NOLOCK) as L
	                        on L.UserID=u.UserID 
	                        inner join QPTreasureDB.dbo.GameScoreInfo(NOLOCK) as s
	                        on s.UserID=u.UserID
	                        where u.IsAndroid=0  and u.IsShowRanking=1  and Nullity=0 and  L.ID>(select ScoreDayLog_EntityID from  [QPGameLogDB].[dbo].[DayIDForStatistics] where DATEDIFF(DAY,InsertTime,GETDATE())=1) 
	                        Order by DifferenceScore DESC"
                           );
            return ExecSqlForDataSet(sbCache.ToString());
        }
        /// <summary>
        /// 魅力榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingLoveLinessDataList(int RankCounts)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT top ").Append(RankCounts).Append(@" u.UserID,u.Accounts,u.NickName,FaceID,s.LoveLiness,u.CustomID
	                        FROM QPAccountsDB.dbo.AccountsInfo(NOLOCK) AS u
	                        inner join QPTreasureDB.dbo.GameScoreInfoEx(NOLOCK) as s
	                        on s.UserID=u.UserID 
                            where u.IsAndroid=0  and u.IsShowRanking=1 and Nullity=0 
	                        Order by LoveLiness DESC"
                           );
            return ExecSqlForDataSet(sbCache.ToString());
        }

        #endregion

        #region 游戏下载奖励信息
        /// <summary>
        /// 游戏下载奖励信息
        /// </summary>
        /// <param name="Gameid"></param>
        /// <returns></returns>
        public GameDownloadReward GetDownloadReward(int Gameid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(string.Format("SELECT * FROM GameDownloadReward WHERE GameID={0}", Gameid));
            return ExecSqlForObject<GameDownloadReward>(sbCache.ToString());
        }

        #endregion

        #region 商城
        /// <summary>
        /// 获取商城数据
        /// </summary>
        /// <param name="wherecase"></param>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public DataSet AppProductList(string wherecase, string orderbywhere)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select A.*,B.IconName,B.IconUrl,B.IconMd5 from AppPruduct(NOLOCK) AS A
                            left join AppIcon(NOLOCK) AS B
                            on A.IConID=B.IconID where 1=1 ");
            if (wherecase.Trim().Length == 0)
            {
                wherecase = " and  A.Nullity=0 ";
            }
            if (orderbywhere.Trim().Length == 0)
            {
                orderbywhere = " order by A.CTime DESC ";
            }
            sbCache.Append(wherecase).Append(orderbywhere); ;
            return ExecSqlForDataSet(sbCache.ToString());
        }
        /// <summary>
        /// 购买记录
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="identifier"></param>
        /// <param name="orderid"></param>
        public void AppInsertAppBuyHistoty(int userid, string identifier, string orderid)
        {
            var param = new List<DbParameter>();
            param.Add(MakeInParam("UserID", userid));
            param.Add(MakeInParam("Identifier", identifier));
            param.Add(MakeInParam("OrderID", orderid));
            ExecProcForDataSet("proc_InsertAppBuyHistoty", param);
        }
        /// <summary>
        /// 是否已经购买过只能购买一次的产品
        /// </summary>
        /// <returns></returns>
        public bool RtRepeatBuy(int userID, string Identifier)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(string.Format(@"select COUNT(*) from AppBuyHistoty(NOLOCK) AS A
                            LEFT JOIN AppPruduct(NOLOCK) AS B
                            ON A.Identifier=B.Identifier
                             where A.UserID={0} and A.Identifier='{1}'  AND RepeatBuy=0", userID, Identifier));
            return Convert.ToInt32(ExecSqlScalar(sbCache.ToString())) > 0;
        }
        #endregion

        #region 比赛
        /// <summary>
        /// 获取比赛奖励信息
        /// </summary>
        /// <param name="Matchid"></param>
        /// <param name="Roundid"></param>
        /// <returns></returns>
        public IList<Modulehelp> AppLoadMatchReward(int Matchid, int Roundid)
        {
            var prams = new List<DbParameter>();
            prams.Add(MakeInParam("MatchID", Matchid));
            prams.Add(MakeInParam("MatchRoundID", Roundid));
            return ExecProcForObjectList<Modulehelp>("proc_AppLoadMatchRewardInfo", prams);
        }

        /// <summary>
        /// 获取比赛信息(手游获取指定信息)
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public Message GetMobileMatchInfo(int matchid, int roundid)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("MatchID", matchid));
            prams.Add(MakeInParam("RoundID", roundid));
            return ExecProcForMessageDataSet("proc_AppLoadMatchInfo", prams);
        }
        /// <summary>
        /// 获取比赛组信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        public DataSet GetMobileGroupInfo(int kindID)
        {
            StringBuilder sbsql = new StringBuilder();
            sbsql.Append(string.Format("SELECT * FROM [QPMatchDB].[dbo].[MatchGroupInfoMobile] WHERE KindId={0} order by SortId desc", kindID));
            return ExecSqlForDataSet(sbsql.ToString());
        }
        #endregion

        #region 手游渠道
        public void InsertChannelLoginHistoty(string accounts, string channelId, string channelAccount, string channelToken, string type, int gameId)
        {
            string sql = @"INSERT INTO [QPMobileAppDB].[dbo].[ChannelLoginHistoty](
                               [Accounts],[ChannelId],[ChannelAccount],[ChannelToken],[Type],[GameId])
                           VALUES(@accounts,@channelId,@channelAccount,@channelToken,@type,@gameId)";

            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("accounts", accounts));
            parms.Add(MakeInParam("channelId", channelId));
            parms.Add(MakeInParam("channelAccount", channelAccount));
            parms.Add(MakeInParam("channelToken", channelToken));
            parms.Add(MakeInParam("type", type));
            parms.Add(MakeInParam("gameId", gameId));
            ExecSqlNonQuery(sql, parms);
        }
        #endregion

        #region 获取GameAppUrlCFG
        /// <summary>
        /// 获取app游戏渠道配置
        /// author:Francis
        /// </summary>
        /// <param name="gameid"></param>
        /// <param name="channelid"></param>
        /// <returns></returns>
        public GameAppUrlCFG GetGameAppUrlCFG(int gameid, int channelid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(string.Format("SELECT * FROM GameAppUrlCFG WHERE GameID={0} AND ChanelID={1}", gameid, channelid));
            return ExecSqlForObject<GameAppUrlCFG>(sbCache.ToString());
        }
        #endregion

        #region 获取小游戏开关配置

        /// <summary>
        /// 获取小游戏关闭配置列表
        /// </summary>
        /// <param name="kindId"></param>
        /// <returns></returns>
        public DataSet GetGameEnabledConfig(int kindId)
        {
            var sbCache = new StringBuilder();
            sbCache.AppendFormat("select gameid from [QPMobileAppDB].[dbo].[GameEnabledConfig] where IsEnabled=0 and kindID={0} group by gameid;select * from [QPMobileAppDB].[dbo].[GameEnabledConfig] where IsEnabled=0 and kindID={0}", kindId);
            return ExecSqlForDataSet(sbCache.ToString());
        }
        #endregion

        #region 获取快充配置

        /// <summary>
        /// 获取快充配置
        /// </summary>
        /// <param name="kindId"></param>
        /// <returns></returns>
        public DataSet GetFastChargeConfig(int kindId)
        {
            var sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT  [ServerLv] ,[Amount],[Score],[Chargetype] FROM [QPMobileAppDB].[dbo].[FastChargeCFG] where KindID={0}", kindId);
            return ExecSqlForDataSet(sbCache.ToString());
        }
        #endregion
        #region 获取游戏客服信息
        public string GetGameKFInfo(int kindID)
        {
            string sql = string.Format("select KFInfo from [QPMobileAppDB].[dbo].[GameKFCFG] where kindID={0}", kindID);
            var result = ExecSqlScalar(sql);
            if (result == null)
            {
                return "";
            }
            return result.ToString();
        }
        #endregion
        public DataSet GameAllServerList()
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from [QPPlatformDB].[dbo].[GroupCFG](NOLOCK) ;SELECT groupid,MinEnterScore,[MaxEnterScore],ServerID,ServerPort from QPPlatformDB.dbo.GameRoomInfo(NOLOCK)");
            return ExecSqlForDataSet(sbCache.ToString());
        }
    }
}
