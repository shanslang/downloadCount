﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.QPMatch;

namespace Game.Data
{
    public class QPMatchProvider : DBHelper, IQPMatchProvider
    {
        #region 构造方法

        public QPMatchProvider(string connString)
            : base(connString)
        {

        }

        #endregion

        /// <summary>
        /// 获取比赛信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public MatchInfo GetMatchInfoByMatchID(int matchid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT * FROM QPMatchDB.dbo.MatchInfo(NOLOCK) WHERE MatchID={0}", matchid);
            return ExecSqlForObject<MatchInfo>(sbCache.ToString());
        }

        /// <summary>
        /// 获取比赛信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public MatchInfo GetMatchInfoByMatchID(int matchid, int roundid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT * FROM QPMatchDB.dbo.MatchInfo(NOLOCK) WHERE MatchID={0} and MatchRoundID={1}", matchid, roundid);
            return ExecSqlForObject<MatchInfo>(sbCache.ToString());
        }

        /// <summary>
        /// 获取比赛信息 提供个游戏的接口
        /// </summary>
        /// <returns></returns>
        public MatchInfo GetMatchInfo(int matchid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("select a.* from [QPMatchDB].[dbo].[MatchInfo] as a");
            sbSql.AppendFormat(" WHERE a.[MatchID]={0}", matchid);
            MatchInfo result = ExecSqlForObject<MatchInfo>(sbSql.ToString());
            if (result != null)
            {
                if (result.MatchType == 1)//定时排名
                {
                    sbSql.Length = 0;
                    sbSql.AppendFormat("select * from [QPMatchDB].[dbo].[MatchByTime] where MatchID={0}", matchid);
                    var oMatchByTime = ExecSqlForObject<MatchByTime>(sbSql.ToString());
                    if (oMatchByTime != null)
                    {
                        result.GameSec = oMatchByTime.GameSec;
                        result.CellScore = oMatchByTime.CellScore;
                        result.OutScore = oMatchByTime.OutScore;
                        result.StopDispatchSec = oMatchByTime.StopDispatchSec;
                        result.minGameCount = oMatchByTime.minGameCount;

                        sbSql.Length = 0;
                        sbSql.AppendFormat("SELECT max([Rank]) FROM [QPMatchDB].[dbo].[MatchReward] where MatchID ={0}", matchid);
                        result.RewardCount = Game.Utils.Utility.StrToInt(ExecSqlScalar(sbSql.ToString()), 0);
                    }
                }
                else if (result.MatchType == 2)//定局排名
                {
                    sbSql.Length = 0;
                    sbSql.AppendFormat("select * from [QPMatchDB].[dbo].[MatchByRound] where MatchID={0}", matchid);
                    //业务逻辑
                    List<MatchByRound> listMatchByRound = ExecSqlForObjectList<MatchByRound>(sbSql.ToString()).ToList();
                    if (listMatchByRound != null)
                    {
                        result.MatchByRoundItemsCount = listMatchByRound.Count();
                        result.MatchByRoundItems = listMatchByRound;
                    }
                }

                //比赛条件、最大奖励
                result.SignCond = string.IsNullOrEmpty(result.SignCondition) ? "-" : result.SignCondition;
                result.Reward = string.IsNullOrEmpty(result.SignMaxReward) ? "-" : result.SignMaxReward;

                //添加ClientVersion ImageVersion SoundVersion
                sbSql.Length = 0;
                sbSql.AppendFormat("select * from [QPPlatformDB].[dbo].[GameGameItem] where GameID={0}", result.KindID);
                var oGameGameItem = ExecSqlForObject<Game.Entity.Platform.GameGameItem>(sbSql.ToString());
                if (oGameGameItem != null)
                {
                    result.ClientVersion = oGameGameItem.ClientVersion;
                    result.ImageVersion = oGameGameItem.ImageVersion;
                    result.SoundVersion = oGameGameItem.SoundVersion;
                }
                result.MatchCost = "";
                DataTable dtcost = ExecSqlForDataSet(string.Format("select case when [CostID]=0 then '金币(保险柜)' else b.Name end as CostName,[CostValue]  from [QPMatchDB].[dbo].[MatchCost] as a left join QPGamePropertyDB.dbo.PropertyCFG as b on a.[CostID]-65536=b.PID  where MatchID={0} and IsCheckOnly=0", matchid)).Tables[0];
                StringBuilder sbcost = new StringBuilder();
                if (dtcost != null && dtcost.Rows.Count > 0)
                {
                    foreach (DataRow item in dtcost.Rows)
                    {
                        sbcost.AppendFormat(",{0} {1}", item["CostName"], item["CostValue"]);
                    }
                    result.MatchCost = sbcost.ToString().Trim(',');
                }
            }
            return result;
        }

        /// <summary>
        /// 获取比赛信息 新版
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public string GetMatchInfoV1Xml(int matchid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat("select a.* from [QPMatchDB].[dbo].[MatchInfo] as a WHERE a.[MatchID]={0}", matchid);
            MatchInfoV1 result = ExecSqlForObject<MatchInfoV1>(sbSql.ToString());

            string xml = null;
            if (result != null)
            {
                //<SortId>//排序Id
                //<LogoId>//Logo图片Id
                //<GroupMask>//分组掩码
                //<SignMaxReward>//比赛最高奖励
                //<SignCondition>//报名条件
                //<RewardCount>//有奖名次
                //<CDKey>//显示CDKey
                //<CDKeyWidth>//CDKey窗口宽度
                //<CDKeyHeight>//CDKey窗口高度
                //<ClientVersion>//客户端版本
                //<ImageVersion>//图片资源版本
                //<SoundVersion>//声音资源版本
                //<SlogansId>//
                //<SlogansFrameCount>
                //<SlogansFrameSpeed>
                //<SlogansTouchEvent>

                StringBuilder xmlCache = new StringBuilder();
                xmlCache.AppendFormat("<MatchInfo>");
                xmlCache.AppendFormat("<SortID>{0}</SortID>", result.SortID);
                xmlCache.AppendFormat("<LogoID>{0}</LogoID>", result.LogoID);
                xmlCache.AppendFormat("<GroupMask>{0}</GroupMask>", result.GroupMask);
                xmlCache.AppendFormat("<SignMaxReward>{0}</SignMaxReward>", result.SignMaxReward);
                xmlCache.AppendFormat("<SignCondition>{0}</SignCondition>", result.SignCondition);
                xmlCache.AppendFormat("<CDKey>{0}</CDKey>", result.CDKey);
                int MatchInfoCDKeyWidth = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MatchInfoCDKeyWidth"]);
                int MatchInfoCDKeyHeight = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MatchInfoCDKeyHeight"]);
                xmlCache.AppendFormat("<CDKeyWidth>{0}</CDKeyWidth>", MatchInfoCDKeyWidth);
                xmlCache.AppendFormat("<CDKeyHeight>{0}</CDKeyHeight>", MatchInfoCDKeyHeight);
                xmlCache.AppendFormat("<SlogansId>{0}</SlogansId>", result.SlogansId);
                xmlCache.AppendFormat("<SlogansFrameCount>{0}</SlogansFrameCount>", result.SlogansFrameCount);
                xmlCache.AppendFormat("<SlogansFrameSpeed>{0}</SlogansFrameSpeed>", result.SlogansFrameSpeed);
                xmlCache.AppendFormat("<SlogansTouchEvent>{0}</SlogansTouchEvent>", result.SlogansTouchEvent);
                xmlCache.AppendFormat("<UserListCount>{0}</UserListCount>", result.UserListCount);

                //添加有奖名次
                sbSql.Length = 0;
                sbSql.AppendFormat("SELECT max([Rank]) FROM [QPMatchDB].[dbo].[MatchReward] where MatchID ={0}", matchid);
                int RewardCount = Game.Utils.Utility.StrToInt(ExecSqlScalar(sbSql.ToString()), 0);
                xmlCache.AppendFormat("<RewardCount>{0}</RewardCount>", RewardCount);

                //添加ClientVersion ImageVersion SoundVersion
                sbSql.Length = 0;
                sbSql.AppendFormat("select * from [QPPlatformDB].[dbo].[GameGameItem] where GameID={0}", result.KindID);
                var oGameGameItem = ExecSqlForObject<Game.Entity.Platform.GameGameItem>(sbSql.ToString());
                if (oGameGameItem != null)
                {
                    xmlCache.AppendFormat("<ClientVersion>{0}</ClientVersion>", oGameGameItem.ClientVersion);
                    xmlCache.AppendFormat("<ImageVersion>{0}</ImageVersion>", oGameGameItem.ImageVersion);
                    xmlCache.AppendFormat("<SoundVersion>{0}</SoundVersion>", oGameGameItem.SoundVersion);
                }

                ////MatchType0
                //sbSql.Length = 0;
                //sbSql.AppendFormat("select * from [QPMatchDB].[dbo].[MatchType] where MatchType={0}", result.MatchType0);
                //var oMatchType0 = ExecSqlForObject<Game.Entity.QPMatch.MatchTypeV1>(sbSql.ToString());
                //if (oMatchType0 != null)
                //{
                //    sbSql.Length = 0;
                //    sbSql.AppendFormat("select * from [QPMatchDB].[dbo].{0} where MatchID={1}", oMatchType0.TypeConfigTable, result.MatchID);
                //    DataTable dtMatchType = ExecSqlForDataSet(sbSql.ToString()).Tables[0];
                //    if (dtMatchType.Rows.Count > 0)
                //    {
                //        xmlCache.AppendFormat("<MatchType0>");
                //        for (int i = 0; i < dtMatchType.Rows.Count; i++)
                //        {
                //            xmlCache.AppendFormat("<Count{0}>", i);
                //            for (int j = 0; j < dtMatchType.Columns.Count; j++)
                //            {
                //                xmlCache.AppendFormat("<{0}>{1}</{0}>", dtMatchType.Columns[j].ColumnName, dtMatchType.Rows[i][j]);
                //            }
                //            xmlCache.AppendFormat("</Count{0}>", i);
                //        }
                //        xmlCache.AppendFormat("</MatchType0>");
                //    }
                //    else
                //    {
                //        xmlCache.AppendFormat("<MatchType0></MatchType0>");
                //    }
                //}
                //else
                //{
                //    xmlCache.AppendFormat("<MatchType0></MatchType0>");
                //}


                ////MatchType1
                //sbSql.Length = 0;
                //sbSql.AppendFormat("select * from [QPMatchDB].[dbo].[MatchType] where MatchType={0}", result.MatchType1);
                //var oMatchType1 = ExecSqlForObject<Game.Entity.QPMatch.MatchTypeV1>(sbSql.ToString());
                //if (oMatchType1 != null)
                //{
                //    sbSql.Length = 0;
                //    sbSql.AppendFormat("select * from [QPMatchDB].[dbo].{0} where MatchID={1}", oMatchType1.TypeConfigTable,result.MatchID);
                //    DataTable dtMatchType = ExecSqlForDataSet(sbSql.ToString()).Tables[0];
                //    if (dtMatchType.Rows.Count > 0)
                //    {
                //        xmlCache.AppendFormat("<MatchType1>");
                //        for (int i = 0; i < dtMatchType.Rows.Count; i++)
                //        {
                //            xmlCache.AppendFormat("<Count{0}>", i);
                //            for (int j = 0; j < dtMatchType.Columns.Count; j++)
                //            {
                //                xmlCache.AppendFormat("<{0}>{1}</{0}>", dtMatchType.Columns[j].ColumnName, dtMatchType.Rows[i][j]);
                //            }
                //            xmlCache.AppendFormat("</Count{0}>", i);
                //        }
                //        xmlCache.AppendFormat("</MatchType1>");
                //    }
                //    else {
                //        xmlCache.AppendFormat("<MatchType1></MatchType1>");
                //    }
                //}
                //else
                //{
                //    xmlCache.AppendFormat("<MatchType1></MatchType1>");
                //}

                xmlCache.AppendFormat("</MatchInfo>");
                xml = xmlCache.ToString();
            }
            return xml;
        }

        /// <summary>
        /// 获取比赛列表信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public IList<MatchInfo> GetMatchInfoList(string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT * FROM QPMatchDB.dbo.MatchInfo(NOLOCK)");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where 1=1 ").Append(wherestr);
            }
            return ExecSqlForObjectList<MatchInfo>(sbCache.ToString());
        }

        /// <summary>
        /// 获取比赛报名信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public int GetMatchSignCount(string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT COUNT(*) FROM QPMatchDB.dbo.MatchSign(NOLOCK) as a left join QPAccountsDB.dbo.AccountsInfo as b on a.UserID=b.UserID");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where 1=1 ").Append(wherestr);
            }
            return (int)ExecSqlScalar(sbCache.ToString());
        }

        /// <summary>
        /// 获取比赛报名信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public IList<MatchSign> GetMatchSignList(int top, string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT {0} a.*,b.NickName FROM QPMatchDB.dbo.MatchSign(NOLOCK) as a left join QPAccountsDB.dbo.AccountsInfo as b on a.UserID=b.UserID", top > 0 ? "top " + top : "");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where 1=1 ").Append(wherestr);
            }
            return ExecSqlForObjectList<MatchSign>(sbCache.ToString());
        }

        /// <summary>
        /// 获取比赛记录信息 最后的记录 只获取有名次的
        /// </summary>
        /// <param name="matchid"></param>
        /// <param name="matchsubid"></param>
        /// <returns></returns>
        public DataSet GetMatchLogByMatchID(int matchid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select a.*,b.Accounts,b.NickName from QPGameLogDB.dbo.MatchLog as a
left join QPAccountsDB.dbo.AccountsInfo as b on a.UserID=b.UserID 
WHERE a.MatchID={0} and RoundID=(select max(RoundID) from [QPGameLogDB].[dbo].[MatchLog] where Rank <= (select max(Rank) from [QPMatchDB].[dbo].[MatchReward] where MatchID={0}) and MatchID={0})
and a.Rank <= (select max(Rank) from [QPMatchDB].[dbo].[MatchReward] where MatchID={0})
order by a.Rank ASC", matchid);
            return ExecSqlForDataSet(sbCache.ToString());
        }

        /// <summary>
        /// 获取比赛记录信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <param name="matchsubid"></param>
        /// <returns></returns>
        public DataSet GetMatchLogByMatchID(int matchid, int matchsubid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select a.*,b.Accounts,b.NickName from QPGameLogDB.dbo.MatchLog as a
left join QPAccountsDB.dbo.AccountsInfo as b on a.UserID=b.UserID 
WHERE MatchID={0} and RoundID={1}
and a.Rank <= (select max(Rank) from [QPMatchDB].[dbo].[MatchReward] where MatchID={0})
order by a.Rank ASC", matchid, matchsubid);
            return ExecSqlForDataSet(sbCache.ToString());
        }

        /// <summary>
        /// 获取比赛奖励信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public IList<MatchReward> GetMatchRewardByMatchID(int matchid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"SELECT a.*,
(CASE 
WHEN RewardType=1 THEN '金币x'+CONVERT(NVARCHAR,RewardValue)
WHEN RewardType=2 THEN '经验值x'+CONVERT(NVARCHAR,RewardValue)
WHEN RewardType=3 THEN '奖牌x'+CONVERT(NVARCHAR,RewardValue)
WHEN RewardType=4 THEN '黄钻x'+CONVERT(NVARCHAR,RewardValue)
WHEN RewardType=5 THEN '红钻x'+CONVERT(NVARCHAR,RewardValue)
WHEN RewardType=6 THEN '蓝钻x'+CONVERT(NVARCHAR,RewardValue)
WHEN RewardType>65536 THEN (SELECT [Name] FROM [QPGamePropertyDB].[dbo].[PropertyCFG] where PID=RewardType-65536)+'x'+CONVERT(NVARCHAR,RewardValue)
ELSE '--' END) as RewardContent
FROM QPMatchDB.dbo.MatchReward AS a WHERE MatchID={0} order by Rank ASC", matchid);
            return ExecSqlForObjectList<MatchReward>(sbCache.ToString());
        }

        /// <summary>
        /// 获取比赛组信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public IList<MatchGroupInfo> GetMatchGroupInfo()
        {
            StringBuilder sqlStr = new StringBuilder();
            sqlStr.AppendFormat(@"select * from QPMatchDB.dbo.MatchGroupInfo ORDER BY mask asc");
            return ExecSqlForObjectList<MatchGroupInfo>(sqlStr.ToString());
        }

        /// <summary>
        /// 获取当前参赛人数
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public Game.Entity.GameLog.MatchOnline GetMatchOnline(int matchid, int matchsubid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT * FROM QPGameLogDB.dbo.MatchOnline(NOLOCK) WHERE MatchID={0} and MatchSubID={1}", matchid, matchsubid);
            return ExecSqlForObject<Game.Entity.GameLog.MatchOnline>(sbCache.ToString());
        }
        /// <summary>
        /// 获取个人比赛成绩和奖励
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public DataSet GetUserMatchReward(int userID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"
SELECT top 100 a.MatchID,a.RoundID,isnull(MatchName,'该比赛已下线') as MatchName,[Rank],convert(nvarchar,a.InsertTime,23) as InsertTime,SUM(CASE WHEN [RewardType]=1 THEN [RewardValue] ELSE 0 END) AS 'GoldTotal', SUM(CASE WHEN [RewardType]=3 THEN [RewardValue] ELSE 0 END) AS 'MedalTotal',SUM(CASE WHEN [RewardType]>65535 THEN [RewardValue] ELSE 0 END) AS 'PropertyTotal'--道具数
 FROM  [QPGameLogDB].[dbo].[MatchRewardLog] as b  left join [QPGameLogDB].[dbo].[MatchLog] as a  on  a.MatchID=b.MatchID  and a.RoundID=b.MatchSubID and  a.userid=b.userid  left join [QPMatchDB].[dbo].[MatchInfo] as c on a.MatchID=c.MatchID where a.userid={0} group by a.MatchID,[rank],c.MatchName,a.RoundID,convert(nvarchar,a.InsertTime,23) order by convert(nvarchar,a.InsertTime,23) desc", userID);
            return ExecSqlForDataSet(sbCache.ToString());
        }
        /// <summary>
        /// 个人单场比赛奖励
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="matchID"></param>
        /// <param name="roundID"></param>
        /// <returns></returns>
        public DataSet GetUserMatchReward(int userID, int matchID, int roundID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"
SELECT a.MatchID,a.RoundID,isnull(MatchName,'该比赛已下线') as MatchName,[Rank], b.InsertTime,SUM(CASE WHEN [RewardType]=1 THEN [RewardValue] ELSE 0 END) AS 'GoldTotal', SUM(CASE WHEN [RewardType]=3 THEN [RewardValue] ELSE 0 END) AS 'MedalTotal',SUM(CASE WHEN [RewardType]>65535 THEN [RewardValue] ELSE 0 END) AS 'PropertyTotal'--道具数
 FROM  [QPGameLogDB].[dbo].[MatchRewardLog] as b  left join [QPGameLogDB].[dbo].[MatchLog] as a  on  a.MatchID=b.MatchID  and a.RoundID=b.MatchSubID and  a.userid=b.userid  left join [QPMatchDB].[dbo].[MatchInfo] as c on a.MatchID=c.MatchID where b.userid={0} and b.MatchID={1} and b.MatchSubID={2}  group by a.MatchID,[rank],c.MatchName,a.RoundID,b.InsertTime order by b.InsertTime desc", userID, matchID, roundID);
            return ExecSqlForDataSet(sbCache.ToString());
        }
    }
}
