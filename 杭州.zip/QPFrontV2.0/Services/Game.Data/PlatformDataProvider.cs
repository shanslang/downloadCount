﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.Platform;
using Game.Kernel;
using Message = Game.Francis.Message;

namespace Game.Data
{
    /// <summary>
    /// 平台数据访问层
    /// </summary>
    public class PlatformDataProvider : DBHelper, IPlatformDataProvider
    {
        #region 构造方法

        public PlatformDataProvider(string connString)
            : base(connString)
        {

        }
        #endregion

        /// <summary>
        /// 根据服务器地址获取数据库信息
        /// </summary>
        /// <param name="addrString"></param>
        /// <returns></returns>
        public DataBaseInfo GetDatabaseInfo(string addrString)
        {
            string sqlQuery = string.Format("SELECT * FROM DataBaseInfo(NOLOCK) WHERE DBAddr='{0}'", addrString);
            DataBaseInfo dbInfo = ExecSqlForObject<DataBaseInfo>(sqlQuery);

            return dbInfo;
        }

        /// <summary>
        /// 根据游戏ID获取服务器地址信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        public GameGameItem GetDBAddString(int kindID)
        {
            string sqlQuery = string.Format("SELECT GameName, DataBaseAddr, DataBaseName, ServerVersion, ClientVersion, ServerDLLName, ClientExeName FROM GameGameItem g,GameKindItem k WHERE KindID={0} AND g.GameID=k.GameID", kindID);
            GameGameItem game = ExecSqlForObject<GameGameItem>(sqlQuery);

            return game;
        }

        /// <summary>
        /// 获取游戏类型列表
        /// </summary>
        /// <returns></returns>
        public IList<GameTypeItem> GetGmaeTypes()
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT TypeID,TypeName ")
                    .Append("FROM GameTypeItem ")
                    .Append("WHERE Nullity=0")
                    .Append(" ORDER By SortID ASC,TypeID ASC");

            return ExecSqlForObjectList<GameTypeItem>(sqlQuery.ToString());
        }

        /// <summary>
        /// 根据类型ID获取游戏列表
        /// </summary>
        /// <param name="typeID"></param>
        /// <returns></returns>
        public IList<GameKindItem> GetGameKindsByTypeID(int typeID)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT KindID, GameID, TypeID, SortID, KindName, ProcessName, GameRuleUrl, DownLoadUrl, Nullity ")
                    .Append("FROM GameKindItem ")
                    .AppendFormat("WHERE Nullity=0 AND TypeID={0} ", typeID)
                    .Append(" ORDER By SortID ASC,KindID ASC");
            return ExecSqlForObjectList<GameKindItem>(sqlQuery.ToString());
        }

        /// <summary>
        /// 获取热门游戏
        /// </summary>
        /// <param name="top"></param>
        /// <returns></returns>
        public IList<GameKindItem> GetHotGame(int top)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT top " + top + " KindID, KindName, GameRuleUrl ")
                    .Append("FROM GameKindItem ")
                    .Append("WHERE Nullity=0")
                    .Append(" ORDER By SortID ASC,KindID ASC");

            return ExecSqlForObjectList<GameKindItem>(sqlQuery.ToString());
        }

        /// <summary>
        /// 得到所有的游戏
        /// </summary>
        /// <returns></returns>
        public IList<GameKindItem> GetAllKinds()
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT KindID, GameID, TypeID, SortID, KindName, ProcessName, GameRuleUrl, DownLoadUrl, Nullity ")
                    .Append("FROM GameKindItem ")
                    .AppendFormat("WHERE Nullity=0 ")
                    .Append(" ORDER By KindID ASC ");
            return ExecSqlForObjectList<GameKindItem>(sqlQuery.ToString());
        }

        /// <summary>
        /// 得到积分游戏
        /// </summary>
        /// <returns></returns>
        public IList<GameKindItem> GetIntegralKinds()
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT KindID, GameID, TypeID, SortID, KindName, ProcessName, GameRuleUrl, DownLoadUrl, Nullity ")
                    .Append("FROM GameKindItem ")
                    .AppendFormat("WHERE Nullity=0 AND GameID NOT IN( SELECT GameID FROM GameGameItem WHERE DataBaseName = 'QPTreasureDB' )")
                    .Append(" ORDER By SortID ASC,KindID ASC ");
            return ExecSqlForObjectList<GameKindItem>(sqlQuery.ToString());
        }

        /// <summary>
        /// 得到游戏列表
        /// </summary>
        /// <returns></returns>
        public IList<GameGameItem> GetGameList()
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT a.KindID,a.KindName,b.DataBaseAddr,b.DataBaseName ")
                    .Append(" FROM GameKindItem a,GameGameItem b ")
                    .Append("WHERE a.GameID = b.GameID ORDER BY SortID");
            return ExecSqlForObjectList<GameGameItem>(sqlQuery.ToString());
        }

        /// <summary>
        /// 得到特定游戏
        /// </summary>
        /// <param name="kindid"></param>
        /// <returns></returns>
        public GameKindItem GetGameKindItem(int kindid)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT KindID, GameID, TypeID, SortID, KindName, ProcessName, GameRuleUrl, DownLoadUrl, Nullity ")
                    .Append("FROM GameKindItem ")
                    .AppendFormat("WHERE Nullity=0 and KindID={0}", kindid)
                    .Append(" ORDER By SortID ASC,KindID ASC ");
            return ExecSqlForObject<GameKindItem>(sqlQuery.ToString());
        }

        /// <summary>
        /// 修改客户端版本号
        /// author:francis
        /// </summary>
        /// <param name="gameid"></param>
        /// <param name="clientversion"></param>
        /// <returns></returns>
        public int UpdateGameGameItemClientVersionByGameID(int gameid, int version)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"update GameGameItem set ClientVersion={0} where GameID={1}", version, gameid);
            return this.ExecSqlNonQuery(sbSql.ToString());
        }
        /// <summary>
        /// 修改图片资源版本号
        /// author:francis
        /// </summary>
        /// <param name="gameid"></param>
        /// <param name="clientversion"></param>
        /// <returns></returns>
        public int UpdateGameGameItemImageVersionByGameID(int gameid, int version)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"update GameGameItem set ImageVersion={0} where GameID={1}", version, gameid);
            return this.ExecSqlNonQuery(sbSql.ToString());
        }
        /// <summary>
        /// 修改声音资源版本号
        /// author:francis
        /// </summary>
        /// <param name="gameid"></param>
        /// <param name="clientversion"></param>
        /// <returns></returns>
        public int UpdateGameGameItemSoundVersionByGameID(int gameid, int version)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"update GameGameItem set SoundVersion={0} where GameID={1}", version, gameid);
            return this.ExecSqlNonQuery(sbSql.ToString());
        }

        /// <summary>
        /// 查询页游配置表
        /// author:francis
        /// </summary>
        /// <returns></returns>
        public GamePageItem GetGamePageItemByPageID(int pageid)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.AppendFormat("SELECT * from [QPPlatformDB].[dbo].[GamePageItem] where PageID={0}", pageid);
            return ExecSqlForObject<GamePageItem>(sqlQuery.ToString());
        }

        #region 公共

        /// <summary>
        /// 根据SQL语句查询一个值
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        public object GetObjectBySql(string sqlQuery)
        {
            return ExecSqlScalar(sqlQuery);
        }

        /// <summary>
        /// 根据sql获取实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public T GetEntity<T>(string commandText)
        {
            return ExecSqlForObject<T>(commandText);
        }

        #endregion

        #region 比赛信息
        /// <summary>
        /// 获得游戏信息及场次信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <param name="matchno"></param>
        /// <returns></returns>
        public GameMatchInfo GetGameMatchInfo(int matchid)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT * from GameMatchInfo WHERE ");
            sqlQuery.Append("MatchID=").Append(matchid);
            //sqlQuery.Append(" AND MatchNO=").Append(matchno);
            return ExecSqlForObject<GameMatchInfo>(sqlQuery.ToString());
        }

        /// <summary>
        /// 获得游戏信息及场次信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <param name="matchno"></param>
        /// <returns></returns>
        public HistoryGameMatchInfo GetHistoryGameMatchInfo(int matchid, int matchno)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT * from HistoryGameMatchInfo WHERE ");
            sqlQuery.Append("MatchID=").Append(matchid);
            sqlQuery.Append(" AND MatchNO=").Append(matchno);
            return ExecSqlForObject<HistoryGameMatchInfo>(sqlQuery.ToString());
        }

        /// <summary>
        /// 获得游戏奖励信息列表
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public IList<MatchAwardConfig> GetMatchAwardConfigList(int matchid)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT *  FROM MatchAwardConfig WHERE ");
            sqlQuery.Append("MatchID=").Append(matchid);
            sqlQuery.Append(" ORDER BY Rank");
            return ExecSqlForObjectList<MatchAwardConfig>(sqlQuery.ToString());
        }
        #endregion

        #region 获取配置文件版本
        /// <summary>
        /// 获取配置文件版本
        /// </summary>
        /// <param name="kindID"></param>
        /// <param name="versionID"></param>
        /// <returns></returns>
        public int GetConfigVersion(int kindID, int versionID)
        {
            string sql = string.Format("SELECT [VersionValue] FROM [QPPlatformDB].[dbo].[ConfigVersion] where KindID={0} and VersionID={1}",kindID,versionID);
            int VersionValue = 1;
            int.TryParse(ExecSqlScalar(sql).ToString(), out VersionValue);
            return VersionValue;
        }
        #endregion
        /// <summary>
        /// 添加系统公告
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertSystemNotice(SystemNotice entity)
        {
            var parms = new List<DbParameter>
            {
                MakeInParam("paramNID", entity.NID),
                MakeInParam("paramGameID", entity.GameID),
                MakeInParam("paramServerID", entity.ServerID),
                MakeInParam("paramStartTime", entity.StartTime),
                MakeInParam("paramEndTime", entity.EndTime),
                MakeInParam("paramTimeSpace", entity.TimeSpace),
                MakeInParam("paramIsLoginSend", entity.IsLoginSend),
                MakeInParam("paramInfo", entity.Info),
                MakeInParam("noticeName", entity.NoticeName),
                MakeOutParam("paramErrorDescribe", DbType.String, 127)
            };
            return ExecProcForMessageDataSet("GSP_AI_InsertSystemNotice", parms);
        }
    }
}
