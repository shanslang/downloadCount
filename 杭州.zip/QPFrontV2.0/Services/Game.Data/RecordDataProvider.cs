﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.Record;

namespace Game.Data
{
    /// <summary>
    /// 记录库数据访问层
    /// </summary>
    public class RecordDataProvider : DBHelper, IRecordDataProvider
    {
        #region 构造方法

        public RecordDataProvider(string dbname)
            : base(dbname)
        {

        }
        #endregion

        #region  查询记录
        /// <summary>
        /// 魅力兑换记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetLovesRecord(string whereQuery, int pageIndex, int pageSize)
        {
            string sqlQuery = "select RecordID, UserID, KindID, ServerID, CurInsureScore, CurPresent, ConvertPresent, ConvertRate, IsGamePlaza, ClientIP, CollectDate from RecordConvertPresent";
            if (!string.IsNullOrEmpty(whereQuery))
            {
                sqlQuery += " where " + whereQuery;
            }
            return GetPagination(pageIndex, pageSize, sqlQuery, null, "CollectDate DESC", null);
        }

        /// <summary>
        /// 奖牌兑换记录
        /// </summary>
        /// <param name="whereQuery">查询条件</param>
        /// <param name="pageIndex">页索引</param>
        /// <param name="pageSize">页大小</param>
        /// <returns></returns>
        public DataSet GetMedalConvertRecord(string whereQuery, int pageIndex, int pageSize)
        {
            string sqlQuery = "select RecordID, UserID, CurInsureScore, CurUserMedal, ConvertUserMedal, ConvertRate, IsGamePlaza, ClientIP, CollectDate from RecordConvertUserMedal";
            if (!string.IsNullOrEmpty(whereQuery))
            {
                sqlQuery += " where " + whereQuery;
            }
            return GetPagination(pageIndex, pageSize, sqlQuery, null, "CollectDate DESC", null);
        }
        #endregion
        
    }
}
