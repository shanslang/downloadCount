﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Game.Francis;
using Game.IData;
using System.Data.Common;
using System.Data.SqlClient;
using Game.Entity.GameProperty;

using Microsoft.Practices.EnterpriseLibrary.Data;
using Game.Entity.Accounts;

namespace Game.Data
{
    public class GamePropertyDataProvider : DBHelper, IGamePropertyDataProvider
    {
        #region 构造函数
        public GamePropertyDataProvider(string dbname)
            : base(dbname)
        {

        }
        #endregion

        /// <summary>
        /// 查询道具记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetPropertyCFGRecord(int pageindex, int pagesize, string wherestr, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from PropertyCFG");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where 1=1 ").Append(wherestr);
            }
            if (string.IsNullOrEmpty(order))
            {
                order = "Pid DESC";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }

        /// <summary>
        /// 查询商品配置信息
        /// </summary>
        /// <returns></returns>
        public IList<PropertyCFGInfo> GetAllPropertyCFGInfo()
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT a.[PID],a.[ImgName],a.[SortID],(case when a.[Gold] <> 0 then a.[Gold] else a.[GoldBeans] end) as Price1,isnull(b.EffectValue,0) as Price2
                             FROM [QPGamePropertyDB].[dbo].[PropertyCFG] a (NOLOCK) 
                             left join [QPGamePropertyDB].[dbo].[PropertyEffectCFG] b (nolock)
                                 on b.PID = a.PID and b.EffectType < 65536
                             WHERE (a.[Gold] <> 0 or a.[GoldBeans] <> 0) and a.[Nullity] = 0");

            return this.ExecSqlForObjectList<PropertyCFGInfo>(sbCache.ToString());
        }

        /// <summary>
        /// 查询用户商品配置信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public IList<UserPropertyCFGInfo> GetUserPropertyCFGInfo(string userID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT a.[PID],a.[PCount],b.[SortID],b.[IsConvert],b.HeapCount,b.ImgName,b.SelfUse,b.ConvertProductPid
                             FROM [QPGamePropertyDB].[dbo].[UserProperty](NOLOCK) a,
                                  [QPGamePropertyDB].[dbo].[PropertyCFG](NOLOCK) b
                             WHERE a.[UserID]=(SELECT TOP 1 [UserID] FROM [QPAccountsDB].[dbo].[AccountsInfo](NOLOCK) WHERE [GameID]=@UserID) AND a.pid = b.pid AND a.[PCount]>0");
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("UserID", userID));
            return this.ExecSqlForObjectList<UserPropertyCFGInfo>(sbCache.ToString(), parms);
        }
        /// <summary>
        /// 查询用户指定道具数量
        /// </summary>
        /// <param name="accounts"></param>
        /// <param name="pID"></param>
        /// <returns></returns>
        public int GetUserPropertyCFGNum(string accounts, int pID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select PCount from [QPGamePropertyDB].[dbo].[UserProperty] as a left join
                        [QPAccountsDB].[dbo].[AccountsInfo] as b on  a.UserID=b.UserID where  Accounts=@Accounts and PID=@PID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("Accounts", accounts));
            prams.Add(MakeInParam("PID", pID));
            return ExecSqlForObject<int>(sbCache.ToString(), prams);
        }

        /// <summary>
        /// 查询道具配置
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public PropertyCFG GetPropertyCFG(int propertypid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from PropertyCFG");
            sbCache.AppendFormat(" where PID={0}", propertypid);
            return this.ExecSqlForObject<PropertyCFG>(sbCache.ToString());
        }

        /// <summary>
        /// 查询道具配置
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public IList<PropertyEffectCFG> GetPropertyEffectCFGRecord(int propertypid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from PropertyEffectCFG");
            sbCache.AppendFormat(" where PID={0}", propertypid);
            return this.ExecSqlForObjectList<PropertyEffectCFG>(sbCache.ToString());
        }

        /// <summary>
        /// 查询用户道具记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetUserPropertyRecord(int pageindex, int pagesize, int userid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,b.[Name],b.ImgUrl,b.IsConvert,b.ConvertProductPid,b.PerUseCount from UserProperty as a left join PropertyCFG as b on a.PID=b.PID");
            sbCache.AppendFormat(" where a.UserID={0} and PCount>0 and b.Nullity=0", userid);
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "Pid DESC", null);
        }

        /// <summary>
        /// 购买道具
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="propertypid"></param>
        /// <param name="count"></param>
        /// <param name="isbuy">是否购买 true购买 false赠送</param>
        /// <returns></returns>
        public Message GiveUserProperty(int userid, int propertypid, int count, bool isbuy)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", userid));
            prams.Add(MakeInParam("ServerID", 0));
            prams.Add(MakeInParam("PID", propertypid));
            prams.Add(MakeInParam("PCount", count));
            prams.Add(MakeInParam("OpType", 21));
            prams.Add(MakeInParam("IsBuy", isbuy ? 1 : 0));
            prams.Add(MakeOutParam("ErrorMessage", DbType.String, 127));
            return ExecProcForMessage("proc_GiveUserProperty", prams);
        }

        /// <summary>
        /// 购买道具
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="propertypid"></param>
        /// <param name="count"></param>
        /// <param name="isbuy">是否购买 true购买 false赠送</param>
        /// <returns></returns>
        public Message GiveUserProperty(int userid, int propertypid, int count, int optype, bool isbuy)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", userid));
            prams.Add(MakeInParam("ServerID", 0));
            prams.Add(MakeInParam("PID", propertypid));
            prams.Add(MakeInParam("PCount", count));
            prams.Add(MakeInParam("OpType", optype));
            prams.Add(MakeInParam("IsBuy", isbuy ? 1 : 0));
            prams.Add(MakeOutParam("ErrorMessage", DbType.String, 127));
            return ExecProcForMessage("proc_GiveUserProperty", prams);
        }

        /// <summary>
        /// 使用道具
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="targetuserid"></param>
        /// <param name="propertypid"></param>
        /// <param name="count"></param>
        /// <param name="forceuse">是否强制使用</param>
        /// <returns></returns>
        public Message UseProperty(int userid, int targetuserid, int propertypid, int count, bool forceuse)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", userid));
            prams.Add(MakeInParam("ServerID", 0));
            prams.Add(MakeInParam("TargetUserID", targetuserid));
            prams.Add(MakeInParam("OpType", 22));
            prams.Add(MakeInParam("PID", propertypid));
            prams.Add(MakeInParam("PCount", count));
            prams.Add(MakeInParam("ForceUse", forceuse ? 1 : 0));
            prams.Add(MakeOutParam("ErrorMessage", DbType.String, 127));
            return ExecProcForMessageDataSet("proc_UseProperty", prams);
        }
        /// <summary>
        /// 转让道具
        /// </summary>
        public Message TransProperty(int UserID, int TargetUserID, int pid, int PCount)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", UserID));
            prams.Add(MakeInParam("TargetUserID", TargetUserID));
            prams.Add(MakeInParam("PID", pid));
            prams.Add(MakeInParam("PCount", PCount));
            prams.Add(MakeOutParam("ErrorMessage", DbType.String, 127));
            return ExecProcForMessage("proc_TransUseProperty", prams);
        }
        #region 获取道具信息
        /// <summary>
        /// 获取道具信息
        /// </summary>
        /// <param name="wherecase"></param>
        /// <param name="orderwhere"></param>
        /// <returns></returns>
        public IList<PropertyCFG> GetPropertyList(string wherecase, string orderwhere)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("select * from PropertyCFG where 1=1 ");
            if (wherecase.Trim().Length > 0)
            {
                sbCache.Append(wherecase);
            }
            if (orderwhere.Trim().Length == 0)
            {
                sbCache.Append(wherecase);
            }
            sbCache.Append(orderwhere);
            return ExecSqlForObjectList<PropertyCFG>(sbCache.ToString());
        }


        #endregion


        #region IOS
        /// <summary>
        /// 查询用户道具(目前仅门票)
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetUserPropertyRecordForIOS(int userid, string contidion)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,b.[Name],b.Explain,b.[ConvertProductPid] from UserProperty as a left join PropertyCFG as b on a.PID=b.PID");
            sbCache.AppendFormat(" where a.UserID={0} and b.Nullity=0 {1}", userid, contidion);
            sbCache.Append("order by Pid DESC");
            return ExecSqlForDataSet(sbCache.ToString());
        }
        #endregion


        #region 获取代理商充值记录
        /// <summary>
        /// 查询代理商充值记录
        /// </summary>
        public DataSet GetRechargeCardDetail(int pageindex, int pagesize, int userid, string stime, string etime)
        {
            string where = "";
            if (stime != null && stime.Length > 0)
            {
                where += " and InsertDate>='" + Convert.ToDateTime(stime) + "'";
            }
            if (etime != null && etime.Length > 0)
            {
                where += " and InsertDate<'" + Convert.ToDateTime(etime).AddDays(1) + "'";
            }
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT  a.ID,case when weixinname='' then  NickName else weixinname end as NickName,b.UserID,[Pcount],[InsertDate]  FROM [QPGameLogDB].[dbo].[RechargeCardLog] as a left join  [QPAccountsDB].[dbo].[AccountsInfo] as b on a.TargetUserID=b.UserID  where a.UserID={0} {1}", userid, where);
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "id DESC", null);
        }
        /// <summary>
        /// 获取充值总数据
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public DataSet GetRechargeCardData(int userId, string stime, string etime)
        {
            string where = "";
            if (stime != null && stime.Length > 0)
            {
                where += " and InsertDate>='" + Convert.ToDateTime(stime) + "'";
            }
            if (etime != null && etime.Length > 0)
            {
                where += " and InsertDate<'" + Convert.ToDateTime(etime).AddDays(1) + "'";
            }
            return ExecSqlForDataSet(string.Format("SELECT count(distinct TargetUserID),isnull(sum(pcount),0)  FROM [QPGameLogDB].[dbo].[RechargeCardLog] where UserID={0} {1}", userId, where));
        }
        /// <summary>
        /// 查询代理商购买记录
        /// </summary>
        public DataSet GetBuyCardDetail(int pageindex, int pagesize, int userid, string stime, string etime)
        {
            string where = "";
            if (stime != null && stime.Length > 0)
            {
                where += " and InsertTime>='" + Convert.ToDateTime(stime) + "'";
            }
            if (etime != null && etime.Length > 0)
            {
                where += " and InsertTime<'" + Convert.ToDateTime(etime).AddDays(1) + "'";
            }
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT *  FROM [QPGameLogDB].[dbo].[RechargeVIPPropertyLog] where userid={0} {1}", userid, where);
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "id DESC", null);
        }
        /// <summary>
        /// 查询玩家房卡记录
        /// </summary>
        public DataSet GetPlayerCardRecord(int pageindex, int pagesize, int agentid, int userid, string stime, string etime)
        {
            //根据时间查询主键ID
            long id = 0;
            var ds = ExecSqlForDataSet(string.Format("select [UserPropertyLog_EntityID]  FROM[QPGameLogDB].[dbo].[DayIDForStatistics] where  datediff(day,InsertTime,'{0}')=0", stime));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                id = Convert.ToInt64(ds.Tables[0].Rows[0][0].ToString());
            }
            string where = string.Empty;
            if (userid > 0)
            {
                where = " and a.userid=" + userid;
            }
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT a.*  FROM [QPGameLogDB].[dbo].[UserPropertyLog] as a, [QPAccountsDB].[dbo].[AccountsInfo] as b  where a.userid=b.userid and b.agentid={0} and pid=99 and id>{1} {2}", agentid, id, where);
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "id DESC", null);
        }
        public DataSet GetRoomCardConsumeStatistics(int pageindex, int pagesize, int agentid, string stime, string etime)
        {
            string where = "";
            if (stime != null && stime.Length > 0)
            {
                where += " and InsertTime>='" + Convert.ToDateTime(stime) + "'";
            }
            if (etime != null && etime.Length > 0)
            {
                where += " and InsertTime<'" + Convert.ToDateTime(etime).Date.AddDays(1) + "'";
            }
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT *  FROM  [QPGameLogDB].[dbo].[PlayerConsumeStatistics] where AgentID={0} {1}", agentid, where);
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "id DESC", null);
        }
        #endregion
    }
}
