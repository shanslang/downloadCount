﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Game.Francis;
using Game.IData;
using System.Data.Common;
using System.Data.SqlClient;
using Game.Entity.Task;

using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Game.Data
{
    public class TaskDataProvider : DBHelper, ITaskDataProvider
    {
        #region 构造函数
        public TaskDataProvider(string dbname)
            : base(dbname)
        {

        }
        #endregion

        #region 旧版
        /// <summary>
        /// 获取未领取或未完成的任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="serverid"></param>
        /// <param name="gameid"></param>
        /// <returns></returns>
        public DataSet GetTaskInfo(int userid, int serverid)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("UserID", userid));
            parms.Add(MakeInParam("ServerID", serverid));
            return this.ExecProcForDataSet("proc_GetUserTaskList", parms);
        }

        /// <summary>
        /// 获取已经完成的任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="serverid"></param>
        /// <param name="gameid"></param>
        /// <returns></returns>
        public DataSet GetTaskInfoed(int userid, int serverid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append(@"select a.*,b.TaskName,b.TaskDescribe from QPGameLogDB.dbo.UserTaskHistory as a
left join dbo.TaskInfo as b on a.TaskID=b.TaskID where a.UserID=").Append(userid);
            //if (serverid > 0)
            //{
            //    sbSql.AppendFormat(" and b.ServerID={0}", serverid);
            //}
            sbSql.Append("order by InsertTime DESC");
            return this.ExecSqlForDataSet(sbSql.ToString());
        }

        /// <summary>
        /// 获取任务奖励详细信息
        /// </summary>
        /// <param name="taskid">任务ID</param>
        /// <param name="sumtaskid">阶段ＩＤ</param>
        /// <returns></returns>
        public IList<TaskRewardCfg> GetTaskRewardList(int taskid, int subtaskid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"select * from TaskRewardCfg where TaskID={0} and subTaskID={1}", taskid, subtaskid);
            return this.ExecSqlForObjectList<TaskRewardCfg>(sbSql.ToString());
        }

        /// <summary>
        /// 领取任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public Message ReceiveTask(int userid, int taskid)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("UserID", userid));
            parms.Add(MakeInParam("TaskID", taskid));
            return this.ExecProcForMessage("proc_UserGetTask", parms);
        }

        /// <summary>
        /// 放弃任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public int GiveupTask(int userid, int taskid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"delete UserActivedTask where UserID={0} and TaskID={1}", userid, taskid);
            return this.ExecSqlNonQuery(sbSql.ToString());
        }

        /// <summary>
        /// 获取任务领取条件
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public DataSet GetTaskReceiveCondition(int userid, int taskid)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("UserID", userid));
            parms.Add(MakeInParam("TaskID", taskid));
            parms.Add(MakeInParam("IsOutPut", 1));
            return this.ExecProcForDataSet("proc_CheckUserCondition", parms);
        }
        /// <summary>
        /// 获取用户任务及阶段信息
        /// </summary>
        /// <param name="TaskID"></param>
        /// <returns></returns>
        public DataSet GetTaskTargetList(string TaskIDList, int Userid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT tar.*,t.*,act.LastValue,Icon.IconID,ISNULL(Icon.IconName,'') AS IconName,ISNULL(IconUrl,'') AS IconUrl,ISNULL(IconMd5,'') AS IconMd5
                            FROM [QPTaskDB].[dbo].TaskTarget(NOLOCK) as tar
                            inner join [QPTaskDB].[dbo].TaskInfo(NOLOCK) as t
                            on tar.TaskID=t.TaskID
                            inner join UserActivedTask(NOLOCK) as act
                            on act.TargetID=tar.TargetID
                            left join QPMobileAppDB.dbo.AppIcon(NOLOCK) AS Icon
                            on Icon.IconID=t.IconID");
            sbCache.Append(string.Format(" where UserID={0} and t.taskid in ({1})", Userid, TaskIDList));

            return ExecSqlForDataSet(sbCache.ToString());
        }
        /// <summary>
        ///获取任务奖励信息
        /// </summary>
        /// <param name="TaskID"></param>
        /// <returns></returns>
        public IList<TaskRewardCfg> GetTaskReward(int TaskID, int subID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(string.Format("select * from TaskRewardCfg(NOLOCK) where TaskID={0} and subTaskID={1}", TaskID, subID));
            return ExecSqlForObjectList<TaskRewardCfg>(sbCache.ToString());
        }
        /// <summary>
        /// 发放任务奖励
        /// </summary>
        /// <param name="TaskID"></param>
        /// <param name="ServerID"></param>
        /// <param name="subTaskID"></param>
        /// <returns></returns>
        public DataSet TaskReceiveReward(int TaskID, int ServerID, int subTaskID, int Userid)
        {
            var param = new List<DbParameter>();
            param.Add(MakeInParam("UserID", Userid));
            param.Add(MakeInParam("ServerID", ServerID));
            param.Add(MakeInParam("TaskID", TaskID));
            param.Add(MakeInParam("subTaskID", subTaskID));
            return ExecProcForDataSet("proc_TaskReward", param);
        }
        #endregion

        #region 新版
        /// <summary>
        /// 
        /// </summary>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public NTaskInfo GetNTaskInfoByTaskIDForPlatform(int taskid)
        {
            NTaskInfo oNTaskInfo = this.GetNTaskInfoByTaskID(taskid);
            if (oNTaskInfo != null)
            {
                var listNTaskReward = this.GetNTaskRewardList(taskid);
                if (listNTaskReward != null)
                {
                    oNTaskInfo.ListNTaskReward = listNTaskReward;
                }
            }
            return oNTaskInfo;
        }
        public NTaskInfo GetNTaskInfoByTaskIDForMobile(int taskid)
        {
            NTaskInfo oNTaskInfo = this.GetNTaskInfoByTaskID(taskid);
            if (oNTaskInfo != null)
            {
                var listNTaskReward = this.GetNTaskRewardListMobile(taskid);
                if (listNTaskReward != null)
                {
                    oNTaskInfo.ListNTaskReward = listNTaskReward;
                }
            }
            return oNTaskInfo;
        }

        /// <summary>
        /// 获取任务对象
        /// </summary>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public NTaskInfo GetNTaskInfoByTaskID(int taskid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"select * from NTaskInfo where TaskId={0}", taskid);
            return this.ExecSqlForObject<NTaskInfo>(sbSql.ToString());
        }
        /// <summary>
        /// 获取任务奖励
        /// </summary>
        /// <returns></returns>
        public IList<NTaskReward> GetNTaskRewardList(int taskid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"select TaskID,case when RewardType>65536 then  (b.TaskImg+65536) else RewardType end as RewardType,RewardValue,RewardRate,case when a.RewardType=1 then '高富帅的象征，多多益善。' when a.RewardType=3 then '集齐一定数量可兑换话费、手机等实物。' else b.Explain end as Explain,case when a.RewardType=1 then '金币' when a.RewardType=3 then '奖牌' else b.Name end as Name from  [QPTaskDB].[dbo].NTaskReward as a left join  [QPGamePropertyDB].[dbo].[PropertyCFG] as b on a.RewardType-65536=b.Pid  where TaskId={0}", taskid);
            return this.ExecSqlForObjectList<NTaskReward>(sbSql.ToString());
        }
        /// <summary>
        /// 获取任务奖励(手机端)
        /// </summary>
        /// <returns></returns>
        public IList<NTaskReward> GetNTaskRewardListMobile(int taskid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"select a.*,case when a.RewardType=1 then '高富帅的象征，多多益善。' when a.RewardType=3 then '集齐一定数量可兑换话费、手机等实物。' else b.Explain end as Explain,case when a.RewardType=1 then '金币' when a.RewardType=3 then '奖牌' else b.Name end as Name from  [QPTaskDB].[dbo].NTaskReward  as a left join  [QPGamePropertyDB].[dbo].[PropertyCFG] as b on a.RewardType-65536=b.Pid where TaskId={0}", taskid);
            return this.ExecSqlForObjectList<NTaskReward>(sbSql.ToString());
        }
        /// <summary>
        /// 获取任务分组
        /// </summary>
        /// <returns></returns>
        public IList<NTaskGroupInfo> GetNTaskGroupInfoList()
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"select * from NTaskGroupInfo");
            return this.ExecSqlForObjectList<NTaskGroupInfo>(sbSql.ToString());
        }

        /// <summary>
        ///获取全部任务信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        public IList<NTaskInfo> GetTaskList(int kindID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select * from NTaskInfo where TaskGame=0 or TaskGame={0}", kindID);
            return ExecSqlForObjectList<NTaskInfo>(sbCache.ToString());
        }
        #endregion
        /// <summary>
        /// 获取宝箱数据
        /// </summary>
        /// <returns></returns>
        public DataSet GetChestsReward()
        {        
             StringBuilder sbSql = new StringBuilder();
             sbSql.Append("SELECT ServerID,[RewardType],[RewardValue] FROM [QPTaskDB].[dbo].[GTRewardCFG] as a left join [QPTaskDB].[dbo].[GTServerCFG] as b on a.TID=b.TID ");
            return this.ExecSqlForDataSet(sbSql.ToString());
        }



    }
}
