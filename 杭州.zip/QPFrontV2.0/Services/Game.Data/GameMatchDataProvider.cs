﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.GameMatch;

namespace Game.Data
{
    public class GameMatchDataProvider : DBHelper, IGameMatchProvider
    {
        #region 构造方法

        public GameMatchDataProvider(string connString)
            : base(connString)
        {

        }

        #endregion

        /// <summary>
        /// 根据sql语句获取数据
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        public DataSet GetDataSetByWhere(string sqlQuery)
        {
            return ExecSqlForDataSet(sqlQuery);
        }

        /// <summary>
        /// 根据sql获取实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public T GetEntity<T>(string commandText, List<DbParameter> parms)
        {
            return ExecSqlForObject<T>(commandText, parms);
        }

        /// <summary>
        /// 根据sql获取实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public T GetEntity<T>(string commandText)
        {
            return ExecSqlForObject<T>(commandText);
        }

        /// <summary>
        /// 获取比赛排名表
        /// </summary>
        /// <returns></returns>
        public IList<StreamMatchHistory> GetStreamMatchHistoryList(int matchid, int matchno)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("select a.*,b.NickName from StreamMatchHistory as a left join QPAccountsDB.dbo.AccountsInfo as b on a.UserID=b.UserID");
            sbCache.AppendFormat(" WHERE a.MatchID={0} AND a.MatchNO={1}", matchid, matchno);
            sbCache.Append(" order by a.Rank ASC");
            return ExecSqlForObjectList<StreamMatchHistory>(sbCache.ToString());
        }
    }
}
