﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.GameScore;

namespace Game.Data
{
    public class GameScoreDataProvider : DBHelper, IGameScoreDataProvider
    {
        #region 构造方法
        public GameScoreDataProvider(string connString)
            : base( connString )
        {

        }
        #endregion

        /// <summary>
        /// 获取游戏道具列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetGamePropertyList(int pageIndex, int pageSize)
        {
            string sqlQuery = "select [ID],[Name],Cash,Gold,Discount,IssueArea,ServiceArea,SendLoveLiness,RecvLoveLiness,RegulationsInfo,Nullity from GameProperty WHERE Nullity=0";
            return GetPagination(pageIndex, pageSize, sqlQuery, null, "[ID] DESC", null);
        }
    }
}
