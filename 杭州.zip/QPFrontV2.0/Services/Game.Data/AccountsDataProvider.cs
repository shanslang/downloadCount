﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.Accounts;
using Game.Utils;

namespace Game.Data
{
    /// <summary>
    /// 用户数据访问层
    /// </summary>
    public class AccountsDataProvider : DBHelper, IAccountsDataProvider
    {
        #region 构造方法
        public AccountsDataProvider(string dbname)
            : base(dbname)
        {

        }
        #endregion

        #region 用户登录、注册、认证

        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="names">用户信息</param>
        /// <returns></returns>
        public Message Login(UserInfo user)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("strAccounts", user.Accounts));
            prams.Add(MakeInParam("strPassword", user.LogonPass));
            prams.Add(MakeInParam("strClientIP", user.LastLogonIP));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageObject<UserInfo>("NET_PW_EfficacyAccounts", prams);
        }

        /// <summary>
        /// 用户注册
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public Message Register(UserInfo user, string parentAccount, int pceggid, string pceggadid)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("strSpreader", parentAccount));
            prams.Add(MakeInParam("strAccounts", user.Accounts));
            prams.Add(MakeInParam("strNickname", user.NickName));
            prams.Add(MakeInParam("strLogonPass", user.LogonPass));
            prams.Add(MakeInParam("strInsurePass", user.InsurePass));
            prams.Add(MakeInParam("strCompellation", user.Compellation));
            prams.Add(MakeInParam("strPassPortID", user.PassPortID));
            prams.Add(MakeInParam("dwFaceID", user.FaceID));
            prams.Add(MakeInParam("dwGender", user.Gender));
            prams.Add(MakeInParam("strClientIP", user.RegisterIP));
            prams.Add(MakeInParam("strAdID", user.AdID));
            prams.Add(MakeInParam("strPCEggsPCID", pceggid));//pc蛋蛋ID
            prams.Add(MakeInParam("strPCEggsADID", pceggadid));//pc蛋蛋ADID
            prams.Add(MakeInParam("RegDeviceType", user.RegDeviceType));
            prams.Add(MakeInParam("RegKindID", user.RegKindID));
            prams.Add(MakeInParam("Regmark", user.Regmark));
            prams.Add(MakeInParam("externalMsg", user.ExternalMsg));
            prams.Add(MakeInParam("RealName", user.RealName ?? ""));
            prams.Add(MakeInParam("IdentityCard", user.IdentityCard ?? ""));
            prams.Add(MakeInParam("WeiXinName", user.WeiXinName ?? ""));
            prams.Add(MakeInParam("RegisterMachine", user.RegisterMachine));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PW_RegisterAccounts1", prams);
        }
        public Message Register(string openid, string machineid, int platformid, string devicemodel, string nickname,string unionid)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("strOpenID", openid));
            prams.Add(MakeInParam("PlatformID", platformid));
            prams.Add(MakeInParam("strClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeInParam("strMachineID", machineid));
            prams.Add(MakeInParam("strDeviceModel", devicemodel));
            prams.Add(MakeInParam("strWXNickName", nickname));
            prams.Add(MakeInParam("strWXFaceUrl", ""));
            prams.Add(MakeInParam("strunionid", unionid));
            return ExecProcForMessageDataSet("NET_PW_EfficacyWXAccounts2_2", prams);
        }
        /// <summary>
        /// 判断用户名是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        public Message IsAccountsExist(string accounts)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("strAccounts", accounts));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PW_IsAccountsExists", prams);
        }

        /// <summary>
        /// 判断昵称是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        public bool IsNickNameExist(string nickName)
        {
            string sqlQuery = "SELECT NickName, UserID FROM AccountsInfo(NOLOCK) WHERE NickName=@NickName";
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("NickName", nickName));
            UserInfo user = ExecSqlForObject<UserInfo>(sqlQuery, prams);
            if (user != null)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 判断认证手机是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        public bool IsAuthTelephoneExist(string telephone)
        {
            //查询手机是否认证过
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT count(*) FROM AccountsInfo WHERE AuthMTelephone=@AuthMTelephone");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("AuthMTelephone", telephone));
            int count = Convert.ToInt32(ExecSqlScalar(sbCache.ToString(), prams));
            return (count > 0);
        }
        /// <summary>
        /// 判断认证手机或用户名是否存在手机号
        /// </summary>
        /// <param name="telephone"></param>
        /// <returns></returns>
        public int IsAuthTelephoneOrRegisterAccounts(string telephone)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT top 1 userID,Compellation FROM AccountsInfo WHERE AuthMTelephone=@AuthMTelephone or Accounts=@AuthMTelephone");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("AuthMTelephone", telephone));
            var dataset = ExecSqlForDataSet(sbCache.ToString(), prams);
            if (dataset != null && dataset.Tables.Count > 0)
            {
                if (dataset.Tables[0].Rows.Count > 0)
                {
                    if (string.IsNullOrEmpty(dataset.Tables[0].Rows[0]["Compellation"].ToString()))
                    {
                        return 1;//官网注册
                    }
                    else
                    {
                        return 2;//渠道用户注册
                    }
                }
                return 0;//没有记录
            }
            else
            {
                return 0;//没有记录
            }
        }
        /// <summary>
        /// 判断认证电子邮件是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        public bool IsAuthEmailExist(string email)
        {
            //查询邮箱是否认证过
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT count(*) FROM AccountsInfo WHERE AuthEmail=@AuthEmail");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("AuthEmail", email));
            int count = Convert.ToInt32(ExecSqlScalar(sbCache.ToString(), prams));
            return (count > 0);
        }
        /// <summary>
        /// 用户MAC与账号关联
        /// </summary>
        public void UserMacthineInsert(int UserID, string Mac)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("INSERT INTO UserMachine(UserID,MacAddress) VALUES(@UserID,@Mac)");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", UserID));
            prams.Add(MakeInParam("Mac", Mac));
            ExecSqlNonQuery(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 根据MAC地址查询用户信息
        /// </summary>
        /// <param name="mac"></param>
        /// <returns></returns>
        public int UserMachineInfoGet(string mac, int Regmark, int kindID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT top 1 ISNULL(a.UserID,0) FROM UserMachine(NOLOCK) as a,AccountsInfo as b WHERE a.UserID=b.UserID and MacAddress=@mac and Regmark=@Regmark and RegKindID=@kindID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("mac", mac));
            prams.Add(MakeInParam("Regmark", Regmark));
            prams.Add(MakeInParam("kindID", kindID));
            return Game.Utils.Utility.StrToInt(ExecSqlScalar(sbCache.ToString(), prams), 0);

        }
        /// <summary>
        /// 根据百度ID查找用户
        /// </summary>
        /// <param name="accessToken"></param>
        /// <returns></returns>
        public int BaiduInfoGet(long baiduUID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT ISNULL(UserID,0) FROM UserBaidu(NOLOCK) WHERE BaiduUID=@baiduUID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("baiduUID", baiduUID));
            return Game.Utils.Utility.StrToInt(ExecSqlScalar(sbCache.ToString(), prams), 0);

        }
        /// <summary>
        /// 百度账号关联
        /// </summary>
        public void BaiduUserInsert(int UserID, long baiduUID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("INSERT INTO [QPAccountsDB].[dbo].UserBaidu(UserID,BaiduUID) VALUES(@UserID,@BaiduUID)");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", UserID));
            prams.Add(MakeInParam("BaiduUID", baiduUID));
            ExecSqlNonQuery(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 根据互联星空账号查询用户信息
        /// </summary>
        /// <param name="mac"></param>
        /// <returns></returns>
        public int VnetInfoGet(string vnetID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT ISNULL(UserID,0) FROM [QPAccountsDB].[dbo].UserVnet(NOLOCK) WHERE VnetID=@VnetID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("VnetID", vnetID));
            return Game.Utils.Utility.StrToInt(ExecSqlScalar(sbCache.ToString(), prams), 0);
        }
        /// <summary>
        /// 互联星空账号关联
        /// </summary>
        public void VnetUserInsert(int UserID, string vnetID, string Tel, string imsi)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("INSERT INTO [QPAccountsDB].[dbo].UserVnet(UserID,vnetID,Tel,imsi) VALUES(@UserID,@vnetID,@Tel,@imsi)");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", UserID));
            prams.Add(MakeInParam("vnetID", vnetID));
            prams.Add(MakeInParam("Tel", Tel));
            prams.Add(MakeInParam("imsi", imsi));
            ExecSqlNonQuery(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 获取互联星空账号信息
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public VnetEntity VnetInfoGet(int UserID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT top 1 * FROM [QPAccountsDB].[dbo].UserVnet(NOLOCK) WHERE UserID=@UserID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", UserID));
            return ExecSqlForObject<VnetEntity>(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 根据AnySDK查询用户信息
        /// </summary>
        public int AnySDKInfoGet(string uID, string channel)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT ISNULL(UserID,0) FROM AnySDKUSer(NOLOCK) WHERE UID=@UID and Channel=@Channel");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UID", uID));
            prams.Add(MakeInParam("Channel", channel));
            return Game.Utils.Utility.StrToInt(ExecSqlScalar(sbCache.ToString(), prams), 0);
        }
        /// <summary>
        /// AnySDK账号关联
        /// </summary>
        public void AnySDKUserInsert(int UserID, string Channel, string UserSdk, string UID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("INSERT INTO [QPAccountsDB].[dbo].AnySDKUSer(UserID,Channel,UserSdk,UID) VALUES(@UserID,@Channel,@UserSdk,@UID)");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", UserID));
            prams.Add(MakeInParam("Channel", Channel));
            prams.Add(MakeInParam("UserSdk", UserSdk));
            prams.Add(MakeInParam("UID", UID));
            ExecSqlNonQuery(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 根据微信获取用户帐号
        /// </summary>
        /// <param name="OpenID"></param>
        /// <returns></returns>
        public int WeiXinUserGet(string OpenID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT ISNULL(UserID,0) FROM [QPAccountsDB].[dbo].[UserWeiXin](NOLOCK) WHERE OpenID=@OpenID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("OpenID", OpenID));
            return Game.Utils.Utility.StrToInt(ExecSqlScalar(sbCache.ToString(), prams), 0);
        }
        /// <summary>
        /// 根据微信获取用户信息
        /// </summary>
        public Message WeiXinUserInfoGet(string OpenID, string unionID)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramopenID", OpenID));
            prams.Add(MakeInParam("paramunionID", unionID));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("proc_GetUserByWeiXinID", prams);
        }
        /// <summary>
        /// 查询是否绑定
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public bool IsBindWeixin(int userId)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT WeiXinName FROM [QPAccountsDB].[dbo].[AccountsInfo](NOLOCK) WHERE userid=@userid");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("userid", userId));
            return ExecSqlScalar(sbCache.ToString(), prams).ToString().Length > 0;
        }
        /// <summary>
        /// 微信公众平台关注
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="OpenID"></param>
        public void WeiXinUserInsert(int UserID, string openid, string unionID, string headurl)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("UserID", UserID));
            parms.Add(MakeInParam("OpenID", openid));
            parms.Add(MakeInParam("unionID", unionID));
            parms.Add(MakeInParam("headurl", headurl));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            ExecProcForMessage("NET_PW_BindWeiXin", parms);
        }
        #endregion

        #region 获取用户信息

        /// <summary>
        /// 根据用户昵称获取用户ID
        /// </summary>
        /// <param name="nickName"></param>
        /// <returns></returns>
        public int GetUserIDByNickName(string nickName)
        {
            string sqlQuery = string.Format("SELECT NickName, UserID FROM AccountsInfo(NOLOCK) WHERE NickName='{0}'", nickName);
            UserInfo user = ExecSqlForObject<UserInfo>(sqlQuery);
            return user == null ? 0 : user.UserID;
        }

        /// <summary>
        /// 获取基本用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserBaseInfoByUserID(int userID)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwUserID", userID));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForObject<UserInfo>("NET_PW_GetUserBaseInfo", prams);
        }

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserFullInfoByUserID(int userID)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwUserID", userID));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForObject<UserInfo>("NET_PW_GetFullBaseInfo", prams);
        }

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserFullInfoByAccounts(string accounts)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT top 1 * FROM AccountsInfo(NOLOCK) WHERE Accounts=@Accounts");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("Accounts", accounts));
            return ExecSqlForObject<UserInfo>(sbCache.ToString(), prams);
        }

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserFullInfoByGameID(int gameid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT top 1 * FROM AccountsInfo(NOLOCK) WHERE GameID>0 and GameID=@GameID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("GameID", gameid));
            return ExecSqlForObject<UserInfo>(sbCache.ToString(), prams);
        }

        /// <summary>
        /// 获取用户基本信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserInfoByUserID(int UserID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT top 1 * FROM AccountsInfo(NOLOCK) WHERE UserID=@UserID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", UserID));
            return ExecSqlForObject<UserInfo>(sbCache.ToString(), prams);
        }

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserFullInfoByAccountsOrGameID(string accountsorid)
        {
            accountsorid = Game.Library.Filter.FilterSQL(accountsorid);
            StringBuilder sbCache = new StringBuilder();
            List<DbParameter> prams = new List<DbParameter>();
            sbCache.Append("SELECT top 1 * FROM AccountsInfo(NOLOCK) WHERE Accounts=@Accounts");
            prams.Add(MakeInParam("Accounts", accountsorid));
            if (Game.Library.Utility.IsInteger(accountsorid))
            {
                if (Convert.ToInt64(accountsorid) < int.MaxValue)
                {
                    sbCache.Append(" OR GameID=@GameID");
                    prams.Add(MakeInParam("GameID", accountsorid));
                }
            }
            return ExecSqlForObject<UserInfo>(sbCache.ToString(), prams);
        }

        /// <summary>
        /// 获取用户配置信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public AccountsConfig GetAccountsConfigByUserID(int userid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT top 1 * FROM AccountsConfig(NOLOCK) WHERE UserID=@UserID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", userid));
            return ExecSqlForObject<AccountsConfig>(sbCache.ToString(), prams);
        }

        /// <summary>
        /// 获取指定用户联系信息
        /// </summary>
        /// <param name="user">用户</param>
        /// <returns></returns> 		
        public IndividualDatum GetUserContactInfoByUserID(int userID)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForObject<IndividualDatum>("NET_PW_GetUserContactInfo", parms);
        }

        /// <summary>
        /// 获取用户全局信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="gameID"></param>
        /// <param name="Accounts"></param>
        /// <returns></returns>
        public Message GetUserGlobalInfo(int userID, int gameID, String Accounts)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));
            parms.Add(MakeInParam("dwGameID", gameID));
            parms.Add(MakeInParam("strAccounts", Accounts));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageObject<UserInfo>("NET_PW_GetUserGlobalsInfo", parms);
        }

        /// <summary>
        /// 获取用户头像信息 返回图片对象
        /// </summary>
        /// <param name="faceid"></param>
        /// <returns></returns>
        public AccountsFace GetUserFaceByFaceID(int faceid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT * FROM AccountsFace WHERE [ID]=").Append(faceid);
            return ExecSqlForObject<AccountsFace>(sbCache.ToString(), null);
        }

        /// <summary>
        /// 获取用户头像信息 返回图片对象
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="faceid"></param>
        /// <returns></returns>
        public AccountsFace GetUserFaceByFaceID(int userid, int faceid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT * FROM AccountsFace WHERE UserID={0} AND [ID]={1}", userid, faceid);
            return ExecSqlForObject<AccountsFace>(sbCache.ToString(), null);
        }

        /// <summary>
        /// 获取密保卡序列号
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <returns></returns>
        public string GetPasswordCardByUserID(int userId)
        {
            string sqlQuery = string.Format("SELECT PasswordID FROM AccountsInfo(NOLOCK) WHERE UserID={0}", userId);
            object result = ExecSqlScalar(sqlQuery);
            if (result != null) return result.ToString();
            return null;
        }
        /// <summary>
        /// 通过手机号获取用户ID
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        public int GetUserIDByPhone(string phone)
        {
            string sqlQuery = string.Format("SELECT top 1 UserID FROM AccountsInfo(NOLOCK) WHERE AuthMTelephone=@phone or Accounts=@phone", phone);
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("phone", phone));
            object result = ExecSqlScalar(sqlQuery, prams);
            if (result != null) return Convert.ToInt32(result);
            return 0;
        }
        #endregion

        #region	 密码管理

        /// <summary>
        /// 重置登录密码
        /// </summary>
        /// <param name="sInfo">密保信息</param>       
        /// <returns></returns>
        public Message ResetLogonPasswd(AccountsProtect sInfo)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", sInfo.UserID));
            parms.Add(MakeInParam("strPassword", sInfo.LogonPass));
            parms.Add(MakeInParam("strResponse1", sInfo.Response1));
            parms.Add(MakeInParam("strResponse2", sInfo.Response2));
            parms.Add(MakeInParam("strResponse3", sInfo.Response3));
            parms.Add(MakeInParam("strClientIP", sInfo.LastLogonIP));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PW_ResetLogonPasswd", parms);
        }

        /// <summary>
        /// 重置银行密码
        /// </summary>
        /// <param name="sInfo">密保信息</param>       
        /// <returns></returns>
        public Message ResetInsurePasswd(AccountsProtect sInfo)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", sInfo.UserID));
            parms.Add(MakeInParam("strInsurePass", sInfo.InsurePass));
            parms.Add(MakeInParam("strResponse1", sInfo.Response1));
            parms.Add(MakeInParam("strResponse2", sInfo.Response2));
            parms.Add(MakeInParam("strResponse3", sInfo.Response3));
            parms.Add(MakeInParam("strClientIP", sInfo.LastLogonIP));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PW_ResetInsurePasswd", parms);
        }

        /// <summary>
        /// 修改登录密码
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="srcPassword">旧密码</param>
        /// <param name="dstPassword">新密码</param>
        /// <param name="ip">连接地址</param>
        /// <returns></returns>
        public Message ModifyLogonPasswd(int userID, string srcPassword, string dstPassword, string ip)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));
            parms.Add(MakeInParam("strSrcPassword", srcPassword));
            parms.Add(MakeInParam("strDesPassword", dstPassword));
            parms.Add(MakeInParam("strClientIP", ip));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PW_ModifyLogonPass", parms);
        }

        /// <summary>
        /// 修改银行密码
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="srcPassword">旧密码</param>
        /// <param name="dstPassword">新密码</param>
        /// <param name="ip">连接地址</param>
        /// <returns></returns>
        public Message ModifyInsurePasswd(int userID, string srcPassword, string dstPassword, string ip)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));
            parms.Add(MakeInParam("strSrcPassword", srcPassword));
            parms.Add(MakeInParam("strDesPassword", dstPassword));
            parms.Add(MakeInParam("strClientIP", ip));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PW_ModifyInsurePass", parms);
        }

        /// <summary>
        /// 编辑登录密码 自带加密
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="dstPassword">新密码</param>
        /// <param name="ip">连接地址</param>
        /// <returns></returns>
        public Message EditLogonPasswd(int userID, string dstPassword, string ip)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));
            parms.Add(MakeInParam("strDesPassword", dstPassword));
            parms.Add(MakeInParam("strClientIP", ip));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PW_EditLogonPass", parms);
        }

        /// <summary>
        /// 编辑银行密码 自带加密
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="dstPassword">新密码</param>
        /// <param name="ip">连接地址</param>
        /// <returns></returns>
        public Message EditInsurePasswd(int userID, string dstPassword, string ip)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));
            parms.Add(MakeInParam("strDesPassword", dstPassword));
            parms.Add(MakeInParam("strClientIP", ip));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PW_EditInsurePass", parms);
        }

        #endregion

        #region  密码保护管理

        /// <summary>
        /// 申请帐号保护
        /// </summary>
        /// <param name="sInfo">密保信息</param>
        /// <returns></returns>
        public Message ApplyUserSecurity(AccountsProtect sInfo)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", sInfo.UserID));

            parms.Add(MakeInParam("strQuestion1", sInfo.Question1));
            parms.Add(MakeInParam("strResponse1", sInfo.Response1));
            parms.Add(MakeInParam("strQuestion2", sInfo.Question2));
            parms.Add(MakeInParam("strResponse2", sInfo.Response2));
            parms.Add(MakeInParam("strQuestion3", sInfo.Question3));
            parms.Add(MakeInParam("strResponse3", sInfo.Response3));

            parms.Add(MakeInParam("dwPassportType", (byte)sInfo.PassportType));
            parms.Add(MakeInParam("strPassportID", sInfo.PassportID));
            parms.Add(MakeInParam("strSafeEmail", sInfo.SafeEmail));

            parms.Add(MakeInParam("strClientIP", sInfo.CreateIP));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_AddAccountProtect", parms);
        }

        /// <summary>
        /// 修改帐号保护
        /// </summary>
        /// <param name="oldInfo">旧密保信息</param>
        /// <param name="newInfo">新密保信息</param>
        /// <returns></returns>
        public Message ModifyUserSecurity(AccountsProtect newInfo)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", newInfo.UserID));

            parms.Add(MakeInParam("strQuestion1", newInfo.Question1));
            parms.Add(MakeInParam("strResponse1", newInfo.Response1));
            parms.Add(MakeInParam("strQuestion2", newInfo.Question2));
            parms.Add(MakeInParam("strResponse2", newInfo.Response2));
            parms.Add(MakeInParam("strQuestion3", newInfo.Question3));
            parms.Add(MakeInParam("strResponse3", newInfo.Response3));

            parms.Add(MakeInParam("strSafeEmail", newInfo.SafeEmail));

            parms.Add(MakeInParam("strClientIP", newInfo.ModifyIP));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_ModifyAccountProtect", parms);
        }

        /// <summary>
        /// 获取密保信息 (userID)
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Message GetUserSecurityByUserID(int userID)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageObject<AccountsProtect>("NET_PW_GetAccountProtectByUserID", parms);
        }

        /// <summary>
        /// 获取密保信息 (gameID)
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Message GetUserSecurityByGameID(int gameID)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwGameID", gameID));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageObject<AccountsProtect>("NET_PW_GetAccountProtectByGameID", parms);
        }

        /// <summary>
        /// 获取密保信息 (Accounts)
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Message GetUserSecurityByAccounts(string accounts)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("strAccounts", accounts));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageObject<AccountsProtect>("NET_PW_GetAccountProtectByAccounts", parms);
        }

        /// <summary>
        /// 密保确认
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public Message ConfirmUserSecurity(AccountsProtect info)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", info.UserID));
            parms.Add(MakeInParam("strResponse1", info.Response1));
            parms.Add(MakeInParam("strResponse2", info.Response2));
            parms.Add(MakeInParam("strResponse3", info.Response3));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PW_ConfirmAccountProtect", parms);
        }

        #endregion

        #region 安全管理

        #region 固定机器

        /// <summary>
        /// 申请机器绑定
        /// </summary>
        /// <param name="sInfo">密保信息</param>
        /// <returns></returns>
        public Message ApplyUserMoorMachine(AccountsProtect sInfo)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", sInfo.UserID));

            parms.Add(MakeInParam("strResponse1", sInfo.Response1));
            parms.Add(MakeInParam("strResponse2", sInfo.Response2));
            parms.Add(MakeInParam("strResponse3", sInfo.Response3));

            parms.Add(MakeInParam("strClientIP", sInfo.LastLogonIP));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_ApplyMoorMachine", parms);
        }

        /// <summary>
        /// 解除机器绑定
        /// </summary>
        /// <param name="sInfo">密保信息</param>
        /// <returns></returns>
        public Message RescindUserMoorMachine(AccountsProtect sInfo)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", sInfo.UserID));

            parms.Add(MakeInParam("strResponse1", sInfo.Response1));
            parms.Add(MakeInParam("strResponse2", sInfo.Response2));
            parms.Add(MakeInParam("strResponse3", sInfo.Response3));

            parms.Add(MakeInParam("strClientIP", sInfo.LastLogonIP));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_CancelMoorMachine", parms);
        }

        #endregion 固定机器结束

        #endregion

        #region 资料管理

        /// <summary>
        /// 更新个人资料
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public Message ModifyUserIndividual(IndividualDatum user)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", user.UserID));

            parms.Add(MakeInParam("dwGender", (byte)user.Gender));
            parms.Add(MakeInParam("strUnderWrite", user.UnderWrite));

            parms.Add(MakeInParam("strCompellation", user.Compellation));
            parms.Add(MakeInParam("strQQ", user.QQ));
            parms.Add(MakeInParam("strEmail", user.EMail));
            parms.Add(MakeInParam("strSeatPhone", user.SeatPhone));
            parms.Add(MakeInParam("strMobilePhone", user.MobilePhone));
            parms.Add(MakeInParam("strDwellingPlace", user.DwellingPlace));
            parms.Add(MakeInParam("strUserNote", user.UserNote));
            parms.Add(MakeInParam("strIsShowRanking", user.IsShowRanking));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_ModifyUserInfo", parms);
        }

        /// <summary>
        /// 更新用户头像
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="faceID"></param>
        /// <returns></returns>
        public Message ModifyUserFace(int userID, int faceID)
        {
            List<DbParameter> prams = new List<DbParameter>();

            prams.Add(MakeInParam("dwUserID", userID));
            prams.Add(MakeInParam("dwFaceID", faceID));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_ModifyUserFace", prams);
        }

        /// <summary>
        /// 更新用户昵称
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="faceID"></param>
        /// <returns></returns>
        public Message ModifyUserNickname(int userID, string nickName, string ip)
        {
            List<DbParameter> prams = new List<DbParameter>();

            prams.Add(MakeInParam("dwUserID", userID));
            prams.Add(MakeInParam("strNickName", nickName));
            prams.Add(MakeInParam("clientIP", ip));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_ModifyUserNickName", prams);
        }
        /// <summary>
        /// 更新微信信息
        /// </summary>
        public bool UpdateWeiXinInfo(int userId, string weixinName, int sex)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("userId", userId));
            prams.Add(MakeInParam("weixinName", weixinName));
            prams.Add(MakeInParam("sex", sex));
            string sqlQuery = "UPDATE AccountsInfo SET WeiXinName=@weixinName, Gender=@sex WHERE UserID=@userId";
            int result = ExecSqlNonQuery(sqlQuery, prams);
            if (result > 0)
            {
                return true;
            }
            return false;
        }

        #endregion

        #region 魅力

        public Message UserConvertPresent(int userID, int present, int rate, string ip)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));
            parms.Add(MakeInParam("dwPresent", present));
            parms.Add(MakeInParam("dwConvertRate", rate));
            parms.Add(MakeInParam("strClientIP", ip));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessageDataSet("NET_PW_ConvertPresent", parms);
        }

        /// <summary>
        /// 根据用户魅力排名(前10名)
        /// </summary>
        /// <returns></returns>
        public IList<UserInfo> GetUserInfoOrderByLoves()
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT TOP 10 Accounts, NickName,GameID, LoveLiness, Present ")
                    .Append("FROM AccountsInfo ")
                    .Append("WHERE Nullity=0 ")
                    .Append(" ORDER By LoveLiness DESC,UserID ASC");
            return ExecSqlForObjectList<UserInfo>(sqlQuery.ToString());
        }

        /// <summary>
        /// 排行榜
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public DataSet GetLovesRanking(int num)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.AppendFormat("select top {0} a.*,b.Accounts,b.NickName,b.GameID,b.Present from QPTreasureDB.dbo.GameScoreInfoEx as a left join AccountsInfo as b on a.UserID=b.UserID", num)
                    .Append(" WHERE b.Nullity=0 ")
                    .Append(" ORDER By a.LoveLiness DESC,a.UserID ASC");
            return ExecSqlForDataSet(sqlQuery.ToString());
        }

        #endregion

        #region 奖牌兑换

        public Message UserConvertMedal(int userID, int medals, int rate, string ip)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));
            parms.Add(MakeInParam("dwMedals", medals));
            parms.Add(MakeInParam("dwConvertRate", rate));
            parms.Add(MakeInParam("strClientIP", ip));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_ConvertMedal", parms);
        }

        #endregion

        #region 电子密保卡

        /// <summary>
        /// 检测密保卡序列号是否存在
        /// </summary>
        /// <param name="serialNumber">密保卡序列号</param>
        /// <returns></returns>
        public bool PasswordIDIsEnable(string serialNumber)
        {
            string sqlQuery = string.Format("SELECT UserID FROM AccountsInfo(NOLOCK) WHERE PasswordID='{0}'", serialNumber);
            AccountsInfo user = ExecSqlForObject<AccountsInfo>(sqlQuery, null);
            if (user == null)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// 检测用户是否绑定了密保卡
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <param name="serialNumber">密保卡序列号</param>
        /// <returns></returns>
        public bool userIsBindPasswordCard(int userId)
        {
            string sqlQuery = string.Format("SELECT UserID FROM AccountsInfo(NOLOCK) WHERE PasswordID<>0 and userID={0}", userId);
            AccountsInfo user = ExecSqlForObject<AccountsInfo>(sqlQuery, null);
            if (user == null)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// 更新用户密保卡序列号
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <param name="serialNumber">密保卡序列号</param>
        /// <returns></returns>
        public bool UpdateUserPasswordCardID(int userId, int serialNumber)
        {
            string sqlQuery = string.Format("UPDATE AccountsInfo SET PasswordID={0} WHERE UserID={1}", serialNumber, userId);
            int result = ExecSqlNonQuery(sqlQuery);
            if (result > 0)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 取消密保卡绑定
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public bool ClearUserPasswordCardID(int userId)
        {
            string sqlQuery = string.Format("UPDATE AccountsInfo SET PasswordID=0 WHERE UserID={0}", userId);
            int result = ExecSqlNonQuery(sqlQuery);
            if (result > 0)
            {
                return true;
            }
            return false;
        }

        #endregion

        #region 获取用户会员列表
        /// <summary>
        /// 根据用户ID获取会员列表
        /// </summary>
        /// <param name="nickName"></param>
        /// <returns></returns>
        public IList<AccountsMember> GetAccountsMemberList(int userid)
        {
            string sqlQuery = string.Format("SELECT MemberOrder,MemberOverDate FROM AccountsMember(NOLOCK) WHERE UserID={0}", userid);
            return ExecSqlForObjectList<AccountsMember>(sqlQuery);
        }
        /// <summary>
        /// 根据条件获取会员列表
        /// </summary>
        /// <param name="nickName"></param>
        /// <returns></returns>
        public IList<AccountsMember> GetAccountsMemberList(string wherecase, string orderwhere)
        {
            string sqlQuery = "SELECT MemberOrder,MemberOverDate,Activation FROM AccountsMember(NOLOCK) WHERE 1=1 ";
            if (wherecase.Trim().Length > 0)
            {
                sqlQuery += wherecase;
            }
            if (orderwhere.Trim().Length == 0)
            {
                orderwhere = " order by Activation DESC ";
            }
            sqlQuery += orderwhere;
            return ExecSqlForObjectList<AccountsMember>(sqlQuery);
        }
        #endregion

        #region 公共

        /// <summary>
        /// 根据SQL语句查询一个值
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        public object GetObjectBySql(string sqlQuery)
        {
            object result = ExecSqlScalar(sqlQuery);
            return result;
        }

        #endregion

        #region 手游
        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        public DataSet GetMAccountInfo(int userid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"select a.UserID,a.GameID,a.Accounts,a.NickName,a.Experience,a.Present,a.LoveLiness,
a.MemberOrder,a.MemberOverDate,b.Score,b.InsureScore,b.WinCount,b.LostCount,b.DrawCount,b.FleeCount,
c.GoldenBean
from QPAccountsDB.dbo.AccountsInfo as a
left join QPTreasureDB.dbo.GameScoreInfo as b on a.UserID=b.UserID
left join QPTreasureDB.dbo.UserGoldenBean as c on a.UserID=c.UserID where a.UserID={0}", userid);
            return this.ExecSqlForDataSet(sbSql.ToString());
        }

        /// <summary>
        /// 获取用户头像信息
        /// </summary>
        /// <param name="FaceID"></param>
        /// <returns></returns>
        public AccountsUploadFace GetUserFaceInfo(int Userid, int FaceID)
        {
            StringBuilder sbCache = new StringBuilder();
            //审核未通过时自己显示新头像
            sbCache.Append(string.Format("select top 1 * from AccountsUploadFace(NOLOCK) where  UserID={0} order by inserttime desc", Userid));
            return ExecSqlForObject<AccountsUploadFace>(sbCache.ToString());
        }
        /// <summary>
        /// 更新用户自定义头像(用户上传图片，更新图片地址)
        /// </summary>
        /// <param name="Userid"></param>
        /// <param name="facelink"></param>
        /// <param name="picmd5"></param>
        /// <returns></returns>
        public Message UploadAccountUserFace(int Userid, string FileMd5, int CustomId, bool isPC)
        {
            var param = new List<DbParameter>();
            param.Add(MakeInParam("userid", Userid));
            param.Add(MakeInParam("fileMd5", FileMd5));
            param.Add(MakeInParam("customId", CustomId));
            param.Add(MakeInParam("IsPC", isPC ? 1 : 0));
            return ExecProcForMessageDataSet("proc_AccountsFaceUpload", param);
        }
        /// <summary>
        /// 获取新手奖励
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        public DataSet GetNoviceAwardList(int kindID)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(@"SELECT a.*,
       CASE
           WHEN a.RewardType=1 THEN '高富帅的象征，多多益善。'
           WHEN a.RewardType=3 THEN '集齐一定数量可兑换话费、手机等实物。'
           ELSE b.Explain
       END AS Explain,
       CASE
           WHEN a.RewardType=1 THEN '金币'
           WHEN a.RewardType=3 THEN '奖牌'
           ELSE b.Name
       END AS Name
FROM [QPAccountsDB].[dbo].[NoviceAward]  as a left join  [QPGamePropertyDB].[dbo].[PropertyCFG] AS b ON a.RewardType-65536=b.Pid  where KindID={0}", kindID);
            return this.ExecSqlForDataSet(sbSql.ToString());
        }
        #endregion
        #region 获取用户麻将开房道具数据
        /// <summary>
        /// 获取用户道具信息（麻将开房道具）
        /// </summary>
        public DataSet GetUserProperty(bool issuper, int targetuser, int userid)
        {
            if (issuper)
            {
                return ExecSqlForDataSet(string.Format("SELECT  b.[userid],case when weixinname='' then  NickName else weixinname end as NickName,isnull((SELECT [PCount]  FROM [QPGamePropertyDB].[dbo].[UserProperty] where userid=b.userid and pid=99),0) as Num FROM  [QPAccountsDB].[dbo].[AccountsInfo] as b where  b.userid={0}", targetuser));//int 不存在注入，暂不用参数化
            }
            return ExecSqlForDataSet(string.Format("SELECT  b.[userid],case when weixinname='' then  NickName else weixinname end as NickName,isnull((SELECT [PCount]  FROM [QPGamePropertyDB].[dbo].[UserProperty] where userid=b.userid and pid=99),0) as Num FROM  [QPAccountsDB].[dbo].[AccountsInfo] as b where IsAgent=0  and b.userid={0} and agentID={1}", targetuser, userid));//int 不存在注入，暂不用参数化
        }
        /// <summary>
        /// 根据用户ID获取开房道具数量
        /// </summary>
        public int GetUserPropertybyUserID(int userid)
        {
            return Convert.ToInt32(ExecSqlScalar(string.Format("SELECT isnull([PCount],0) as num  FROM [QPGamePropertyDB].[dbo].[UserProperty] where userid={0} and pid=99", userid)));//int 不存在注入，暂不用参数化
        }
        #endregion

        #region 经销商相关
        /// <summary>
        /// 获取是否成为下级经销商标识
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public int GetIsConfirm(int userID)
        {
            string sql = string.Format("select isnull(IsConfirm,0)   FROM [QPAccountsDB].[dbo].[DealerRelationship] where userid={0}", userID);
            return Convert.ToInt32(ExecSqlScalar(sql));
        }
        /// <summary>
        /// 获取上级代理商
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public DataSet GetParentDealerName(int userID)
        {
            string sql = string.Format("SELECT case when weixinname ='' then NickName else weixinname end as Name,b.userid  FROM [QPAccountsDB].[dbo].[DealerRelationship] as a left join [QPAccountsDB].[dbo].[AccountsInfo] as b on a.ParentID=b.userid where a.userid={0}", userID);
            return ExecSqlForDataSet(sql);
        }
        /// <summary>
        /// 确认成为下级经销商
        /// </summary>
        /// <param name="userID"></param>
        public int ConfirmChildDealer(int userID)
        {
            string sql = string.Format("update [QPAccountsDB].[dbo].[DealerRelationship] set IsConfirm=0 , ConfirmTime='{1}' where userid={0}", userID, DateTime.Now);
            return ExecSqlNonQuery(sql);
        }
        /// <summary>
        /// 取消下级经销商
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public int CancelChildDealer(int userID)
        {
            string sql = string.Format("delete from [QPAccountsDB].[dbo].[DealerRelationship] where userid={0}", userID);
            return ExecSqlNonQuery(sql);
        }
        /// <summary>
        /// 新增下级代理商
        /// </summary>
        public Message AddChildDealer(int userID, int childUserID, string name)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("userID", userID));
            parms.Add(MakeInParam("name", name));
            parms.Add(MakeInParam("childUserID", childUserID));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("proc_AddChildDealer", parms);
        }
        /// <summary>
        /// 新增下级代理商
        /// </summary>
        public Message AddChildAgent(int userID, string userName, string nickName, string pwd)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("strAccounts", userName));
            parms.Add(MakeInParam("strNickName", nickName));
            parms.Add(MakeInParam("strLogonPass", pwd));
            parms.Add(MakeInParam("strInsurePass", pwd));
            parms.Add(MakeInParam("dwFaceID", 1));
            parms.Add(MakeInParam("IsAndroid", byte.Parse("0")));
            parms.Add(MakeInParam("strRegisterIP", ""));
            parms.Add(MakeInParam("agentlv", 0));
            parms.Add(MakeInParam("isAgent", 1));
            parms.Add(MakeInParam("userID", userID));
            return ExecProcForMessage("proc_AddChildAgent", parms);
        }
        /// <summary>
        /// 获取经销商列表
        /// </summary>
        public DataSet GetDealerList(int pageindex, int pagesize, int userid)
        {
            string sql = string.Format(" select a.*,case when weixinname='' then nickname else weixinname end as name from [QPAccountsDB].[dbo].[DealerRelationship]  as a left join  [QPAccountsDB].[dbo].[AccountsInfo] as b on a.userid=b.userid where parentID={0}", userid);
            return GetPagination(pageindex, pagesize, sql, null, "InsertTime desc", null);
        }
        /// <summary>
        /// 获取有效二级经销商数量
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public int GetChildDealerCount(int userID)
        {
            return Convert.ToInt32(ExecSqlScalar("SELECT count(1) FROM [QPAccountsDB].[dbo].[DealerRelationship] where IsConfirm=0 and parentid=" + userID));
        }
        #endregion
        public DataSet GetWeiXinUserInfo(string table, string unionID)
        {
            return ExecSqlForDataSet(string.Format("select [UserID],[headurl] from {0} where openid='{1}'", table, unionID));
        }
        public void InsertWeiXinUser(int UserID, string openid, string unionID, string headurl, string table)
        {
            ExecSqlNonQuery(string.Format(" INSERT INTO {0}(OpenID,UserID,headurl) VALUES('{1}',{2},'{3}')", table, unionID, UserID, headurl));
        }
        public void UpdateWeiXinHead(string unionID, string headurl, string table)
        {
            ExecSqlNonQuery(string.Format(" update {0} set headurl='{1}' where openid='{2}'", table, headurl, unionID));
        }
        /// <summary>
        /// 获取用户战绩
        /// </summary>
        public Message GetUserScore(int userID, int kindID)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramuserID", userID));
            parms.Add(MakeInParam("paramkindID", kindID));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("proc_GetUserScore", parms);
        }
        public Message GetUserScore(int drawID)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramdrawID", drawID));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("proc_GetUserScore1", parms);
        }
        #region 代理商
        /// <summary>
        /// 绑定代理商
        /// </summary>
        public Message BindAgent(int userID, int agentID)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramuserID", userID));
            parms.Add(MakeInParam("paramagentID", agentID));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("proc_BindAgent", parms);
        }
        /// <summary>
        /// 获取绑定的代理商ID
        /// </summary>
        public int GetUserAgentID(int userID)
        {
            string sql = string.Format("select agentID from  [QPAccountsDB].[dbo].[AccountsInfo] where UserID={0}", userID);
            var result = ExecSqlScalar(sql);
            if (result == null)
            {
                return 0;
            }
            return Convert.ToInt32(result);
        }
        /// <summary>
        /// 获取绑定玩家列表
        /// </summary>
        public DataSet GetBindPlayerList(int pageindex, int pagesize, int agentid, int userid, string stime, string etime)
        {
            StringBuilder sbwhere = new StringBuilder();
            if (userid > 0)
            {
                sbwhere.AppendFormat(" and userid={0}", userid);
            }
            if (stime != null && stime.Length > 0)
            {
                sbwhere.AppendFormat(" and BindAgentTime>='{0}'", Convert.ToDateTime(stime));

            }
            if (etime != null && etime.Length > 0)
            {
                sbwhere.AppendFormat(" and BindAgentTime<'{0}'", Convert.ToDateTime(stime).Date.AddDays(1));
            }
            string sql = string.Format("select userid,case when weixinname='' then nickname else weixinname end as name,BindAgentTime,LastLogonDate from  [QPAccountsDB].[dbo].[AccountsInfo] where AgentID={0} {1}", agentid, sbwhere.ToString());
            return GetPagination(pageindex, pagesize, sql, null, "userid desc", null);
        }
        /// <summary>
        /// 获取绑定玩家列表
        /// </summary>
        public DataSet GetBindPlayerList(int pageindex, int pagesize, int agentid, int userid, bool issuper)
        {
            StringBuilder sbwhere = new StringBuilder();
            if (userid > 0)
            {
                sbwhere.AppendFormat(" and userid={0}", userid);
            }
            string sql = string.Empty;
            if (issuper)
            {
                sql = string.Format("select userid,case when weixinname='' then nickname else weixinname end as name,isnull((SELECT [PCount]  FROM [QPGamePropertyDB].[dbo].[UserProperty](nolock) where userid=b.userid and pid=99),0) as Num  from  [QPAccountsDB].[dbo].[AccountsInfo](nolock) as b where 1=1 {1}", agentid, sbwhere.ToString());
            }
            else
            {
                sql = string.Format("select userid,case when weixinname='' then nickname else weixinname end as name,isnull((SELECT [PCount]  FROM [QPGamePropertyDB].[dbo].[UserProperty](nolock) where userid=b.userid and pid=99),0) as Num  from  [QPAccountsDB].[dbo].[AccountsInfo](nolock) as b where IsAgent=0 and AgentID={0} {1}", agentid, sbwhere.ToString());
            }
            return GetPagination(pageindex, pagesize, sql, null, "userid desc", null);
        }

        public int updatepwd(int userID, string pwd)
        {
            var list = new List<DbParameter>();
            list.Add(MakeInParam("strDesPassword", pwd));
            list.Add(MakeInParam("UserID", userID));
            return ExecSqlNonQuery("UPDATE AccountsInfo SET LogonPass=@strDesPassword WHERE UserID=@UserID ", list);
        }
        public int GetParentAgentID(int userID)
        {
            string sql = string.Format("select isnull(ParentID,0)   FROM [QPAccountsDB].[dbo].[DealerRelationship] where userid={0}", userID);
            return Convert.ToInt32(ExecSqlScalar(sql));
        }
        public int DongJie(int userID)
        {
            var list = new List<DbParameter>();
            list.Add(MakeInParam("UserID", userID));
            return ExecSqlNonQuery("UPDATE AccountsInfo SET Nullity=1,NullityOverDate='2099-01-01' WHERE UserID=@UserID ", list);
        }
        /// <summary>
        /// 获取房间列表
        /// </summary>
        public DataSet GetRoomList(int pageindex, int pagesize, int userid)
        {
            string sql = string.Format(@"
SELECT a.[DrawID]
      ,[PlayerCount]
        ,TableKey
      ,a.[PlayCount]
      ,a.[MaxPlayCount]
      ,a.[DiamondCost]
      ,[GameStart]
      ,a.[CreateTime]
      ,[EndTime]
	  ,c.kindName
  FROM [QPGameLogDB].[dbo].[WebCreateLog] as a left join [QPStreamDB].[dbo].[RecordVIPInfo] as b on a.DrawID=b.DrawID
  left join [QPPlatformDB].[dbo].[GameKindItem] as c on b.KindID=c.KindID where a.OwnerID={0}", userid);
            return GetPagination(pageindex, pagesize, sql, null, "DrawID desc", null);
        }
        /// <summary>
        /// 获取用户开房数据详情
        /// </summary>
        public Message GetUserRoomInfo(int userID, int drawid)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramuserID", userID));
            parms.Add(MakeInParam("paramDrawID", drawid));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("proc_GetUserRoomInfo", parms);
        }
        #endregion
        public Message GetRankList(int userid, int type)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwUserID", userid));
            prams.Add(MakeInParam("dwType", type));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("GSP_MB_RankList1", prams);
        }
        public long GetRankScore(int userid, int type)
        {
            if (type == 1)
            {
                return (long)ExecSqlScalar("SELECT isnull(score+InsureScore,0) as score FROM THTreasureDB.dbo.GameScoreInfo WHERE UserID=" + userid);
            }
            else
            {
                var obj = ExecSqlScalar("SELECT isnull(GameSum,0)  as score FROM THRecordDB.[dbo].[RecordUserCountInfo] WHERE UserID=" + userid);
                if (obj == null)
                {
                    return 0;
                }
                else
                {
                    return (long)obj;
                }
            }
        }
    }
}
