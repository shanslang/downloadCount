﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Game.Francis;
using Game.IData;
using Game.Entity.Treasure;
using Game.Utils;
using Game.Entity.GameLog;
using Game.Entity.MobileApp;

namespace Game.Data
{
    /// <summary>
    /// 金币数据访问层
    /// </summary>
    public class TreasureDataProvider : DBHelper, ITreasureDataProvider
    {
        #region 构造方法
        public TreasureDataProvider(string dbname)
            : base(dbname)
        {

        }
        public TreasureDataProvider(string connectionString, object constructedType)
            : base(connectionString, constructedType)
        {

        }
        #endregion

        #region 在线充值
        /// <summary>
        /// 生成订单
        /// </summary>
        /// <param name="orderInfo"></param>
        /// <returns></returns>
        public Message RequestOrder(OnLineOrder orderInfo)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramOperUserID", orderInfo.OperUserID));

            prams.Add(MakeInParam("paramShareID", orderInfo.ShareID));
            prams.Add(MakeInParam("paramAccounts", orderInfo.Accounts));

            prams.Add(MakeInParam("paramOrderID", orderInfo.OrderID));
            prams.Add(MakeInParam("paramOrderAmount", orderInfo.OrderAmount));

            prams.Add(MakeInParam("paramCardTypeID", orderInfo.CardTypeID));
            prams.Add(MakeInParam("paramCardTotal", orderInfo.CardTotal));

            prams.Add(MakeInParam("paramOrderUseType", orderInfo.OrderUseType));
            prams.Add(MakeInParam("paramKindID", orderInfo.KindID));
            prams.Add(MakeInParam("paramIPAddress", orderInfo.IPAddress));
            prams.Add(MakeInParam("paramTimeSpan", orderInfo.TimeSpan));
            prams.Add(MakeInParam("paramServerID", orderInfo.ServerID));
            prams.Add(MakeInParam("paramFastChargetype", orderInfo.FastChargetype));
            prams.Add(MakeInParam("paramFastServerLv", orderInfo.FastServerLv));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));

            return ExecProcForMessageObject<OnLineOrder>("NET_PW_ApplyOnLineOrder", prams);
        }

        ///// <summary>
        ///// 添加 购买会员服务明细 和订单关联
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //public Message InsertBuyMemberOrderDetails(BuyMemberOrderDetails entity)
        //{
        //    List<DbParameter> prams = new List<DbParameter>();
        //    prams.Add(MakeInParam("paramOrderID", entity.OrderID));
        //    prams.Add(MakeInParam("paramCardTypeID", entity.CardTypeID));
        //    prams.Add(MakeInParam("paramMemberDayNum", entity.MemberDayNum));
        //    prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));

        //    return ExecProcForMessage("NET_PW_BuyMemberOrderDetails", prams);
        //}

        /// <summary>
        /// 添加 购买会员服务明细 和订单关联1
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertBuyMemberOrderDetails1(BuyMemberOrderDetails1 entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramOrderID", entity.OrderID));
            prams.Add(MakeInParam("paramMemberOrder", entity.MemberOrder));
            prams.Add(MakeInParam("paramMemberDays", entity.MemberDays));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_BuyMemberOrderDetails1", prams);
        }
        /// <summary>
        /// 获取 购买会员服务明细 和订单关联1  
        /// </summary>
        /// <param name="orderid"></param>
        /// <returns></returns>
        public BuyMemberOrderDetails1 GetBuyMemberOrderDetails1(string orderid)
        {
            StringBuilder sbCache = new StringBuilder();
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("orderID", orderid));
            sbCache.Append(" SELECT * FROM BuyMemberOrderDetails1 WHERE OrderID=@orderID");
            return ExecSqlForObject<BuyMemberOrderDetails1>(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 添加 购买道具明细 和订单关联
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertBuyProperDetails(BuyProperDetails entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramOrderID", entity.OrderID));
            prams.Add(MakeInParam("paramProperPid", entity.ProperPid));
            prams.Add(MakeInParam("paramProperNumber", entity.ProperNumber));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_BuyProperDetails", prams);
        }
        /// <summary>
        /// 添加 购买金币明细 和订单关联
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertBuyGoldDetails(BuyGoldOrderDetails entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramOrderID", entity.OrderID));
            prams.Add(MakeInParam("paramPriceGold", entity.PriceGold));
            prams.Add(MakeInParam("paramBuyCount", entity.BuyCount));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_BuyGoldDetails", prams);
        }
        ///// <summary>
        ///// 快钱充值成功 更新订单信息
        ///// Author:xujianbo
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteKQRecharge(ReturnKQDetailInfo returnInfo)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("strMerchantAcctID", returnInfo.MerchantAcctID));
        //    parms.Add(MakeInParam("strVersion", returnInfo.Version));
        //    parms.Add(MakeInParam("dwLanguage", returnInfo.Language));
        //    parms.Add(MakeInParam("dwSignType", returnInfo.SignType));
        //    parms.Add(MakeInParam("strPayType", returnInfo.PayType));
        //    parms.Add(MakeInParam("strBankID", returnInfo.BankID));
        //    parms.Add(MakeInParam("strOrderID", returnInfo.OrderID));
        //    parms.Add(MakeInParam("dtOrderTime", returnInfo.OrderTime));
        //    parms.Add(MakeInParam("fOrderAmount", returnInfo.OrderAmount));
        //    parms.Add(MakeInParam("strDealID", returnInfo.DealID));
        //    parms.Add(MakeInParam("strBankDealID", returnInfo.BankDealID));
        //    parms.Add(MakeInParam("dtDealTime", returnInfo.DealTime));
        //    parms.Add(MakeInParam("fPayAmount", returnInfo.PayAmount));
        //    parms.Add(MakeInParam("fFee", returnInfo.Fee));
        //    parms.Add(MakeInParam("strPayResult", returnInfo.PayResult));
        //    parms.Add(MakeInParam("strErrCode", returnInfo.ErrCode));
        //    parms.Add(MakeInParam("strSignMsg", returnInfo.SignMsg));
        //    parms.Add(MakeInParam("strExt1", returnInfo.Ext1));
        //    parms.Add(MakeInParam("strExt2", returnInfo.Ext2));
        //    parms.Add(MakeInParam("CardNumber", returnInfo.CardNumber));
        //    parms.Add(MakeInParam("CardPwd", returnInfo.CardPwd));
        //    parms.Add(MakeInParam("BossType", returnInfo.BossType));
        //    parms.Add(MakeInParam("ReceiveBossType", returnInfo.ReceiveBossType));
        //    parms.Add(MakeInParam("ReceiverAcctId", returnInfo.ReceiverAcctId));
        //    parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
        //    parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
        //    return ExecProcForMessage("NET_PM_KQRecharge", parms);
        //}

        ///// <summary>
        ///// 支付宝充值成功 更新订单信息
        ///// Author:xujianbo
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteZFBRecharge(ReturnZFBDetailInfo returnInfo)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("Is_success", returnInfo.Is_success));
        //    parms.Add(MakeInParam("Sign_type", returnInfo.Sign_type));
        //    parms.Add(MakeInParam("Sign", returnInfo.Sign));
        //    parms.Add(MakeInParam("Out_trade_no", returnInfo.Out_trade_no));
        //    parms.Add(MakeInParam("Subject", returnInfo.Subject));
        //    parms.Add(MakeInParam("Payment_type", returnInfo.Payment_type));
        //    parms.Add(MakeInParam("Exterface", returnInfo.Exterface));
        //    parms.Add(MakeInParam("Trade_no", returnInfo.Trade_no));
        //    parms.Add(MakeInParam("Trade_status", returnInfo.Trade_status));
        //    parms.Add(MakeInParam("Notify_id", returnInfo.Notify_id));
        //    parms.Add(MakeInParam("Notify_time", returnInfo.Notify_time));
        //    parms.Add(MakeInParam("Notify_type", returnInfo.Notify_type));
        //    parms.Add(MakeInParam("Seller_email", returnInfo.Seller_email));
        //    parms.Add(MakeInParam("Buyer_email", returnInfo.Buyer_email));
        //    parms.Add(MakeInParam("Seller_id", returnInfo.Seller_id));
        //    parms.Add(MakeInParam("Buyer_id", returnInfo.Buyer_id));
        //    parms.Add(MakeInParam("Total_fee", returnInfo.Total_fee));
        //    parms.Add(MakeInParam("Body", returnInfo.Body));
        //    parms.Add(MakeInParam("Extra_common_param", returnInfo.Extra_common_param));
        //    parms.Add(MakeInParam("Agent_user_id", returnInfo.Agent_user_id));
        //    parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
        //    parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
        //    return ExecProcForMessage("NET_PM_ZFBRecharge", parms);
        //}

        ///// <summary>
        ///// 声讯电信充值成功 更新订单信息
        ///// Author:xujianbo
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteSXDXRecharge(ReturnSXDXDetailInfo returnInfo)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("p0_Result", returnInfo.P0_Result));
        //    parms.Add(MakeInParam("p1_Mode", returnInfo.P1_Mode));
        //    parms.Add(MakeInParam("pc_User", returnInfo.Pc_User));
        //    parms.Add(MakeInParam("pc_SubArea", returnInfo.Pc_SubArea));
        //    parms.Add(MakeInParam("pc_SubAreaFee", returnInfo.Pc_SubAreaFee));
        //    parms.Add(MakeInParam("pb_Gate", returnInfo.Pb_Gate));
        //    parms.Add(MakeInParam("pb_Channel", returnInfo.Pb_Channel));
        //    parms.Add(MakeInParam("p5_OrderNo", returnInfo.P5_OrderNo));
        //    parms.Add(MakeInParam("p6_Fee", returnInfo.P6_Fee));
        //    parms.Add(MakeInParam("p11_TransactionNo", returnInfo.P11_TransactionNo));
        //    parms.Add(MakeInParam("P12_ResultDesc", returnInfo.P12_ResultDesc));
        //    parms.Add(MakeInParam("p9_ExtData", returnInfo.P9_ExtData));
        //    parms.Add(MakeInParam("p10_MD5Str", returnInfo.P10_MD5Str));

        //    parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
        //    parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
        //    return ExecProcForMessage("NET_PM_SXDXRecharge", parms);
        //}

        ///// <summary>
        ///// 声讯联通充值成功 更新订单信息
        ///// Author:xujianbo
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteSXLTRecharge(ReturnSXLTDetailInfo returnInfo)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("p0_Result", returnInfo.P0_Result));
        //    parms.Add(MakeInParam("p1_Mode", returnInfo.P1_Mode));
        //    parms.Add(MakeInParam("pc_User", returnInfo.Pc_User));
        //    parms.Add(MakeInParam("pc_SubArea", returnInfo.Pc_SubArea));
        //    parms.Add(MakeInParam("pc_SubAreaFee", returnInfo.Pc_SubAreaFee));
        //    parms.Add(MakeInParam("pb_Gate", returnInfo.Pb_Gate));
        //    parms.Add(MakeInParam("pb_Channel", returnInfo.Pb_Channel));
        //    parms.Add(MakeInParam("p5_OrderNo", returnInfo.P5_OrderNo));
        //    parms.Add(MakeInParam("p6_Fee", returnInfo.P6_Fee));
        //    parms.Add(MakeInParam("p11_TransactionNo", returnInfo.P11_TransactionNo));
        //    parms.Add(MakeInParam("P12_ResultDesc", returnInfo.P12_ResultDesc));
        //    parms.Add(MakeInParam("p9_ExtData", returnInfo.P9_ExtData));
        //    parms.Add(MakeInParam("p10_MD5Str", returnInfo.P10_MD5Str));

        //    parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
        //    parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
        //    return ExecProcForMessage("NET_PM_SXLTRecharge", parms);
        //}

        ///// <summary>
        ///// 快钱充值卡充值成功 更新订单信息
        ///// Author:xujianbo
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteKQCardRecharge(ReturnKQCardDetailInfo returnInfo)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("parmMerchantAcctId ", returnInfo.MerchantAcctId));
        //    parms.Add(MakeInParam("parmVersion", returnInfo.Version));
        //    parms.Add(MakeInParam("parmLanguage", returnInfo.Language));
        //    parms.Add(MakeInParam("parmPayType", returnInfo.PayType));
        //    parms.Add(MakeInParam("parmCardNumber", returnInfo.CardNumber));
        //    parms.Add(MakeInParam("parmCardPwd", returnInfo.CardPwd));
        //    parms.Add(MakeInParam("parmOrderId", returnInfo.OrderId));
        //    parms.Add(MakeInParam("parmOrderAmount", returnInfo.OrderAmount));
        //    parms.Add(MakeInParam("parmDealId", returnInfo.DealId));
        //    parms.Add(MakeInParam("parmOrderTime", returnInfo.OrderTime));
        //    parms.Add(MakeInParam("parmExt1", returnInfo.Ext1));
        //    parms.Add(MakeInParam("parmExt2", returnInfo.Ext2));
        //    parms.Add(MakeInParam("parmPayAmount", returnInfo.PayAmount));
        //    parms.Add(MakeInParam("parmBillOrderTime", returnInfo.BillOrderTime));
        //    parms.Add(MakeInParam("parmPayResult", returnInfo.PayResult));
        //    parms.Add(MakeInParam("parmSignType", returnInfo.SignType));
        //    parms.Add(MakeInParam("parmBossType", returnInfo.BossType));
        //    parms.Add(MakeInParam("parmReceiveBossType", returnInfo.ReceiveBossType));
        //    parms.Add(MakeInParam("parmReceiverAcctId", returnInfo.ReceiverAcctId));
        //    parms.Add(MakeInParam("parmSignMsg", returnInfo.SignMsg));

        //    parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
        //    parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
        //    return ExecProcForMessage("NET_PM_KQCardRecharge", parms);
        //}

        ///// <summary>
        ///// 天下付充值成功 更新订单信息
        ///// Author:xujianbo
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteTXFRecharge(string orderID)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("strOrderID", orderID));
        //    parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
        //    parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
        //    return ExecProcForMessage("NET_PM_TXFRecharge", parms);
        //}

        /// <summary>
        /// APPLE IAP充值成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message WriteAppleIAPRecharge(string orderID, string version, ReturnAppleIAPDetailInfo o)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("original_purchase_date_pst", o.original_purchase_date_pst));
            parms.Add(MakeInParam("purchase_date_ms", o.purchase_date_ms));
            parms.Add(MakeInParam("unique_identifier", o.unique_identifier));
            parms.Add(MakeInParam("original_transaction_id", o.original_transaction_id));
            parms.Add(MakeInParam("bvrs", o.bvrs));
            parms.Add(MakeInParam("transaction_id", o.transaction_id));
            parms.Add(MakeInParam("quantity", o.quantity));
            parms.Add(MakeInParam("unique_vendor_identifier", o.unique_vendor_identifier));
            parms.Add(MakeInParam("item_id", o.item_id));
            parms.Add(MakeInParam("product_id", o.product_id));
            parms.Add(MakeInParam("purchase_date", o.purchase_date));
            parms.Add(MakeInParam("original_purchase_date", o.original_purchase_date));
            parms.Add(MakeInParam("purchase_date_pst", o.purchase_date_pst));
            parms.Add(MakeInParam("bid", o.bid));
            parms.Add(MakeInParam("original_purchase_date_ms", o.original_purchase_date_ms));
            parms.Add(MakeInParam("json", o.json));
            parms.Add(MakeInParam("order_amount", o.orderamount));
            parms.Add(MakeInParam("iap_transaction", o.iap_transaction));

            parms.Add(MakeInParam("strOrderID", orderID));
            parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
            parms.Add(MakeInParam("strVersion", version));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessageDataSet("NET_PM_AppleIAPRecharge", parms);
        }

        /// <summary>
        /// 充值成功，更改订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <param name="version"></param>
        /// <param name="o"></param>
        /// <returns></returns>
        public Message WriteLJIAPRecharge(ReturnLJDetailInfo rtinfo, OnLineOrder order)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("orderId", order.OrderID));
            parms.Add(MakeInParam("userID", order.UserID));
            parms.Add(MakeInParam("ShareID", GetShareIDbyChannelLable(rtinfo.channelLabel)));
            parms.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            parms.Add(MakeInParam("price", rtinfo == null ? 0 : rtinfo.price));
            parms.Add(MakeInParam("channelCode", rtinfo == null ? "" : rtinfo.channelCode));
            parms.Add(MakeInParam("callbackInfo", rtinfo == null ? "" : rtinfo.callbackInfo));
            parms.Add(MakeInParam("signmsg", rtinfo == null ? "" : rtinfo.signmsg));
            parms.Add(MakeInParam("channelLabel", rtinfo == null ? "" : rtinfo.channelLabel));
            parms.Add(MakeInParam("iosOrder", rtinfo == null ? 1 : 0));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PW_AddReturnLJInfo", parms);   //记录回调数据 并处理订单
        }
        int GetShareIDbyChannelLable(string lable)
        {
            switch (lable)
            {
                case "wandoujia":
                    return (int)Game.Type.GlobalShareInfo.Wandoujia;
                case "360":
                    return (int)Game.Type.GlobalShareInfo._360;
                default:
                    return 17;
            }
        }
        /// <summary>
        /// 联通充值成功，更改订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <param name="version"></param>
        /// <param name="o"></param>
        /// <returns></returns>
        public Message WriteLTRecharge(callbackReq rtinfo, OnLineOrder order)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("orderId", order.OrderID));
            parms.Add(MakeInParam("userID", order.UserID));
            parms.Add(MakeInParam("ShareID", order.ShareID));
            parms.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            parms.Add(MakeInParam("ordertime", rtinfo == null ? "" : rtinfo.ordertime));
            parms.Add(MakeInParam("cpid", rtinfo == null ? "" : rtinfo.cpid));
            parms.Add(MakeInParam("appid", rtinfo == null ? "" : rtinfo.appid));
            parms.Add(MakeInParam("fid", rtinfo == null ? "" : rtinfo.fid));
            parms.Add(MakeInParam("payfee", rtinfo == null ? "" : rtinfo.payfee));
            parms.Add(MakeInParam("consumeCode", rtinfo == null ? "" : rtinfo.consumeCode));
            parms.Add(MakeInParam("payType", rtinfo == null ? "" : rtinfo.payType));
            parms.Add(MakeInParam("hRet", rtinfo == null ? "" : rtinfo.hRet));
            parms.Add(MakeInParam("status", rtinfo == null ? "" : rtinfo.status));
            parms.Add(MakeInParam("signMsg", rtinfo == null ? "" : rtinfo.signMsg));
            parms.Add(MakeInParam("iosOrder", rtinfo == null ? 1 : 0));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PW_AddReturnLTInfo", parms);   //记录回调数据 并处理订单
        }
        /// <summary>
        /// 百度sdk支付
        /// </summary>
        /// <param name="rtinfo"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public Message WriteBDRecharge(ReturnBDDetailInfo rtinfo, OnLineOrder order)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("orderId", order.OrderID));
            parms.Add(MakeInParam("userID", order.UserID));
            parms.Add(MakeInParam("ShareID", order.ShareID));
            parms.Add(MakeInParam("MerchandiseName", rtinfo == null ? "" : rtinfo.MerchandiseName));
            parms.Add(MakeInParam("OrderMoney ", rtinfo == null ? order.PayAmount : rtinfo.OrderMoney));
            parms.Add(MakeInParam("StartDateTime", rtinfo == null ? DateTime.Now : rtinfo.StartDateTime));
            parms.Add(MakeInParam("BankDateTime", rtinfo == null ? DateTime.Now : rtinfo.BankDateTime));
            parms.Add(MakeInParam("OrderStatus", rtinfo == null ? 1 : rtinfo.OrderStatus));
            parms.Add(MakeInParam("StatusMsg", rtinfo == null ? "支付成功" : rtinfo.StatusMsg));
            parms.Add(MakeInParam("ExtInfo", rtinfo == null ? "" : rtinfo.ExtInfo));
            parms.Add(MakeInParam("VoucherMoney ", rtinfo == null ? 0 : rtinfo.VoucherMoney));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PW_AddReturnBDInfo", parms);
        }
        /// <summary>
        /// 支付宝充值成功，更改订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <param name="version"></param>
        /// <param name="o"></param>
        /// <returns></returns>
        public Message WriteZFBRecharge(ReturnZFBDetailInfo returnInfo, OnLineOrder order)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("userID", order.UserID));
            parms.Add(MakeInParam("ShareID", order.ShareID));
            parms.Add(MakeInParam("Is_success", returnInfo.Is_success));
            parms.Add(MakeInParam("Sign_type", returnInfo.Sign_type));
            parms.Add(MakeInParam("Sign", returnInfo.Sign));
            parms.Add(MakeInParam("Out_trade_no", returnInfo.Out_trade_no));
            parms.Add(MakeInParam("Subject", returnInfo.Subject));
            parms.Add(MakeInParam("Payment_type", returnInfo.Payment_type));
            parms.Add(MakeInParam("Exterface", returnInfo.Exterface));
            parms.Add(MakeInParam("Trade_no", returnInfo.Trade_no));
            parms.Add(MakeInParam("Trade_status", returnInfo.Trade_status));
            parms.Add(MakeInParam("Notify_id", returnInfo.Notify_id));
            parms.Add(MakeInParam("Notify_time", returnInfo.Notify_time));
            parms.Add(MakeInParam("Notify_type", returnInfo.Notify_type));
            parms.Add(MakeInParam("Seller_email", returnInfo.Seller_email));
            parms.Add(MakeInParam("Buyer_email", returnInfo.Buyer_email));
            parms.Add(MakeInParam("Seller_id", returnInfo.Seller_id));
            parms.Add(MakeInParam("Buyer_id", returnInfo.Buyer_id));
            parms.Add(MakeInParam("Total_fee", returnInfo.Total_fee));
            parms.Add(MakeInParam("Body", returnInfo.Body));
            parms.Add(MakeInParam("Extra_common_param", returnInfo.Extra_common_param));
            parms.Add(MakeInParam("Agent_user_id", returnInfo.Agent_user_id));

            parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));


            return ExecProcForMessageDataSet("NET_PW_AddReturnZFBInfo", parms);   //记录回调数据 并处理订单
        }

        /// <summary>
        /// 银联回调充值成功，更改订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <param name="version"></param>
        /// <param name="o"></param>
        /// <returns></returns>
        public Message WriteUnionPayRecharge(OnLineOrder order)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("UserID", order.UserID));
            parms.Add(MakeInParam("OrderID", order.OrderID));
            parms.Add(MakeInParam("ShareID", order.ShareID));
            parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PW_AddReturnUnionPayInfo", parms);   //记录回调数据 并处理订单
        }
        /// <summary>
        /// 互联星空回调充值成功，更改订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <param name="version"></param>
        /// <param name="o"></param>
        /// <returns></returns>
        public Message WriteVnetPayRecharge(OnLineOrder order)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("UserID", order.UserID));
            parms.Add(MakeInParam("OrderID", order.OrderID));
            parms.Add(MakeInParam("ShareID", order.ShareID));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PW_AddReturnVnetPayInfo", parms);   //记录回调数据 并处理订单
        }

        ///// <summary>
        ///// 写天天付返回记录
        ///// </summary>
        ///// <param name="returnKQ"></param>
        //public void WriteReturnDayDetail(ReturnDayDetailInfo returnDay)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("@OrderID", returnDay.OrderID));
        //    parms.Add(MakeInParam("@MerID", returnDay.MerID));
        //    parms.Add(MakeInParam("@PayMoney", returnDay.PayMoney));
        //    parms.Add(MakeInParam("@UserName", returnDay.UserName));
        //    parms.Add(MakeInParam("@Sign", returnDay.Sign));
        //    parms.Add(MakeInParam("@PayType", returnDay.PayType));
        //    parms.Add(MakeInParam("@Status", returnDay.Status));
        //    ExecProcForMessage("NET_PW_AddReturnDayInfo", parms);
        //}

        ///// <summary>
        ///// 写快钱返回记录
        ///// </summary>
        ///// <param name="returnKQ"></param>
        //public void WriteReturnKQDetail(ReturnKQDetailInfo returnKQ)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("strMerchantAcctID", returnKQ.MerchantAcctID));
        //    parms.Add(MakeInParam("strVersion", returnKQ.Version));
        //    parms.Add(MakeInParam("dwLanguage", returnKQ.Language));
        //    parms.Add(MakeInParam("dwSignType", returnKQ.SignType));
        //    parms.Add(MakeInParam("strPayType", returnKQ.PayType));
        //    parms.Add(MakeInParam("strBankID", returnKQ.BankID));
        //    parms.Add(MakeInParam("strOrderID", returnKQ.OrderID));
        //    parms.Add(MakeInParam("dtOrderTime", returnKQ.OrderTime));
        //    parms.Add(MakeInParam("fOrderAmount", returnKQ.OrderAmount));
        //    parms.Add(MakeInParam("strDealID", returnKQ.DealID));
        //    parms.Add(MakeInParam("strBankDealID", returnKQ.BankDealID));
        //    parms.Add(MakeInParam("dtDealTime", returnKQ.DealTime));
        //    parms.Add(MakeInParam("fPayAmount", returnKQ.PayAmount));
        //    parms.Add(MakeInParam("fFee", returnKQ.Fee));
        //    parms.Add(MakeInParam("strPayResult", returnKQ.PayResult));
        //    parms.Add(MakeInParam("strErrCode", returnKQ.ErrCode));
        //    parms.Add(MakeInParam("strSignMsg", returnKQ.SignMsg));
        //    parms.Add(MakeInParam("strExt1", returnKQ.Ext1));
        //    parms.Add(MakeInParam("strExt2", returnKQ.Ext2));

        //    parms.Add(MakeInParam("CardNumber", returnKQ.CardNumber));
        //    parms.Add(MakeInParam("CardPwd", returnKQ.CardPwd));
        //    parms.Add(MakeInParam("BossType", returnKQ.BossType));
        //    parms.Add(MakeInParam("ReceiveBossType", returnKQ.ReceiveBossType));
        //    parms.Add(MakeInParam("ReceiverAcctId", returnKQ.ReceiverAcctId));

        //    ExecProcForMessage("NET_PW_AddReturnKQInfo", parms);
        //}

        ///// <summary>
        ///// 写电话充值返回记录
        ///// </summary>
        ///// <param name="returnKQ"></param>
        //public Message WriteReturnVBDetail(ReturnVBDetailInfo returnVB)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("Rtmd5", returnVB.Rtmd5));
        //    parms.Add(MakeInParam("Rtka", returnVB.Rtka));
        //    parms.Add(MakeInParam("Rtmi", returnVB.Rtmi));
        //    parms.Add(MakeInParam("Rtmz", returnVB.Rtmz));
        //    parms.Add(MakeInParam("Rtlx", returnVB.Rtlx));
        //    parms.Add(MakeInParam("Rtoid", returnVB.Rtoid));
        //    parms.Add(MakeInParam("OrderID", returnVB.OrderID));
        //    parms.Add(MakeInParam("Rtuserid", returnVB.Rtuserid));
        //    parms.Add(MakeInParam("Rtcustom", returnVB.Rtcustom));
        //    parms.Add(MakeInParam("Rtflag", returnVB.Rtflag));
        //    parms.Add(MakeInParam("EcryptStr", returnVB.EcryptStr));
        //    parms.Add(MakeInParam("SignMsg", returnVB.SignMsg));

        //    parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

        //    return ExecProcForMessage("NET_PW_AddReturnVBInfo", parms); ;
        //}

        ///// <summary>
        ///// 写易宝返回记录
        ///// </summary>
        ///// <param name="returnYB"></param>
        //public Message WriteReturnYBDetail(ReturnYPDetailInfo returnYB)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("p1_MerId", returnYB.P1_MerId));
        //    parms.Add(MakeInParam("r0_Cmd", returnYB.R0_Cmd));
        //    parms.Add(MakeInParam("r1_Code", returnYB.R1_Code));
        //    parms.Add(MakeInParam("r2_TrxId", returnYB.R2_TrxId));
        //    parms.Add(MakeInParam("r3_Amt", returnYB.R3_Amt));
        //    parms.Add(MakeInParam("r4_Cur", returnYB.R4_Cur));
        //    parms.Add(MakeInParam("r5_Pid", returnYB.R5_Pid));
        //    parms.Add(MakeInParam("r6_Order", returnYB.R6_Order));
        //    parms.Add(MakeInParam("r7_Uid", returnYB.R7_Uid));
        //    parms.Add(MakeInParam("r8_MP", returnYB.R8_MP));
        //    parms.Add(MakeInParam("r9_BType", returnYB.R9_BType));
        //    parms.Add(MakeInParam("rb_BankId", returnYB.Rb_BankId));
        //    parms.Add(MakeInParam("ro_BankOrderId", returnYB.Ro_BankOrderId));
        //    parms.Add(MakeInParam("rp_PayDate", returnYB.Rp_PayDate));
        //    parms.Add(MakeInParam("rq_CardNo", returnYB.Rq_CardNo));
        //    parms.Add(MakeInParam("ru_Trxtime", returnYB.Ru_Trxtime));
        //    parms.Add(MakeInParam("hmac", returnYB.Hmac));

        //    return ExecProcForMessage("NET_PW_AddReturnYBInfo", parms); ;
        //}

        ///// <summary>
        ///// 在线充值
        ///// </summary>
        ///// <param name="olDetial"></param>
        ///// <returns></returns>
        //public Message FilliedOnline(ShareDetialInfo olDetial, int isVB)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("strOrdersID", olDetial.OrderID));
        //    parms.Add(MakeInParam("strOrderAmount", olDetial.PayAmount));
        //    parms.Add(MakeInParam("isVB", isVB));
        //    parms.Add(MakeInParam("strIPAddress", olDetial.IPAddress));
        //    parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

        //    return ExecProcForMessage("NET_PW_FilledOnLine", parms);
        //}

        ///// <summary>
        ///// 苹果充值
        ///// </summary>
        ///// <param name="olDetial"></param>
        ///// <returns></returns>
        //public Message FilliedApp(ShareDetialInfo olDetial)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("dwUserID", olDetial.UserID));
        //    parms.Add(MakeInParam("strOrdersID", olDetial.OrderID));
        //    parms.Add(MakeInParam("PayAmount", olDetial.PayAmount));
        //    parms.Add(MakeInParam("dwShareID", olDetial.ShareID));
        //    parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

        //    return ExecProcForMessage("NET_PW_FilledApp", parms);
        //}

        /// <summary>
        /// 实卡充值
        /// </summary>
        /// <param name="associator"></param>
        /// <param name="operUserID"></param>
        /// <param name="accounts"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        public Message FilledLivcard(ShareDetialInfo detialInfo, string password)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwOperUserID", detialInfo.OperUserID));

            prams.Add(MakeInParam("strSerialID", detialInfo.SerialID));
            prams.Add(MakeInParam("strPassword", password));
            prams.Add(MakeInParam("strAccounts", detialInfo.Accounts));

            prams.Add(MakeInParam("strClientIP", detialInfo.IPAddress));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessageDataSet("NET_PW_FilledLivcard", prams);
        }

        /// <summary>
        /// 获取订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        public OnLineOrder GetOnlineOrder(string orderID)
        {
            string sqlQuery = string.Format("SELECT * FROM OnLineOrder(NOLOCK) WHERE OrderID='{0}'", orderID);
            OnLineOrder order = ExecSqlForObject<OnLineOrder>(sqlQuery);

            return order;
        }
        /// <summary>
        /// 获取订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        public OnLineOrder GetOnlineOrderByID(string onlineID)
        {
            string sqlQuery = string.Format("SELECT * FROM OnLineOrder(NOLOCK) WHERE onlineID='{0}'", onlineID);
            OnLineOrder order = ExecSqlForObject<OnLineOrder>(sqlQuery);

            return order;
        }

        /// <summary>
        /// 记录联通订单校验数据
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        public void AddOnLineOrderByLT(string orderID, string imei, string macaddress, string ipaddress, string identifier)
        {
            string sqlQuery = "INSERT INTO [QPTreasureDB].[dbo].[OnLineOrderByLT]([OrderID],[imei],[macaddress],[ipaddress],[identifier]) VALUES(@OrderID,@imei,@macaddress,@ipaddress,@identifier)";
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("OrderID", orderID));
            prams.Add(MakeInParam("imei", imei));
            prams.Add(MakeInParam("macaddress", macaddress));
            prams.Add(MakeInParam("ipaddress", ipaddress));
            prams.Add(MakeInParam("identifier", identifier));
            ExecSqlNonQuery(sqlQuery, prams);
        }
        /// <summary>
        /// 获取联通订单校验数据
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        public DataSet GetOnLineOrderByLT(string orderID)
        {
            string sqlQuery = "SELECT TOP 1 [OrderID],[imei],[macaddress],[ipaddress],[identifier] FROM [QPTreasureDB].[dbo].[OnLineOrderByLT](NOLOCK) WHERE [OrderID]=@OrderID";
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("OrderID", orderID));
            return ExecSqlForDataSet(sqlQuery, prams);
        }
        /// <summary>
        /// 获取订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        public OnLineOrder GetOnlineOrder(string orderID, int Userid)
        {
            string sqlQuery = string.Format("SELECT * FROM OnLineOrder(NOLOCK) WHERE OrderID='{0}' AND UserID={1}", orderID, Userid);
            OnLineOrder order = ExecSqlForObject<OnLineOrder>(sqlQuery);

            return order;
        }

        ///// <summary>
        ///// 获取苹果产品列表
        ///// </summary>
        ///// <returns></returns>
        //public DataSet GetAppList()
        //{
        //    string sqlQuery = string.Format("SELECT ProductID,ProductName,Description,Price FROM GlobalAppInfo(NOLOCK)");
        //    return ExecSqlForDataSet(sqlQuery);
        //}

        ///// <summary>
        ///// 获取苹果产品列表
        ///// </summary>
        ///// <returns></returns>
        //public DataSet GetAppListByTagID(int tagID)
        //{
        //    string sqlQuery = string.Format("SELECT ProductID,ProductName,Description,Price FROM GlobalAppInfo(NOLOCK) WHERE TagID={0}", tagID);
        //    return ExecSqlForDataSet(sqlQuery);
        //}

        ///// <summary>
        ///// 获取产品信息
        ///// </summary>
        ///// <param name="ProductID"></param>
        ///// <returns></returns>
        //public DataSet GetAppInfoByProductID(string productID)
        //{
        //    string sqlQuery = string.Format("SELECT ProductID,ProductName,Description,Price FROM GlobalAppInfo(NOLOCK) WHERE ProductID='{0}'", productID);
        //    return ExecSqlForDataSet(sqlQuery);
        //}

        ///// <summary>
        ///// 写苹果返回记录
        ///// </summary>
        ///// <param name="detialInfo"></param>
        ///// <param name="receipt"></param>
        //public void WriteReturnAppDetail(ShareDetialInfo detialInfo, AppReceiptInfo receipt)
        //{
        //    StringBuilder sqlQuery = new StringBuilder();
        //    sqlQuery.Append("INSERT INTO ReturnAppDetailInfo(UserID,OrderID,PayAmount,Status,quantity,product_id,transaction_id,purchase_date,original_transaction_id,");
        //    sqlQuery.Append("original_purchase_date,app_item_id,version_external_identifier,bid,bvrs)");
        //    sqlQuery.Append(" VALUES(");
        //    sqlQuery.Append("@UserID,@OrderID,@PayAmount,@Status,@quantity,@product_id,@transaction_id,@purchase_date,@original_transaction_id,");
        //    sqlQuery.Append("@original_purchase_date,@app_item_id,@version_external_identifier,@bid,@bvrs)");

        //    List<DbParameter> prams = new List<DbParameter>();
        //    prams.Add(MakeInParam("UserID", detialInfo.UserID));
        //    prams.Add(MakeInParam("OrderID", detialInfo.OrderID));
        //    prams.Add(MakeInParam("PayAmount", detialInfo.PayAmount));
        //    prams.Add(MakeInParam("Status", receipt.Status));
        //    prams.Add(MakeInParam("quantity", receipt.Receipt.quantity));
        //    prams.Add(MakeInParam("product_id", receipt.Receipt.product_id));
        //    prams.Add(MakeInParam("transaction_id", receipt.Receipt.transaction_id));
        //    prams.Add(MakeInParam("purchase_date", receipt.Receipt.purchase_date));
        //    prams.Add(MakeInParam("original_transaction_id", receipt.Receipt.original_transaction_id));
        //    prams.Add(MakeInParam("original_purchase_date", receipt.Receipt.original_purchase_date));
        //    prams.Add(MakeInParam("app_item_id", receipt.Receipt.app_item_id));
        //    prams.Add(MakeInParam("version_external_identifier", receipt.Receipt.version_external_identifier));
        //    prams.Add(MakeInParam("bid", receipt.Receipt.bid));
        //    prams.Add(MakeInParam("bvrs", receipt.Receipt.bvrs));

        //    ExecSqlNonQuery(sqlQuery.ToString(), prams);
        //}

        #endregion

        #region 充值记录

        /// <summary>
        /// 充值记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetPayRecord(string whereQuery, int pageIndex, int pageSize)
        {
            string sqlQuery = @"select a.*,b.ShareName 
                                from ShareDetailInfo as a left join GlobalShareInfo as b on a.ShareID=b.ShareID";
            if (!string.IsNullOrEmpty(whereQuery))
            {
                sqlQuery += " where " + whereQuery;
            }
            return GetPagination(pageIndex, pageSize, sqlQuery, null, "ApplyDate DESC", null);
        }

        /// <summary>
        /// 充值记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="wherestr"></param>
        /// <returns></returns>
        public DataSet GetRechRecord(int pageindex, int pagesize, string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,b.OrderUseType from ShareDetailInfo as a
                                left join OnLineOrder as b on a.OrderID=b.OrderID");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "ApplyDate DESC", null);
        }

        ///// <summary>
        ///// 查询购买会员明细
        ///// </summary>
        ///// <param name="orderid"></param>
        ///// <returns></returns>
        //public BuyMemberOrderDetails GetBuyMemberOrderDetails(string orderid)
        //{
        //    StringBuilder sbCache = new StringBuilder();
        //    sbCache.Append(@"select * from BuyMemberOrderDetails");
        //    sbCache.Append(" where OrderID=@OrderID");
        //    List<DbParameter> prams = new List<DbParameter>();
        //    prams.Add(MakeInParam("OrderID", orderid));
        //    return ExecSqlForObject<BuyMemberOrderDetails>(sbCache.ToString(), prams);
        //}
        #endregion

        #region 推广中心

        /// <summary>
        /// 获取用户推广信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Message GetUserSpreadInfo(int userID)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwUserID", userID));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessageObject<RecordSpreadInfo>("NET_PW_GetUserSpreadInfo", prams);
        }

        /// <summary>
        /// 用户推广结算信息
        /// </summary>
        /// <param name="balance"></param>
        /// <param name="userID"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        public Message GetUserSpreadBalance(int balance, int userID, string ip)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwUserID", userID));
            prams.Add(MakeInParam("dwBalance", balance));

            prams.Add(MakeInParam("strClientIP", ip));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_SpreadBalance", prams);
        }

        /// <summary>
        /// 推广记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetSpreaderRecord(string whereQuery, int pageIndex, int pageSize)
        {
            string sqlQuery = @"select RecordID,UserID,Score,TypeID,ChildrenID,InsureScore,CollectDate,CollectNote from RecordSpreadInfo";
            if (!string.IsNullOrEmpty(whereQuery))
            {
                sqlQuery += " where " + whereQuery;
            }
            return GetPagination(pageIndex, pageSize, sqlQuery, null, "CollectDate DESC", null);
        }

        /// <summary>
        /// 单个用户下所有被推荐人的推广信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetUserSpreaderList(int userID, int pageIndex, int pageSize)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwUserID", userID));
            prams.Add(MakeInParam("dwPageIndex", pageIndex));
            prams.Add(MakeInParam("dwPageSize", pageSize));

            return ExecProcForDataSet("NET_PW_GetAllChildrenInfoByUserID", prams);
        }

        /// <summary>
        /// 获取单个结算总额
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public long GetUserSpreaderTotal(string sWhere)
        {
            string sql = "SELECT SUM(Score) AS Score FROM RecordSpreadInfo";
            if (!string.IsNullOrEmpty(sWhere))
            {
                sql += " where " + sWhere;
            }
            RecordSpreadInfo spreader = ExecSqlForObject<RecordSpreadInfo>(sql);
            return spreader == null ? 0 : spreader.Score;
        }

        /// <summary>
        /// 获取推广配置实体
        /// </summary>
        /// <returns></returns>
        public GlobalSpreadInfo GetGlobalSpreadInfo()
        {
            string sql = "SELECT TOP 1 * FROM GlobalSpreadInfo ORDER BY ID DESC";
            GlobalSpreadInfo model = ExecSqlForObject<GlobalSpreadInfo>(sql);
            return model;
        }

        #endregion

        #region 银行操作

        /// <summary>
        /// 金币存入
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="TradeScore"></param>
        /// <param name="minTradeScore"></param>
        /// <param name="clientIP"></param>
        /// <param name="note"></param>
        /// <returns></returns>
        public Message InsureIn(int userID, int TradeScore, int minTradeScore, string clientIP, string note)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));

            parms.Add(MakeInParam("dwMinSwapScore", minTradeScore));
            parms.Add(MakeInParam("dwSwapScore", TradeScore));

            parms.Add(MakeInParam("strClientIP", clientIP));
            parms.Add(MakeInParam("strCollectNote", note));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessageObject<GameScoreInfo>("NET_PW_InsureIn", parms);
        }

        /// <summary>
        /// 金币取出
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="insurePass"></param>
        /// <param name="TradeScore"></param>
        /// <param name="minTradeScore"></param>
        /// <param name="clientIP"></param>
        /// <param name="note"></param>
        /// <returns></returns>
        public Message InsureOut(int userID, string insurePass, int TradeScore, int minTradeScore, string clientIP, string note)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwUserID", userID));
            parms.Add(MakeInParam("strInsurePass", insurePass));

            parms.Add(MakeInParam("dwMinSwapScore", minTradeScore));
            parms.Add(MakeInParam("dwSwapScore", TradeScore));

            parms.Add(MakeInParam("strClientIP", clientIP));
            parms.Add(MakeInParam("strCollectNote", note));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessageObject<GameScoreInfo>("NET_PW_InsureOut", parms);
        }

        /// <summary>
        /// 金币转账
        /// </summary>
        /// <param name="srcUserID"></param>
        /// <param name="insurePass"></param>
        /// <param name="dstUserID"></param>
        /// <param name="TradeScore"></param>
        /// <param name="minTradeScore"></param>
        /// <param name="clientIP"></param>
        /// <param name="note"></param>
        /// <returns></returns>
        public Message InsureTransfer(int srcUserID, string insurePass, int dstUserID, int TradeScore, int minTradeScore, string clientIP, string note)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwSrcUserID", srcUserID));
            parms.Add(MakeInParam("strInsurePass", insurePass));
            parms.Add(MakeInParam("dwDstUserID", dstUserID));

            parms.Add(MakeInParam("dwMinSwapScore", minTradeScore));
            parms.Add(MakeInParam("dwSwapScore", TradeScore));

            parms.Add(MakeInParam("strClientIP", clientIP));
            parms.Add(MakeInParam("strCollectNote", note));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_InsureTransfer", parms);
        }

        /// <summary>
        /// 游戏记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetInsureTradeRecord(string whereQuery, int pageIndex, int pageSize)
        {
            string sqlQuery = @"select RecordID,KindID,ServerID,SourceUserID,SourceGold,SourceBank,TargetUserID,
                                TargetGold,TargetBank,SwapScore,Revenue,IsGamePlaza,TradeType,ClientIP,CollectDate,CollectNote
                                from RecordInsure";
            if (!string.IsNullOrEmpty(whereQuery))
            {
                sqlQuery += " where " + whereQuery;
            }
            return GetPagination(pageIndex, pageSize, sqlQuery, null, "CollectDate DESC", null);
        }

        #endregion

        #region 获取金币信息

        /// <summary>
        /// 根据用户ID得到金币信息
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public GameScoreInfo GetTreasureInfo2(int UserID)
        {
            string sqlQuery = string.Format("SELECT * FROM GameScoreInfo(NOLOCK) WHERE UserID={0}", UserID);
            GameScoreInfo score = ExecSqlForObject<GameScoreInfo>(sqlQuery);

            return score;
        }

        #endregion

        #region 财富排名

        /// <summary>
        /// 财富排名
        /// </summary>
        /// <returns></returns>
        public IList<GameScoreInfo> GetGameScoreInfoOrderByScore()
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT TOP 10 UserID, Score, InsureScore ")
                    .Append(" FROM GameScoreInfo ")
                    .Append(" ORDER BY Score DESC,InsureScore DESC ");
            return ExecSqlForObjectList<GameScoreInfo>(sqlQuery.ToString());
        }

        /// <summary>
        /// 财富排行
        /// </summary>
        /// <returns></returns>
        public DataSet GetScoreRanking(int num)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT TOP ").Append(num).Append(" Score, NickName, Nullity ")
                    .Append(" FROM GameScoreInfo AS A LEFT JOIN QPAccountsDB.dbo.AccountsInfo AS B ")
                    .Append(" ON A.UserID = B.UserID WHERE B.Nullity=0 ORDER BY A.Score DESC ");
            return ExecSqlForDataSet(sqlQuery.ToString());
        }

        #endregion

        #region 会员操作

        /// <summary>
        /// 负分清零
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        public Message ClearGameScore(int userID, string ip)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwUserID", userID));

            prams.Add(MakeInParam("strClientIP", ip));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_ResetGameScore", prams);
        }

        /// <summary>
        /// 逃跑清零
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        public Message ClearGameFlee(int userID, string ip)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwUserID", userID));

            prams.Add(MakeInParam("strClientIP", ip));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_ResetGameFlee", prams);
        }

        #endregion

        #region 游戏记录

        //        /// <summary>
        //        /// 每桌游戏记录
        //        /// </summary>
        //        /// <param name="whereQuery"></param>
        //        /// <param name="pageIndex"></param>
        //        /// <param name="pageSize"></param>
        //        /// <returns></returns>
        //        public DataSet GetDrawInfoRecord(string whereQuery, int pageIndex, int pageSize)
        //        {
        //            string sqlQuery = @"select DrawID,KindID,ServerID,TableID,UserCount,AndroidCount,Waste,Revenue,
        //                                UserMedal,StartTime,ConcludeTime,InsertTime
        //                                from QPStreamDB.dbo.RecordDrawInfo";
        //            if (!string.IsNullOrEmpty(whereQuery))
        //            {
        //                sqlQuery += " where " + whereQuery;
        //            }
        //            return GetPagination(pageIndex, pageSize, sqlQuery, null, "InsertTime DESC", null);
        //        }

        //        /// <summary>
        //        /// 每桌详细记录
        //        /// </summary>
        //        /// <param name="whereQuery"></param>
        //        /// <param name="pageIndex"></param>
        //        /// <param name="pageSize"></param>
        //        /// <returns></returns>
        //        public DataSet GetDrawScoreRecord(string whereQuery, int pageIndex, int pageSize)
        //        {
        //            string sqlQuery = @"select DrawID,UserID,ChairID,Score,Grade,Revenue,UserMedal,PlayTimeCount,InsertTime
        //                                from QPStreamDB.dbo.RecordDrawScore";
        //            if (!string.IsNullOrEmpty(whereQuery))
        //            {
        //                sqlQuery += " where " + whereQuery;
        //            }
        //            return GetPagination(pageIndex, pageSize, sqlQuery, null, "InsertTime DESC", null);
        //        }

        #endregion

        #region 公共

        /// <summary>
        /// 获取数据
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="pageIndex">页索引</param>
        /// <param name="pageSize">页大小</param>
        /// <param name="pkey">排序或分组</param>
        /// <param name="whereQuery">查询条件</param>
        /// <param name="whereQuery">字段</param>
        public DataSet GetList(int pageIndex, int pageSize, string sqlQuery, string whereQuery, string orderBy)
        {
            if (!string.IsNullOrEmpty(whereQuery))
            {
                sqlQuery += " where " + whereQuery;
            }
            return GetPagination(pageIndex, pageSize, sqlQuery, null, orderBy, null);
        }

        /// <summary>
        /// 根据sql语句获取数据
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        public DataSet GetDataSetByWhere(string sqlQuery)
        {
            return ExecSqlForDataSet(sqlQuery);
        }

        /// <summary>
        /// 根据sql获取实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public T GetEntity<T>(string commandText, List<DbParameter> parms)
        {
            return ExecSqlForObject<T>(commandText, parms);
        }

        /// <summary>
        /// 根据sql获取实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public T GetEntity<T>(string commandText)
        {
            return ExecSqlForObject<T>(commandText);
        }

        #endregion

        #region 任务系统

        /// <summary>
        /// 每日签到
        /// </summary>
        /// <param name="detialInfo"></param>
        /// <param name="receipt"></param>
        public Message WriteCheckIn(int userID, string strClientIP)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwUserID", userID));
            prams.Add(MakeInParam("strClientIP", strClientIP));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_WriteCheckIn", prams);
        }
        #endregion

        #region 获取卡类型信息
        /// <summary>
        /// 获取卡类型列表
        /// </summary>
        /// <returns></returns>
        public IList<GlobalLivcard> GetGlobalLivcardList(int top, string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("select * from GlobalLivcard");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            return ExecSqlForObjectList<GlobalLivcard>(sbCache.ToString());
        }
        #endregion

        #region 喔咕咕交易
        /// <summary>
        /// 喔咕咕 冻结卖家金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message WggFreeze(WguguOrder entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramOrderID", entity.OrderID));
            prams.Add(MakeInParam("paramPlayerID", entity.PlayerID));
            prams.Add(MakeInParam("paramWareID", entity.WareID));
            prams.Add(MakeInParam("paramWareNum", entity.WareNum));
            prams.Add(MakeInParam("paramWGGTime", entity.WGGTime));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_WggFreeze", prams);
        }
        /// <summary>
        /// 喔咕咕 买家购买金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message WggTrade(WguguOrder entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramOrderID ", entity.OrderID));
            prams.Add(MakeInParam("paramPlayerID", entity.PlayerID));
            prams.Add(MakeInParam("paramWareID  ", entity.WareID));
            prams.Add(MakeInParam("paramWareNum ", entity.WareNum));
            prams.Add(MakeInParam("paramWGGTime ", entity.WGGTime));
            prams.Add(MakeInParam("paramProID	", entity.ProID));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_WggTrade", prams);
        }
        /// <summary>
        /// 喔咕咕 解冻卖家金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message WggUnfreeze(WguguOrder entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramOrderID", entity.OrderID));
            prams.Add(MakeInParam("paramPlayerID", entity.PlayerID));
            prams.Add(MakeInParam("paramWareID", entity.WareID));
            prams.Add(MakeInParam("paramWareNum", entity.WareNum));
            prams.Add(MakeInParam("paramWGGTime", entity.WGGTime));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_WggUnfreeze", prams);
        }
        #endregion

        #region 网站 砸金蛋 转盘 挖宝 活动 已经废弃by francis
        //        /// <summary>
        //        /// 活动赠送金币
        //        /// </summary>
        //        /// <param name="entity"></param>
        //        /// <returns></returns>
        //        public Message InsertRecordActivityPresentGold(int userid, long gold, bool ispresent, int activitypid, int expendtype, int expendnum)
        //        {
        //            List<DbParameter> prams = new List<DbParameter>();
        //            prams.Add(MakeInParam("paramActivityPid", activitypid));
        //            prams.Add(MakeInParam("paramExpendType", expendtype));
        //            prams.Add(MakeInParam("paramExpendNum", expendnum));
        //            prams.Add(MakeInParam("paramUserID", userid));
        //            prams.Add(MakeInParam("paramGold", gold));
        //            prams.Add(MakeInParam("paramIsPresent", ispresent ? 1 : 0));
        //            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
        //            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
        //            return ExecProcForMessage("NET_PM_InsertRecordActivityPresentGold", prams);
        //        }
        //        /// <summary>
        //        /// 活动赠送会员
        //        /// </summary>
        //        /// <param name="entity"></param>
        //        /// <returns></returns>
        //        public Message InsertRecordActivityPresentMember(int userid, int membercardtypeid, int memberdays, bool ispresent, int activitypid, int expendtype, int expendnum)
        //        {
        //            List<DbParameter> prams = new List<DbParameter>();
        //            prams.Add(MakeInParam("paramActivityPid", activitypid));
        //            prams.Add(MakeInParam("paramExpendType", expendtype));
        //            prams.Add(MakeInParam("paramExpendNum", expendnum));
        //            prams.Add(MakeInParam("paramUserID", userid));
        //            prams.Add(MakeInParam("paramMemberCardTypeID", membercardtypeid));
        //            prams.Add(MakeInParam("paramMemberDays", memberdays));
        //            prams.Add(MakeInParam("paramIsPresent", ispresent ? 1 : 0));
        //            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
        //            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
        //            return ExecProcForMessage("NET_PM_InsertRecordActivityPresentMember", prams);
        //        }
        //        /// <summary>
        //        /// 活动赠送奖牌
        //        /// </summary>
        //        /// <param name="entity"></param>
        //        /// <returns></returns>
        //        public Message InsertRecordActivityPresentUserMedal(int userid, int usermedal, bool ispresent, int activitypid, int expendtype, int expendnum)
        //        {
        //            List<DbParameter> prams = new List<DbParameter>();
        //            prams.Add(MakeInParam("paramActivityPid", activitypid));
        //            prams.Add(MakeInParam("paramExpendType", expendtype));
        //            prams.Add(MakeInParam("paramExpendNum", expendnum));
        //            prams.Add(MakeInParam("paramUserID", userid));
        //            prams.Add(MakeInParam("paramUserMedal", usermedal));
        //            prams.Add(MakeInParam("paramIsPresent", ispresent ? 1 : 0));
        //            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
        //            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
        //            return ExecProcForMessage("NET_PM_InsertRecordActivityPresentUserMedal", prams);
        //        }



        #endregion

        #region 网站活动 订单管理
        ///// <summary>
        ///// 活动赠送实物及奖品 产生订单
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //public Message InsertProductOrderForActivity(string orderid, int productpid, int userid, int number, bool ispresent, int activitypid, int expendtype, int expendnum)
        //{
        //    List<DbParameter> prams = new List<DbParameter>();
        //    prams.Add(MakeInParam("paramActivityPid", activitypid));
        //    prams.Add(MakeInParam("paramExpendType", expendtype));
        //    prams.Add(MakeInParam("paramExpendNum", expendnum));
        //    prams.Add(MakeInParam("paramIsPresent", ispresent ? 1 : 0));
        //    prams.Add(MakeInParam("paramUserID", userid));
        //    prams.Add(MakeInParam("paramOrderID", orderid));
        //    prams.Add(MakeInParam("paramProductPid", productpid));
        //    prams.Add(MakeInParam("paramNumber", number));
        //    prams.Add(MakeInParam("paramOrderStatus", (int)Game.Type.ProductOrderStatus.新建));
        //    prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
        //    prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
        //    return ExecProcForMessage("NET_PM_InsertProductOrderForActivity", prams);
        //}
        /// <summary>
        /// 活动赠送实物及奖品 处理订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message ActivityProductOrderProcess(string orderid, string qqnumber, string telephone, string postcode, string address, string remark)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramOrderID", orderid));
            prams.Add(MakeInParam("paramQQNumber", qqnumber));
            prams.Add(MakeInParam("paramTelePhone", telephone));
            prams.Add(MakeInParam("paramPostCode", postcode));
            prams.Add(MakeInParam("paramAddress", address));
            prams.Add(MakeInParam("paramRemark", remark));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_ActivityProductOrderProcess", prams);
        }
        #endregion

        #region 产品订单管理
        /// <summary>
        /// 商城购买虚拟物品 产生订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertProductOrderForMall(string orderid, int productpid, int userid, int number, string name, string qqnumber, string telephone, string postcode, string address, string remark, Game.Type.ProductOrderStatus orderstatus)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramOrderID", orderid));
            prams.Add(MakeInParam("paramProductPid", productpid));
            prams.Add(MakeInParam("paramNumber", number));
            prams.Add(MakeInParam("paramOrderStatus", (int)orderstatus));
            prams.Add(MakeInParam("paramName", name));
            prams.Add(MakeInParam("paramQQNumber", qqnumber));
            prams.Add(MakeInParam("paramTelePhone", telephone));
            prams.Add(MakeInParam("paramPostCode", postcode));
            prams.Add(MakeInParam("paramAddress", address));
            prams.Add(MakeInParam("paramRemark", remark));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_InsertProductOrderForMall", prams);
        }
        /// <summary>
        /// 商城购买虚拟物品 处理订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message MallProductOrderProcess(string orderid, Game.Type.ProductOrderStatus status, string remark)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramOrderID", orderid));
            prams.Add(MakeInParam("paramOrderStatus", (int)status));
            prams.Add(MakeInParam("paramRemark", remark));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_MallProductOrderProcess", prams);
        }

        /// <summary>
        /// 查询单条产品记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public Product GetProduct(int pid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from Product");
            sbCache.Append(" where Pid=@Pid");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("Pid", pid));
            return ExecSqlForObject<Product>(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 查询记录数量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public int GetProductCount(string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select count(*) from Product");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            return Game.Utils.Utility.StrToInt(this.ExecSqlScalar(sbCache.ToString()), 0);
        }
        /// <summary>
        /// 查询产品记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public IList<Product> GetProductTopList(int top, string wherestr, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select {0} * from Product", top > 0 ? "top " + top : "");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            if (!string.IsNullOrEmpty(order))
            {
                sbCache.AppendFormat(" order by {0}", order);
            }
            return this.ExecSqlForObjectList<Product>(sbCache.ToString());
        }
        /// <summary>
        /// 查询产品记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetProductRecord(int pageindex, int pagesize, string wherestr, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from Product");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            if (string.IsNullOrEmpty(order))
            {
                order = " SortID asc";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }
        /// <summary>
        /// 获取商品信息IconID
        /// </summary>
        /// <param name="wherecase"></param>
        /// <returns></returns>
        public DataSet GetProductRecord(string wherecase)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT a.*,B.IconID from Product(NOLOCK) AS A
                             Left JOIN ProductIcon(NOLOCK) AS B
                             ON A.Pid=B.ProductID WHERE 1=1 ");
            sbCache.Append(wherecase + " order by sortID asc");
            return ExecSqlForDataSet(sbCache.ToString());
        }
        /// <summary>
        /// 查询单条订单记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public ProductOrder GetProductOrder(string orderid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from ProductOrder");
            sbCache.Append(" where OrderID=@OrderID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("OrderID", orderid));
            return ExecSqlForObject<ProductOrder>(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 查询记录数量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public int GetProductOrderCount(string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select count(*) from ProductOrder");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            return Game.Utils.Utility.StrToInt(this.ExecSqlScalar(sbCache.ToString()), 0);
        }
        /// <summary>
        /// 查询订单记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public IList<ProductOrder> GetProductOrderTopList(int top, string wherestr, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select {0} a.*,b.Accounts,b.NickName,c.ProductName,c.ProductType from ProductOrder as a 
                                left join QPAccountsDB.dbo.AccountsInfo as b on a.UserID=b.UserID
                                left join Product as c on a.ProductPid = c.Pid", top > 0 ? "top " + top : "");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            if (!string.IsNullOrEmpty(order))
            {
                sbCache.AppendFormat(" order by {0}", order);
            }
            return this.ExecSqlForObjectList<ProductOrder>(sbCache.ToString());
        }
        /// <summary>
        /// 查询订单记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetProductOrderRecord(int pageindex, int pagesize, string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,b.Accounts,b.NickName,c.ProductName,c.ProductType,isnull(D.IconID,99999) as IconID from ProductOrder as a 
                                left join QPAccountsDB.dbo.AccountsInfo as b on a.UserID=b.UserID
                                left join Product as c on a.ProductPid = c.Pid
                                Left JOIN ProductIcon(NOLOCK) AS D  ON c.Pid=D.ProductID");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "CTime DESC", null);
        }

        /// <summary>
        /// 查询订单明细记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public MallBuyDetail GetProductOrderDetailObject(string orderid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select * from MallBuyDetail where OrderID=@OrderID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("OrderID", orderid));
            return ExecSqlForObject<MallBuyDetail>(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 查询订单明细记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetProductOrderDetailRecord(int pageindex, int pagesize, string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from MallBuyDetail");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "CTime DESC", null);
        }
        #endregion

        #region 新版充值 金豆充值
        /// <summary>
        /// 创建充值金豆订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRechOrder(RechOrder entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramOrderID", entity.OrderID));
            prams.Add(MakeInParam("paramUserID", entity.UserID));
            prams.Add(MakeInParam("paramOperUserID", entity.OperUserID));
            prams.Add(MakeInParam("paramShareID", entity.ShareID));
            prams.Add(MakeInParam("paramOrderAmount", entity.OrderAmount));
            prams.Add(MakeInParam("paramDiscountScale", entity.DiscountScale));
            prams.Add(MakeInParam("paramPayAmount", entity.PayAmount));
            prams.Add(MakeInParam("paramOrderStatus", entity.OrderStatus));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_WEB_InsertRechOrder", prams);
        }

        /// <summary>
        /// 快钱RMB充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechGoldenBeanFromKQRMB(ReturnKQDetailInfo returnInfo)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("strMerchantAcctID", returnInfo.MerchantAcctID));
            parms.Add(MakeInParam("strVersion", returnInfo.Version));
            parms.Add(MakeInParam("dwLanguage", returnInfo.Language));
            parms.Add(MakeInParam("dwSignType", returnInfo.SignType));
            parms.Add(MakeInParam("strPayType", returnInfo.PayType));
            parms.Add(MakeInParam("strBankID", returnInfo.BankID));
            parms.Add(MakeInParam("strOrderID", returnInfo.OrderID));
            parms.Add(MakeInParam("dtOrderTime", returnInfo.OrderTime));
            parms.Add(MakeInParam("fOrderAmount", returnInfo.OrderAmount));
            parms.Add(MakeInParam("strDealID", returnInfo.DealID));
            parms.Add(MakeInParam("strBankDealID", returnInfo.BankDealID));
            parms.Add(MakeInParam("dtDealTime", returnInfo.DealTime));
            parms.Add(MakeInParam("fPayAmount", returnInfo.PayAmount));
            parms.Add(MakeInParam("fFee", returnInfo.Fee));
            parms.Add(MakeInParam("strPayResult", returnInfo.PayResult));
            parms.Add(MakeInParam("strErrCode", returnInfo.ErrCode));
            parms.Add(MakeInParam("strSignMsg", returnInfo.SignMsg));
            parms.Add(MakeInParam("strExt1", returnInfo.Ext1));
            parms.Add(MakeInParam("strExt2", returnInfo.Ext2));
            parms.Add(MakeInParam("CardNumber", returnInfo.CardNumber));
            parms.Add(MakeInParam("CardPwd", returnInfo.CardPwd));
            parms.Add(MakeInParam("BossType", returnInfo.BossType));
            parms.Add(MakeInParam("ReceiveBossType", returnInfo.ReceiveBossType));
            parms.Add(MakeInParam("ReceiverAcctId", returnInfo.ReceiverAcctId));
            parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));

            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_RechGoldenBeanFromKQRMB", parms);
        }

        /// <summary>
        /// 快钱充值卡充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechGoldenBeanFromKQCARD(ReturnKQCardDetailInfo returnInfo)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("parmMerchantAcctId ", returnInfo.MerchantAcctId));
            parms.Add(MakeInParam("parmVersion", returnInfo.Version));
            parms.Add(MakeInParam("parmLanguage", returnInfo.Language));
            parms.Add(MakeInParam("parmPayType", returnInfo.PayType));
            parms.Add(MakeInParam("parmCardNumber", returnInfo.CardNumber));
            parms.Add(MakeInParam("parmCardPwd", returnInfo.CardPwd));
            parms.Add(MakeInParam("parmOrderId", returnInfo.OrderId));
            parms.Add(MakeInParam("parmOrderAmount", returnInfo.OrderAmount));
            parms.Add(MakeInParam("parmDealId", returnInfo.DealId));
            parms.Add(MakeInParam("parmOrderTime", returnInfo.OrderTime));
            parms.Add(MakeInParam("parmExt1", returnInfo.Ext1));
            parms.Add(MakeInParam("parmExt2", returnInfo.Ext2));
            parms.Add(MakeInParam("parmPayAmount", returnInfo.PayAmount));
            parms.Add(MakeInParam("parmBillOrderTime", returnInfo.BillOrderTime));
            parms.Add(MakeInParam("parmPayResult", returnInfo.PayResult));
            parms.Add(MakeInParam("parmSignType", returnInfo.SignType));
            parms.Add(MakeInParam("parmBossType", returnInfo.BossType));
            parms.Add(MakeInParam("parmReceiveBossType", returnInfo.ReceiveBossType));
            parms.Add(MakeInParam("parmReceiverAcctId", returnInfo.ReceiverAcctId));
            parms.Add(MakeInParam("parmSignMsg", returnInfo.SignMsg));

            parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_RechGoldenBeanFromKQCARD", parms);
        }

        /// <summary>
        /// 支付宝充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechGoldenBeanFromZFB(ReturnZFBDetailInfo returnInfo)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("Is_success", returnInfo.Is_success));
            parms.Add(MakeInParam("Sign_type", returnInfo.Sign_type));
            parms.Add(MakeInParam("Sign", returnInfo.Sign));
            parms.Add(MakeInParam("Out_trade_no", returnInfo.Out_trade_no));
            parms.Add(MakeInParam("Subject", returnInfo.Subject));
            parms.Add(MakeInParam("Payment_type", returnInfo.Payment_type));
            parms.Add(MakeInParam("Exterface", returnInfo.Exterface));
            parms.Add(MakeInParam("Trade_no", returnInfo.Trade_no));
            parms.Add(MakeInParam("Trade_status", returnInfo.Trade_status));
            parms.Add(MakeInParam("Notify_id", returnInfo.Notify_id));
            parms.Add(MakeInParam("Notify_time", returnInfo.Notify_time));
            parms.Add(MakeInParam("Notify_type", returnInfo.Notify_type));
            parms.Add(MakeInParam("Seller_email", returnInfo.Seller_email));
            parms.Add(MakeInParam("Buyer_email", returnInfo.Buyer_email));
            parms.Add(MakeInParam("Seller_id", returnInfo.Seller_id));
            parms.Add(MakeInParam("Buyer_id", returnInfo.Buyer_id));
            parms.Add(MakeInParam("Total_fee", returnInfo.Total_fee));
            parms.Add(MakeInParam("Body", returnInfo.Body));
            parms.Add(MakeInParam("Extra_common_param", returnInfo.Extra_common_param));
            parms.Add(MakeInParam("Agent_user_id", returnInfo.Agent_user_id));

            parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_RechGoldenBeanFromZFB", parms);
        }
        /// <summary>
        /// 支付宝充值vip房间道具 更新订单信息
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechVIPFromZFB(ReturnZFBDetailInfo returnInfo)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("Is_success", returnInfo.Is_success));
            parms.Add(MakeInParam("Sign_type", returnInfo.Sign_type));
            parms.Add(MakeInParam("Sign", returnInfo.Sign));
            parms.Add(MakeInParam("Out_trade_no", returnInfo.Out_trade_no));
            parms.Add(MakeInParam("Subject", returnInfo.Subject));
            parms.Add(MakeInParam("Payment_type", returnInfo.Payment_type));
            parms.Add(MakeInParam("Exterface", returnInfo.Exterface));
            parms.Add(MakeInParam("Trade_no", returnInfo.Trade_no));
            parms.Add(MakeInParam("Trade_status", returnInfo.Trade_status));
            parms.Add(MakeInParam("Notify_id", returnInfo.Notify_id));
            parms.Add(MakeInParam("Notify_time", returnInfo.Notify_time));
            parms.Add(MakeInParam("Notify_type", returnInfo.Notify_type));
            parms.Add(MakeInParam("Seller_email", returnInfo.Seller_email));
            parms.Add(MakeInParam("Buyer_email", returnInfo.Buyer_email));
            parms.Add(MakeInParam("Seller_id", returnInfo.Seller_id));
            parms.Add(MakeInParam("Buyer_id", returnInfo.Buyer_id));
            parms.Add(MakeInParam("Total_fee", returnInfo.Total_fee));
            parms.Add(MakeInParam("Body", returnInfo.Body));
            parms.Add(MakeInParam("Extra_common_param", returnInfo.Extra_common_param));
            parms.Add(MakeInParam("Agent_user_id", returnInfo.Agent_user_id));

            parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_RechVIPFromZFB", parms);
        }

        /// <summary>
        ///微信充值vip房间道具 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechVIPFromWX(ReturnWeixinDetailInfo returnInfo)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("return_code", returnInfo.return_code));
            parms.Add(MakeInParam("return_msg", returnInfo.return_msg));
            parms.Add(MakeInParam("appid", returnInfo.appid));
            parms.Add(MakeInParam("mch_id", returnInfo.mch_id));
            parms.Add(MakeInParam("device_info", returnInfo.device_info));
            parms.Add(MakeInParam("nonce_str", returnInfo.nonce_str));
            parms.Add(MakeInParam("sign", returnInfo.sign));
            parms.Add(MakeInParam("result_code", returnInfo.result_code));
            parms.Add(MakeInParam("err_code", returnInfo.err_code));
            parms.Add(MakeInParam("err_code_des", returnInfo.err_code_des));
            parms.Add(MakeInParam("openid", returnInfo.openid));
            parms.Add(MakeInParam("is_subscribe", returnInfo.is_subscribe));
            parms.Add(MakeInParam("trade_type", returnInfo.trade_type));
            parms.Add(MakeInParam("bank_type", returnInfo.bank_type));
            parms.Add(MakeInParam("total_fee", returnInfo.total_fee));
            parms.Add(MakeInParam("coupon_fee", returnInfo.coupon_fee));
            parms.Add(MakeInParam("fee_type", returnInfo.fee_type));
            parms.Add(MakeInParam("transaction_id", returnInfo.transaction_id));
            parms.Add(MakeInParam("out_trade_no", returnInfo.out_trade_no));
            parms.Add(MakeInParam("attach", returnInfo.attach));
            parms.Add(MakeInParam("time_end", returnInfo.time_end));
            parms.Add(MakeInParam("json", returnInfo.json));

            parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_RechVIPFromWX", parms);
        }
        /// <summary>
        /// 微信二维码充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechGoldenBeanFromWeixin(ReturnWeixinDetailInfo returnInfo)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("return_code", returnInfo.return_code));
            parms.Add(MakeInParam("return_msg", returnInfo.return_msg));
            parms.Add(MakeInParam("appid", returnInfo.appid));
            parms.Add(MakeInParam("mch_id", returnInfo.mch_id));
            parms.Add(MakeInParam("device_info", returnInfo.device_info));
            parms.Add(MakeInParam("nonce_str", returnInfo.nonce_str));
            parms.Add(MakeInParam("sign", returnInfo.sign));
            parms.Add(MakeInParam("result_code", returnInfo.result_code));
            parms.Add(MakeInParam("err_code", returnInfo.err_code));
            parms.Add(MakeInParam("err_code_des", returnInfo.err_code_des));
            parms.Add(MakeInParam("openid", returnInfo.openid));
            parms.Add(MakeInParam("is_subscribe", returnInfo.is_subscribe));
            parms.Add(MakeInParam("trade_type", returnInfo.trade_type));
            parms.Add(MakeInParam("bank_type", returnInfo.bank_type));
            parms.Add(MakeInParam("total_fee", returnInfo.total_fee));
            parms.Add(MakeInParam("coupon_fee", returnInfo.coupon_fee));
            parms.Add(MakeInParam("fee_type", returnInfo.fee_type));
            parms.Add(MakeInParam("transaction_id", returnInfo.transaction_id));
            parms.Add(MakeInParam("out_trade_no", returnInfo.out_trade_no));
            parms.Add(MakeInParam("attach", returnInfo.attach));
            parms.Add(MakeInParam("time_end", returnInfo.time_end));
            parms.Add(MakeInParam("json", returnInfo.json));

            parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_RechGoldenBeanFromWeixin", parms);
        }

        /// <summary>
        /// 天下付充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechGoldenBeanFromTXF(string orderID)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("strOrderID", orderID));
            parms.Add(MakeInParam("strIPAddress", GameRequest.GetUserIP()));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_RechGoldenBeanFromTXF", parms);
        }

        /// <summary>
        /// 查询用户金豆信息
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public UserGoldenBean GetUserGoldenBean(int userid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from UserGoldenBean where UserID=@UserID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", userid));
            return ExecSqlForObject<UserGoldenBean>(sbCache.ToString(), prams);
        }

        /// <summary>
        /// 查询充值金豆订单信息
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public RechOrder GetRechOrderByOrderID(string orderid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from RechOrder where OrderID=@OrderID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("OrderID", orderid));
            return ExecSqlForObject<RechOrder>(sbCache.ToString(), prams);
        }

        ///// <summary>
        ///// 使用金豆购买会员和金币
        ///// </summary>
        ///// <param name="userid"></param>
        ///// <param name="memberorder"></param>
        ///// <param name="number"></param>
        ///// <returns></returns>
        //public Message ConvertGoldenBeanToMemberAndGold(int userid, int number)
        //{
        //    var parms = new List<DbParameter>();
        //    parms.Add(MakeInParam("paramUserID", userid));
        //    parms.Add(MakeInParam("paramGoldenBeanNumber", number));
        //    parms.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
        //    parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
        //    return ExecProcForMessage("NET_WEB_ConvertGoldenBeanToMemberAndGold", parms);
        //}

        /// <summary>
        /// 查询充值金豆规则
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public Message QueryRechRules(int userid, decimal orderamount)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramUserID", userid));
            parms.Add(MakeInParam("paramOrderAmount", orderamount));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageObjectList<RechActivityRules>("NET_WEB_QueryRechRules", parms);
        }

        /// <summary>
        /// 查询金豆交易记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetRecordUserGoldenBean(int pageindex, int pagesize, string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,b.Accounts,b.NickName from RecordUserGoldenBean as a 
                                left join QPAccountsDB.dbo.AccountsInfo as b on a.UserID=b.UserID");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "CTime DESC", null);
        }
        #endregion

        #region 新版奖牌、魅力值
        /// <summary>
        /// 查询用户金豆信息
        /// author:francis
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public GameScoreInfoEx GetGameScoreInfoEx(int userid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT TOP 1 [UserId],[UserMedal],[LoveLiness]
                                  ,ISNULL((SELECT SUM([PCount]) FROM [QPGamePropertyDB].[dbo].[UserProperty] 
	                                 WHERE [UserID]=@UserID AND [PID] IN (SELECT [PID] FROM [QPGamePropertyDB].[dbo].[PropertyCFG] WHERE [PropType]=8)),0) AS BillVolume
                              FROM [QPTreasureDB].[dbo].[GameScoreInfoEx] 
                              WHERE [UserID]=@UserID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", userid));
            return ExecSqlForObject<GameScoreInfoEx>(sbCache.ToString(), prams);
        }
        #endregion

        #region 新版任务系统
        /// <summary>
        /// 查询任务记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="wherestr"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetUserTaskRecord(int pageindex, int pagesize, string wherestr, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from UserTask");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where 1=1 ").Append(wherestr);
            }
            if (string.IsNullOrEmpty(order))
            {
                order = "PublishTime DESC";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }
        /// <summary>
        /// 修改任务状态
        /// </summary>
        /// <param name="taskid"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public bool UpdateUserTaskStatusByTaskID(int taskid, int userid)
        {
            int count = 0;
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"update UserTask set Status={0} where TaskID={1} and UserID={2}", (int)Game.Type.UserTaskStatus.已接, taskid, userid);
            count = ExecSqlNonQuery(sbCache.ToString());
            return count > 0;
        }
        #endregion

        #region 美女视频
        /// <summary>
        /// 美女扣费记录
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message ProcessMeinvFee(RecordMeinvFee entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramuId", entity.uId));
            prams.Add(MakeInParam("paramtransactionId", entity.transactionId));
            prams.Add(MakeInParam("paramgoodsId", entity.goodsId));
            prams.Add(MakeInParam("paramgoodsName", entity.goodsName));
            prams.Add(MakeInParam("paramgoodsPrice", entity.goodsPrice));
            prams.Add(MakeInParam("paramgoodsItems", entity.goodsItems));
            prams.Add(MakeInParam("paramtotalPrice", entity.totalPrice));
            prams.Add(MakeInParam("paramcurrency", entity.currency));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeInParam("paramCTime", DateTime.Now));
            prams.Add(MakeInParam("paramServerID", entity.ServerID));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_ProcessMeinvFee", prams);
        }

        /// <summary>
        /// 新增美女主播浏览记录
        /// </summary>
        /// <param name="entity"></param>
        public void InsertRecordMeinvSPBrowse(RecordMeinvSPBrowse entity)
        {
            string sql = "insert into QPGameLogDB.dbo.RecordMeinvSPBrowse(UserID,DateID,InsertTime) values(@UserID,@DateID,@InsertTime)";
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", entity.UserID));
            prams.Add(MakeInParam("DateID", (DateTime.Now - Convert.ToDateTime("1970-01-01 00:00:00")).TotalSeconds));
            prams.Add(MakeInParam("InsertTime", DateTime.Now));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            ExecSqlNonQuery(sql, prams);
        }
        #endregion

        #region 互动道具
        /// <summary>
        /// 获取互动道具配置
        /// </summary>
        /// <returns></returns>
        public DataSet GetInteractItem()
        {
            return ExecSqlForDataSet("SELECT [serverid],[itmeid],[score] FROM [QPTreasureDB].[dbo].[InteractItem]");
        }
        #endregion
        #region vip房间充值配置获取
        /// <summary>
        /// vip房间充值配置获取
        /// </summary>
        public DataSet GetVipRechargeReward()
        {
            StringBuilder sbsql = new StringBuilder();
            sbsql.Append("SELECT * FROM  [QPMobileAppDB].[dbo].[VipRechargeReward]");
            return ExecSqlForDataSet(sbsql.ToString());
        }
        /// <summary>
        /// 查询返利记录
        /// </summary>
        public DataSet GetRebateDetail(int pageindex, int pagesize, int userid, string stime, string etime)
        {
            string where = "";
            if (stime != null && stime.Length > 0)
            {
                where += " and InsertTime>='" + Convert.ToDateTime(stime) + "'";
            }
            if (etime != null && etime.Length > 0)
            {
                where += " and InsertTime<'" + Convert.ToDateTime(etime).AddDays(1) + "'";
            }
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT a.*,(case when weixinname='' then nickname else weixinname end) as name  FROM [QPTreasureDB].[dbo].[RecordRebate] as a left join  [QPAccountsDB].[dbo].[AccountsInfo] as b on a.SourceUserID=b.userid where a.userid={0} {1}", userid, where);
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "id DESC", null);
        }
        /// <summary>
        /// 根据条件获取返利数量
        /// </summary>
        /// <param name="where"></param>
        /// <returns></returns>
        public int GetRebateCount(string where)
        {
            return Convert.ToInt32(ExecSqlScalar("select isnull(sum([count]),0) from [QPTreasureDB].[dbo].[RecordRebate] where 1=1 " + where));
        }
        #endregion
    }
}
