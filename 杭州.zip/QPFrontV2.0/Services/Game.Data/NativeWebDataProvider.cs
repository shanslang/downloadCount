﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.NativeWeb;
using Game.Utils;
using Game.Type;

namespace Game.Data
{
    /// <summary>
    /// 网站数据访问层
    /// </summary>
    public class NativeWebDataProvider : DBHelper, INativeWebDataProvider
    {
        #region 测试DB
        public DataSet TestTableLock()
        {
            this.ExecProcForMessage("[QPGameLogDB].[dbo].[TestLock1]");

            return null;
        }
        #endregion

        #region 构造方法
        public NativeWebDataProvider(string dbname)
            : base(dbname)
        {

        }
        #endregion

        #region sql执行统计
        /// <summary>
        /// 
        /// </summary>
        /// <param name="top"></param>
        /// <returns></returns>
        public IList<Game.Francis.DBHelper.RecordQPFrontExecSQL> GetRecordQPFrontExecSQLList()
        {
            StringBuilder sqlQuery = new StringBuilder()
            .AppendFormat("SELECT * FROM QPGameLogDB.dbo.RecordQPFrontExecSQL ");
            return ExecSqlForObjectList<Game.Francis.DBHelper.RecordQPFrontExecSQL>(sqlQuery.ToString());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        public void InsertRecordQPFrontExecSQL(Dictionary<string, Game.Francis.DBHelper.RecordQPFrontExecSQL> data)
        {
            using (DbConnection conn = db.CreateConnection())
            {
                conn.Open();
                DbTransaction trans = conn.BeginTransaction();
                try
                {
                    //清理数据
                    DbCommand cmdtruncate = db.GetSqlStringCommand("truncate table QPGameLogDB.dbo.RecordQPFrontExecSQL");
                    db.ExecuteNonQuery(cmdtruncate, trans);
                    //同步新数据
                    foreach (KeyValuePair<string, Game.Francis.DBHelper.RecordQPFrontExecSQL> row in data)
                    {
                        var item = row.Value;
                        DbCommand cmd = db.GetSqlStringCommand("insert QPGameLogDB.dbo.RecordQPFrontExecSQL(Sqlmd5,Sql,ExecCount,ExecTotalMilliseconds,RecordTime) values(@Sqlmd5,@Sql,@ExecCount,@ExecTotalMilliseconds,@RecordTime)");
                        List<DbParameter> prams = new List<DbParameter>();
                        prams.Add(MakeInParam("Sqlmd5", item.Sqlmd5));
                        prams.Add(MakeInParam("Sql", item.Sql));
                        prams.Add(MakeInParam("ExecCount", item.ExecCount));
                        prams.Add(MakeInParam("ExecTotalMilliseconds", item.ExecTotalMilliseconds));
                        prams.Add(MakeInParam("RecordTime", item.RecordTime));
                        AddDbParameterForDbCommand(cmd, prams);
                        db.ExecuteNonQuery(cmd, trans);
                    }
                    //提交事务.
                    trans.Commit();
                }
                catch
                {
                    //回滚
                    trans.Rollback();
                }
                finally
                {
                    conn.Close();
                }
            }
        }
        #endregion

        #region 网站新闻

        /// <summary>
        /// 获取置顶新闻列表
        /// </summary>
        /// <param name="newsType"></param>
        /// <param name="hot"></param>
        /// <param name="elite"></param>
        /// <param name="top"></param>
        /// <returns></returns>
        public IList<News> GetTopNewsList(int typeID, int hot, int elite, int top)
        {
            StringBuilder sqlQuery = new StringBuilder()
            .AppendFormat("SELECT TOP({0}) ", top)
            .Append("NewsID, Subject,OnTop,OnTopAll,IsElite,IsHot,IsLinks,LinkUrl,HighLight,ClassID,IssueDate,LastModifyDate ")
            .Append("FROM News ");

            //查询条件
            sqlQuery.Append(" WHERE IsLock=1 AND IsDelete=0 ");

            //新闻类别
            if (typeID != 0)
            {
                sqlQuery.AppendFormat(" AND {0}={1} ", "ClassID", typeID);
            }

            //新闻状态            
            if (hot > 0)
            {
                sqlQuery.AppendFormat(" AND {0}={1} ", "IsHot", hot);
            }

            if (elite > 0)
            {
                sqlQuery.AppendFormat(" AND {0}={1} ", "IsElite", elite);
            }

            //排序
            sqlQuery.Append(" ORDER By OnTopAll DESC,OnTop DESC,IssueDate DESC ,NewsID DESC");

            return ExecSqlForObjectList<News>(sqlQuery.ToString());
        }

        /// <summary>
        /// 获取新闻列表
        /// </summary>
        /// <returns></returns>
        public IList<News> GetNewsList()
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT NewsID,Subject,OnTop,OnTopAll,IsElite,IsHot,IsLinks,LinkUrl,ClassID,IssueDate, HighLight ")
                    .Append("FROM News ")
                    .Append("WHERE  IsLock=1 AND IsDelete=0 AND IssueDate <= '")
                    .Append(DateTime.Now.Date.ToString())
                    .Append("' ORDER By OnTopAll DESC,OnTop DESC,IssueDate DESC ,NewsID DESC");

            return ExecSqlForObjectList<News>(sqlQuery.ToString());
        }

        /// <summary>
        /// 获取分页新闻列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetNewsList(int pageIndex, int pageSize)
        {
            string sqlQuery = "select NewsID,Subject,OnTop,OnTopAll,IsElite,IsHot,Islinks,LinkUrl,ClassID,IssueDate,HighLight from News where IsLock=1 AND IsDelete=0";
            return GetPagination(pageIndex, pageSize, sqlQuery, null, "OnTopAll DESC,OnTop DESC,IssueDate DESC,NewsID DESC", null);
        }

        /// <summary>
        /// 获取分页新闻列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetNewsList(int pageIndex, int pageSize, string wherestr)
        {
            string sqlQuery = "select NewsID,Subject,OnTop,OnTopAll,IsElite,IsHot,Islinks,LinkUrl,ClassID,IssueDate,HighLight from News where IsLock=1 AND IsDelete=0";
            if (!string.IsNullOrEmpty(wherestr))
            {
                sqlQuery += " " + wherestr;
            }
            return GetPagination(pageIndex, pageSize, sqlQuery, null, "OnTopAll DESC,OnTop DESC,IssueDate DESC,NewsID DESC", null);
        }

        /// <summary>
        /// 获取新闻 by newsID
        /// </summary>
        /// <param name="newsID"></param>
        /// <param name="mode">模式选择, 0=当前主题, 1=上一主题, 2=下一主题</param>
        /// <returns></returns>
        public News GetNewsByNewsID(int newsID, byte mode)
        {
            News news = null;

            switch (mode)
            {
                case 1:
                    List<DbParameter> prams = new List<DbParameter>();
                    prams.Add(MakeInParam("dwNewsID", newsID));
                    prams.Add(MakeInParam("dwMode", 1));
                    news = ExecProcForObject<News>("NET_PW_GetNewsInfoByID", prams);
                    break;
                case 2:
                    List<DbParameter> pram = new List<DbParameter>();
                    pram.Add(MakeInParam("dwNewsID", newsID));
                    pram.Add(MakeInParam("dwMode", 2));
                    news = ExecProcForObject<News>("NET_PW_GetNewsInfoByID", pram);
                    break;
                default:
                    news = ExecSqlForObject<News>(string.Format("SELECT * FROM News(NOLOCK) WHERE IsLock=1 AND IsDelete=0 AND NewsID={0}", newsID));
                    break;
            }

            return news;
        }

        /// <summary>
        /// 获取公告
        /// </summary>
        /// <param name="noticeID"></param>
        /// <returns></returns>
        public Notice GetNotice(int noticeID)
        {
            string sqlQuery = string.Format("SELECT * FROM Notice(NOLOCK) WHERE NoticeID={0}", noticeID);
            Notice notice = ExecSqlForObject<Notice>(sqlQuery, null);
            return notice;
        }

        #endregion

        #region 网站问题

        /// <summary>
        /// 获取问题列表
        /// </summary>
        /// <param name="issueType"></param>
        /// <param name="top"></param>
        /// <returns></returns>
        public IList<GameIssueInfo> GetTopIssueList(int top)
        {
            StringBuilder sqlQuery = new StringBuilder()
            .AppendFormat("SELECT TOP({0}) ", top)
            .Append("IssueID,IssueTitle,IssueContent,Nullity,CollectDate,ModifyDate ")
            .Append("FROM GameIssueInfo ");

            //查询条件
            sqlQuery.Append(" WHERE Nullity=0 ");

            //排序
            sqlQuery.Append(" ORDER By CollectDate DESC");

            return ExecSqlForObjectList<GameIssueInfo>(sqlQuery.ToString());
        }

        /// <summary>
        /// 获取问题列表
        /// </summary>
        /// <returns></returns>
        public IList<GameIssueInfo> GetIssueList()
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT IssueID,IssueTitle,IssueContent,Nullity,CollectDate,ModifyDate ")
                    .Append("FROM GameIssueInfo ")
                    .Append("WHERE  Nullity=0 AND CollectDate <= '")
                    .Append(DateTime.Now.Date.ToString())
                    .Append("' ORDER By CollectDate DESC");

            return ExecSqlForObjectList<GameIssueInfo>(sqlQuery.ToString());
        }

        /// <summary>
        /// 获取分页问题列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetIssueList(int pageIndex, int pageSize)
        {
            string sqlQuery = "select IssueID,IssueTitle,IssueContent,Nullity,CollectDate,ModifyDate from GameIssueInfo where Nullity=0";
            return GetPagination(pageIndex, pageSize, sqlQuery, null, "CollectDate DESC", null);
        }

        /// <summary>
        /// 获取问题实体
        /// </summary>
        /// <param name="issueID"></param>
        /// <param name="mode">模式选择, 0=当前主题, 1=上一主题, 2=下一主题</param>
        /// <returns></returns>
        public GameIssueInfo GetIssueByIssueID(int issueID, byte mode)
        {
            GameIssueInfo Issue = null;

            switch (mode)
            {
                case 2:
                    Issue = ExecSqlForObject<GameIssueInfo>(string.Format("SELECT * FROM GameIssueInfo(NOLOCK) WHERE Nullity=-0 AND IssueID<{0} ORDER BY CollectDate DESC", issueID), null);
                    break;
                case 1:
                    Issue = ExecSqlForObject<GameIssueInfo>(string.Format("SELECT * FROM GameIssueInfo(NOLOCK) WHERE Nullity=0 AND IssueID>{0} ORDER BY CollectDate ASC", issueID), null);
                    break;
                case 0:
                default:
                    Issue = ExecSqlForObject<GameIssueInfo>(string.Format("SELECT * FROM GameIssueInfo(NOLOCK) WHERE Nullity=0 AND IssueID={0}", issueID), null);
                    break;
            }

            return Issue;
        }
        #endregion

        #region 反馈意见

        /// <summary>
        /// 获取分页反馈意见列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetFeedbacklist(int pageIndex, int pageSize)
        {
            string sqlQuery = "select FeedbackID,FeedbackTitle,FeedbackContent,Nullity,Accounts,FeedbackDate,ViewCount,RevertContent,RevertDate from GameFeedbackInfo where Nullity=0";
            return GetPagination(pageIndex, pageSize, sqlQuery, null, "FeedbackDate DESC", null);
        }

        /// <summary>
        /// 获取反馈意见实体
        /// </summary>
        /// <param name="issueID"></param>
        /// <param name="mode">模式选择, 0=当前主题, 1=上一主题, 2=下一主题</param>
        /// <returns></returns>
        public GameFeedbackInfo GetGameFeedBackInfo(int feedID, byte mode)
        {
            GameFeedbackInfo Issue = null;

            switch (mode)
            {
                case 1:
                    Issue = ExecSqlForObject<GameFeedbackInfo>(string.Format("SELECT * FROM GameFeedbackInfo(NOLOCK) WHERE Nullity=-0 AND FeedbackID<{0} ORDER BY FeedbackID DESC", feedID), null);
                    break;
                case 2:
                    Issue = ExecSqlForObject<GameFeedbackInfo>(string.Format("SELECT * FROM GameFeedbackInfo(NOLOCK) WHERE Nullity=0 AND FeedbackID>{0} ORDER BY FeedbackID ASC", feedID), null);
                    break;
                case 0:
                default:
                    Issue = ExecSqlForObject<GameFeedbackInfo>(string.Format("SELECT * FROM GameFeedbackInfo(NOLOCK) WHERE Nullity=0 AND FeedbackID={0}", feedID), null);
                    break;
            }

            return Issue;
        }

        /// <summary>
        /// 更新浏览量
        /// </summary>
        /// <param name="feedID"></param>
        public void UpdateFeedbackViewCount(int feedID)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("dwFeedbackID", feedID));
            ExecProcForMessage("NET_PW_UpdateViewCount", parms);
        }

        /// <summary>
        /// 发表留言
        /// </summary>
        /// <returns></returns>
        public Message PublishFeedback(GameFeedbackInfo info)
        {
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("strAccounts", info.Accounts));

            parms.Add(MakeInParam("strTitle", info.FeedbackTitle));
            parms.Add(MakeInParam("strContent", info.FeedbackContent));

            parms.Add(MakeInParam("strClientIP", info.ClientIP));
            parms.Add(MakeInParam("strQuestType", info.QuestType));
            parms.Add(MakeInParam("strContactw", info.Contactw));
            parms.Add(MakeInParam("strImageUrl", info.ImageUrl));
            parms.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PW_AddGameFeedback", parms);

        }
        /// <summary>
        /// 设置问题反馈的图片信息
        /// </summary>
        /// <param name="imageurl"></param>
        public void FeedbackSetImage(int entityid, string imageurl)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(string.Format("UPDATE GameFeedbackInfo SET ImageUrl='{0}' WHERE FeedbackID={1}", imageurl, entityid));
            ExecSqlNonQuery(sbCache.ToString());
        }
        #endregion

        #region 游戏帮助数据

        /// <summary>
        /// 获取推荐游戏详细列表
        /// </summary>
        /// <returns></returns>
        public IList<GameRulesInfo> GetGameHelps(int top)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.AppendFormat("SELECT TOP({0}) ", top)
                    .Append("KindID, KindName, ImgRuleUrl, HelpIntro, HelpRule, HelpGrade, JoinIntro, Nullity, CollectDate, ModifyDate ")
                    .Append("FROM GameRulesInfo ")
                    .Append("WHERE  Nullity=0 ")
                    .Append(" ORDER By CollectDate DESC");

            return ExecSqlForObjectList<GameRulesInfo>(sqlQuery.ToString());
        }

        /// <summary>
        /// 获取游戏详细信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        public GameRulesInfo GetGameHelp(int kindID)
        {
            StringBuilder sqlQuery = new StringBuilder();
            sqlQuery.Append("SELECT KindID, KindName, ImgRuleUrl, HelpIntro, HelpRule, HelpGrade, JoinIntro, Nullity, CollectDate, ModifyDate ")
                    .Append("FROM GameRulesInfo ")
                    .AppendFormat("WHERE KindID={0} ", kindID)
                    .Append(" ORDER By CollectDate DESC");

            return ExecSqlForObject<GameRulesInfo>(sqlQuery.ToString());
        }

        #endregion

        #region 游戏比赛信息

        /// <summary>
        /// 得到比赛列表
        /// </summary>
        /// <returns></returns>
        public IList<GameMatchInfo> GetMatchList()
        {
            string sql = "SELECT * FROM GameMatchInfo WHERE Nullity = 0 ORDER BY CollectDate DESC";
            return ExecSqlForObjectList<GameMatchInfo>(sql);
        }

        /// <summary>
        /// 得到比赛详细信息
        /// </summary>
        /// <param name="matchID"></param>
        /// <returns></returns>
        public GameMatchInfo GetMatchInfo(int matchID)
        {
            string sql = @"SELECT * FROM GameMatchInfo WHERE MatchID = @MatchID";
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("MatchID", matchID));
            return ExecSqlForObject<GameMatchInfo>(sql, parms);
        }

        /// <summary>
        /// 比赛报名
        /// </summary>
        /// <param name="userInfo"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public Message AddGameMatch(GameMatchUserInfo userInfo, string password)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("dwMatchID", userInfo.MatchID));
            prams.Add(MakeInParam("strAccounts", userInfo.Accounts));
            prams.Add(MakeInParam("strPassword", password));
            prams.Add(MakeInParam("strCompellation", userInfo.Compellation));
            prams.Add(MakeInParam("dwGender", userInfo.Gender));
            prams.Add(MakeInParam("strPassportID", userInfo.PassportID));
            prams.Add(MakeInParam("strMobilePhone", userInfo.MobilePhone));
            prams.Add(MakeInParam("strEMail", userInfo.EMail));
            prams.Add(MakeInParam("strQQ", userInfo.QQ));
            prams.Add(MakeInParam("strDwellingPlace", userInfo.DwellingPlace));
            prams.Add(MakeInParam("strPostalCode", userInfo.PostalCode));
            prams.Add(MakeInParam("strClientIP", userInfo.ClientIP));
            prams.Add(MakeOutParam("strErrorDescribe", DbType.String, 127));

            return ExecProcForMessage("NET_PW_AddGameMatchUser", prams);
        }

        #endregion

        #region 简易论坛
        /// <summary>
        /// 获取单条栏目信息
        /// </summary>
        /// <returns></returns>
        public InfoCatalog GetInfoCatalogByPid(int pid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("select * from InfoCatalog");
            sbCache.Append(" WHERE StateID=").Append((int)Game.Type.CommonState.正常);
            sbCache.Append(" AND Pid=").Append(pid);
            return ExecSqlForObject<InfoCatalog>(sbCache.ToString());
        }

        /// <summary>
        /// 获取栏目分类列表
        /// </summary>
        /// <returns></returns>
        public IList<InfoCatalog> GetInfoCatalogList(int top)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("select * from InfoCatalog");
            sbCache.Append(" WHERE StateID=").Append((int)Game.Type.CommonState.正常);
            sbCache.Append(" order by OrderID ASC");
            return ExecSqlForObjectList<InfoCatalog>(sbCache.ToString());
        }

        /// <summary>
        /// 获取单条列主题信息
        /// </summary>
        /// <returns></returns>
        public InfoTopic GetInfoTopicByPid(int pid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("select * from InfoTopic");
            sbCache.Append(" WHERE StateID=").Append((int)Game.Type.CommonState.正常);
            sbCache.Append(" AND Pid=").Append(pid);
            return ExecSqlForObject<InfoTopic>(sbCache.ToString());
        }

        /// <summary>
        /// 获取主题列表
        /// </summary>
        /// <returns></returns>
        public DataSet GetInfoTopicList(int pageindex, int pagesize, string where, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,b.CataName,b.CataIndex,c.NickName,
                            (select top 1 CTime from infoitem where TopicID=a.Pid order by CTime DESC) as LRCTime,
                            (select top 1 CUserID from infoitem where TopicID=a.Pid order by CTime DESC) as LRUserID,
                            (select top 1 NickName from infoitem as aa 
                            left join QPAccountsDB.dbo.AccountsInfo as bb on aa.CUserID=bb.UserID
                            where aa.TopicID=a.Pid order by CTime DESC) as LRNickName
                            from InfoTopic as a
                            left join InfoCatalog as b on a.CataID=b.Pid
                            left join QPAccountsDB.dbo.AccountsInfo as c on a.CUserID=c.UserID");
            sbCache.Append(" WHERE a.StateID=").Append((int)Game.Type.CommonState.正常);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            if (string.IsNullOrEmpty(order))
            {
                order = "Pid DESC";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }

        /// <summary>
        /// 新增主题
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertInfoTopic(InfoTopic entity)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramTopicTypeID", entity.TopicTypeID));
            parms.Add(MakeInParam("paramCataID", entity.CataID));
            parms.Add(MakeInParam("paramItemNum", entity.ItemNum));
            parms.Add(MakeInParam("paramTitle", entity.Title));
            parms.Add(MakeInParam("paramContent", entity.Content));
            parms.Add(MakeInParam("paramSummary", entity.Summary));
            parms.Add(MakeInParam("paramAuthor", entity.Author));
            parms.Add(MakeInParam("paramTags", entity.Tags));
            parms.Add(MakeInParam("paramHits", entity.Hits));
            parms.Add(MakeInParam("paramFlagID", entity.FlagID));
            parms.Add(MakeInParam("paramDiggTop", entity.DiggTop));
            parms.Add(MakeInParam("paramDiggStep", entity.DiggStep));
            parms.Add(MakeInParam("paramStateID", entity.StateID));
            parms.Add(MakeInParam("paramUserID", entity.CUserID));
            parms.Add(MakeInParam("paramUserIP", entity.CUserIP));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("BBS_InsertInfoTopic", parms);
        }

        /// <summary>
        /// 修改主题
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message UpdateInfoTopicByPid(InfoTopic entity)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramPid", entity.Pid));
            parms.Add(MakeInParam("paramTopicTypeID", entity.TopicTypeID));
            parms.Add(MakeInParam("paramCataID", entity.CataID));
            parms.Add(MakeInParam("paramTitle", entity.Title));
            parms.Add(MakeInParam("paramContent", entity.Content));
            parms.Add(MakeInParam("paramSummary", entity.Summary));
            parms.Add(MakeInParam("paramAuthor", entity.Author));
            parms.Add(MakeInParam("paramTags", entity.Tags));
            parms.Add(MakeInParam("paramFlagID", entity.FlagID));
            parms.Add(MakeInParam("paramUserID", entity.EUserID));
            parms.Add(MakeInParam("paramUserIP", entity.EUserIP));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("BBS_UpdateInfoTopic", parms);
        }

        /// <summary>
        /// 修改主题点击次数
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message UpdateInfoTopicHitsByPid(InfoTopic entity)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramPid", entity.Pid));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("BBS_UpdateHits", parms);
        }

        /// <summary>
        /// 删除主题
        /// </summary>
        /// <returns></returns>
        public Message DeleteInfoTopicByPid(InfoTopic entity)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramPid", entity.Pid));
            parms.Add(MakeInParam("paramStateID", entity.StateID));
            parms.Add(MakeInParam("paramEUserID", entity.CUserID));
            parms.Add(MakeInParam("paramEUserIP", entity.CUserIP));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("BBS_DeleteInfoTopic", parms);
        }

        /// <summary>
        /// 获取回复列表
        /// </summary>
        /// <returns></returns>
        public DataSet GetInfoItemList(int pageindex, int pagesize, string where, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,b.Title,c.UserID,c.NickName,c.Experience,c.MemberOrder,c.FaceID from infoitem as a
                                left join infotopic as b on a.TopicID=b.Pid
                                left join QPAccountsDB.dbo.AccountsInfo as c on a.CUserID=c.UserID");
            sbCache.Append(" WHERE a.StateID=").Append((int)Game.Type.CommonState.正常);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            if (string.IsNullOrEmpty(order))
            {
                order = "Pid ASC";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }

        /// <summary>
        /// 新增回复
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertInfoItem(InfoItem entity)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramTopicID", entity.TopicID));
            parms.Add(MakeInParam("paramContent", entity.Content));
            parms.Add(MakeInParam("paramStateID", entity.StateID));
            parms.Add(MakeInParam("paramCUserID", entity.CUserID));
            parms.Add(MakeInParam("paramCUserIP", entity.CUserIP));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("BBS_InsertInfoItem", parms);
        }

        /// <summary>
        /// 删除回复
        /// </summary>
        /// <returns></returns>
        public Message DeleteInfoItemByPid(InfoItem entity)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramPid", entity.Pid));
            parms.Add(MakeInParam("paramStateID", entity.StateID));
            parms.Add(MakeInParam("paramEUserID", entity.CUserID));
            parms.Add(MakeInParam("paramEUserIP", entity.CUserIP));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("BBS_DeleteInfoItem", parms);
        }
        #endregion

        #region 友情链接
        /// <summary>
        /// 获取友情链接列表
        /// </summary>
        /// <returns></returns>
        public DataSet GetFriendLinksList(int pageindex, int pagesize, string where, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT * FROM FriendLinks");
            sbCache.Append(" WHERE StateID=").Append((int)Game.Type.CommonState.正常);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            if (string.IsNullOrEmpty(order))
            {
                order = "Pid DESC";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }
        #endregion

        #region 推广系统
        /// <summary>
        /// 验证推广ID是否存在
        /// </summary>
        /// <param name="SpreadID"></param>
        /// <returns></returns>
        public int ExistsSpreadUserID(int gameid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select TOP 1 u.UserID from QPAccountsDB.dbo.AccountsInfo(NOLOCK) as u
                            inner join  [QPNativeWebDB].[dbo].[SpreadUser](NOLOCK) as b
                            on u.GameID=@gameid and u.userid=b.UserID");
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("gameid", gameid));
            DataSet ds = ExecSqlForDataSet(sbCache.ToString(), parms);
            int result = -1;
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                result = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
            }
            return result;
        }
        /// <summary>
        /// 建立推广员关系
        /// </summary>
        /// <returns></returns>
        public bool SpreadUserBindingSet(int UserID, int SpreadUserID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"IF NOT EXISTS(SELECT 1 FROM QPNativeWebDB.dbo.RecordTrackRegister(NOLOCK) WHERE SpreadUserID=@SpreaderID AND RegUserID=@NewUserID)	
                             BEGIN 
	                            IF 0<(SELECT COUNT(1) FROM QPNativeWebDB.dbo.SpreadUser(NOLOCK) WHERE UserID=@SpreaderID)
		                            AND NOT EXISTS(SELECT 1 FROM QPNativeWebDB.dbo.SpreadUserAccounts(NOLOCK) WHERE UserID=@NewUserID)
	                            BEGIN
		                            INSERT INTO QPNativeWebDB.dbo.RecordTrackRegister(SpreadUserID,RegUserID,RegTime,ClientIP)
		                            VALUES(@SpreaderID,@NewUserID,getdate(),@strClientIP) 
		                            INSERT INTO QPNativeWebDB.dbo.SpreadUserAccounts(SpreadUserID,UserID,CTime) 
		                            VALUES(@SpreaderID,@NewUserID,@cTime)
		                            UPDATE [QPAccountsDB].[dbo].[AccountsInfo]
		                            SET [SpreaderID]=@SpreaderID
		                            WHERE [UserID]=@NewUserID
	                            END
                             END");
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("SpreaderID", SpreadUserID));
            parms.Add(MakeInParam("NewUserID", UserID));
            parms.Add(MakeInParam("strClientIP", GameRequest.GetUserIP()));
            parms.Add(MakeInParam("cTime", DateTime.Now));
            return ExecSqlNonQuery(sbCache.ToString(), parms) > 0;
        }
        /// <summary>
        /// 新增推广员
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertSpreadUser(SpreadUser entity)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramUserID", entity.UserID));
            parms.Add(MakeInParam("paramName", entity.Name));
            parms.Add(MakeInParam("paramSpreadUserNature", entity.SpreadUserNature));
            parms.Add(MakeInParam("paramSex", entity.Sex));
            parms.Add(MakeInParam("paramTelephone", entity.Telephone));
            parms.Add(MakeInParam("paramQQ", entity.QQ));
            parms.Add(MakeInParam("paramEmail", entity.Email));
            parms.Add(MakeInParam("paramAddress", entity.Address));
            parms.Add(MakeInParam("paramPostCode", entity.PostCode));
            parms.Add(MakeInParam("paramRemark", entity.Remark));
            parms.Add(MakeInParam("paramStateID", entity.StateID));
            parms.Add(MakeInParam("paramAuditStateID", entity.AuditStateID));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_WEB_InsertSpreadUser", parms);
        }
        /// <summary>
        /// 新增浏览记录
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRecordRecordTrackBrowse(RecordTrackBrowse entity)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramUserID", entity.UserID));
            parms.Add(MakeInParam("paramPageUrl", entity.PageUrl));
            parms.Add(MakeInParam("paramClientIP", entity.ClientIP));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_WEB_InsertRecordRecordTrackBrowse", parms);
        }
        /// <summary>
        /// 获取推广员信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        public SpreadUser GetSpreadUserByUserID(int userid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT * FROM QPNativeWebDB.dbo.SpreadUser");
            sbCache.Append(" WHERE UserID=").Append(userid);
            return ExecSqlForObject<SpreadUser>(sbCache.ToString());
        }
        /// <summary>
        /// 新增推广财务信息
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertSpreadFinanceInfo(SpreadFinanceInfo entity)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramSpreadUserPid", entity.SpreadUserPid));
            parms.Add(MakeInParam("paramFinanceNature", entity.FinanceNature));
            parms.Add(MakeInParam("paramBankName", entity.BankName));
            parms.Add(MakeInParam("paramBankAddress", entity.BankAddress));
            parms.Add(MakeInParam("paramBankAccount", entity.BankAccount));
            parms.Add(MakeInParam("paramBankPerson", entity.BankPerson));
            parms.Add(MakeInParam("paramIdentityCode", entity.IdentityCode));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_WEB_InsertSpreadFinanceInfo", parms);
        }
        /// <summary>
        /// 获取推广员财务信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        public SpreadFinanceInfo GetSpreadFinanceInfoBySpreadUserID(int spreaduserpid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT * FROM QPNativeWebDB.dbo.SpreadFinanceInfo");
            sbCache.Append(" WHERE SpreadUserPid=").Append(spreaduserpid);
            return ExecSqlForObject<SpreadFinanceInfo>(sbCache.ToString());
        }
        /// <summary>
        /// 获取推广员审核的最新信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        public RecordSpreadUserAudit GetSpreadUserLastAuditInfo(int spreaduserid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT TOP 1 * FROM QPNativeWebDB.dbo.RecordSpreadUserAudit");
            sbCache.Append(" WHERE SpreadUserPid=").Append(spreaduserid);
            sbCache.Append(" ORDER BY AuditDate DESC");
            return ExecSqlForObject<RecordSpreadUserAudit>(sbCache.ToString());
        }

        /// <summary>
        /// 获取推广注册记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetSpreadRegRecord(int pageindex, int pagesize, string where, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,b.GameID,b.NickName,ISNULL(b.PlayTimeCount,0) AS PlayTimeCount,GameLogonTimes,
                           
                            (select ISNULL(SUM(OrderAmount),0) as OrderAmount from [QPTreasureDB].[dbo].[ShareDetailInfo] where UserID=a.RegUserID) as OrderAmount                        
                         
                            from QPNativeWebDB.dbo.RecordTrackRegister as a
                            left join QPAccountsDB.dbo.AccountsInfo as b on a.RegUserID=b.UserID
                            ");
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" WHERE ").Append(where);
            }
            if (string.IsNullOrEmpty(order))
            {
                order = "Pid DESC";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }
        /// <summary>
        /// 获取推广充值记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetSpreadRechRecord(int pageindex, int pagesize, string where, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,b.Accounts,b.NickName,c.OrderAmount from QPNativeWebDB.dbo.RecordTrackRech as a
                            left join QPAccountsDB.dbo.AccountsInfo as b on a.RechUserID=b.UserID
                            left join QPTreasureDB.dbo.ShareDetailInfo as c on a.RechOrderID=c.OrderID");
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" WHERE ").Append(where);
            }
            if (string.IsNullOrEmpty(order))
            {
                order = "Pid DESC";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }
        /// <summary>
        /// 获取推广浏览记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetSpreadBrowseRecord(int spreaduserid, int pageindex, int pagesize, string where, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,b.Accounts,b.NickName from QPNativeWebDB.dbo.RecordTrackBrowse as a
                            left join QPAccountsDB.dbo.AccountsInfo as b on a.UserID=b.UserID");
            sbCache.AppendFormat(@" where a.UserID in(select UserID from QPNativeWebDB.dbo.SpreadUserAccounts where SpreadUserID={0})", spreaduserid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            if (string.IsNullOrEmpty(order))
            {
                order = "Pid DESC";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }
        /// <summary>
        /// 获取推广浏览记录 按天
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetSpreadBrowseRecordByDay(int spreaduserid, int pageindex, int pagesize, string where, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("select temp.CCTime,sum(temp.IPCount) as ClientIP,sum(temp.PVCount) as PageView from ");
            sbCache.Append("(select convert(nvarchar(10),CTime,20) as CCTime,IPCount,PVCount from [QPGameLogDB].[dbo].[SpreadInfoStatistics]");
            sbCache.AppendFormat(@" WHERE SpreadUserID={0}", spreaduserid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(where);
            }
            sbCache.Append(") as temp group by temp.CCTime");
            if (string.IsNullOrEmpty(order))
            {
                order = "Pid DESC";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }
        /// <summary>
        /// 获取推广业绩 按天
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetSpreadRecordByDay(int spreaduserid, int pageindex, int pagesize, string where, string order)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("select  * FROM [QPGameLogDB].[dbo].[SpreadInfoStatistics] ");
            sbCache.AppendFormat(@" WHERE SpreadUserID={0}", spreaduserid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(where);
            }
            if (string.IsNullOrEmpty(order))
            {
                order = "CTime DESC";
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, order, null);
        }

        /// <summary>
        /// 统计访问量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataRow GetSpreadBrowseTotal(int spreaduserid, string where)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select sum(IPCount) as IPCount,sum(PVCount) as PageView,sum(EffectCount) as EffectCount from [QPGameLogDB].[dbo].[SpreadInfoStatistics]");
            sbCache.AppendFormat(@" WHERE SpreadUserID={0}", spreaduserid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            DataSet ds = ExecSqlForDataSet(sbCache.ToString());
            if (ds.Tables[0].Rows.Count == 1)
            {
                return ds.Tables[0].Rows[0];
            }
            return null;
        }
        /// <summary>
        /// 统计注册人数
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataRow GetSpreadRegTotal(int spreaduserid, string where)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select count(*) as RegCount from QPNativeWebDB.dbo.RecordTrackRegister");
            sbCache.AppendFormat(@" WHERE SpreadUserID={0}", spreaduserid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            DataSet ds = ExecSqlForDataSet(sbCache.ToString());
            if (ds.Tables[0].Rows.Count == 1)
            {
                return ds.Tables[0].Rows[0];
            }
            return null;
        }
        /// <summary>
        /// 统计注册人数(通过手机认证)
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataRow GetSpreadRegTelephoneAuthTotal(int spreaduserid, string where)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select count(*) as RegCount from QPNativeWebDB.dbo.RecordTrackRegister as a
left join QPAccountsDB.dbo.AccountsInfo as b on a.RegUserID=b.UserID");
            sbCache.AppendFormat(@" WHERE a.SpreadUserID={0} and len(b.AuthMTelephone)=11", spreaduserid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            DataSet ds = ExecSqlForDataSet(sbCache.ToString());
            if (ds.Tables[0].Rows.Count == 1)
            {
                return ds.Tables[0].Rows[0];
            }
            return null;
        }
        /// <summary>
        /// 统计注册人数(有效用户 充值金额大于0  and 游戏时间大于20分钟)
        /// </summary>
        /// <param name="spreaduserid"></param>
        /// <param name="where"></param>
        /// <returns></returns>
        public DataRow GetSpreadRegEffectiveTotal(int spreaduserid, string where)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select COUNT(*) AS EffectiveCount from QPNativeWebDB.dbo.RecordTrackRegister as a
left join QPAccountsDB.dbo.AccountsInfo as b on a.RegUserID=b.UserID
where ((select ISNULL(SUM(OrderAmount),0) as OrderAmount from [QPTreasureDB].[dbo].[ShareDetailInfo] where UserID=a.RegUserID)>0
or b.PlayTimeCount>(20*60)) and a.SpreadUserID={0}", spreaduserid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            DataSet ds = ExecSqlForDataSet(sbCache.ToString());
            if (ds.Tables[0].Rows.Count == 1)
            {
                return ds.Tables[0].Rows[0];
            }
            return null;
        }
        /// <summary>
        /// 统计充值人数
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataRow GetSpreadRechTotal(int spreaduserid, string where)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select count(distinct RechUserID) as OrderCount,sum(b.OrderAmount) as OrderAmountTotal from QPNativeWebDB.dbo.RecordTrackRech as a
                            left join QPTreasureDB.dbo.ShareDetailInfo as b on a.RechOrderID=b.OrderID");
            sbCache.AppendFormat(@" WHERE SpreadUserID={0}", spreaduserid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            DataSet ds = ExecSqlForDataSet(sbCache.ToString());
            if (ds.Tables[0].Rows.Count == 1)
            {
                return ds.Tables[0].Rows[0];
            }
            return null;
        }
        /// <summary>
        /// 统计已经兑换兑换码数量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public int GetChannelIDCDKeyTotal(int channelid, string where)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select count(*) from [QPNativeWebDB].[dbo].[PackageCDKey] a 
left join [QPNativeWebDB].[dbo].[ChannelCFG] as b on a.[PackageTypePid]=b.[PackageTypePid]
left join [QPNativeWebDB].[dbo].[RecordConvertPackage] as c on a.[CDKey]=c.[CDKey]
where a.IsUse=1 and b.[ChannelID]={0} {1}", channelid, where);
            return Game.Utils.Utility.StrToInt(ExecSqlScalar(sbCache.ToString()), 0);
        }
        /// <summary>
        /// 统计活跃人数
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataRow GetSpreadActiveTotal(int spreaduserid, string where)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"select count(*) as LoginCount from QPNativeWebDB.dbo.RecordTrackRegister as a
WHERE SpreadUserID={0} and 
(select count(*) from [QPGameLogDB].[dbo].[RecordLoginInfo] as ca
left join QPAccountsDB.dbo.AccountsInfo as cb on ca.UserID=cb.UserID
where ca.UserID=a.RegUserID AND ca.LoginType in(0,2) AND ca.InsertTime<=DATEADD(DAY,15,cb.RegisterDate))>=3", spreaduserid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            DataSet ds = ExecSqlForDataSet(sbCache.ToString());
            if (ds.Tables[0].Rows.Count == 1)
            {
                return ds.Tables[0].Rows[0];
            }
            return null;
        }
        /// <summary>
        /// 统计结算提成
        /// </summary>
        /// <param name="spreaduserid"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        public DataRow CalculateSpreadUserCommission(int spreaduserid, DateTime date)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramSpreadUserID", spreaduserid));
            parms.Add(MakeInParam("paramCalculateTime", date));
            DataSet ds = ExecProcForDataSet("NET_WEB_CalculateSpreadUserCommission", parms);

            if (ds.Tables[0].Rows.Count == 1)
            {
                return ds.Tables[0].Rows[0];
            }
            return null;
        }
        /// <summary>
        /// 获取最近24笔 已经结算的记录
        /// </summary>
        /// <param name="spreaduserpid"></param>
        /// <param name="where"></param>
        /// <returns></returns>
        public DataTable GetSpreadSettlement(int spreaduserpid, string where)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select top 24 a.* from QPNativeWebDB.dbo.SpreadSettlement as a
                             left join QPNativeWebDB.dbo.SpreadUser as b on a.SpreadUserPid=b.Pid");
            sbCache.AppendFormat(@" WHERE a.SpreadUserPid={0}", spreaduserpid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.Append(" AND ").Append(where);
            }
            sbCache.Append(" order by SettlementEndTime DESC");
            return ExecSqlForDataSet(sbCache.ToString()).Tables[0];
        }
        /// <summary>
        /// 推广处理结算
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="settlementtype"></param>
        /// <returns></returns>
        public Message SpreadSettlementProcess(int pid, int settlementtype)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramPid", pid));
            parms.Add(MakeInParam("paramSettlementType", settlementtype));
            parms.Add(MakeInParam("paramClientIP", Game.Utils.GameRequest.GetUserIP()));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_WEB_SpreadSettlementProcess", parms);
        }
        #endregion

        #region 生成验证码
        /// <summary>
        /// 生成认证Code
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public string BuilderCheckCode(Game.Type.AuthUseType type, int userid, string telephone, string email)
        {
            string code = "";
            Random rand = new Random();
            string[] ary = new string[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
            for (int i = 1; i <= 6; i++) { code += ary[rand.Next(0, ary.Length - 1)]; }

            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramUseType", (int)type));
            prams.Add(MakeInParam("paramCheckCode", code));
            prams.Add(MakeInParam("paramTelephone", telephone));
            prams.Add(MakeInParam("paramEmail", email));
            prams.Add(MakeInParam("paramClientIP", Game.Utils.GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            Message msg = ExecProcForMessage("NET_PM_BuilderCheckCode", prams);
            if (msg.Success)
            {
                return code;
            }
            else
            {
                throw new Exception(msg.Content);
            }
        }
        /// <summary>
        /// 绑定手机
        /// </summary>
        public Message BindPhone(int userid, string code, string telephone)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramCheckCode", code));
            prams.Add(MakeInParam("paramTelephone", telephone));
            prams.Add(MakeInParam("paramClientIP", Game.Utils.GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_BindPhone", prams);
        }
        /// <summary>
        /// 生成认证Code
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public Message BuilderCheckCodeFormsg(Game.Type.AuthUseType type, int userid, string telephone, string email)
        {
            string code = "";
            Random rand = new Random();
            string[] ary = new string[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
            for (int i = 1; i <= 6; i++) { code += ary[rand.Next(0, ary.Length - 1)]; }

            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramUseType", (int)type));
            prams.Add(MakeInParam("paramCheckCode", code));
            prams.Add(MakeInParam("paramTelephone", telephone));
            prams.Add(MakeInParam("paramEmail", email));
            prams.Add(MakeInParam("paramClientIP", Game.Utils.GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            Message msg = ExecProcForMessage("NET_PM_BuilderCheckCode", prams);
            if (msg.Success) { msg.Content = code; }
            return msg;
        }
        /// <summary>
        /// 认证验证
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public Message AuthCheck(Game.Type.AuthUseType type, int userid, string code, string telephone, string email)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramUseType", (int)type));
            prams.Add(MakeInParam("paramCheckCode", code));
            prams.Add(MakeInParam("paramTelephone", telephone));
            prams.Add(MakeInParam("paramEmail", email));
            prams.Add(MakeInParam("paramClientIP", Game.Utils.GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_AuthCheck", prams);
        }
        /// <summary>
        /// 认证手机（不需要验证验证码）
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public Message AuthPhone(int userid, string telephone)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramTelephone", telephone));
            prams.Add(MakeInParam("paramClientIP", Game.Utils.GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_AuthTelephone", prams);
        }
        /// <summary>
        /// 认证验证新版
        /// </summary>
        public Message AuthCheckNew(int userid, string code, string telephone, string nickname, string password)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramCheckCode", code));
            prams.Add(MakeInParam("paramTelephone", telephone));
            prams.Add(MakeInParam("parmnickname", nickname));
            prams.Add(MakeInParam("parmpassword", password));
            prams.Add(MakeInParam("paramClientIP", Game.Utils.GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_AuthTelephoneV2", prams);
        }
        /// <summary>
        /// 验证验证码
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public Message VerificationCheckCode(Game.Type.AuthUseType type, int userid, string code, string telephone, string email)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramUseType", (int)type));
            prams.Add(MakeInParam("paramCheckCode", code));
            prams.Add(MakeInParam("paramTelephone", telephone));
            prams.Add(MakeInParam("paramEmail", email));
            prams.Add(MakeInParam("paramClientIP", Game.Utils.GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_CheckVerificationCode", prams);
        }
        #endregion

        #region 每日签到
        /// <summary>
        /// 每日领取金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRecordDailySign(RecordDailySign entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", entity.UserID));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_InsertRecordDailySign", prams);
        }
        /// <summary>
        /// 获取当月签到记录
        /// </summary>
        /// <returns></returns>
        public IList<RecordDailySign> GetCurrentMonthDailySignList(int userid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT TOP 10 *  FROM RecordDailySign");
            sbCache.AppendFormat(" WHERE UserID={0} AND CONVERT(NVARCHAR(7),GETDATE(),23)='{1}'", userid, DateTime.Now.ToString("yyyy-MM"));
            sbCache.Append(" ORDER BY SignTime DESC ");
            return ExecSqlForObjectList<RecordDailySign>(sbCache.ToString());
        }
        /// <summary>
        /// 获取签到奖励配置信息
        /// </summary>
        /// <returns></returns>
        public DataSet GetSignRewardCFGList()
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select s.*,p.name as PName ,i.IconName,i.IconUrl,i.IconMd5
                            from [dbo].[SignRewardCFG] as s 
                            left join QPGamePropertyDB.dbo.PropertyCFG(nolock) as p on s.RewardValue-65536=p.Pid
                            left join QPMobileAppDB.dbo.AppIcon(NOLOCK) AS i
                            on i.IconID=s.IconID WHERE RangeType<>1 ");
            return ExecSqlForDataSet(sbCache.ToString());
        }

        #endregion

        #region 许愿活动
        /// <summary>
        /// 获得母亲节许愿活动
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public void InsertActivityWishing(ActivityWishing o)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"insert into ActivityWishing(UserID,WishTo,WishFrom,Content,GiftImg,Backgound,CTime,ClientIP) values(@UserID,@WishTo,@WishFrom,@Content,@GiftImg,@Backgound,@CTime,@ClientIP)");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("UserID", o.UserID));
            prams.Add(MakeInParam("WishTo", o.WishTo));
            prams.Add(MakeInParam("WishFrom", o.WishFrom));
            prams.Add(MakeInParam("Content", o.Content));
            prams.Add(MakeInParam("GiftImg", o.GiftImg));
            prams.Add(MakeInParam("Backgound", o.Backgound));
            prams.Add(MakeInParam("CTime", DateTime.Now));
            prams.Add(MakeInParam("ClientIP", GameRequest.GetUserIP()));
            ExecSqlNonQuery(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 获得母亲节许愿活动
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetActivityWishingList(int pageindex, int pagesize, string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select a.*,CONVERT(NVARCHAR(30),CTime,20) as CTimeStr,b.Accounts,b.NickName from ActivityWishing as a
                                        left join QPAccountsDB.dbo.AccountsInfo as b on a.UserID=b.UserID");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where 1=1 ").Append(wherestr);
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "CTime DESC", null);
        }
        #endregion

        #region 检测网吧活动
        /// <summary>
        /// 获取网吧信息
        /// </summary>
        /// <param name="ipaddress">IP地址</param>
        /// <returns></returns>
        public ActivityInternetcafe GetActivityInternetcafeByIP(string ipaddress)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from ActivityInternetcafe");
            sbCache.Append(" where IPAddress=@IPAddress");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("IPAddress", ipaddress));
            return ExecSqlForObject<ActivityInternetcafe>(sbCache.ToString(), prams);
        }
        /// <summary>
        /// 获取网吧当日用户是否达到最大次数
        /// </summary>
        /// <param name="ipaddress">IP地址</param>
        /// <returns></returns>
        public bool IsExceedDayFreeNum(ActivityInternetcafe internetcafe, int userid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT COUNT(*) FROM RecordActivityInternetcafe");
            sbCache.Append(" WHERE CONVERT(NVARCHAR(30),getdate(),23)=CONVERT(NVARCHAR(30),CTime,23) AND ActivityInternetcafePid=@ActivityInternetcafePid AND UserID=@UserID");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("ActivityInternetcafePid", internetcafe.Pid));
            prams.Add(MakeInParam("UserID", userid));
            int count = Game.Utils.Utility.StrToInt(ExecSqlScalar(sbCache.ToString(), prams), 0);
            return count >= internetcafe.DayFreeNum;
        }
        #endregion

        #region 网站活动 活动记录
        /// <summary>
        /// 活动奖励记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetActivityPlizeRecord(int pageindex, int pagesize, string wherestr)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select temp.*,bb.Accounts,bb.NickName from(
select ActivityPid,1 as GoodType,UserID,'金币' as [Name],Gold as Number,0 as MemberOrder,CTime from RecordActivityPresentGold
union
select ActivityPid,2 as GoodType,UserID,'会员' as [Name],MemberDays as Number,MemberOrder,CTime from RecordActivityPresentMember
union
select ActivityPid,3 as GoodType,UserID,b.ProductName as [Name],a.Number,0 as MemberOrder,a.CTime from RecordActivityPrize as a left join QPTreasureDB.dbo.Product as b on a.ProductPid=b.Pid
union
select ActivityPid,4 as GoodType,UserID,'奖牌' as [Name],Medal as Number,0 as MemberOrder,CTime from RecordActivityPresentMedal
union
select ActivityPid,5 as GoodType,UserID,b.Name as [Name],Number as Number,0 as MemberOrder,a.CTime from RecordActivityPresentProperty as a left join [QPGamePropertyDB].[dbo].[PropertyCFG] as b on a.PropertyPid=b.Pid
) as temp left join QPAccountsDB.dbo.AccountsInfo as bb on temp.UserID=bb.UserID");
            if (!string.IsNullOrEmpty(wherestr))
            {
                sbCache.Append(" where ").Append(wherestr);
            }
            return GetPagination(pageindex, pagesize, sbCache.ToString(), null, "CTime DESC", null);
        }
        #endregion

        #region 网站活动 黄金挖矿
        /// <summary>
        /// 网站活动 黄金挖矿
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="activitypid"></param>
        /// <param name="expendgold"></param>
        /// <param name="ispresent"></param>
        /// <param name="presenttype"></param>
        /// <param name="presentgold"></param>
        /// <param name="presentmedal"></param>
        /// <param name="presentmemberorder"></param>
        /// <param name="presentmemberdays"></param>
        /// <returns></returns>
        public Message ActivityHJWK(int userid, int activitypid, long expendgold, bool ispresent, long presenttype, long presentgold, long presentmedal, int presentmemberorder, int presentmemberdays)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramActivityPid", activitypid));
            prams.Add(MakeInParam("paramExpendGold", expendgold));
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramIsPresent", ispresent ? 1 : 0));
            prams.Add(MakeInParam("paramPresentType", presenttype));
            prams.Add(MakeInParam("paramPresentGold", presentgold));
            prams.Add(MakeInParam("paramPresentMedal", presentmedal));
            prams.Add(MakeInParam("paramPresentMemberOrder", presentmemberorder));
            prams.Add(MakeInParam("paramPresentMemberDays", presentmemberdays));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_ActivityHJWK", prams);
        }
        #endregion

        #region 网站活动 欢乐购
        /// <summary>
        /// 活动 金豆购买会员送奖牌
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="memberdays"></param>
        /// <returns></returns>
        public Message ActivityHLG(int activitypid, int userid, Game.Type.MemberLevel memberorder, int memberdays)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramActivityPid", activitypid));
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramMemberOrder", memberorder));
            prams.Add(MakeInParam("paramMemberDays", memberdays));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_ActivityBuyMemberExpendGold", prams);
        }
        #endregion

        #region 网站活动 九宫格免费抽奖
        /// <summary>
        /// 活动 九宫格免费抽奖
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="memberdays"></param>
        /// <returns></returns>
        public Message ActivityJGGMFCJ(int userid, int activitypid, long presenttype, long presentgold, long presentmedal, int presentmemberorder, int presentmemberdays, int presentproertypid, int presentproerty)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramActivityPid", activitypid));
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramPresentType", presenttype));
            prams.Add(MakeInParam("paramPresentGold", presentgold));
            prams.Add(MakeInParam("paramPresentMedal", presentmedal));
            prams.Add(MakeInParam("paramPresentMemberOrder", presentmemberorder));
            prams.Add(MakeInParam("paramPresentMemberDays", presentmemberdays));
            prams.Add(MakeInParam("paramPresentPropertyPid", presentproertypid));
            prams.Add(MakeInParam("paramPresentProperty", presentproerty));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_ActivityJGGMFCJ", prams);
        }
        /// <summary>
        /// 查询用户还须玩的局数
        /// </summary>
        /// <returns></returns>
        public int GetUserGameCount(int userid, string where)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat(@"SELECT count(*) FROM QPStreamDB.dbo.RecordDrawScore WHERE 
            ID>(select top 1 DrawScore_EntityID from [QPGameLogDB].[dbo].[DayIDForStatistics] order by inserttime desc) 
            AND UserID={0}", userid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.AppendFormat(" {0}", where);
            }
            return Game.Utils.Utility.StrToInt(ExecSqlScalar(sbCache.ToString()), 0);
        }
        /// <summary>
        /// 查询用户是否参与抽奖次数
        /// </summary>
        /// <returns></returns>
        public int GetUserIsJoinActivityJGG(int userid, int activitypid, string where)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("select count(*) from [QPNativeWebDB].[dbo].[RecordActivityConsumption] WHERE UserID={0} and ActivityPid={1}", userid, activitypid);
            if (!string.IsNullOrEmpty(where))
            {
                sbCache.AppendFormat(" {0}", where);
            }
            return Game.Utils.Utility.StrToInt(ExecSqlScalar(sbCache.ToString()), 0);
        }
        /// <summary>
        /// 活动 九宫格免费抽奖-定时奖励
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="memberdays"></param>
        /// <returns></returns>
        public Message ActivityJGGMFCJReward(string json, DateTime stime, DateTime etime)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramJson", json));
            prams.Add(MakeInParam("paramStartDate", stime));
            prams.Add(MakeInParam("paramEndDate", etime));
            prams.Add(MakeInParam("paramCurrentDate", DateTime.Now));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageObject<ActivityJGGMFCJReward>("NET_PM_ActivityJGGMFCJReward", prams);
        }
        #endregion

        #region QQ邮箱发送记录
        /// <summary>
        /// 新增QQ邮箱发送记录
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRecordSendEmail(RecordSendEmail entity)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramPid", entity.Pid));
            parms.Add(MakeInParam("paramUserID", entity.UserID));
            parms.Add(MakeInParam("paramEmail", entity.Email));
            parms.Add(MakeInParam("paramSendTitle", entity.SendTitle));
            parms.Add(MakeInParam("paramSendContent", entity.SendContent));
            parms.Add(MakeInParam("paramStateID", entity.StateID));
            parms.Add(MakeInParam("paramCTime", entity.CTime));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_InsertRecordSendEmail", parms);
        }
        /// <summary>
        /// 修改QQ企业邮箱发送记录状态
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message UpdateRecordSendEmailStateID(int pid, byte stateid)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramPid", pid));
            parms.Add(MakeInParam("paramStateID", stateid));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("NET_PM_UpdateRecordSendEmailStateID", parms);
        }
        /// <summary>
        /// 获取QQ邮箱发送记录
        /// </summary>
        /// <returns></returns>
        public RecordSendEmail GetRecordSendEmailLast()
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT TOP 1 * FROM RecordSendEmail");
            sbCache.Append(" WHERE StateID=").Append((int)Game.Type.SendEmailStateID.未发送);
            sbCache.Append(" ORDER BY Pid ASC");
            return ExecSqlForObject<RecordSendEmail>(sbCache.ToString());
        }
        #endregion

        #region PC蛋蛋
        /// <summary>
        /// PC蛋蛋广告奖励查询接口
        /// </summary>
        /// <param name="gameid"></param>
        /// <returns></returns>
        public DataSet GetPCeggsReward(int gameid)
        {
            //string adid = "wBq%2b15ROTUs%3d";

            StringBuilder sbCache = new StringBuilder();
            //            sbCache.AppendFormat(@"select a.GameID,a.Accounts,
            //(select isnull(sum(WinScore),0) from [QPGameLogDB].[dbo].[UserSpreadLog] where UserID=a.UserID ) as WinScore,
            //(select isnull(sum(WinCount),0) from [QPGameLogDB].[dbo].[UserSpreadLog] where UserID=a.UserID and GameID=27) as WinCount
            //from [QPAccountsDB].[dbo].[AccountsInfo] as a
            //where a.GameID={0}", gameid);

            //WinCount1(代表斗地主和换三张) WinCount2(代表牛牛和赢三张) 
            sbCache.AppendFormat(@"select a.GameID,a.Accounts,
(select isnull(sum(WinCount),0) from [QPGameLogDB].[dbo].[UserSpreadLog] where UserID=a.UserID and GameID in(200,378)) as WinCount1,
(select isnull(sum(WinCount),0) from [QPGameLogDB].[dbo].[UserSpreadLog] where UserID=a.UserID and GameID in(6,27)) as WinCount2
from [QPAccountsDB].[dbo].[AccountsInfo] as a left join [QPGameLogDB].[dbo].[RecordPceggsRegInfo] as b on a.UserID=b.UserID
            where a.GameID={0}", gameid);
            return ExecSqlForDataSet(sbCache.ToString(), null);
        }
        #endregion

        #region 活动信息
        /// <summary>
        /// 获取活动配置信息
        /// </summary>
        /// <param name="whereCase"></param>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public IList<ActivityInfoCFG> GetActivityInfoList(string whereCase, string orderbywhere)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"select * from  QPNativeWebDB.dbo.[ActivityInfoCFG](NOLOCK) AS A
                            LEFT JOIN QPMobileAppDB.dbo.AppIcon(NOLOCK) AS B
                            ON A.AppIconID=B.IConID WHERE 1=1 ");
            if (whereCase.Trim().Length > 0)
            {
                sbCache.Append(whereCase);
            } if (orderbywhere.Trim().Length == 0)
            {
                orderbywhere = " order By StartTime DESC ";
            }
            sbCache.Append(orderbywhere);
            return ExecSqlForObjectList<ActivityInfoCFG>(sbCache.ToString());
        }

        #endregion

        #region 小游戏 财神到
        /// <summary>
        /// 检查是否可以开始游戏
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="xgameconfigpid">游戏配置ID</param>
        /// <returns></returns>
        public Message XGameCheckUserGame(int userid, int xgameconfigpid)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramUserID", userid));
            parms.Add(MakeInParam("paramXGameConfigPid", xgameconfigpid));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("XGame_CheckUserGame", parms);
        }
        /// <summary>
        /// 购买游戏次数
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="xgameconfigpid">游戏配置ID</param>
        /// <returns></returns>
        public Message XGamePayGameCount(int userid, int xgameconfigpid)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramUserID", userid));
            parms.Add(MakeInParam("paramXGameConfigPid", xgameconfigpid));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessage("XGame_PayGameCount", parms);
        }
        /// <summary>
        /// 财神到游戏写分
        /// </summary>
        /// <param name="recordpid">游戏记录ID</param>
        /// <param name="userid"></param>
        /// <param name="score">分数</param>
        /// <returns></returns>
        public Message XGameCSDWriteScore(int recordpid, int userid, int score)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramPid", recordpid));
            parms.Add(MakeInParam("paramUserID", userid));
            parms.Add(MakeInParam("paramScore", score));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("XGame_CSDWriteScore", parms);
        }
        /// <summary>
        /// 西游记游戏写分
        /// </summary>
        /// <param name="recordpid">游戏记录ID</param>
        /// <param name="userid"></param>
        /// <param name="score">分数</param>
        /// <returns></returns>
        public Message XGameXYJWriteScore(int recordpid, int userid, int score)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramPid", recordpid));
            parms.Add(MakeInParam("paramUserID", userid));
            parms.Add(MakeInParam("paramScore", score));
            parms.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("XGame_XYJWriteScore", parms);
        }
        #endregion

        #region 每日签到V2.0
        /// <summary>
        /// 每日签到
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRecordDailySignV2(RecordDailySignV2 entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", entity.UserID));
            prams.Add(MakeInParam("paramSignTime", DBNull.Value));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_InsertRecordDailySignV2", prams);
        }
        /// <summary>
        /// 每日签到（补签）
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRecordDailySignV2Repair(RecordDailySignV2 entity)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", entity.UserID));
            prams.Add(MakeInParam("paramSignTime", entity.SignTime));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeInParam("paramDays", entity.Days));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_InsertRecordDailySignV2Repair", prams);
        }
        /// <summary>
        /// 每日签到（连续签到奖励）
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message DailySignV2ContinuityReward(int userid, int rewardtype)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramRewardType", rewardtype));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_DailySignV2ContinuityReward", prams);
        }
        /// <summary>
        /// 获取当月签到记录
        /// </summary>
        /// <returns></returns>
        public IList<RecordDailySignV2> GetCurrentMonthDailySignV2List(int userid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT *  FROM RecordDailySignV2");
            sbCache.AppendFormat(" WHERE UserID={0} AND DATEDIFF(MONTH,SignTime,GETDATE())=0", userid);
            sbCache.Append(" ORDER BY SignTime ASC ");
            return ExecSqlForObjectList<RecordDailySignV2>(sbCache.ToString());
        }
        /// <summary>
        /// 获取当月连续签到记录
        /// </summary>
        /// <returns></returns>
        public IList<RecordDailySignV2Reward> GetCurrentMonthDailySignV2RewardList(int userid)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT *  FROM RecordDailySignV2Reward");
            sbCache.AppendFormat(" WHERE UserID={0} AND DATEDIFF(MONTH,RewardTime,GETDATE())=0", userid);
            sbCache.Append(" ORDER BY RewardTime ASC ");
            return ExecSqlForObjectList<RecordDailySignV2Reward>(sbCache.ToString());
        }
        /// <summary>
        /// 获取当月具体签到日期(cheua)
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public List<int> GetSignDayThisMonth(int UserID)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append(@"SELECT DATEPART(DAY, SignTime) AS SignDay FROM [dbo].[RecordDailySignV2](NOLOCK) 
                             WHERE USERID=@userid AND DATEDIFF(Month,SignTime,Getdate())=0");
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("userid", UserID));
            DataSet ds = ExecSqlForDataSet(sbCache.ToString(), prams);
            DataTable dt = ds.Tables[0];
            List<int> DaysList = new List<int>();
            foreach (DataRow item in dt.Rows)
            {
                DaysList.Add(Convert.ToInt32(item["SignDay"]));
            }
            return DaysList;
        }

        /// <summary>
        /// 获上传手机游戏发布包KEY
        /// </summary>
        /// <param name="stardt"></param>
        /// <param name="enddt"></param>
        /// <returns></returns>
        public string GetUpLoadDeployKey()
        {
            string ugId = System.Guid.NewGuid().ToString();
            string strSql = @"SELECT [Password] FROM [QPNativeWebDB].[dbo].[admin](NOLOCK) WHERE [UserName]='UploadTheUpdateDeployAdmin'
                              UPDATE [QPNativeWebDB].[dbo].[admin]
	                          SET [Password]=@Password
	                          WHERE [UserName]='UploadTheUpdateDeployAdmin'";
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("Password", ugId));
            DataSet ds = ExecSqlForDataSet(strSql, prams);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                return ds.Tables[0].Rows[0][0].ToString();
            else
                return "-1";
        }
        #endregion

        #region 战绩榜、财富榜、魅力榜
        /// <summary>
        /// 财富榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingScoreDataList(int RankCounts)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT top ").Append(RankCounts).Append(@" u.UserID,u.Accounts,u.NickName,u.MemberOrder,FaceID,CustomID,(s.Score+s.InsureScore) as AllScore
	                         FROM QPAccountsDB.dbo.AccountsInfo(NOLOCK) AS u
	                         inner join QPTreasureDB.dbo.GameScoreInfo(NOLOCK) as s
	                         on s.UserID=u.UserID  where u.IsAndroid=0   and u.IsShowRanking=1   and Nullity=0
	                         Order by (Score+InsureScore) DESC"
                           );
            return ExecSqlForDataSet(sbCache.ToString());
        }
        /// <summary>
        /// 战绩榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingRecordDataList(int RankCounts)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT top ").Append(RankCounts).Append(@" u.UserID,u.Accounts,u.NickName,u.MemberOrder,FaceID,CustomID,(s.Score+s.InsureScore)-(L.Score+L.BankScore) as DifferenceScore
	                        FROM QPAccountsDB.dbo.AccountsInfo(NOLOCK) AS u
	                        inner join QPGameLogDB.dbo.ScoreDayLog(NOLOCK) as L
	                        on L.UserID=u.UserID 
	                        inner join QPTreasureDB.dbo.GameScoreInfo(NOLOCK) as s
	                        on s.UserID=u.UserID
	                        where u.IsAndroid=0   and u.IsShowRanking=1   and Nullity=0 and  L.ID>(select ScoreDayLog_EntityID from  [QPGameLogDB].[dbo].[DayIDForStatistics] where DATEDIFF(DAY,InsertTime,GETDATE())=1) 
	                        Order by DifferenceScore DESC"
                           );
            return ExecSqlForDataSet(sbCache.ToString());
        }
        /// <summary>
        /// 魅力榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingLoveLinessDataList(int RankCounts)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.Append("SELECT top ").Append(RankCounts).Append(@" u.UserID,u.Accounts,u.NickName,u.MemberOrder,FaceID,CustomID,s.LoveLiness
	                        FROM QPAccountsDB.dbo.AccountsInfo(NOLOCK) AS u
	                        inner join QPTreasureDB.dbo.GameScoreInfoEx(NOLOCK) as s
	                        on s.UserID=u.UserID where u.IsAndroid=0   and u.IsShowRanking=1  and Nullity=0 
	                        Order by LoveLiness DESC"
                           );
            return ExecSqlForDataSet(sbCache.ToString());
        }
        #endregion

        #region 兑换CDK
        /// <summary>
        /// 兑换CDK
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message ConvertPackageCDKey(int userid, string packagecdkey, int channelid)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramPackageCDKey", packagecdkey));
            prams.Add(MakeInParam("paramChannelID", channelid));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_ConvertPackageCDKey", prams);
        }
        /// <summary>
        /// 随机生成CDK
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message GenerationPackageCDKey(int packagetypepid, string packagecdkey)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramPackageTypePid", packagetypepid));
            prams.Add(MakeInParam("paramCDKey", packagecdkey));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_GenerationPackageCDKey", prams);
        }
        #endregion

        #region 获取自动发送短信池
        /// <summary>
        /// 获取自动发送短信池 未发送的短信记录
        /// </summary>
        /// <returns></returns>
        public IList<AutoSendTelephoneMessage> GetAutoSendTelephoneMessageTopList(int top)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("SELECT {0} * FROM AutoSendTelephoneMessage", top > 0 ? "top " + top : "");
            sbCache.Append(" WHERE Status=0 ");
            sbCache.Append(" ORDER BY Pid ASC ");
            return ExecSqlForObjectList<AutoSendTelephoneMessage>(sbCache.ToString());
        }
        /// <summary>
        /// 修改短信记录状态
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="status">发送状态 0=未发送 1=已发送</param>
        /// <returns></returns>
        public bool UpdateAutoSendTelephoneMessageStatus(int pid, byte status)
        {
            StringBuilder sbCache = new StringBuilder();
            sbCache.AppendFormat("UPDATE AutoSendTelephoneMessage SET Status={0}", status);
            sbCache.AppendFormat(" WHERE pid={0}", pid);
            int count = ExecSqlNonQuery(sbCache.ToString());
            return count > 0;
        }
        #endregion

        #region 绑定推广员
        /// <summary>
        /// 绑定推广员
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message BindSpread(int userid, int spreadgameid)
        {
            List<DbParameter> prams = new List<DbParameter>();
            prams.Add(MakeInParam("paramUserID", userid));
            prams.Add(MakeInParam("paramSpreadGameID", spreadgameid));
            prams.Add(MakeInParam("paramClientIP", GameRequest.GetUserIP()));
            prams.Add(MakeOutParam("paramErrorDescribe", DbType.String, 127));
            return ExecProcForMessageDataSet("NET_PM_BindSpread", prams);
        }
        #endregion

        #region 获取比赛条件
        /// <summary>
        /// 获取比赛参赛条件
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public DataSet GetMatchCondition(int userid, int matchid)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramUserID", userid));
            parms.Add(MakeInParam("paramMatchID", matchid));
            return ExecProcForDataSet("[QPNativeWebDB].[DBO].[NET_PM_GetMatchCondition]", parms);
        }
        /// <summary>
        /// 获取比赛参赛条件App
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public DataSet GetMatchConditionApp(int matchid)
        {
            var parms = new List<DbParameter>();
            parms.Add(MakeInParam("paramMatchID", matchid));
            return ExecProcForDataSet("[QPNativeWebDB].[DBO].[NET_PM_GetMatchConditionApp]", parms);
        }
        #endregion

        #region 下载统计
        /// <summary>
        /// 插入下载记录
        /// </summary>
        /// <param name="DeviceType"></param>
        /// <param name="KindID"></param>
        /// <returns></returns>
        public int InsertDownLoadLog(int DeviceType, int KindID)
        {
            string sql = @"insert into [QPGameLogDB].[dbo].[DownLoadLog]([DeviceType],[KindID],[InsertTime]) VALUES(@DeviceType,@KindID,getdate())";
            List<DbParameter> parms = new List<DbParameter>();
            parms.Add(MakeInParam("DeviceType", DeviceType));
            parms.Add(MakeInParam("KindID", KindID));
            return ExecSqlNonQuery(sql, parms);
        }
        #endregion
    }
}
