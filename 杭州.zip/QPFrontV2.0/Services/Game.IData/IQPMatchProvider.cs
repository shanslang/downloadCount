﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.QPMatch;

namespace Game.IData
{
    public interface IQPMatchProvider
    {
        /// <summary>
        /// 获取比赛信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        MatchInfo GetMatchInfoByMatchID(int matchid);
        /// <summary>
        /// 获取比赛信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        MatchInfo GetMatchInfoByMatchID(int matchid, int roundid);
        /// <summary>
        /// 获取比赛信息 提供个游戏的接口
        /// </summary>
        /// <returns></returns>
        MatchInfo GetMatchInfo(int matchid);
        /// <summary>
        /// 获取比赛信息 新版
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        string GetMatchInfoV1Xml(int matchid);
        /// <summary>
        /// 获取比赛列表信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        IList<MatchInfo> GetMatchInfoList(string wherestr);
        /// <summary>
        /// 获取比赛报名信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        int GetMatchSignCount(string wherestr);
        /// <summary>
        /// 获取比赛报名信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        IList<MatchSign> GetMatchSignList(int top, string wherestr);


        /// <summary>
        /// 获取比赛记录信息 最后的记录
        /// </summary>
        /// <param name="matchid"></param>
        /// <param name="matchsubid"></param>
        /// <returns></returns>
        DataSet GetMatchLogByMatchID(int matchid);
        /// <summary>
        /// 获取比赛记录信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <param name="matchsubid"></param>
        /// <returns></returns>
        DataSet GetMatchLogByMatchID(int matchid, int matchsubid);
        /// <summary>
        /// 获取比赛奖励信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        IList<MatchReward> GetMatchRewardByMatchID(int matchid);

        /// <summary>
        /// 获取比赛组信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        IList<MatchGroupInfo> GetMatchGroupInfo();

        /// <summary>
        /// 获取当前参赛人数
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        Game.Entity.GameLog.MatchOnline GetMatchOnline(int matchid, int matchsubid);
        /// <summary>
        /// 获取个人比赛成绩和奖励
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        DataSet GetUserMatchReward(int userID);
        /// <summary>
        /// 个人单场比赛奖励
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="matchID"></param>
        /// <param name="roundID"></param>
        /// <returns></returns>
        DataSet GetUserMatchReward(int userID, int matchID, int roundID);
    }
}
