﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.Platform;

namespace Game.IData
{
    /// <summary>
    /// 平台库数据层接口
    /// </summary>
    public interface IPlatformDataProvider //: IProvider
    {
        /// <summary>
        /// 根据服务器地址获取数据库信息
        /// </summary>
        /// <param name="addrString"></param>
        /// <returns></returns>
        DataBaseInfo GetDatabaseInfo(string addrString);

        /// <summary>
        /// 根据游戏ID获取服务器地址信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        GameGameItem GetDBAddString(int kindID);

        /// <summary>
        /// 获取游戏类型列表
        /// </summary>
        /// <returns></returns>
        IList<GameTypeItem> GetGmaeTypes();

        /// <summary>
        /// 根据类型ID获取游戏列表
        /// </summary>
        /// <param name="typeID"></param>
        /// <returns></returns>
        IList<GameKindItem> GetGameKindsByTypeID(int typeID);

        /// <summary>
        /// 得到所有的游戏
        /// </summary>
        /// <returns></returns>
        IList<GameKindItem> GetAllKinds();

        /// <summary>
        /// 得到积分的游戏
        /// </summary>
        /// <returns></returns>
        IList<GameKindItem> GetIntegralKinds();

        /// <summary>
        /// 得到游戏列表
        /// </summary>
        /// <returns></returns>
        IList<GameGameItem> GetGameList();

        /// <summary>
        /// 得到特定游戏
        /// </summary>
        /// <param name="kindid"></param>
        /// <returns></returns>
        GameKindItem GetGameKindItem(int kindid);

        /// <summary>
        /// 修改客户端版本号
        /// author:francis
        /// </summary>
        /// <param name="gameid"></param>
        /// <param name="clientversion"></param>
        /// <returns></returns>
        int UpdateGameGameItemClientVersionByGameID(int gameid, int version);
        /// <summary>
        /// 修改图片资源版本号
        /// author:francis
        /// </summary>
        /// <param name="gameid"></param>
        /// <param name="clientversion"></param>
        /// <returns></returns>
        int UpdateGameGameItemImageVersionByGameID(int gameid, int version);
        /// <summary>
        /// 修改声音资源版本号
        /// author:francis
        /// </summary>
        /// <param name="gameid"></param>
        /// <param name="clientversion"></param>
        /// <returns></returns>
        int UpdateGameGameItemSoundVersionByGameID(int gameid, int version);

        /// <summary>
        /// 查询页游配置表
        /// author:francis
        /// </summary>
        /// <returns></returns>
        GamePageItem GetGamePageItemByPageID(int pageid);

        #region 公共

        /// <summary>
        /// 根据SQL语句查询一个值
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        object GetObjectBySql(string sqlQuery);

        /// <summary>
        /// 根据sql获取实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <returns></returns>
        T GetEntity<T>(string commandText);

        #endregion

        #region 比赛信息
        /// <summary>
        /// 获得游戏信息及场次信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <param name="matchno"></param>
        /// <returns></returns>
        GameMatchInfo GetGameMatchInfo(int matchid);

        /// <summary>
        /// 获得游戏信息及场次信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <param name="matchno"></param>
        /// <returns></returns>
        HistoryGameMatchInfo GetHistoryGameMatchInfo(int matchid, int matchno);

        /// <summary>
        /// 获得游戏奖励信息列表
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        IList<MatchAwardConfig> GetMatchAwardConfigList(int matchid);
        #endregion


        /// <summary>
        /// 获取配置文件版本
        /// </summary>
        /// <param name="kindID"></param>
        /// <param name="versionID"></param>
        /// <returns></returns>
        int GetConfigVersion(int kindID, int versionID);
        /// <summary>
        /// 添加系统公告
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertSystemNotice(SystemNotice entity);
    }
}
