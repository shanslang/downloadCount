﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

using Game.Francis;
using Game.Entity.GameProperty;
using Game.Entity.Accounts;

namespace Game.IData
{
    public interface IGamePropertyDataProvider
    {
        /// <summary>
        /// 查询道具配置
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        PropertyCFG GetPropertyCFG(int propertypid);

        /// <summary>
        /// 查询道具记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        DataSet GetPropertyCFGRecord(int pageindex, int pagesize, string wherestr, string order);

        /// <summary>
        /// 查询商品配置信息
        /// </summary>
        /// <returns></returns>
        IList<PropertyCFGInfo> GetAllPropertyCFGInfo();

        /// <summary>
        /// 查询用户商品配置信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        IList<UserPropertyCFGInfo> GetUserPropertyCFGInfo(string userID);
        /// <summary>
        /// 查询用户指定道具数量
        /// </summary>
        /// <param name="accounts"></param>
        /// <param name="pID"></param>
        /// <returns></returns>
        int GetUserPropertyCFGNum(string accounts, int pID);

        /// <summary>
        /// 查询道具配置
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        IList<PropertyEffectCFG> GetPropertyEffectCFGRecord(int propertypid);

        /// <summary>
        /// 查询用户道具记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        DataSet GetUserPropertyRecord(int pageindex, int pagesize, int userid);

        /// <summary>
        /// 购买道具
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="propertypid"></param>
        /// <param name="count"></param>
        /// <param name="isbuy">是否购买 true购买 false赠送</param>
        /// <returns></returns>
        Message GiveUserProperty(int userid, int propertypid, int count, bool isbuy);

        /// <summary>
        /// 购买道具
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="propertypid"></param>
        /// <param name="count"></param>
        /// <param name="isbuy">是否购买 true购买 false赠送</param>
        /// <returns></returns>
        Message GiveUserProperty(int userid, int propertypid, int count, int optype, bool isbuy);

        /// <summary>
        /// 使用道具
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="targetuserid"></param>
        /// <param name="propertypid"></param>
        /// <param name="count"></param>
        /// <param name="forceuse">是否强制使用</param>
        /// <returns></returns>
        Message UseProperty(int userid, int targetuserid, int propertypid, int count, bool forceuse);
        /// <summary>
        /// 转让道具
        /// </summary>
        Message TransProperty(int UserID, int TargetUserID, int pid, int PCount);
        #region 获取道具信息
        /// <summary>
        /// 获取道具信息
        /// </summary>
        /// <param name="wherecase"></param>
        /// <param name="orderwhere"></param>
        /// <returns></returns>
        IList<PropertyCFG> GetPropertyList(string wherecase, string orderwhere);


        #endregion

        #region IOS
        /// <summary>
        /// 查询用户道具(目前仅门票)
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        DataSet GetUserPropertyRecordForIOS(int userid, string contidion);
        #endregion
        #region 获取代理商充值记录
        /// <summary>
        /// 查询代理商给玩家充值记录
        /// </summary>
        DataSet GetRechargeCardDetail(int pageindex, int pagesize, int userid, string stime, string etime);
        /// <summary>
        /// 获取充值总数据
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        DataSet GetRechargeCardData(int userId, string stime, string etime);
        /// <summary>
        /// 查询代理商购买记录
        /// </summary>
        DataSet GetBuyCardDetail(int pageindex, int pagesize, int userid, string stime, string etime);
        #endregion
        /// <summary>
        /// 查询玩家房卡记录
        /// </summary>
        DataSet GetPlayerCardRecord(int pageindex, int pagesize, int agentid, int userid, string stime, string etime);
        DataSet GetRoomCardConsumeStatistics(int pageindex, int pagesize, int agentid, string stime, string etime);
    }
}
