﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.GameScore;

namespace Game.IData
{
    public interface IGameScoreDataProvider
    {
        /// <summary>
        /// 获取游戏道具列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        DataSet GetGamePropertyList(int pageIndex, int pageSize);
    }
}
