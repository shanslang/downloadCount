﻿using Game.Entity.MobileApp;
using Game.Francis;
using Game.Type;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Game.IData
{
    public interface IMobileAppDataProvider
    {
        /// <summary>
        /// 获取登陆服务器地址
        /// </summary>
        /// <returns></returns>
        IList<AppServerAddressCFG> GetLogonServerAddress(int versionid,int userid);

        /// <summary>
        /// 获取接口访问地址
        /// </summary>
        /// <returns></returns>
        AppVisitAddressCFG GetAppVisitAddress(int versionid);

        /// <summary>
        /// 获取app游戏渠道配置
        /// </summary> 
        DataSet GetGameAppUrlCFG(int gameID, int chanelID, int userId);

        /// <summary>
        /// 新增手游戏渠道配置
        /// </summary> 
        void AddGameAppUrlCFG(string GameID, string ChanelID, string AppURL, string EngineVersion, string Description, string UpdateInFo, string ApkMD5);

        /// <summary>
        /// 获取游戏下载地址(IOS AppID)
        /// </summary>
        /// <param name="SerType"></param>
        /// <returns></returns>
        GameAppIDInfo APPIDInfoGet(AppSerType SerType);
        /// <summary>
        ///获取游戏场次数据
        /// </summary>
        /// <returns></returns>
        IList<GameScreenings> GameScreeningsList(string wherecase, string orderbywhere);
        /// <summary>
        /// 游戏场次信息房间数据
        /// </summary>
        /// <param name="ScreenID"></param>
        /// <returns></returns>
        IList<GameScreeningsSerCFG> GameScreenServerList(int ScreenID);
        /// <summary>
        /// 获取更多游戏数据信息
        /// </summary>
        /// <param name="whereCase"></param>
        /// <returns></returns>
        DataSet MoreGameList(string whereCase, int UserID);
        /// <summary>
        /// 获取公告配置信息
        /// </summary>
        /// <returns></returns>
        NoticeCFG AppNoticeCFGInfo();
        /// <summary>
        /// 最近一次获奖记录
        /// </summary>
        /// <returns></returns>
        string AppNoticeReword();

        /// <summary>
        /// 获取公告列表
        /// </summary>
        /// <param name="wherecase"></param>
        /// <returns></returns>
        DataSet NoticeList(string wherecase);
        /// <summary>
        /// 获取某个用户的排名名次
        /// </summary>
        /// <param name="Userid"></param>
        /// <returns></returns>
        DataSet RakingDataByUser(int Userid);
        /// <summary>
        /// 财富榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        DataSet RakingScoreDataList(int RankCounts);
        /// <summary>
        /// 战绩榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        DataSet RakingRecordDataList(int RankCounts);
        /// <summary>
        /// 魅力榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        DataSet RakingLoveLinessDataList(int RankCounts);
        /// <summary>
        /// 游戏下载奖励信息
        /// </summary>
        /// <param name="Gameid"></param>
        /// <returns></returns>
        GameDownloadReward GetDownloadReward(int Gameid);
        /// <summary>
        /// 领取奖励(更多游戏下载)
        /// </summary>
        /// <param name="RewardID"></param>
        /// <returns></returns>
        Message MoreGameReward(int GameID, int UserID);

        void InsertChannelLoginHistoty(string accounts, string channelId, string channelAccount, string channelToken, string type, int gameId);

        DataSet GetAppVerfilterList(string GameId, string Version);
        #region 商城
        /// <summary>
        /// 获取商城数据
        /// </summary>
        /// <param name="wherecase"></param>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        DataSet AppProductList(string wherecase, string orderbywhere);
        /// <summary>
        /// 购买记录
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="identifier"></param>
        /// <param name="orderid"></param>
        void AppInsertAppBuyHistoty(int userid, string identifier, string orderid);
        /// <summary>
        /// 是否已经购买过只能购买一次的产品
        /// </summary>
        /// <returns></returns>
        bool RtRepeatBuy(int userID, string Identifier);
        #region 比赛
        /// <summary>
        /// 获取比赛奖励信息
        /// </summary>
        /// <param name="Matchid"></param>
        /// <param name="Roundid"></param>
        /// <returns></returns>
        IList<Modulehelp> AppLoadMatchReward(int Matchid, int Roundid);
        /// <summary>
        /// 获取比赛信息(手游获取指定信息)
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        Message GetMobileMatchInfo(int matchid, int roundid);
        /// <summary>
        /// 获取比赛组信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        DataSet GetMobileGroupInfo(int kindID);
        /// <summary>
        /// 获取多个房间准入金币信息
        /// </summary>
        /// <param name="wherecase"></param>
        /// <returns></returns>
        DataSet GameScreenServerList(string wherecase);
        #endregion
        #endregion

        #region 获取GameAppUrlCFG
        /// <summary>
        /// 获取app游戏渠道配置
        /// author:Francis
        /// </summary>
        /// <param name="gameid"></param>
        /// <param name="channelid"></param>
        /// <returns></returns>
        GameAppUrlCFG GetGameAppUrlCFG(int gameid, int channelid);
        #endregion


        #region 获取小游戏开关配置

        /// <summary>
        /// 获取小游戏配置
        /// </summary>
        /// <param name="kindId"></param>
        /// <returns></returns>
        DataSet GetGameEnabledConfig(int kindId);

        #endregion
        #region 获取快充配置
        /// <summary>
        /// 获取快充配置
        /// </summary>
        /// <param name="kindId"></param>
        /// <returns></returns>
        DataSet GetFastChargeConfig(int kindId);
        #endregion
        #region 获取游戏客服信息
        string GetGameKFInfo(int kindID);
        #endregion
        DataSet GameAllServerList();
    }
}
