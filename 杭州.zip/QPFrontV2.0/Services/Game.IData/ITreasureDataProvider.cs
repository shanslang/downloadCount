﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.Treasure;
using Game.Entity.GameLog;
using Game.Entity.MobileApp;

namespace Game.IData
{
    /// <summary>
    /// 金币库数据层接口
    /// </summary>
    public interface ITreasureDataProvider //: IProvider
    {
        #region 在线充值

        /// <summary>
        /// 生成订单
        /// </summary>
        /// <param name="orderInfo"></param>
        /// <returns></returns>
        Message RequestOrder(OnLineOrder orderInfo);

        ///// <summary>
        ///// 添加 购买会员服务明细 和订单关联
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //Message InsertBuyMemberOrderDetails(BuyMemberOrderDetails entity);

        /// <summary>
        /// 添加 购买会员服务明细 和订单关联1
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertBuyMemberOrderDetails1(BuyMemberOrderDetails1 entity);
        /// <summary>
        /// 获取 购买会员服务明细 和订单关联1  
        /// </summary>
        /// <param name="orderid"></param>
        /// <returns></returns>
        BuyMemberOrderDetails1 GetBuyMemberOrderDetails1(string orderid);

        /// <summary>
        /// 添加 购买道具明细 和订单关联
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertBuyProperDetails(BuyProperDetails entity);
        /// <summary>
        /// 添加 购买金币明细 和订单关联
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertBuyGoldDetails(BuyGoldOrderDetails entity);

        ///// <summary>
        ///// 快钱充值成功 更新订单信息
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //Message WriteKQRecharge(ReturnKQDetailInfo returnInfo);

        ///// <summary>
        ///// 支付宝充值成功 更新订单信息
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //Message WriteZFBRecharge(ReturnZFBDetailInfo returnInfo);

        ///// <summary>
        ///// 声讯电信充值成功 更新订单信息
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //Message WriteSXDXRecharge(ReturnSXDXDetailInfo returnInfo);

        ///// <summary>
        ///// 声讯联通充值成功 更新订单信息
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //Message WriteSXLTRecharge(ReturnSXLTDetailInfo returnInfo);

        ///// <summary>
        ///// 快钱充值卡充值成功 更新订单信息
        ///// Author:xujianbo
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //Message WriteKQCardRecharge(ReturnKQCardDetailInfo returnInfo);

        ///// <summary>
        ///// 天下付充值成功 更新订单信息
        ///// Author:xujianbo
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //Message WriteTXFRecharge(string orderID);

        /// <summary>
        /// APPLE IAP充值成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        Message WriteAppleIAPRecharge(string orderID, string version, ReturnAppleIAPDetailInfo o);
        /// <summary>
        /// 充值成功，更改订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <param name="version"></param>
        /// <param name="o"></param>
        /// <returns></returns>
        Message WriteLJIAPRecharge(ReturnLJDetailInfo rtinfo, OnLineOrder order);

        Message WriteLTRecharge(callbackReq rtinfo, OnLineOrder order);
        Message WriteBDRecharge(ReturnBDDetailInfo rtinfo, OnLineOrder order);
        //支付宝
        Message WriteZFBRecharge(ReturnZFBDetailInfo rtinfo, OnLineOrder order);

        /// <summary>
        /// 银联回调充值成功，更改订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <param name="version"></param>
        /// <param name="o"></param>
        /// <returns></returns>
        Message WriteUnionPayRecharge(OnLineOrder order);
        /// <summary>
        /// 互联星空回调充值成功，更改订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <param name="version"></param>
        /// <param name="o"></param>
        /// <returns></returns>
        Message WriteVnetPayRecharge(OnLineOrder order);


        ///// <summary>
        ///// 写天天付返回记录
        ///// </summary>
        ///// <param name="returnKQ"></param>
        //void WriteReturnDayDetail(ReturnDayDetailInfo returnDay);

        ///// <summary>
        ///// 写快钱返回记录
        ///// </summary>
        ///// <param name="returnKQ"></param>
        //void WriteReturnKQDetail(ReturnKQDetailInfo returnKQ);

        ///// <summary>
        ///// 写电话充值返回记录
        ///// </summary>
        ///// <param name="returnKQ"></param>
        //Message WriteReturnVBDetail(ReturnVBDetailInfo returnVB);

        //// <summary>
        ///// 写易宝返回记录
        ///// </summary>
        ///// <param name="returnYB"></param>
        //Message WriteReturnYBDetail(ReturnYPDetailInfo returnYB);

        ///// <summary>
        ///// 在线充值
        ///// </summary>
        ///// <param name="olDetial"></param>
        ///// <returns></returns>
        //Message FilliedOnline(ShareDetialInfo olDetial, int isVB);

        ///// <summary>
        ///// 苹果充值
        ///// </summary>
        ///// <param name="olDetial"></param>
        ///// <returns></returns>
        //Message FilliedApp(ShareDetialInfo olDetial);

        /// <summary>
        /// 实卡充值
        /// </summary>
        /// <param name="associator"></param>
        /// <param name="operUserID"></param>
        /// <param name="accounts"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        Message FilledLivcard(ShareDetialInfo detialInfo, string password);

        /// <summary>
        /// 获取订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        OnLineOrder GetOnlineOrder(string orderID);
        /// <summary>
        /// 获取订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        OnLineOrder GetOnlineOrderByID(string onlineID);
        /// <summary>
        /// 记录联通订单校验数据
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        void AddOnLineOrderByLT(string orderID, string imei, string macaddress, string ipaddress, string identifier);
        /// <summary>
        /// 获取联通订单校验数据
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        DataSet GetOnLineOrderByLT(string orderID);
        /// <summary>
        /// 获取订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        OnLineOrder GetOnlineOrder(string orderID, int Userid);

        ///// <summary>
        ///// 获取苹果产品列表
        ///// </summary>
        ///// <returns></returns>
        //DataSet GetAppList();

        ///// <summary>
        ///// 获取苹果产品列表
        ///// </summary>
        ///// <returns></returns>
        //DataSet GetAppListByTagID(int tagID);

        ///// <summary>
        ///// 获取产品信息
        ///// </summary>
        ///// <param name="ProductID"></param>
        ///// <returns></returns>
        //DataSet GetAppInfoByProductID(string productID);

        ///// <summary>
        ///// 写快钱返回记录
        ///// </summary>
        ///// <param name="detialInfo"></param>
        ///// <param name="receiptt"></param>
        //void WriteReturnAppDetail(ShareDetialInfo detialInfo, AppReceiptInfo receiptt);

        #endregion

        #region 充值记录

        /// <summary>
        /// 充值记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        DataSet GetPayRecord(string whereQuery, int pageIndex, int pageSize);

        /// <summary>
        /// 充值记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="wherestr"></param>
        /// <returns></returns>
        DataSet GetRechRecord(int pageindex, int pagesize, string wherestr);

        ///// <summary>
        ///// 查询购买会员明细
        ///// </summary>
        ///// <param name="orderid"></param>
        ///// <returns></returns>
        //BuyMemberOrderDetails GetBuyMemberOrderDetails(string orderid);

        #endregion

        #region 推广中心

        /// <summary>
        /// 获取用户推广信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        Message GetUserSpreadInfo(int userID);

        /// <summary>
        /// 用户推广结算
        /// </summary>
        /// <param name="balance"></param>
        /// <param name="userID"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        Message GetUserSpreadBalance(int balance, int userID, string ip);

        /// <summary>
        /// 推广记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        DataSet GetSpreaderRecord(string whereQuery, int pageIndex, int pageSize);

        /// <summary>
        /// 单个用户下所有被推荐人的推广信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        DataSet GetUserSpreaderList(int userID, int pageIndex, int pageSize);

        /// <summary>
        /// 获取单个结算总额
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        long GetUserSpreaderTotal(string sWhere);

        /// <summary>
        /// 获取推广配置实体
        /// </summary>
        /// <returns></returns>
        GlobalSpreadInfo GetGlobalSpreadInfo();

        #endregion

        #region 银行操作

        /// <summary>
        /// 金币存入
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="TradeScore"></param>
        /// <param name="minTradeScore"></param>
        /// <param name="clientIP"></param>
        /// <param name="note"></param>
        /// <returns></returns>
        Message InsureIn(int userID, int TradeScore, int minTradeScore, string clientIP, string note);


        /// <summary>
        /// 金币取出
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="insurePass"></param>
        /// <param name="TradeScore"></param>
        /// <param name="minTradeScore"></param>
        /// <param name="clientIP"></param>
        /// <param name="note"></param>
        /// <returns></returns>
        Message InsureOut(int userID, string insurePass, int TradeScore, int minTradeScore, string clientIP, string note);

        /// <summary>
        /// 金币转账
        /// </summary>
        /// <param name="srcUserID"></param>
        /// <param name="insurePass"></param>
        /// <param name="dstUserID"></param>
        /// <param name="TradeScore"></param>
        /// <param name="minTradeScore"></param>
        /// <param name="clientIP"></param>
        /// <param name="note"></param>
        /// <returns></returns>
        Message InsureTransfer(int srcUserID, string insurePass, int dstUserID, int TradeScore, int minTradeScore, string clientIP, string note);

        /// <summary>
        /// 游戏记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        DataSet GetInsureTradeRecord(string whereQuery, int pageIndex, int pageSize);

        #endregion

        #region 获取金币信息

        /// <summary>
        /// 根据用户ID得到金币信息
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        GameScoreInfo GetTreasureInfo2(int UserID);

        #endregion

        #region 财富排名

        /// <summary>
        /// 财富排名
        /// </summary>
        /// <returns></returns>
        IList<GameScoreInfo> GetGameScoreInfoOrderByScore();

        /// <summary>
        /// 财富排名
        /// </summary>
        /// <returns></returns>
        DataSet GetScoreRanking(int num);
        #endregion

        #region 会员操作

        /// <summary>
        /// 负分清零
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        Message ClearGameScore(int userID, string ip);

        /// <summary>
        /// 逃跑清零
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        Message ClearGameFlee(int userID, string ip);

        #endregion

        #region 游戏记录

        ///// <summary>
        ///// 每桌游戏记录
        ///// </summary>
        ///// <param name="whereQuery"></param>
        ///// <param name="pageIndex"></param>
        ///// <param name="pageSize"></param>
        ///// <returns></returns>
        //DataSet GetDrawInfoRecord(string whereQuery, int pageIndex, int pageSize);

        ///// <summary>
        ///// 每桌详细记录
        ///// </summary>
        ///// <param name="whereQuery"></param>
        ///// <param name="pageIndex"></param>
        ///// <param name="pageSize"></param>
        ///// <returns></returns>
        //DataSet GetDrawScoreRecord(string whereQuery, int pageIndex, int pageSize);

        #endregion

        #region 公共

        /// <summary>
        /// 获取数据
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sqlQuery"></param>
        /// <param name="whereQuery"></param>
        /// <param name="orderBy"></param>
        /// <returns></returns>
        DataSet GetList(int pageIndex, int pageSize, string sqlQuery, string whereQuery, string orderBy);

        /// <summary>
        /// 根据sql语句获取数据
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        DataSet GetDataSetByWhere(string sqlQuery);

        /// <summary>
        /// 根据sql获取实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <returns></returns>
        T GetEntity<T>(string commandText, List<DbParameter> parms);

        /// <summary>
        /// 根据sql获取实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <returns></returns>
        T GetEntity<T>(string commandText);

        #endregion

        #region 任务系统

        /// <summary>
        /// 每日签到
        /// </summary>
        /// <param name="detialInfo"></param>
        /// <param name="receipt"></param>
        Message WriteCheckIn(int userID, string strClientIP);
        #endregion

        #region 获取卡类型信息
        /// <summary>
        /// 获取卡类型列表
        /// </summary>
        /// <returns></returns>
        IList<GlobalLivcard> GetGlobalLivcardList(int top, string wherestr);
        #endregion

        #region 喔咕咕交易
        /// <summary>
        /// 喔咕咕 冻结卖家金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message WggFreeze(WguguOrder entity);
        /// <summary>
        /// 喔咕咕 买家购买金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message WggTrade(WguguOrder entity);
        /// <summary>
        /// 喔咕咕 解冻卖家金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message WggUnfreeze(WguguOrder entity);
        #endregion

        #region 网站 砸金蛋 转盘 挖宝 活动
        ///// <summary>
        ///// 活动赠送金币
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //Message InsertRecordActivityPresentGold(int userid, long gold, bool ispresent, int activitypid, int expendtype, int expendnum);
        ///// <summary>
        ///// 活动赠送会员
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //Message InsertRecordActivityPresentMember(int userid, int membercardtypeid, int memberdays, bool ispresent, int activitypid, int expendtype, int expendnum);
        ///// <summary>
        ///// 活动赠送奖牌
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //Message InsertRecordActivityPresentUserMedal(int userid, int usermedal, bool ispresent, int activitypid, int expendtype, int expendnum);



        #endregion

        #region 网站活动 订单管理
        ///// <summary>
        ///// 活动赠送实物及奖品 产生订单
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //Message InsertProductOrderForActivity(string orderid, int productpid, int userid, int number, bool ispresent, int activitypid, int expendtype, int expendnum);
        /// <summary>
        /// 活动赠送实物及奖品 处理订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message ActivityProductOrderProcess(string orderid, string qqnumber, string telephone, string postcode, string address, string remark);
        #endregion

        #region 产品订单管理
        /// <summary>
        /// 商城购买虚拟物品 产生订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertProductOrderForMall(string orderid, int productpid, int userid, int number, string name, string qqnumber, string telephone, string postcode, string address, string remark, Game.Type.ProductOrderStatus orderstatus);
        /// <summary>
        /// 商城购买虚拟物品 处理订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message MallProductOrderProcess(string orderid, Game.Type.ProductOrderStatus status, string remark);
        /// <summary>
        /// 查询单条产品记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        Product GetProduct(int pid);
        /// <summary>
        /// 查询记录数量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        int GetProductCount(string wherestr);
        /// <summary>
        /// 查询产品记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        IList<Product> GetProductTopList(int top, string wherestr, string order);
        /// <summary>
        /// 查询产品记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        DataSet GetProductRecord(int pageindex, int pagesize, string wherestr, string order);
        /// <summary>
        /// 获取商品信息IconID
        /// </summary>
        /// <param name="wherecase"></param>
        /// <returns></returns>
        DataSet GetProductRecord(string wherecase);
        /// <summary>
        /// 查询单条订单记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        ProductOrder GetProductOrder(string orderid);
        /// <summary>
        /// 查询记录数量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        int GetProductOrderCount(string wherestr);
        /// <summary>
        /// 查询订单记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        IList<ProductOrder> GetProductOrderTopList(int top, string wherestr, string order);
        /// <summary>
        /// 查询订单记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        DataSet GetProductOrderRecord(int pageindex, int pagesize, string wherestr);

        /// <summary>
        /// 查询订单明细记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        MallBuyDetail GetProductOrderDetailObject(string orderid);
        /// <summary>
        /// 查询订单明细记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        DataSet GetProductOrderDetailRecord(int pageindex, int pagesize, string wherestr);
        #endregion

        #region 新版充值 金豆充值
        /// <summary>
        /// 创建充值金豆订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertRechOrder(RechOrder entity);

        /// <summary>
        /// 快钱RMB充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        Message RechGoldenBeanFromKQRMB(ReturnKQDetailInfo returnInfo);

        /// <summary>
        /// 快钱充值卡充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        Message RechGoldenBeanFromKQCARD(ReturnKQCardDetailInfo returnInfo);

        /// <summary>
        /// 支付宝充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        Message RechGoldenBeanFromZFB(ReturnZFBDetailInfo returnInfo);
        /// <summary>
        /// 支付宝充值vip房间道具 更新订单信息
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        Message RechVIPFromZFB(ReturnZFBDetailInfo returnInfo);

        /// <summary>
        ///微信充值vip房间道具 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        Message RechVIPFromWX(ReturnWeixinDetailInfo returnInfo);

        /// <summary>
        /// 微信二维码充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        Message RechGoldenBeanFromWeixin(ReturnWeixinDetailInfo returnInfo);

        /// <summary>
        /// 天下付充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        Message RechGoldenBeanFromTXF(string orderID);

        /// <summary>
        /// 查询用户金豆信息
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        UserGoldenBean GetUserGoldenBean(int userid);

        /// <summary>
        /// 查询充值金豆订单信息
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        RechOrder GetRechOrderByOrderID(string orderid);

        ///// <summary>
        ///// 使用金豆购买会员和金币
        ///// </summary>
        ///// <param name="userid"></param>
        ///// <param name="memberorder"></param>
        ///// <param name="number"></param>
        ///// <returns></returns>
        //Message ConvertGoldenBeanToMemberAndGold(int userid, int number);

        /// <summary>
        /// 查询充值金豆规则
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        Message QueryRechRules(int userid, decimal orderamount);

        /// <summary>
        /// 查询金豆交易记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        DataSet GetRecordUserGoldenBean(int pageindex, int pagesize, string wherestr);
        #endregion

        #region 新版奖牌、魅力值
        /// <summary>
        /// 查询用户金豆信息
        /// author:francis
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        GameScoreInfoEx GetGameScoreInfoEx(int userid);
        #endregion

        #region 新版任务系统
        /// <summary>
        /// 查询任务记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="wherestr"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataSet GetUserTaskRecord(int pageindex, int pagesize, string wherestr, string order);
        /// <summary>
        /// 修改任务状态
        /// </summary>
        /// <param name="taskid"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        bool UpdateUserTaskStatusByTaskID(int taskid, int userid);
        #endregion

        #region 美女视频
        /// <summary>
        /// 美女扣费记录
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message ProcessMeinvFee(RecordMeinvFee entity);
        /// <summary>
        /// 新增美女主播浏览记录
        /// </summary>
        /// <param name="entity"></param>
        void InsertRecordMeinvSPBrowse(RecordMeinvSPBrowse entity);
        #endregion
        #region 互动道具
        /// <summary>
        /// 获取互动道具配置
        /// </summary>
        /// <returns></returns>
        DataSet GetInteractItem();
        #endregion
        #region vip房间充值配置获取
        /// <summary>
        /// vip房间充值配置获取
        /// </summary>
        DataSet GetVipRechargeReward();
        /// <summary>
        /// 查询返利记录
        /// </summary>
        DataSet GetRebateDetail(int pageindex, int pagesize, int userid, string stime, string etime);
        /// <summary>
        /// 根据条件获取返利数量
        /// </summary>
        /// <param name="where"></param>
        /// <returns></returns>
        int GetRebateCount(string where);
        #endregion
    }
}
