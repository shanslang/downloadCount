﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.NativeWeb;
using Game.Type;

namespace Game.IData
{
    /// <summary>
    /// 网站库数据层接口
    /// </summary>
    public interface INativeWebDataProvider //: IProvider
    {
        #region 测试DB
        DataSet TestTableLock();
        #endregion

        #region sql执行统计
        IList<Game.Francis.DBHelper.RecordQPFrontExecSQL> GetRecordQPFrontExecSQLList();
        void InsertRecordQPFrontExecSQL(Dictionary<string, Game.Francis.DBHelper.RecordQPFrontExecSQL> data);
        #endregion

        #region 网站新闻

        /// <summary>
        /// 获取置顶新闻列表
        /// </summary>
        /// <param name="newsType"></param>
        /// <param name="hot"></param>
        /// <param name="elite"></param>
        /// <param name="top"></param>
        /// <returns></returns>
        IList<News> GetTopNewsList(int typeID, int hot, int elite, int top);

        /// <summary>
        /// 获取新闻列表
        /// </summary>
        /// <returns></returns>
        IList<News> GetNewsList();

        /// <summary>
        /// 获取分页新闻列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        DataSet GetNewsList(int pageIndex, int pageSize);

        /// <summary>
        /// 获取分页新闻列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        DataSet GetNewsList(int pageIndex, int pageSize, string wherestr);

        /// <summary>
        /// 获取新闻 by newsID
        /// </summary>
        /// <param name="newsID"></param>
        /// <param name="mode">模式选择, 0=当前主题, 1=上一主题, 2=下一主题</param>
        /// <returns></returns>
        News GetNewsByNewsID(int newsID, byte mode);

        /// <summary>
        /// 获取公告
        /// </summary>
        /// <param name="noticeID"></param>
        /// <returns></returns>
        Notice GetNotice(int noticeID);

        #endregion

        #region 网站问题

        /// <summary>
        /// 获取问题列表
        /// </summary>
        /// <param name="issueType"></param>
        /// <param name="top"></param>
        /// <returns></returns>
        IList<GameIssueInfo> GetTopIssueList(int top);

        /// <summary>
        /// 获取问题列表
        /// </summary>
        /// <returns></returns>
        IList<GameIssueInfo> GetIssueList();

        /// <summary>
        /// 获取分页问题列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        DataSet GetIssueList(int pageIndex, int pageSize);

        /// <summary>
        /// 获取问题实体
        /// </summary>
        /// <param name="issueID"></param>
        /// <param name="mode">模式选择, 0=当前主题, 1=上一主题, 2=下一主题</param>
        /// <returns></returns>
        GameIssueInfo GetIssueByIssueID(int issueID, byte mode);

        #endregion

        #region 反馈意见

        /// <summary>
        /// 获取分页反馈意见列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        DataSet GetFeedbacklist(int pageIndex, int pageSize);

        /// <summary>
        /// 获取反馈意见实体
        /// </summary>
        /// <param name="issueID"></param>
        /// <param name="mode">模式选择, 0=当前主题, 1=上一主题, 2=下一主题</param>
        /// <returns></returns>
        GameFeedbackInfo GetGameFeedBackInfo(int feedID, byte mode);

        /// <summary>
        /// 更新浏览量
        /// </summary>
        /// <param name="feedID"></param>
        void UpdateFeedbackViewCount(int feedID);

        /// <summary>
        /// 发表留言
        /// </summary>
        /// <returns></returns>
        Message PublishFeedback(GameFeedbackInfo info);
        /// <summary>
        /// 设置问题反馈的图片信息
        /// </summary>
        /// <param name="imageurl"></param>
        void FeedbackSetImage(int entityid, string imageurl);

        #endregion

        #region 游戏帮助数据

        /// <summary>
        /// 获取推荐游戏详细列表
        /// </summary>
        /// <returns></returns>
        IList<GameRulesInfo> GetGameHelps(int top);

        /// <summary>
        /// 获取游戏详细信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        GameRulesInfo GetGameHelp(int kindID);

        #endregion

        #region 游戏比赛信息

        /// <summary>
        /// 得到比赛列表
        /// </summary>
        /// <returns></returns>
        IList<GameMatchInfo> GetMatchList();

        /// <summary>
        /// 得到比赛详细信息
        /// </summary>
        /// <param name="matchID"></param>
        /// <returns></returns>
        GameMatchInfo GetMatchInfo(int matchID);

        /// <summary>
        /// 比赛报名
        /// </summary>
        /// <param name="userInfo"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        Message AddGameMatch(GameMatchUserInfo userInfo, string password);

        #endregion

        #region 简易论坛
        /// <summary>
        /// 获取单条栏目信息
        /// </summary>
        /// <returns></returns>
        InfoCatalog GetInfoCatalogByPid(int pid);

        /// <summary>
        /// 获取栏目列表
        /// </summary>
        /// <returns></returns>
        IList<InfoCatalog> GetInfoCatalogList(int top);

        /// <summary>
        /// 获取单条列主题信息
        /// </summary>
        /// <returns></returns>
        InfoTopic GetInfoTopicByPid(int pid);

        /// <summary>
        /// 获取主题列表
        /// </summary>
        /// <returns></returns>
        DataSet GetInfoTopicList(int pageindex, int pagesize, string order, string where);

        /// <summary>
        /// 新增主题
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertInfoTopic(InfoTopic entity);

        /// <summary>
        /// 修改主题
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message UpdateInfoTopicByPid(InfoTopic entity);

        /// <summary>
        /// 修改主题点击次数
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message UpdateInfoTopicHitsByPid(InfoTopic entity);

        /// <summary>
        /// 删除主题
        /// </summary>
        /// <returns></returns>
        Message DeleteInfoTopicByPid(InfoTopic entity);

        /// <summary>
        /// 获取回复列表
        /// </summary>
        /// <returns></returns>
        DataSet GetInfoItemList(int pageindex, int pagesize, string order, string where);

        /// <summary>
        /// 新增回复
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertInfoItem(InfoItem entity);

        /// <summary>
        /// 删除回复
        /// </summary>
        /// <returns></returns>
        Message DeleteInfoItemByPid(InfoItem entity);
        #endregion

        #region 友情链接
        /// <summary>
        /// 获取友情链接列表
        /// </summary>
        /// <returns></returns>
        DataSet GetFriendLinksList(int pageindex, int pagesize, string where, string order);
        #endregion

        #region 推广系统
        /// <summary>
        /// 验证推广ID是否存在
        /// </summary>
        /// <param name="SpreadID"></param>
        /// <returns></returns>
        int ExistsSpreadUserID(int SpreadID);
        /// <summary>
        /// 建立推广员关系
        /// </summary>
        /// <returns></returns>
        bool SpreadUserBindingSet(int UserID, int SpreadUserID);
        /// <summary>
        /// 新增推广员
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertSpreadUser(SpreadUser entity);
        /// <summary>
        /// 新增浏览记录
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertRecordRecordTrackBrowse(RecordTrackBrowse entity);
        /// <summary>
        /// 获取推广员信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        SpreadUser GetSpreadUserByUserID(int userid);

        /// <summary>
        /// 新增推广财务信息
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertSpreadFinanceInfo(SpreadFinanceInfo entity);
        /// <summary>
        /// 获取推广员财务信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        SpreadFinanceInfo GetSpreadFinanceInfoBySpreadUserID(int spreaduserpid);

        /// <summary>
        /// 获取推广员审核的最新信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        RecordSpreadUserAudit GetSpreadUserLastAuditInfo(int spreaduserid);
        /// <summary>
        /// 获取推广注册记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataSet GetSpreadRegRecord(int pageindex, int pagesize, string where, string order);
        /// <summary>
        /// 获取推广充值记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataSet GetSpreadRechRecord(int pageindex, int pagesize, string where, string order);
        /// <summary>
        /// 获取推广浏览记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataSet GetSpreadBrowseRecord(int spreaduserid, int pageindex, int pagesize, string where, string order);
        /// <summary>
        /// 获取推广浏览记录 按天
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataSet GetSpreadBrowseRecordByDay(int spreaduserid, int pageindex, int pagesize, string where, string order);

        /// <summary>
        /// 获取推广业绩 按天
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataSet GetSpreadRecordByDay(int spreaduserid, int pageindex, int pagesize, string where, string order);
        /// <summary>
        /// 统计访问量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataRow GetSpreadBrowseTotal(int spreaduserid, string where);
        /// <summary>
        /// 统计注册人数
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataRow GetSpreadRegTotal(int spreaduserid, string where);
        /// <summary>
        /// 统计注册人数(通过手机认证)
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataRow GetSpreadRegTelephoneAuthTotal(int spreaduserid, string where);
        /// <summary>
        /// 统计注册人数(有效用户 充值金额大于0  and 游戏时间大于20分钟)
        /// </summary>
        /// <param name="spreaduserid"></param>
        /// <param name="where"></param>
        /// <returns></returns>
        DataRow GetSpreadRegEffectiveTotal(int spreaduserid, string where);
        /// <summary>
        /// 统计充值人数
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataRow GetSpreadRechTotal(int spreaduserid, string where);
        /// <summary>
        /// 统计活跃人数
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        DataRow GetSpreadActiveTotal(int spreaduserid, string where);
        /// <summary>
        /// 统计已经兑换兑换码数量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        int GetChannelIDCDKeyTotal(int channelid, string where);
        /// <summary>
        /// 统计结算提成
        /// </summary>
        /// <param name="spreaduserid"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        DataRow CalculateSpreadUserCommission(int spreaduserid, DateTime date);
        /// <summary>
        /// 获取最近24笔 已经结算的记录
        /// </summary>
        /// <param name="spreaduserpid"></param>
        /// <param name="where"></param>
        /// <returns></returns>
        DataTable GetSpreadSettlement(int spreaduserpid, string where);
        /// <summary>
        /// 推广处理结算
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="settlementtype"></param>
        /// <returns></returns>
        Message SpreadSettlementProcess(int pid, int settlementtype);
        #endregion

        #region 生成验证码
        /// <summary>
        /// 生成认证Code
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        string BuilderCheckCode(Game.Type.AuthUseType type, int userid, string telephone, string email);
        /// <summary>
        /// 绑定手机
        /// </summary>
        Message BindPhone(int userid, string code, string telephone);
        /// <summary>
        /// 生成认证Code
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        Message BuilderCheckCodeFormsg(Game.Type.AuthUseType type, int userid, string telephone, string email);

        /// <summary>
        /// 认证验证
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        Message AuthCheck(Game.Type.AuthUseType type, int userid, string code, string telephone, string email);
         /// <summary>
        /// 认证手机（不需要验证验证码）
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        Message AuthPhone(int userid, string telephone);
        /// <summary>
        /// 认证验证新版
        /// </summary>
        Message AuthCheckNew(int userid, string code, string telephone, string nickname, string password);
        /// <summary>
        /// 验证验证码
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        Message VerificationCheckCode(Game.Type.AuthUseType type, int userid, string code, string telephone, string email);
        #endregion

        #region 每日签到
        /// <summary>
        /// 每日领取金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertRecordDailySign(RecordDailySign entity);
        /// <summary>
        /// 获取当月签到记录
        /// </summary>
        /// <returns></returns>
        IList<RecordDailySign> GetCurrentMonthDailySignList(int userid);
        /// <summary>
        /// 获取签到奖励配置信息
        /// </summary>
        /// <returns></returns>
        DataSet GetSignRewardCFGList();

        #endregion

        #region 许愿活动
        /// <summary>
        /// 获得母亲节许愿活动
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        void InsertActivityWishing(ActivityWishing o);

        /// <summary>
        /// 获得母亲节许愿活动
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        DataSet GetActivityWishingList(int pageindex, int pagesize, string wherestr);
        #endregion

        #region 检测网吧活动
        /// <summary>
        /// 获取网吧信息
        /// </summary>
        /// <param name="ipaddress">IP地址</param>
        /// <returns></returns>
        ActivityInternetcafe GetActivityInternetcafeByIP(string ipaddress);

        /// <summary>
        /// 获取网吧当日用户是否达到最大次数
        /// </summary>
        /// <param name="ipaddress">IP地址</param>
        /// <returns></returns>
        bool IsExceedDayFreeNum(ActivityInternetcafe internetcafe, int userid);
        #endregion

        #region 网站活动 活动记录
        /// <summary>
        /// 活动奖励记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        DataSet GetActivityPlizeRecord(int pageindex, int pagesize, string wherestr);
        #endregion

        #region 网站活动 黄金挖矿
        /// <summary>
        /// 网站活动 黄金挖矿
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="activitypid"></param>
        /// <param name="expendgold"></param>
        /// <param name="ispresent"></param>
        /// <param name="presenttype"></param>
        /// <param name="presentgold"></param>
        /// <param name="presentmedal"></param>
        /// <param name="presentmemberorder"></param>
        /// <param name="presentdays"></param>
        /// <returns></returns>
        Message ActivityHJWK(int userid, int activitypid, long expendgold, bool ispresent, long presenttype, long presentgold, long presentmedal, int presentmemberorder, int presentmemberdays);
        #endregion

        #region 网站活动 欢乐购
        /// <summary>
        /// 活动 金豆购买会员送奖牌
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="memberdays"></param>
        /// <returns></returns>
        Message ActivityHLG(int activitypid, int userid, Game.Type.MemberLevel memberorder, int memberdays);
        #endregion

        #region 活动配置信息
        /// <summary>
        /// 获取活动配置信息
        /// </summary>
        /// <param name="whereCase"></param>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        IList<ActivityInfoCFG> GetActivityInfoList(string whereCase, string orderbywhere);

        #endregion

        #region 网站活动 九宫格免费抽奖
        /// <summary>
        /// 活动 九宫格免费抽奖
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="memberdays"></param>
        /// <returns></returns>
        Message ActivityJGGMFCJ(int userid, int activitypid, long presenttype, long presentgold, long presentmedal, int presentmemberorder, int presentmemberdays, int presentproertypid, int presentproerty);
        /// <summary>
        /// 查询用户还须玩的局数
        /// </summary>
        /// <returns></returns>
        int GetUserGameCount(int userid, string where);
        /// <summary>
        /// 查询用户是否参与抽奖次数
        /// </summary>
        /// <returns></returns>
        int GetUserIsJoinActivityJGG(int userid, int activitypid, string where);
        /// <summary>
        /// 活动 九宫格免费抽奖-定时奖励
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="memberdays"></param>
        /// <returns></returns>
        Message ActivityJGGMFCJReward(string json, DateTime stime, DateTime etime);
        #endregion

        #region QQ邮箱发送记录
        /// <summary>
        /// 新增QQ邮箱发送记录
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertRecordSendEmail(RecordSendEmail entity);
        /// <summary>
        /// 修改QQ企业邮箱发送记录状态
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message UpdateRecordSendEmailStateID(int pid, byte stateid);
        /// <summary>
        /// 获取QQ邮箱发送记录
        /// </summary>
        /// <returns></returns>
        RecordSendEmail GetRecordSendEmailLast();
        #endregion

        #region PC蛋蛋
        /// <summary>
        /// PC蛋蛋广告奖励查询接口
        /// </summary>
        /// <param name="gameid"></param>
        /// <returns></returns>
        DataSet GetPCeggsReward(int gameid);
        #endregion

        #region 小游戏 财神到
        /// <summary>
        /// 检查是否可以开始游戏
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="xgameconfigpid">游戏配置ID</param>
        /// <returns></returns>
        Message XGameCheckUserGame(int userid, int xgameconfigpid);
        /// <summary>
        /// 购买游戏次数
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="xgameconfigpid">游戏配置ID</param>
        /// <returns></returns>
        Message XGamePayGameCount(int userid, int xgameconfigpid);
        /// <summary>
        /// 财神到游戏写分
        /// </summary>
        /// <param name="recordpid">游戏记录ID</param>
        /// <param name="userid"></param>
        /// <param name="score">分数</param>
        /// <returns></returns>
        Message XGameCSDWriteScore(int recordpid, int userid, int score);
        /// <summary>
        /// 西游记游戏写分
        /// </summary>
        /// <param name="recordpid">游戏记录ID</param>
        /// <param name="userid"></param>
        /// <param name="score">分数</param>
        /// <returns></returns>
        Message XGameXYJWriteScore(int recordpid, int userid, int score);
        #endregion

        #region 每日签到V2.0
        /// <summary>
        /// 每日签到
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertRecordDailySignV2(RecordDailySignV2 entity);
        /// <summary>
        /// 每日签到（补签）
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message InsertRecordDailySignV2Repair(RecordDailySignV2 entity);
        /// <summary>
        /// 每日签到（连续签到奖励）
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message DailySignV2ContinuityReward(int userid, int rewardtype);
        /// <summary>
        /// 获取当月签到记录
        /// </summary>
        /// <returns></returns>
        IList<RecordDailySignV2> GetCurrentMonthDailySignV2List(int userid);
        /// <summary>
        /// 获取当月连续签到记录
        /// </summary>
        /// <returns></returns>
        IList<RecordDailySignV2Reward> GetCurrentMonthDailySignV2RewardList(int userid);
        /// <summary>
        /// 获取当月具体签到日期
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        List<int> GetSignDayThisMonth(int UserID);

        /// <summary>
        /// 获取手游安装包上传管理员Key
        /// </summary>
        /// <returns></returns>
        string GetUpLoadDeployKey();
        #endregion

        #region 战绩榜、财富榜、魅力榜
        /// <summary>
        /// 财富榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        DataSet RakingScoreDataList(int RankCounts);
        /// <summary>
        /// 战绩榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        DataSet RakingRecordDataList(int RankCounts);
        /// <summary>
        /// 魅力榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        DataSet RakingLoveLinessDataList(int RankCounts);
        #endregion

        #region 兑换CDK
        /// <summary>
        /// 兑换CDK
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message ConvertPackageCDKey(int userid, string packagecdkey, int channelid);
        /// <summary>
        /// 随机生成CDK
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message GenerationPackageCDKey(int packagetypepid, string packagecdkey);
        #endregion

        #region 获取自动发送短信池
        /// <summary>
        /// 获取自动发送短信池 未发送的短信记录
        /// </summary>
        /// <returns></returns>
        IList<AutoSendTelephoneMessage> GetAutoSendTelephoneMessageTopList(int top);
        /// <summary>
        /// 修改短信记录状态
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="status">发送状态 0=未发送 1=已发送</param>
        /// <returns></returns>
        bool UpdateAutoSendTelephoneMessageStatus(int pid, byte status);
        #endregion

        #region 绑定推广员
        /// <summary>
        /// 绑定推广员
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Message BindSpread(int userid, int spreadgameid);
        #endregion

        #region 获取比赛条件
        /// <summary>
        /// 获取比赛参赛条件
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="matchid"></param>
        /// <returns></returns>
        DataSet GetMatchCondition(int userid, int matchid);
        /// <summary>
        /// 获取比赛参赛条件App
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="matchid"></param>
        /// <returns></returns>
        DataSet GetMatchConditionApp(int matchid);
        #endregion

        #region 下载统计
        /// <summary>
        /// 插入下载记录
        /// </summary>
        /// <param name="DeviceType"></param>
        /// <param name="KindID"></param>
        /// <returns></returns>
        int InsertDownLoadLog(int DeviceType, int KindID);
        #endregion
    }
}
