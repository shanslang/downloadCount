﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

using Game.Francis;
using Game.Entity.Task;

namespace Game.IData
{
    public interface ITaskDataProvider
    {
        #region 旧版
        /// <summary>
        /// 获取未领取或未完成的任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="serverid"></param>
        /// <param name="gameid"></param>
        /// <returns></returns>
        DataSet GetTaskInfo(int userid, int serverid);

        /// <summary>
        /// 获取已经完成的任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="serverid"></param>
        /// <param name="gameid"></param>
        /// <returns></returns>
        DataSet GetTaskInfoed(int userid, int serverid);

        /// <summary>
        /// 获取任务奖励详细信息
        /// </summary>
        /// <param name="taskid">任务ID</param>
        /// <param name="sumtaskid">阶段ＩＤ</param>
        /// <returns></returns>
        IList<TaskRewardCfg> GetTaskRewardList(int taskid, int subtaskid);

        /// <summary>
        /// 领取任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        Message ReceiveTask(int userid, int taskid);

        /// <summary>
        /// 放弃任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        int GiveupTask(int userid, int taskid);

        /// <summary>
        /// 获取任务领取条件
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        DataSet GetTaskReceiveCondition(int userid, int taskid);
        /// <summary>
        /// 获取任务阶段列表
        /// </summary>
        /// <param name="TaskID"></param>
        /// <returns></returns>
        DataSet GetTaskTargetList(string TaskIDList, int Userid);
        /// <summary>
        ///获取任务奖励信息
        /// </summary>
        /// <param name="TaskID"></param>
        /// <returns></returns>
        IList<TaskRewardCfg> GetTaskReward(int TaskID, int subid);
        /// <summary>
        /// 发放任务奖励
        /// </summary>
        /// <param name="TaskID"></param>
        /// <param name="ServerID"></param>
        /// <param name="subTaskID"></param>
        /// <returns></returns>
        DataSet TaskReceiveReward(int TaskID, int ServerID, int subTaskID, int Userid);
        #endregion

        #region 新版
        /// <summary>
        /// 
        /// </summary>
        /// <param name="taskid"></param>
        /// <returns></returns>
        NTaskInfo GetNTaskInfoByTaskIDForPlatform(int taskid);
        NTaskInfo GetNTaskInfoByTaskIDForMobile(int taskid);
        /// <summary>
        /// 获取任务对象
        /// </summary>
        /// <param name="taskid"></param>
        /// <returns></returns>
        NTaskInfo GetNTaskInfoByTaskID(int taskid);
        /// <summary>
        /// 获取任务奖励
        /// </summary>
        /// <returns></returns>
        IList<NTaskReward> GetNTaskRewardList(int taskid);
        /// <summary>
        /// 获取任务分组
        /// </summary>
        /// <returns></returns>
        IList<NTaskGroupInfo> GetNTaskGroupInfoList();
        /// <summary>
        ///获取全部任务信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        IList<NTaskInfo> GetTaskList(int kindID);
        #endregion
        /// <summary>
        /// 获取宝箱数据
        /// </summary>
        /// <returns></returns>
        DataSet GetChestsReward();
    }
}
