﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using Game.Francis;
using Game.IData;
using Game.Entity.Accounts;

namespace Game.IData
{
    /// <summary>
    ///  用户库数据层接口
    /// </summary>
    public interface IAccountsDataProvider//:IProvider
    {
        #region 用户登录、注册

        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="names">用户信息</param>
        /// <returns></returns>
        Message Login(UserInfo user);

        /// <summary>
        /// 用户注册
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        Message Register(UserInfo user, string parentAccount, int pceggid, string pceggadid);

        /// <summary>
        /// 判断用户名是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        Message IsAccountsExist(string accounts);

        /// <summary>
        /// 判断昵称是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        bool IsNickNameExist(string nickName);

        /// <summary>
        /// 判断认证手机是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        bool IsAuthTelephoneExist(string telephone);
        /// <summary>
        /// 判断认证手机或用户名是否存在手机号
        /// </summary>
        /// <param name="telephone"></param>
        /// <returns></returns>
        int IsAuthTelephoneOrRegisterAccounts(string telephone);
        /// <summary>
        /// 判断认证电子邮件是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        bool IsAuthEmailExist(string email);

        /// <summary>
        /// 用户MAC与账号关联
        /// </summary>
        void UserMacthineInsert(int UserID, string Mac);
        /// <summary>
        /// 根据MAC地址查询用户信息
        /// </summary>
        /// <param name="mac"></param>
        /// <returns></returns>
        int UserMachineInfoGet(string mac, int Regmark, int kindID);
        /// <summary>
        ///  根据百度ID查找用户
        /// </summary>
        /// <param name="baiduUID"></param>
        /// <returns></returns>
        int BaiduInfoGet(long baiduUID);
        /// <summary>
        /// 百度账号关联
        /// </summary>
        void BaiduUserInsert(int UserID, long baiduUID);
        /// <summary>
        /// 根据互联星空账号查询用户信息
        /// </summary>
        /// <param name="mac"></param>
        /// <returns></returns>
        int VnetInfoGet(string vnetID);

        /// <summary>
        /// 百度账号关联
        /// </summary>
        void VnetUserInsert(int UserID, string vnetID, string Tel, string imsi);
        /// <summary>
        /// 获取互联星空信息
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        VnetEntity VnetInfoGet(int UserID);
        /// <summary>
        /// 根据AnySDK查询用户信息
        /// </summary>
        int AnySDKInfoGet(string UID, string channel);
        /// <summary>
        /// AnySDK账号关联
        /// </summary>
        void AnySDKUserInsert(int UserID, string Channel, string UserSdk, string UID);
        /// <summary>
        /// 根据微信获取用户帐号
        /// </summary>
        /// <param name="OpenID"></param>
        /// <returns></returns>
        int WeiXinUserGet(string OpenID);
        /// <summary>
        /// 根据微信获取用户信息
        /// </summary>
        /// <param name="OpenID"></param>
        /// <returns></returns>
        Message WeiXinUserInfoGet(string OpenID, string unionID);
        /// <summary>
        /// 微信公众平台关注
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="OpenID"></param>
        void WeiXinUserInsert(int UserID, string openid, string unionID, string headurl);
        /// <summary>
        /// 查询是否绑定
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        bool IsBindWeixin(int userId);
        #endregion

        #region 获取用户信息

        /// <summary>
        /// 根据用户昵称获取用户ID
        /// </summary>
        /// <param name="nickName"></param>
        /// <returns></returns>
        int GetUserIDByNickName(string nickName);

        /// <summary>
        /// 获取基本用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        UserInfo GetUserBaseInfoByUserID(int userID);

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        UserInfo GetUserFullInfoByUserID(int userID);

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        UserInfo GetUserFullInfoByAccounts(string accounts);

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        UserInfo GetUserFullInfoByGameID(int gameid);
        /// <summary>
        /// 获取用户基本信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        UserInfo GetUserInfoByUserID(int UserID);

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        UserInfo GetUserFullInfoByAccountsOrGameID(string accountsorid);

        /// <summary>
        /// 获取用户配置信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        AccountsConfig GetAccountsConfigByUserID(int userid);

        /// <summary>
        /// 获取指定用户联系信息
        /// </summary>
        /// <param name="user">用户</param>
        /// <returns></returns> 		
        IndividualDatum GetUserContactInfoByUserID(int userID);

        /// <summary>
        /// 获取用户全局信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="gameID"></param>
        /// <param name="Accounts"></param>
        /// <returns></returns>
        Message GetUserGlobalInfo(int userID, int gameID, String Accounts);

        /// <summary>
        /// 获取用户头像信息 返回图片对象
        /// </summary>
        /// <param name="faceid"></param>
        /// <returns></returns>
        AccountsFace GetUserFaceByFaceID(int faceid);

        /// <summary>
        /// 获取用户头像信息 返回图片对象
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="faceid"></param>
        /// <returns></returns>
        AccountsFace GetUserFaceByFaceID(int userid, int faceid);

        /// <summary>
        /// 获取密保卡序列号
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <returns></returns>
        string GetPasswordCardByUserID(int userId);
        /// <summary>
        /// 通过手机号获取用户ID
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        int GetUserIDByPhone(string phone);
        #endregion

        #region	 密码管理

        /// <summary>
        /// 重置登录密码
        /// </summary>
        /// <param name="sInfo">密保信息</param>       
        /// <returns></returns>
        Message ResetLogonPasswd(AccountsProtect sInfo);

        /// <summary>
        /// 重置银行密码
        /// </summary>
        /// <param name="sInfo">密保信息</param>       
        /// <returns></returns>
        Message ResetInsurePasswd(AccountsProtect sInfo);

        /// <summary>
        /// 修改登录密码
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="srcPassword">旧密码</param>
        /// <param name="dstPassword">新密码</param>
        /// <param name="ip">连接地址</param>
        /// <returns></returns>
        Message ModifyLogonPasswd(int userID, string srcPassword, string dstPassword, string ip);

        /// <summary>
        /// 修改银行密码
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="srcPassword">旧密码</param>
        /// <param name="dstPassword">新密码</param>
        /// <param name="ip">连接地址</param>
        /// <returns></returns>
        Message ModifyInsurePasswd(int userID, string srcPassword, string dstPassword, string ip);

        /// <summary>
        /// 编辑登录密码 自带加密
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="dstPassword">新密码</param>
        /// <param name="ip">连接地址</param>
        /// <returns></returns>
        Message EditLogonPasswd(int userID, string dstPassword, string ip);

        /// <summary>
        /// 编辑银行密码 自带加密
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="dstPassword">新密码</param>
        /// <param name="ip">连接地址</param>
        /// <returns></returns>
        Message EditInsurePasswd(int userID, string dstPassword, string ip);

        #endregion

        #region  密码保护管理

        /// <summary>
        /// 申请帐号保护
        /// </summary>
        /// <param name="sInfo">密保信息</param>
        /// <returns></returns>
        Message ApplyUserSecurity(AccountsProtect sInfo);

        /// <summary>
        /// 修改帐号保护
        /// </summary>
        /// <param name="oldInfo">旧密保信息</param>
        /// <param name="newInfo">新密保信息</param>
        /// <returns></returns>
        Message ModifyUserSecurity(AccountsProtect newInfo);

        /// <summary>
        /// 获取密保信息 (userID)
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        Message GetUserSecurityByUserID(int userID);

        /// <summary>
        /// 获取密保信息 (gameID)
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        Message GetUserSecurityByGameID(int gameID);

        /// <summary>
        /// 获取密保信息 (Accounts)
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        Message GetUserSecurityByAccounts(string accounts);

        /// <summary>
        /// 密保确认
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        Message ConfirmUserSecurity(AccountsProtect info);

        #endregion

        #region 安全管理

        #region 固定机器

        /// <summary>
        /// 申请机器绑定
        /// </summary>
        /// <param name="sInfo">密保信息</param>
        /// <returns></returns>
        Message ApplyUserMoorMachine(AccountsProtect sInfo);

        /// <summary>
        /// 解除机器绑定
        /// </summary>
        /// <param name="sInfo">密保信息</param>
        /// <returns></returns>
        Message RescindUserMoorMachine(AccountsProtect sInfo);

        #endregion 固定机器结束

        #endregion

        #region 资料管理

        /// <summary>
        /// 更新个人资料
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        Message ModifyUserIndividual(IndividualDatum user);

        /// <summary>
        /// 更新用户头像
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="faceID"></param>
        /// <returns></returns>
        Message ModifyUserFace(int userID, int faceID);

        /// <summary>
        /// 更新用户昵称
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="faceID"></param>
        /// <returns></returns>
        Message ModifyUserNickname(int userID, string nickName, string ip);
        /// <summary>
        /// 更新微信信息
        /// </summary>
        bool UpdateWeiXinInfo(int userId, string weixinName, int sex);
        #endregion

        #region 魅力

        /// <summary>
        /// 魅力兑换
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="medals"></param>
        /// <param name="rate"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        Message UserConvertPresent(int userID, int medals, int rate, string ip);

        /// <summary>
        /// 根据用户魅力排名(前10名)
        /// </summary>
        /// <returns></returns>
        IList<UserInfo> GetUserInfoOrderByLoves();

        /// <summary>
        /// 获取用户排行榜
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        DataSet GetLovesRanking(int num);

        #endregion

        #region 奖牌兑换

        Message UserConvertMedal(int userID, int medals, int rate, string ip);

        #endregion

        #region 密保卡信息

        /// <summary>
        /// 检测密保卡序列号是否存在
        /// </summary>
        /// <param name="serialNumber">密保卡序列号</param>
        /// <returns></returns>
        bool PasswordIDIsEnable(string serialNumber);

        /// <summary>
        /// 检测用户是否绑定了密保卡
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <param name="serialNumber">密保卡序列号</param>
        /// <returns></returns>
        bool userIsBindPasswordCard(int userId);

        /// <summary>
        /// 更新用户密保卡序列号
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <param name="serialNumber">密保卡序列号</param>
        /// <returns></returns>
        bool UpdateUserPasswordCardID(int userId, int serialNumber);

        /// <summary>
        /// 取消密保卡绑定
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        bool ClearUserPasswordCardID(int userId);

        #endregion

        #region 获取用户会员列表
        /// <summary>
        /// 根据用户ID获取会员列表
        /// </summary>
        /// <param name="nickName"></param>
        /// <returns></returns>
        IList<AccountsMember> GetAccountsMemberList(int userid);
        /// <summary>
        /// 根据条件获取会员列表
        /// </summary>
        /// <param name="nickName"></param>
        /// <returns></returns>
        IList<AccountsMember> GetAccountsMemberList(string wherecase, string orderwhere);
        #endregion

        #region 公共

        /// <summary>
        /// 根据SQL语句查询一个值
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        object GetObjectBySql(string sqlQuery);

        #endregion

        #region 手游
        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        DataSet GetMAccountInfo(int userid);
        /// <summary>
        /// 获取用户头像信息
        /// </summary>
        /// <param name="FaceID"></param>
        /// <returns></returns>
        AccountsUploadFace GetUserFaceInfo(int Userid, int FaceID);
        /// <summary>
        /// 更新用户自定义头像(用户上传图片，更新图片地址)
        /// </summary>
        /// <param name="Userid"></param>
        /// <param name="facelink"></param>
        /// <param name="picmd5"></param>
        /// <returns></returns>
        Message UploadAccountUserFace(int Userid, string FileMd5, int CustomId, bool isPC);
        /// <summary>
        /// 获取新手奖励
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        DataSet GetNoviceAwardList(int kindID);
        #endregion
        #region 获取用户麻将开房道具数据
        /// <summary>
        /// 获取用户道具信息（麻将开房道具）
        /// </summary>
        DataSet GetUserProperty(bool issuper, int targetuser, int userid);
        /// <summary>
        /// 根据用户ID获取开房道具数量
        /// </summary>
        int GetUserPropertybyUserID(int userid);
        #endregion
        #region 经销商相关
        /// <summary>
        /// 获取是否成为下级经销商标识
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        int GetIsConfirm(int userID);
        /// <summary>
        /// 获取上级代理商
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        DataSet GetParentDealerName(int userID);
        /// <summary>
        /// 确认成为下级经销商
        /// </summary>
        /// <param name="userID"></param>
        int ConfirmChildDealer(int userID);
        /// <summary>
        /// 取消下级经销商
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        int CancelChildDealer(int userID);
        /// <summary>
        /// 新增下级代理商
        /// </summary>
        Message AddChildDealer(int userID, int childUserID, string name);
        /// <summary>
        /// 新增下级代理商
        /// </summary>
        Message AddChildAgent(int userID, string userName, string nickName, string pwd);
        /// <summary>
        /// 获取经销商列表
        /// </summary>
        DataSet GetDealerList(int pageindex, int pagesize, int userid);
        /// <summary>
        /// 获取二级经销商数量
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        int GetChildDealerCount(int userID);
        #endregion
        DataSet GetWeiXinUserInfo(string table, string unionID);
        void InsertWeiXinUser(int UserID, string openid, string unionID, string headurl, string table);
        void UpdateWeiXinHead(string unionID, string headurl, string table);
        /// <summary>
        /// 获取用户战绩
        /// </summary>
        Message GetUserScore(int userID, int kindID);
        Message GetUserScore(int drawID);
        /// <summary>
        /// 绑定代理商
        /// </summary>
        Message BindAgent(int userID, int agentID);
        /// <summary>
        /// 获取绑定的代理商ID
        /// </summary>
        int GetUserAgentID(int userID);
        /// <summary>
        /// 获取绑定玩家列表
        /// </summary>
        DataSet GetBindPlayerList(int pageindex, int pagesize, int agentid, int userid, string stime, string etime);
        /// <summary>
        /// 获取绑定玩家列表
        /// </summary>
        DataSet GetBindPlayerList(int pageindex, int pagesize, int agentid, int userid, bool issuper);
        int updatepwd(int userID, string pwd);
        int GetParentAgentID(int userID);
        int DongJie(int userID);
        DataSet GetRoomList(int pageindex, int pagesize, int userid);
        /// <summary>
        /// 获取用户开房数据详情
        /// </summary>
        Message GetUserRoomInfo(int userID, int drawid);
        Message GetRankList(int userid, int type);
        long GetRankScore(int userid, int type);
        Message Register(string openid, string machineid, int platformid, string devicemodel, string nickname, string unionid);
    }
}
