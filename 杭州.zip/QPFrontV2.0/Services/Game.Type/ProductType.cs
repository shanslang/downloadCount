﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 产品类型
    /// </summary>
    public enum ProductType
    {
        虚拟物品 = 1,
        实物物品 = 2,
    }
}
