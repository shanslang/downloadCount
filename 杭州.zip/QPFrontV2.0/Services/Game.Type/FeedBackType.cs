﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public enum FeedBackType
    {
        [DescriptionAttribute("支付问题")]
        支付问题 = 0,
        [DescriptionAttribute("游戏故障")]
        游戏故障 = 1,
        [DescriptionAttribute("其他问题")]
        其他问题 = 2,
    }
}
