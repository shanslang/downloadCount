﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 会员级别
    /// </summary>
    public enum MemberLevel
    {
        [DescriptionAttribute("普通会员")]
        普通会员 = 0,
        [DescriptionAttribute("黄钻会员")]
        一星会员 = 1,
        [DescriptionAttribute("蓝钻会员")]
        二星会员 = 2,
        [DescriptionAttribute("红钻会员")]
        三星会员 = 3,
        [DescriptionAttribute("四星会员")]
        四星会员 = 4,
        [DescriptionAttribute("VIP会员")]
        五星会员 = 5
    }
}
