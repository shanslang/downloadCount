﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
namespace Game.Type
{
    public enum MedalTradeTypeEnum
    {
        /// <summary>
        /// 获得
        /// </summary>
        [DescriptionAttribute("获得")]
        Deposit = 1,
        /// <summary>
        /// 消耗
        /// </summary>
        [DescriptionAttribute("消耗")]
        Take = 2
    } 
}
