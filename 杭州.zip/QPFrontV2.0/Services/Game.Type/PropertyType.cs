﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public enum PropertyType
    {
        未指定 = 0,
        金币礼包 = 1,
        黄钻会员 = 4,
        红钻会员 = 5,
        蓝钻会员 = 6,
        其它道具 = 7,
    }
}
