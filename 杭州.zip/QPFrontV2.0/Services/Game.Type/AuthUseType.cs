﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 认证类型
    /// </summary>
    public enum AuthUseType
    {
        验证手机 = 1,
        验证邮箱 = 2,
        找回登录密码 = 3,
        找回保险柜密码 = 4
    }
}
