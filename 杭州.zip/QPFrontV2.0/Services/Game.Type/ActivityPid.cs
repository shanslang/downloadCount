﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 活动PID
    /// </summary>
    public enum ActivityPid
    {
        大转盘 = 1,
        砸金蛋 = 2,
        翻牌 = 3,
        挖矿 = 4,
        新版挖矿 = 5,
        会员欢乐购 = 6,
        九宫格免费抽奖 = 7
    }
}
