﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public class Constant
    {
        /// <summary>
        /// 栏目根节点
        /// </summary>
        public static int RootInfoCatalog
        {
            get
            {
                return 0;
            }
        }

        /// <summary>
        /// 标识一点魅力值兑换LoverRate金币 1:800
        /// </summary>
        public const int LoverRate = 8000;
    }
}
