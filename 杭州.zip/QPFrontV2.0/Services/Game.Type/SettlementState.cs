﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
namespace Game.Type
{
    /// <summary>
    /// 结算状态 0、未结算 1、已结算  2、处理中
    /// </summary>
    public enum SettlementState
    {
        /// <summary>
        /// 未结算
        /// </summary>
        [DescriptionAttribute("未结算")]
        未结算 = 0,
        /// <summary>
        /// 已结算
        /// </summary>
        [DescriptionAttribute("已结算")]
        已结算 = 1,
        /// <summary>
        /// 处理中
        /// </summary>
        [DescriptionAttribute("处理中")]
        处理中 = 2
    }
}
