﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public enum CommonState
    {
        正常 = 1,
        禁用 = 2,
        删除 = 4
    }
}
