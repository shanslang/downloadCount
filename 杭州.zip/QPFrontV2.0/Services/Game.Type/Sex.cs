﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 性别
    /// </summary>
    public enum Sex
    {
        女 = 0,
        男 = 1,
    }
}
