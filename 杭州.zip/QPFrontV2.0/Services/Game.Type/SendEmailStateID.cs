﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 企业QQ邮箱发送状态
    /// </summary>
    public enum SendEmailStateID
    {
        未发送 = 0,
        已发送 = 1,
        作废 = 2
    }
}
