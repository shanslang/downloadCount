﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public enum SmsCodeState
    {
        未使用 = 0,
        已使用 = 1
    }
}
