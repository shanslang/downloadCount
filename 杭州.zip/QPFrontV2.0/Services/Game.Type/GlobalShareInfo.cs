﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 第三方充值平台
    /// </summary>
    public enum GlobalShareInfo
    {
        /// <summary>
        /// 实卡
        /// </summary>
        SK = 1,
        /// <summary>
        /// 快钱
        /// </summary>
        KQ = 2,
        /// <summary>
        /// 声讯
        /// </summary>
        SX = 12,
        /// <summary>
        /// 支付宝
        /// </summary>
        ZFB = 13,
        /// <summary>
        /// 天下付
        /// </summary>
        TXF = 14,
        /// <summary>
        /// 苹果IAP
        /// </summary>
        APPLE = 15,
        /// <summary>
        /// 微信支付
        /// </summary>
        WX = 16,
        /// <summary>
        /// 棱镜
        /// </summary>
        LJ = 17,
        /// <summary>
        /// 15173
        /// </summary>
        CARD = 18,
        /// <summary>
        /// 联通
        /// </summary>
        LT=19,
        /// <summary>
        /// 360sdk
        /// </summary>
        _360=20,
        /// <summary>
        /// 百度sdk
        /// </summary>
        BD=21,
        /// <summary>
        /// 银联
        /// </summary>
        YL=22,
        /// <summary>
        /// 湖北互联星空
        /// </summary>
        Vnet=23,
        /// <summary>
        /// 189天翼空间
        /// </summary>
        _189Store=24,
        /// <summary>
        /// Anysdk
        /// </summary>
        Anysdk=25,
        /// <summary>
        /// 悠悠村
        /// </summary>
        Uucun=26,
        /// <summary>
        /// 豌豆荚
        /// </summary>
        Wandoujia = 27,
        /// <summary>
        /// 谷歌pay
        /// </summary>
        GooglePay=28,
        /// <summary>
        /// UC支付
        /// </summary>
        UC=29,
        /// <summary>
        /// 笨手机
        /// </summary>
        BSJ=30,
        /// <summary>
        /// 魅族应用商店
        /// </summary>
        MZ=31,
        /// <summary>
        /// 爱游戏
        /// </summary>
        AYX=32,
        /// <summary>
        /// 酷派
        /// </summary>
        KP=33


    }
}
