﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 充值订单状态
    /// </summary>
    public enum OnLineOrderStatus
    {
        未付款 =0,
        已付款待处理=1,
        处理完成=2
    }
}
