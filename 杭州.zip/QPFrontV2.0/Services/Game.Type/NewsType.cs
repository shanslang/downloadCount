﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 新闻分类
    /// </summary>
    public enum NewsType
    {
        /// <summary>
        /// 游戏公告
        /// </summary>
        [DescriptionAttribute("游戏公告")]
        游戏公告 = 2,
        /// <summary>
        /// 比赛中心
        /// </summary>
        [DescriptionAttribute("比赛信息")]
        比赛中心 = 5,
        /// <summary>
        /// 最新资讯
        /// </summary>
        [DescriptionAttribute("游戏资讯")]
        新闻中心 = 1,
        /// <summary>
        /// 游戏更新
        /// </summary>
        [DescriptionAttribute("游戏更新")]
        游戏更新 = 3,
        /// <summary>
        /// 维护公告
        /// </summary>
        [DescriptionAttribute("维护公告")]
        维护公告 = 4,
        
    }
}
