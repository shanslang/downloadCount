﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    [Serializable]
    public enum AppSerType
    {
        /// <summary>
        /// 麻将
        /// </summary>
        XL = 1,
        /// <summary>
        /// 牛牛
        /// </summary>
        NN = 2,
        /// <summary>
        /// 炸金花
        /// </summary>
        ZJH = 3, 
        /// <summary>
        /// 斗地主
        /// </summary>
        DDZ = 4,
        /// <summary>
        /// 癞子斗地主
        /// </summary>
        LZDDZ = 5,
        /// <summary>
        /// 欢乐斗地主
        /// </summary>
        HLDDZ=6

    }
}
