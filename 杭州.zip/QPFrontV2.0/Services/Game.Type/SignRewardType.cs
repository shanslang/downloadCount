﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 连续签到奖励类型
    /// </summary>
    public enum SignRewardType
    {
        /// <summary>
        /// 初始值
        /// </summary>
        RewardDefault = 0,
        /// <summary>
        /// 累计签到3天
        /// </summary>
        Reward3 = 1,
        /// <summary>
        /// 累计签到7天
        /// </summary>
        Reward7 = 2,
        /// <summary>
        /// 累计签到15天
        /// </summary>
        Reward15 = 3,
        /// <summary>
        /// 累计签到25天
        /// </summary>
        Reward25 = 4,
        /// <summary>
        /// 全勤
        /// </summary>
        RewardAll = 5
    }
}
