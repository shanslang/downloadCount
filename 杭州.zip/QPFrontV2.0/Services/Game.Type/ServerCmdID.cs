﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 命令ID1，是要求房间重新加载配置（包括任务变动）
    /// 命令ID2，是要求房间刷新玩家P2P任务信息（一般是广播）
    /// </summary>
    public enum ServerCmdID
    {
        /// <summary>
        /// 命令ID1，要求重新加载配置(p1:null,p2:null)
        /// </summary>
        房间重新加载配置 = 1,
        /// <summary>
        /// 命令ID2，玩家P2P信息刷新(p1:UserID,p2:null)
        /// </summary>
        房间刷新玩家P2P任务信息 = 2,
        /// <summary>
        /// 命令ID3，批量点对点命令(p1:组ID,p2:null)
        /// </summary>
        房间批量刷新玩家P2P任务信息 = 3,
        /// <summary>
        /// 命令ID4，重新加载用户信息(p1:UserID,p2:null)
        /// </summary>
        重新加载用户信息 = 4,
        /// <summary>
        /// 用户金币更新(p1:UserID,p2:GoldKey)
        /// </summary>
        用户金币更新 = 5,
        /// <summary>
        /// 公告刷新(p1:公告ID,p2:null)
        /// </summary>
        公告刷新 = 6,
        /// <summary>
        /// 客户端版本号(p1:GameID,p2:ClientVer)
        /// </summary> 
        客户端版本号 = 7,
        /// <summary>
        /// 重新加载房间参数(p1:null,p2:null) 
        /// </summary>
        重新加载房间参数 = 8,
        /// <summary>
        /// 踢人(p1:UserID,p2:是否强踢)
        /// </summary>
        踢人 = 9,
        /// <summary>
        /// 重新加载敏感词(p1:null,p2:null)
        /// </summary>
        重新加载敏感词 = 10,
        /// <summary>
        /// 重新检测房间锁定(p1:null,p2:null)
        /// </summary>
        重新检测房间锁定 = 11,
        /// <summary>
        /// 重新加载自定义配置(p1:null,p2:null)
        /// </summary>
        重新加载自定义配置 = 12,
        /// <summary>
        /// 重新加载用户扩展信息(p1:UserID,p2:null)
        /// </summary>
        重新加载用户扩展信息 = 13,
        /// <summary>
        /// 重新加载防沉迷(p1:UserID,p2:null)
        /// </summary>
        重新加载防沉迷 = 14,
        /// <summary>
        /// 重新加载比赛 ServerId=66537 (p1:主ID（主ID为0则重新加载所有比赛）,p2:子ID)
        /// </summary>
        重新加载比赛 = 15,
        /// <summary>
        /// 结束比赛 ServerId=66537 (p1:主ID（主ID为0则结束所有比赛）,p2:子ID)
        /// </summary>
        结束比赛 = 16,
        /// <summary>
        /// 解散赛场(p1:ServerID)
        /// </summary>
        解散赛场 = 17,
        /// <summary>
        /// 用户信息重新加载 ServerId=65536  (p1:用户ID,p2:重新加载标志)
        /// p2:重新加载标志  金币=0x00000001  头像=0x00000002 会员=0x00000004 金豆0x00000008 基本信息0x00000010 道具0x00000020 奖牌0x00000040
        /// 指定电话券0x00000080 充值成功0x00000100
        /// </summary>
        用户信息重新加载 = 20,
        /// <summary>
        /// 用户信息重新加载（p1:kindID,p2:id）
        /// </summary>
        配置文件重新加载=21,
        解散房间=18,
        /// <summary>
        /// （p1:userid,p2:0未绑定，1已绑定）
        /// </summary>
        绑定代理商=22,

        刷新开局消耗配置=23,
        开房间=19,
        /// <summary>
        /// 房卡(p1:UserID,p2:房卡,p3:金币)
        /// </summary>
        加玩家金币和房卡 = 25,
        金币控制信息改动 = 26,
        新房间控制 = 27,
        用户控制 = 28,
        解散玩家俱乐部 = 34,
    }
}
