﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 认证状态
    /// </summary>
    public enum AuthStatus
    {
        未认证 = 1,
        已认证 = 2,
    }
}
