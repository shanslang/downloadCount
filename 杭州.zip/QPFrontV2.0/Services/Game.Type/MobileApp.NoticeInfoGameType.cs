﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Game.Type.MobileApp
{
    /// <summary>
    /// 游戏类别
    /// </summary>
    public enum NoticeInfoGameType
    {
        /// <summary>
        /// 牛牛
        /// </summary>
        [DescriptionAttribute("牛牛")]
        牛牛 = 1,
        /// <summary>
        /// 麻将
        /// </summary>
        [DescriptionAttribute("血流")]
        麻将 = 2,
        /// <summary>
        /// 炸金花
        /// </summary>
        [DescriptionAttribute("炸金花")]
        炸金花 = 3,
        /// <summary>
        /// 斗地主
        /// </summary>
        [DescriptionAttribute("斗地主")]
        斗地主 = 4,
        /// <summary>
        /// 癞子斗地主
        /// </summary>
        [DescriptionAttribute("癞子斗地主")]
        癞子斗地主 = 5,
    }
}
