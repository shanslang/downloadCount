﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 产品订单状态
    /// </summary>
    public enum ProductOrderStatus
    {
        新建 = 0,
        完结 = 1,
        处理中 = 2,
        人工处理 = 3,
        人工处理中 = 4,
        作废订单 = 5
    }
}
