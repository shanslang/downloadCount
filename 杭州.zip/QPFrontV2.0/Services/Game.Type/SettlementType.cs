﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
namespace Game.Type
{
    /// <summary>
    /// 结算类型 1、金币 2、人民币 3、金币和人民币
    /// </summary>
    public enum SettlementType
    {
        /// <summary>
        /// 个人
        /// </summary>
        [DescriptionAttribute("金币")]
        金币 = 1,
        /// <summary>
        /// 审核中
        /// </summary>
        [DescriptionAttribute("人民币")]
        人民币 = 2,
        /// <summary>
        /// 金币和人民币
        /// </summary>
        [DescriptionAttribute("金币或人民币")]
        金币或人民币 = 3,
    }
}
