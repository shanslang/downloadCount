﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    [Flags]
    public enum ReleaseState
    {
        已发布 = 1,
        待发布 = 2,
    }
}
