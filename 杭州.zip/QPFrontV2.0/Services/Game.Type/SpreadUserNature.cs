﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
namespace Game.Type
{
    /// <summary>
    /// 用户性质 1、个人  2、公司
    /// </summary>
    public enum SpreadUserNature
    {
        /// <summary>
        /// 个人
        /// </summary>
        [DescriptionAttribute("个人")]
        个人 = 1,
        /// <summary>
        /// 审核中
        /// </summary>
        [DescriptionAttribute("公司")]
        公司 = 2
    }
}
