﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 小游戏Pid配置
    /// </summary>
    public enum XGamePid
    {
        /// <summary>
        /// 西游记
        /// </summary>
        西游记 = 1,
        /// <summary>
        /// 财神到
        /// </summary>
        财神到 = 2,
    }
}
