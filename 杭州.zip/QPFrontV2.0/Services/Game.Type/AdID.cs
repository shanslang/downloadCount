﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 推广AdID
    /// </summary>
    public enum AdID
    {
        /// <summary>
        /// pc蛋蛋
        /// </summary>
        PCEggs = 1,
    }
}
