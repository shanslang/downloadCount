﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public enum SmsCodeType
    {
        验证手机 = 1,
        验证邮箱 = 2, 
    }
}
