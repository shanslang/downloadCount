﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 固定产品PID
    /// </summary>
    public enum ProductID
    {
        腾讯QQ币 = 1,
        话费10元 = 2,
        话费20元 = 3,
        话费30元 = 4,
        话费50元 = 5,
        话费100元 = 6,

        LOL点券100 = 63,
        LOL点券500 = 64,
        LOL点券1000 = 65,
        LOL点券3000 = 66,
        LOL点券5000 = 67,
        LOL点券10000 = 68,

        首页奖品展示01 = 76,
        首页奖品展示02 = 6,
        首页奖品展示03 = 102,
        首页奖品展示04 = 30,
        首页奖品展示05 = 42,


        LOL45元普通皮肤=106,
        LOL99元限定皮肤=107,
        LOL199元限定皮肤=108
    }
}
