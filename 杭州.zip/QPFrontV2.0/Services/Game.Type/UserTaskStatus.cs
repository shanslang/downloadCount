﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 任务状态 0.未接 1.已接 2.完成 3.进行中
    /// </summary>
    public enum UserTaskStatus
    {
        未接 = 0,
        已接 = 1,
        完成 = 2,
        进行中 = 3
    }
}
