﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 问题ID
    /// </summary>
    public enum IssueID
    {
        关于我们 = 28,
        联系我们 = 33,
        家长监护 = 29,
        客服中心 = 30,
        网站导航 = 31,
        服务条款 = 24,
        文网文 = 32,
        ICP = 30,
        用户注册协议 = 24,
        会员特权说明 = 15,

        账号常见问题 = 1,
        如何领取实物奖励 = 13,
        保险柜的用法 = 3,
        如何设置密码保护 = 17
    }
}
