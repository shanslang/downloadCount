﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 产品状态 1=正常 2=归档 3=禁用
    /// </summary>
    public enum ProductStateID
    {
        正常 = 1,
        归档 = 2,
        禁用 = 3
    }
}
