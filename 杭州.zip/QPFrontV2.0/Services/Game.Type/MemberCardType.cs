﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 会员卡类型
    /// </summary>
    public enum MemberCardType
    {
        [DescriptionAttribute("一星会员")]
        一星会员 = 1,
        [DescriptionAttribute("二星会员")]
        二星会员 = 2,
        [DescriptionAttribute("三星会员")]
        三星会员 = 3,
        [DescriptionAttribute("四星会员")]
        四星会员 = 4,
        [DescriptionAttribute("五星会员")]
        五星会员 = 5
    }
}
