﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
namespace Game.Type
{
    /// <summary>
    /// 活动PID
    /// </summary>
    public enum SpreadUserAuditStateID
    {
        /// <summary>
        /// 新建
        /// </summary>
        [DescriptionAttribute("新建")]
        新建 = 0,
        /// <summary>
        /// 审核通过
        /// </summary>
        [DescriptionAttribute("通过")]
        审核通过 = 1,
        /// <summary>
        /// 审核中
        /// </summary>
        [DescriptionAttribute("审核中")]
        审核中 = 2,
        /// <summary>
        /// 审核未通过
        /// </summary>
        [DescriptionAttribute("未通过")]
        审核不通过 = 3
    }
}
