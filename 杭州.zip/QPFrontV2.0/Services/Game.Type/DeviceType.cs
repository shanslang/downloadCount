﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public enum DeviceType
    {
        /// <summary>
        /// 电脑
        /// </summary>
        PC = 1,
        /// <summary>
        /// 苹果设备
        /// </summary>
        IOS = 2,
        /// <summary>
        /// Android设备
        /// </summary>
        Android = 3
    }
}
