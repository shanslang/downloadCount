﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public enum ContinuousSignType
    {
        /// <summary>
        /// 累计签到3天
        /// </summary>
        累积签到3天 =2,
        /// <summary>
        /// 累积签到7天
        /// </summary>
        累积签到7天 = 3,
        /// <summary>
        /// 累积签到15天
        /// </summary>
        累积签到15天 = 7,
        /// <summary>
        /// 累积签到25天
        /// </summary>
        累积签到25天 =15,
        /// <summary>
        /// 月全勤(30天)
        /// </summary>
        累积签到30天 = 30,
    }
}
