﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 金豆充值订单状态
    /// 订单状态 0、未付款 1、处理完成 2、处理中
    /// </summary>
    public enum RechOrderStatus
    {
        未付款 = 0,
        处理完成 = 1,
        处理中 = 2
    }
}
