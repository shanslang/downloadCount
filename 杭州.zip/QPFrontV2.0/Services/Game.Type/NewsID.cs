﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 新闻ID
    /// </summary>
    public enum NewsID
    {
        
    }
}
