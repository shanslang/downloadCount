﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public enum MedalTradePlace
    {
        /// <summary>
        /// 大厅
        /// </summary>
        [DescriptionAttribute("大厅")]
        TheHall = 0,
        /// <summary>
        /// 网页
        /// </summary>
        [DescriptionAttribute("网页")]
        Webpage = 1 
    }
}
