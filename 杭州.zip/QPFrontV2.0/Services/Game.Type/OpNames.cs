﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 
    /// </summary>
    public enum OpNames
    {
        /// <summary>
        /// 百度外卖合作
        /// </summary>
        百度外卖合作 = 39,
    }
}
