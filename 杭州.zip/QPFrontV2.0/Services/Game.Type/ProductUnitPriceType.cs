﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 1、人民币 2、金币 3、奖牌
    /// </summary>
    public enum ProductUnitPriceType
    {
        人民币 = 1,
        金币 = 2,
        奖牌 = 3,
        道具 = 4,
        话费券 = 5
    }
}
