﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
namespace Game.Type
{
    public enum UserGroupType
    {
        /// <summary>
        /// 未分组
        /// </summary>
        [DescriptionAttribute("未分组")]
        Nopoint = 0,
        /// <summary>
        /// 黑名单:这类用户归纳为我们不受欢迎的用户，专门利用游戏及网站牟取利益的
        /// </summary>
        [DescriptionAttribute("黑名单")]
        BlackList = 1,
        /// <summary>
        /// 白名单:这类用户是我们游戏的忠实客户，但是没有充值的记录，在线时间长，值得培养的客户
        /// </summary>
        [DescriptionAttribute("白名单")]
        WhiteList = 2,
        /// <summary>
        /// 优质客户:(已经充值这类用户为重点关注及跟踪的客户群体，有较大金额充值的记录，需要重点引导和爱护。
        /// </summary>
        [DescriptionAttribute("优质客户")]
        HighQualityCustomer = 3,
        /// <summary>
        /// 新用户:每天新注册用户，重点关注认证手机和邮箱的客户，这部分值得去培养
        /// </summary>
        [DescriptionAttribute("新客户")]
        NewCustomer = 4,
        /// <summary>
        /// 长时间不登录客户:针对手机认证及邮箱认证的用户，长时间不登录游戏的用户，在开展新活动时，使用邮件或者短信的方式提醒
        /// </summary>
        [DescriptionAttribute("久不登录")]
        LongtermNoSignin = 5,
        /// <summary>
        /// 内部账号:公司内部专用账号
        /// </summary>
        [DescriptionAttribute("内部账号")]
        Internal = 6,
        /// <summary>
        /// 永久封号
        /// </summary>
        [DescriptionAttribute("永久封号")]
        ForeverProhibited = 7
    }
}
