﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Game.Type
{
    /// <summary>
    /// 订单用途类型
    /// </summary>
    public enum OrderUseType
    {
        /// <summary>
        /// 充值金币
        /// </summary>
        [DescriptionAttribute("购买金币")]
        充值金币 = 1,
        /// <summary>
        /// 购买会员
        /// </summary>
        [DescriptionAttribute("购买会员")]
        购买会员 = 2,
        /// <summary>
        /// 实卡充值
        /// </summary>
        [DescriptionAttribute("实卡充值")]
        实卡充值 = 3,
        /// <summary>
        /// 购买道具
        /// </summary>
        [DescriptionAttribute("购买道具")]
        购买道具 = 4,
    }
}
