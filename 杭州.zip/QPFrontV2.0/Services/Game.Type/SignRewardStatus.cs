﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public enum SignRewardStatus
    {
        /// <summary>
        /// 已经领取
        /// </summary>
        RewardAlready = 0,
        /// <summary>
        /// 可领取
        /// </summary>
        RewardNow = 1,
        /// <summary>
        /// 不能领取
        /// </summary>
        RewardNo = 2
    }
}
