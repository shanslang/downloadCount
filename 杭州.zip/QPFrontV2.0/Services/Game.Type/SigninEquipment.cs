﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Type
{
    public enum SigninEquipment
    {
        /// <summary>
        /// PC登录=0
        /// </summary>
        PCSignIn = 0,
        /// <summary>
        /// Android登录=16
        /// </summary>
        AndroidSignIn = 16,
        /// <summary>
        /// ITouch登录=32
        /// </summary>
        ITouchSignIn = 32,
        /// <summary>
        /// IPhone登录=64
        /// </summary>
        IPhoneSignIn = 64,
        /// <summary>
        /// iPad登录=128
        /// </summary>
        IPadSignIn = 128

    }
}
