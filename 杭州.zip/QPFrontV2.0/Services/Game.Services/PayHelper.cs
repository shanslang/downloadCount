﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Game.Utils;
using Game.Entity;
using System.Drawing;

namespace Game.WebV3
{
    /// <summary>
    /// 订单助手
    /// </summary>
    public class PayHelper
    {
        /// <summary>
        /// 获取交易流水号
        /// </summary>
        /// <returns></returns>
        public static string GetOrderID()
        {
            //构造订单号 (形如:20101201102322159111111)
            StringBuffer tradeNoBuffer = new StringBuffer();
            tradeNoBuffer += TextUtility.GetDateTimeLongString();
            tradeNoBuffer += TextUtility.CreateRandom(8, 1, 0, 0, 0, "");

            return tradeNoBuffer.ToString();
        }

        /// <summary>
        /// 获取交易流水号
        /// </summary>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public static string GetOrderIDByPrefix(string prefix)
        {
            //构造订单号 (形如:20101201102322159111111)
            int orderIDLength = 32;
            int randomLength = 6;
            StringBuffer tradeNoBuffer = new StringBuffer();

            tradeNoBuffer += prefix;
            tradeNoBuffer += TextUtility.GetDateTimeLongString();

            if ((tradeNoBuffer.Length + randomLength) > orderIDLength)
                randomLength = orderIDLength - tradeNoBuffer.Length;

            tradeNoBuffer += TextUtility.CreateRandom(randomLength, 1, 0, 0, 0, "");

            return tradeNoBuffer.ToString();
        }

        /// <summary>
        /// 获取当前字符串的像素长度
        ///将字符串画在图片上面计算像素
        /// create by gaoxing 
        /// </summary>
        /// <param name="str">输入字符串</param>
        /// <param name="picPath">传入图片路径</param>
        /// <returns>当前字符串的长度</returns>
        public static float GetStringLength(string str)
        {
            Bitmap bitmap = new Bitmap(1, 1);
            Graphics g = Graphics.FromImage(bitmap);
            g.PageUnit = GraphicsUnit.Pixel;
            SizeF size = g.MeasureString(str, new Font(new FontFamily("微软雅黑"), 7, FontStyle.Regular));
            float StringWidth = size.Width;
            g.Dispose();
            bitmap.Dispose();
            return StringWidth;
        }
    }
}
