﻿using Game.BusinessLogic;
using Game.Entity.Accounts;
using Game.Francis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Security;

namespace Game.WebV3
{
    public sealed partial class GlobalParameter
    {
        #region 构造
        private GlobalParameter() { }

        /// <summary>
        /// 取得全局类的单实例。
        /// </summary>
        public static GlobalParameter Instance
        {
            get { return Nested.instance; }
        }

        /// <summary>
        /// 辅助实现单件模式的嵌套类。
        /// </summary>
        sealed class Nested
        {
            static Nested() { }
            internal static readonly GlobalParameter instance = new GlobalParameter();
        }
        #endregion

        #region 属性
        private const string UC_COOKIE_LOGON_TOKEN = "LOGONTOKEN_8633";     //登录Cookie令牌
        private const string UC_COOKIE_LOGON_TOKEN_ENCRYPTKEY = "FLBCOMPANY_LONG";      //Cookie加密文本
        public const string UC_VERIFY_CODE_KEY = "UC_VERIFYCODE_KEY";       //验证码Session键KEY
        private AccountsFacade oAccountsFacade = new AccountsFacade();
        private IDictionary<int, UserInfo> onlineUsers = new Dictionary<int, UserInfo>();
        #endregion

        #region 登录用户
        /// <summary>
        /// 获取当前登录用户
        /// </summary>
        public UserInfo CurrentLoginUser
        {
            get
            {
                UserInfo user = null;
                if (this.IsAuthenticated)
                {
                    string id = System.Web.HttpContext.Current.User.Identity.Name;
                    if (!string.IsNullOrEmpty(id))
                    {
                        int userid = Game.Utils.Utility.StrToInt(id, 0);
                        lock (onlineUsers)
                        {
                            if (onlineUsers.ContainsKey(userid))
                            {
                                user = onlineUsers[userid];
                            }
                            else
                            {
                                user = oAccountsFacade.GetUserFullInfoByUserID(userid);
                                onlineUsers.Add(userid, user);
                            }
                        }
                    }
                }
                return user;
            }
        }
        /// <summary>
        /// 更新用户信息
        /// </summary>
        /// <param name="user"></param>
        public void UpdateUser(UserInfo user)
        {
            if (onlineUsers.ContainsKey(user.UserID))
            {
                onlineUsers[user.UserID] = user;
            }
        }
        /// <summary>
        /// 移除缓存用户信息
        /// </summary>
        /// <param name="userid"></param>
        public void RemoveUser(int userid)
        {
            lock (onlineUsers)
            {
                if (onlineUsers.ContainsKey(userid))
                {
                    onlineUsers.Remove(userid);
                }
            }

        }
        /// <summary>
        /// 判断指示是否登录成功
        /// </summary>
        public bool IsAuthenticated
        {
            get
            {
                return HttpContext.Current.Request.IsAuthenticated;
            }
        }
        #endregion

        #region 登录 登出
        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="loginName"></param>
        /// <param name="passWord"></param>
        /// <param name="checkCode"></param>
        /// <returns></returns>
        public UserInfo Login(string loginName, string passWord, string checkCode, bool autoLogin)
        {
            if (string.IsNullOrEmpty(checkCode)) throw new Exception("验证码不能为空.");
            //验证码错误
            string msg = this.ValidationCode(checkCode);
            if (!string.IsNullOrEmpty(msg))
            {
                throw new Exception(msg);
            }
            var result = Login(loginName, passWord, autoLogin);
            return result;
        }

        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="loginName"></param>
        /// <param name="passWord"></param>
        /// <returns></returns>
        public UserInfo Login(string loginName, string passWord, bool autoLogin, int isAgent = 0)
        {
            if (string.IsNullOrEmpty(loginName)) throw new Exception("用户名不能为空.");
            if (string.IsNullOrEmpty(passWord)) throw new Exception("密码不能为空.");
            UserInfo user = null;
            Message umsg = oAccountsFacade.Logon(loginName, passWord, isAgent);
            if (umsg.Success)
            {
                user = umsg.EntityList[0] as UserInfo;
                Login(user.UserID, autoLogin);
            }
            else
            {
                throw new Exception(umsg.Content);
            }
            return user;
        }
        /// <summary>
        /// 登录方法
        /// </summary>
        /// <param name="userid"></param>
        public void Login(int userid, bool autoLogin)
        {
            UserInfo user = oAccountsFacade.GetUserFullInfoByUserID(userid);
            //写入登陆信息到COOKIE中
            if (user != null)
            {
                if (autoLogin)
                {
                    DateTime expires = DateTime.Now.AddMonths(1);
                    FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1, user.UserID.ToString(), DateTime.Now, expires, true,user.LogonPass, "/");//建立身份验证票对象
                    string hashTicket = FormsAuthentication.Encrypt(ticket);//加密序列化验证票为字符串
                    HttpCookie userCookie = new HttpCookie(FormsAuthentication.FormsCookieName, hashTicket);
                    userCookie.HttpOnly = true;
                    userCookie.Expires = expires;
                    HttpContext.Current.Response.Cookies.Add(userCookie); //输出Cookie
                }
                else
                {
                    System.Web.Security.FormsAuthentication.SetAuthCookie(user.UserID.ToString(), false);
                }
                //将用户信息添加到信息
                lock (onlineUsers)
                {
                    if (onlineUsers.ContainsKey(user.UserID)) { onlineUsers.Remove(user.UserID); }
                    onlineUsers.Add(user.UserID, user);
                }
            }
        }
        /// <summary>
        /// 登录方法
        /// </summary>
        /// <param name="userid"></param>
        public void Logout()
        {
            UserInfo user = this.CurrentLoginUser;
            if (user != null)
            {
                this.RemoveUser(user.UserID);
                System.Web.Security.FormsAuthentication.SignOut();
            }
        }
        #endregion

        #region 验证码
        /// <summary>
        /// 检测验证码是否正确。返回错误信息，若返回空串表示登录成功。
        /// </summary>
        /// <param name="validCode">验证码</param>
        /// <returns></returns>
        public string ValidationCode(string validCode)
        {
            string msgResult = string.Empty;
            validCode = validCode.ToLower();
            System.Web.SessionState.HttpSessionState session = HttpContext.Current.Session;
            if (session[GlobalParameter.UC_VERIFY_CODE_KEY] == null)
            {
                msgResult = "验证码失效,请点击验证码图片更换验证码！";
            }
            else
            {
                string strValidateCode = (string)session[GlobalParameter.UC_VERIFY_CODE_KEY];
                if (validCode.ToUpper() != strValidateCode.ToUpper())
                {
                    msgResult = "您输入的验证码不正确";
                }
                else
                {
                    int count = 0;
                    string strLastValidateCode = (string)session["ValidateCode0"];

                    if (strLastValidateCode != strValidateCode)
                    {
                        session["ValidateCode0"] = strValidateCode;
                    }
                    else
                    {
                        count = Convert.ToInt32(session["ValidateCount"]);
                    }

                    if (count >= 3)
                    {
                        msgResult = "登录错误次数已经过最大次数，请更换新的验证码后再尝试登录！";
                    }
                    else
                    {
                        count++;
                        session["ValidateCount"] = count;
                    }
                }
            }
            if (msgResult == null) msgResult = string.Empty;
            return msgResult;
        }
        #endregion
    }
}
