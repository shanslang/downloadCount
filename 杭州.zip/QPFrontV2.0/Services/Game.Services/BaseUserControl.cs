﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Game.BusinessLogic;
using Game.Entity.Accounts;

namespace Game.WebV3
{
    public class BaseUserControl : System.Web.UI.UserControl
    {
        #region 业务逻辑
        protected AccountsFacade oAccountsFacade = new AccountsFacade();
        protected GameMatchFacade oGameMatchFacade = new GameMatchFacade();
        protected GamePropertyFacade oGamePropertyFacade = new GamePropertyFacade();
        protected GameScoreFacade oGameScoreFacade = new GameScoreFacade();
        protected NativeWebFacade oNativeWebFacade = new NativeWebFacade();
        protected PlatformFacade oPlatformFacade = new PlatformFacade();
        protected RecordFacade oRecordFacade = new RecordFacade();
        protected TaskFacade oTaskFacade = new TaskFacade();
        protected TreasureFacade oTreasureFacade = new TreasureFacade();
        #endregion

        /// <summary>
        /// 初始化类
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            //EnableViewState = false;
        }

        #region 通用属性 for xujianbo
        protected System.Text.StringBuilder sbCache = null;
        /// <summary>
        /// 临时缓存
        /// </summary>
        protected void ResetCache()
        {
            if (this.sbCache == null)
            {
                this.sbCache = new System.Text.StringBuilder();
            }
            else
            {
                this.sbCache.Length = 0;
            }
        }
        /// <summary>
        /// 当前登录用户
        /// </summary>
        protected UserInfo CurrentUser
        {
            get
            {
                if (GlobalParameter.Instance.CurrentLoginUser != null)
                {
                    return GlobalParameter.Instance.CurrentLoginUser;
                }
                return null;
            }
        }
        #endregion
    }
}