﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Practices.Unity;
using System.Runtime.InteropServices;

namespace Game.Services
{
    public static class DataInit
    {
        private static IUnityContainer _IUnityContainer = null;
        private static object lockUnityContainer = new object();
        /// <summary>
        /// 初始化和获取IOC容器应用程序版
        /// </summary>
        /// <returns></returns>
        public static IUnityContainer GetUnityContainer()
        {
            if (_IUnityContainer == null)
            {
                lock (lockUnityContainer)
                {
                    if (_IUnityContainer == null)
                    {
                        _IUnityContainer = Game.Francis.EntLibHelper.GetUnityContainer();
                        _IUnityContainer.RegisterType<Game.IData.IAccountsDataProvider, Game.Data.AccountsDataProvider>(new ContainerControlledLifetimeManager(), new InjectionConstructor("QPAccountsDB"));
                        _IUnityContainer.RegisterType<Game.IData.IGameMatchProvider, Game.Data.GameMatchDataProvider>(new ContainerControlledLifetimeManager(), new InjectionConstructor("QPGameMatchDB"));
                        _IUnityContainer.RegisterType<Game.IData.IGameScoreDataProvider, Game.Data.GameScoreDataProvider>(new ContainerControlledLifetimeManager(), new InjectionConstructor("QPGameScoreDB"));
                        _IUnityContainer.RegisterType<Game.IData.INativeWebDataProvider, Game.Data.NativeWebDataProvider>(new ContainerControlledLifetimeManager(), new InjectionConstructor("QPNativeWebDB"));
                        _IUnityContainer.RegisterType<Game.IData.IPlatformDataProvider, Game.Data.PlatformDataProvider>(new ContainerControlledLifetimeManager(), new InjectionConstructor("QPPlatformDB"));
                        _IUnityContainer.RegisterType<Game.IData.IRecordDataProvider, Game.Data.RecordDataProvider>(new ContainerControlledLifetimeManager(), new InjectionConstructor("QPRecordDB"));
                        _IUnityContainer.RegisterType<Game.IData.ITreasureDataProvider, Game.Data.TreasureDataProvider>(new ContainerControlledLifetimeManager(), new InjectionConstructor("QPTreasureDB"));
                        _IUnityContainer.RegisterType<Game.IData.ITreasureDataProvider, Game.Data.TreasureDataProvider>("AssignConnectString", new ContainerControlledLifetimeManager(), new InjectionConstructor("QPTreasureDB", ""));
                        _IUnityContainer.RegisterType<Game.IData.ITaskDataProvider, Game.Data.TaskDataProvider>(new ContainerControlledLifetimeManager(), new InjectionConstructor("QPTaskDB"));
                        _IUnityContainer.RegisterType<Game.IData.IGamePropertyDataProvider, Game.Data.GamePropertyDataProvider>(new ContainerControlledLifetimeManager(), new InjectionConstructor("QPGamePropertyDB"));
                        _IUnityContainer.RegisterType<Game.IData.IQPMatchProvider, Game.Data.QPMatchProvider>(new ContainerControlledLifetimeManager(), new InjectionConstructor("QPMatchDB"));
                        Game.Library.Log.WriteLogInfo("DataInit", new Exception("GetUnityContainer初始化，HashCode:" + _IUnityContainer.GetHashCode()));
                    }
                }
            }
            //StringBuilder sb = new StringBuilder();
            //sb.AppendLine("GetUnityContainer获取对象IAccountsDataProvider，HashCode:" + _IUnityContainer.Resolve<Game.IData.IAccountsDataProvider>().GetHashCode());
            //sb.AppendLine("GetUnityContainer获取对象IGameMatchProvider，HashCode:" + _IUnityContainer.Resolve<Game.IData.IGameMatchProvider>().GetHashCode());
            //sb.AppendLine("GetUnityContainer获取对象IGameScoreDataProvider，HashCode:" + _IUnityContainer.Resolve<Game.IData.IGameScoreDataProvider>().GetHashCode());
            //sb.AppendLine("GetUnityContainer获取对象INativeWebDataProvider，HashCode:" + _IUnityContainer.Resolve<Game.IData.INativeWebDataProvider>().GetHashCode());
            //sb.AppendLine("GetUnityContainer获取对象IPlatformDataProvider，HashCode:" + _IUnityContainer.Resolve<Game.IData.IPlatformDataProvider>().GetHashCode());
            //sb.AppendLine("GetUnityContainer获取对象IRecordDataProvider，HashCode:" + _IUnityContainer.Resolve<Game.IData.IRecordDataProvider>().GetHashCode());
            //sb.AppendLine("GetUnityContainer获取对象ITreasureDataProvider，HashCode:" + _IUnityContainer.Resolve<Game.IData.ITreasureDataProvider>().GetHashCode());
            //sb.AppendLine("GetUnityContainer获取对象ITreasureDataProvider-AssignConnectString，HashCode:" + _IUnityContainer.Resolve<Game.IData.ITreasureDataProvider>("AssignConnectString").GetHashCode());
            //sb.AppendLine("GetUnityContainer获取对象ITaskDataProvider，HashCode:" + _IUnityContainer.Resolve<Game.IData.ITaskDataProvider>().GetHashCode());
            //sb.AppendLine("GetUnityContainer获取对象IGamePropertyDataProvider，HashCode:" + _IUnityContainer.Resolve<Game.IData.IGamePropertyDataProvider>().GetHashCode());
            //sb.Append("GetUnityContainer获取对象IQPMatchProvider，HashCode:" + _IUnityContainer.Resolve<Game.IData.IQPMatchProvider>().GetHashCode());
            //Game.Library.Log.WriteLogInfo("DataInit", new Exception(sb.ToString()));

            return _IUnityContainer;
        }

        #region 通知游戏平台接口操作
        /// <summary>
        /// 通知游戏平台接口
        /// </summary>
        /// <param name="nCmdID">命令ID</param>
        /// <param name="nServerID">房间ID</param>
        /// <param name="nParam1">参数1</param>
        /// <param name="nParam2">参数2</param>
        /// <returns></returns>
        public static int ServerCmd(Game.Type.ServerCmdID nCmdID, int nServerID, int nParam1, int nParam2)
        {
#if DEBUG
            Game.Library.Log.WriteLogInfo("命令发送记录", new Exception("远程服务器命令：" + nCmdID + " ServerID：" + nServerID + " P1：" + nParam1 + " P2：" + nParam2));
#endif
            int cmdstate = DataInit.ServerCmd(Game.WebV3.Constant.CoordinationServerIP, Game.WebV3.Constant.CoordinationServerPort, nServerID, (int)nCmdID, nParam1 + "," + nParam2);
            if (cmdstate != 0)
            {
                Game.Library.Log.WriteLogInfo("WebClientDLL", new Exception("调用远程服务器命令错误码：" + cmdstate + " 命令ID：" + nCmdID + " ServerID：" + nServerID + " P1：" + nParam1 + " P2：" + nParam2));
            }
            return cmdstate;
        }
        public static int ServerCmd(Game.Type.ServerCmdID nCmdID, int nServerID, string parm)
        {
#if DEBUG
            Game.Library.Log.WriteLogInfo("命令发送记录", new Exception("远程服务器命令：" + nCmdID + " ServerID：" + nServerID + " P：" + parm));
#endif
            int cmdstate = DataInit.ServerCmd(Game.WebV3.Constant.CoordinationServerIP, Game.WebV3.Constant.CoordinationServerPort, nServerID, (int)nCmdID, parm);
            if (cmdstate != 0)
            {
                Game.Library.Log.WriteLogInfo("WebClientDLL", new Exception("调用远程服务器命令错误码：" + cmdstate + " 命令ID：" + nCmdID + " ServerID：" + nServerID + " P：" + parm));
            }
            return cmdstate;
        }
        /// <summary>
        /// 通知游戏平台接口
        /// </summary>
        /// <param name="nCmdID">命令ID</param>
        /// <param name="nServerID">房间ID</param>
        /// <param name="nParam1">参数1</param>
        /// <param name="nParam2">参数2</param>
        /// <returns></returns>
        public static int ServerCmd(int nCmdID, int nServerID, int nParam1, int nParam2)
        {
#if DEBUG
            Game.Library.Log.WriteLogInfo("命令发送记录", new Exception("远程服务器命令：" + nCmdID + " ServerID：" + nServerID + " P1：" + nParam1 + " P2：" + nParam2));
#endif
            int cmdstate = DataInit.ServerCmd(Game.WebV3.Constant.CoordinationServerIP, Game.WebV3.Constant.CoordinationServerPort, nServerID, (int)nCmdID, nParam1 + "," + nParam2);
            if (cmdstate != 0)
            {
                Game.Library.Log.WriteLogInfo("WebClientDLL", new Exception("调用远程服务器命令错误码：" + cmdstate));
            }
            return cmdstate;
        }
        /// <summary>
        /// 推荐使用 ServerCmd(int nServerID, int nCmdID, int nParam1, int nParam2)
        /// lpsServer：协调服务器地址
        /// uPort：协调服务器端口
        /// nServerID：发送的房间ID（0表示广播）
        /// nCmdID：命令ID
        /// 剩下的是命令的两个参数，
        /// </summary>
        /// <param name="lpsServer"></param>
        /// <param name="uPort"></param>
        /// <param name="nServerID"></param>
        /// <param name="nCmdID"></param>
        /// <param name="nParam1"></param>
        /// <param name="nParam2"></param>
        /// <returns></returns>
        [DllImport("WebClient.dll", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.Cdecl)]
        public static extern int ServerCmd(string lpsServer, uint uPort, int nServerID, int nCmdID, string parm);
        #endregion
    }
}
