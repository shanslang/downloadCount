﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Game.IData;
using Microsoft.Practices.Unity;
using Game.Francis;
using Game.Entity.GameProperty;
using Game.Entity.Accounts;

namespace Game.BusinessLogic
{
    public class GamePropertyFacade
    {
        private IGamePropertyDataProvider oIGamePropertyDataProvider;
        #region 构造函数
        public GamePropertyFacade()
        {
            oIGamePropertyDataProvider = Game.Services.DataInit.GetUnityContainer().Resolve<IGamePropertyDataProvider>();
        }
        #endregion

        /// <summary>
        /// 查询道具配置
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public PropertyCFG GetPropertyCFG(int propertypid)
        {
            return oIGamePropertyDataProvider.GetPropertyCFG(propertypid);
        }

        /// <summary>
        /// 查询商品配置信息
        /// </summary>
        /// <returns></returns>
        public IList<PropertyCFGInfo> GetAllPropertyCFGInfo()
        {
            return oIGamePropertyDataProvider.GetAllPropertyCFGInfo();
        }

        /// <summary>
        /// 查询用户商品配置信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public IList<UserPropertyCFGInfo> GetUserPropertyCFGInfo(string userID)
        {
            return oIGamePropertyDataProvider.GetUserPropertyCFGInfo(userID);
        }

        /// <summary>
        /// 查询道具记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetPropertyCFGRecord(int pageindex, int pagesize, string wherestr, string order)
        {
            return oIGamePropertyDataProvider.GetPropertyCFGRecord(pageindex, pagesize, wherestr, order);
        }

        /// <summary>
        /// 查询道具配置
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public IList<PropertyEffectCFG> GetPropertyEffectCFGRecord(int propertypid)
        {
            return oIGamePropertyDataProvider.GetPropertyEffectCFGRecord(propertypid);
        }

        /// <summary>
        /// 查询用户道具记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetUserPropertyRecord(int pageindex, int pagesize, int userid)
        {
            return oIGamePropertyDataProvider.GetUserPropertyRecord(pageindex, pagesize, userid);
        }

        /// <summary>
        /// 购买道具
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="propertypid"></param>
        /// <param name="count"></param>
        /// <param name="isbuy">是否购买 true购买 false赠送</param>
        /// <returns></returns>
        public Message GiveUserProperty(int userid, int propertypid, int count, bool isbuy)
        {
            Message msg1 = oIGamePropertyDataProvider.GiveUserProperty(userid, propertypid, count, isbuy);
            if (msg1.Success)
            {
                Game.WebV3.GlobalParameter.Instance.RemoveUser(userid);//刷新用户信息
                var oProperty = oIGamePropertyDataProvider.GetPropertyCFG(propertypid);
                if (oProperty != null)
                {
                    if (oProperty.IsAuto == 1)
                    {
                        Message msg2 = this.UseProperty(userid, userid, propertypid, count, true, isbuy);
                        if (msg2.Success == false)
                        {
                            throw new Exception(msg2.Content);
                        }
                    }
                    else if (isbuy)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, 8);
                    }
                }
            }
            return msg1;
        }

        /// <summary>
        /// 购买道具
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="propertypid"></param>
        /// <param name="count"></param>
        /// <param name="isbuy">是否购买 true购买 false赠送</param>
        /// <returns></returns>
        public Message GiveUserProperty(int userid, int propertypid, int count, Game.Type.OpNames optype, bool isbuy)
        {
            Message msg1 = oIGamePropertyDataProvider.GiveUserProperty(userid, propertypid, count, (int)optype, isbuy);
            if (msg1.Success)
            {
                Game.WebV3.GlobalParameter.Instance.RemoveUser(userid);//刷新用户信息
                var oProperty = oIGamePropertyDataProvider.GetPropertyCFG(propertypid);
                if (oProperty != null)
                {
                    if (oProperty.IsAuto == 1)
                    {
                        Message msg2 = this.UseProperty(userid, userid, propertypid, count, true, isbuy);
                        if (msg2.Success == false)
                        {
                            throw new Exception(msg2.Content);
                        }
                    }
                    else if (isbuy)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, 8);
                    }
                }
            }
            return msg1;
        }

        /// <summary>
        /// 使用道具
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="targetuserid"></param>
        /// <param name="propertypid"></param>
        /// <param name="count"></param>
        /// <param name="forceuse">是否强制使用</param>
        /// <returns></returns>
        public Message UseProperty(int userid, int targetuserid, int propertypid, int count, bool forceuse, bool isbuy)
        {
            Message msg = oIGamePropertyDataProvider.UseProperty(userid, targetuserid, propertypid, count, forceuse);
            if (msg.Success)
            {
                Game.WebV3.GlobalParameter.Instance.RemoveUser(userid);//刷新用户信息
                if (msg.EntityList != null)
                {
                    DataSet ds = null;
                    if (msg.EntityList[0] != null)
                    {
                        ds = msg.EntityList[0] as DataSet;
                        int p2 = 0;
                        if (isbuy)
                        {
                            p2 = 8;
                            // Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, 8);
                        }
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow item in ds.Tables[0].Rows)
                            {
                                int EffectType = Convert.ToInt32(item["EffectType"]);

                                if (EffectType == 1)//金币
                                {
                                    int EffectValue = Convert.ToInt32(item["EffectValue"]);
                                    if (Convert.ToInt32(item["IsRoom"]) != 0)
                                        Game.Services.DataInit.ServerCmd(Game.Type.ServerCmdID.用户金币更新, 0, userid, EffectValue);
                                    else
                                    {
                                        // Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, 1);
                                        p2 = p2 | 1;
                                    }

                                }
                                else if (EffectType == 2)//魅力值
                                {
                                    Game.Services.DataInit.ServerCmd(Game.Type.ServerCmdID.重新加载用户信息, 0, userid, 1);
                                }
                                else if (EffectType == 4 || EffectType == 5 || EffectType == 6)
                                {
                                    p2 = p2 | 4;
                                    //  Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, 4);
                                }
                                else if (EffectType >= 65536)
                                {
                                    p2 = p2 | 32;
                                    // Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, 32);
                                }
                            }
                        }
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, p2);
                    }
                }
            }
            return msg;
        }
        /// <summary>
        /// 转让道具
        /// </summary>
        public Message TransProperty(int UserID, int TargetUserID, int pid, int PCount)
        {
            var msg = oIGamePropertyDataProvider.TransProperty(UserID, TargetUserID, pid, PCount);
            if (msg.Success)
            {
                Game.WebV3.GlobalParameter.Instance.RemoveUser(UserID);//刷新用户信息
                //刷新道具
                Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, UserID, 0x00000020);
                Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, TargetUserID, 0x00000020);

            }
            return msg;
        }
        #region 获取道具信息
        /// <summary>
        /// 获取道具信息
        /// </summary>
        /// <param name="wherecase"></param>
        /// <param name="orderwhere"></param>
        /// <returns></returns>
        public IList<PropertyCFG> GetPropertyList(string wherecase, string orderwhere)
        {
            return oIGamePropertyDataProvider.GetPropertyList(wherecase, orderwhere);
        }
        #endregion

        #region IOS
        /// <summary>
        /// 查询用户道具(目前仅门票)
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetUserPropertyRecordForIOS(int userid, string contidion)
        {
            return oIGamePropertyDataProvider.GetUserPropertyRecordForIOS(userid, contidion);
        }
        #endregion
        #region 获取代理商充值记录
        /// <summary>
        /// 查询代理商充值记录
        /// </summary>
        public DataSet GetRechargeCardDetail(int pageindex, int pagesize, int userid, string stime, string etime)
        {
            return oIGamePropertyDataProvider.GetRechargeCardDetail(pageindex, pagesize, userid, stime, etime);
        }
        /// <summary>
        /// 获取充值总数据
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public DataSet GetRechargeCardData(int userId, string stime, string etime)
        {
            return oIGamePropertyDataProvider.GetRechargeCardData(userId, stime, etime);
        }
        /// <summary>
        /// 查询代理商购买记录
        /// </summary>
        public DataSet GetBuyCardDetail(int pageindex, int pagesize, int userid, string stime, string etime)
        {
            return oIGamePropertyDataProvider.GetBuyCardDetail(pageindex, pagesize, userid, stime, etime);
        }
        #endregion
        /// <summary>
        /// 查询玩家房卡记录
        /// </summary>
        public DataSet GetPlayerCardRecord(int pageindex, int pagesize, int agentid, int userid, string stime, string etime)
        {
            return oIGamePropertyDataProvider.GetPlayerCardRecord(pageindex, pagesize, agentid, userid, stime, etime);
        }
        public DataSet GetRoomCardConsumeStatistics(int pageindex, int pagesize, int agentid, string stime, string etime)
        {
            return oIGamePropertyDataProvider.GetRoomCardConsumeStatistics(pageindex, pagesize, agentid, stime, etime);
        }
    }
}
