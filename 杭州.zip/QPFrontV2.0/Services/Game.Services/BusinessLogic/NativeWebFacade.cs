﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Game.IData;
using Game.Francis;
using Game.Utils;
using Game.Entity.NativeWeb;
using System.Data;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web;
using Microsoft.Practices.Unity;
using Game.WebV3;

namespace Game.BusinessLogic
{
    /// <summary>
    /// 网站外观
    /// </summary>
    public class NativeWebFacade
    {
        #region Fields

        private INativeWebDataProvider webData;

        #endregion

        #region 构造函数

        /// <summary>
        /// 构造函数
        /// </summary>
        public NativeWebFacade()
        {
            webData = Game.Services.DataInit.GetUnityContainer().Resolve<INativeWebDataProvider>();
        }
        #endregion

        #region 网站新闻

        /// <summary>
        /// 获取置顶新闻列表
        /// </summary>
        /// <param name="newsType"></param>
        /// <param name="hot"></param>
        /// <param name="elite"></param>
        /// <param name="top"></param>
        /// <returns></returns>
        public IList<News> GetTopNewsList(int typeID, int hot, int elite, int top)
        {
            return webData.GetTopNewsList(typeID, hot, elite, top);
        }

        /// <summary>
        /// 获取新闻列表
        /// </summary>
        /// <returns></returns>
        public IList<News> GetNewsList()
        {
            return webData.GetNewsList();
        }

        /// <summary>
        /// 获取分页新闻列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetNewsList(int pageIndex, int pageSize)
        {
            return webData.GetNewsList(pageIndex, pageSize);
        }

        /// <summary>
        /// 获取分页新闻列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetNewsList(int pageIndex, int pageSize, string wherestr)
        {
            return webData.GetNewsList(pageIndex, pageSize, wherestr);
        }

        /// <summary>
        /// 获取新闻 by newsID
        /// </summary>
        /// <param name="newsID"></param>
        /// <param name="mode">模式选择, 0=当前主题, 1=上一主题, 2=下一主题</param>
        /// <returns></returns>
        public News GetNewsByNewsID(int newsID, byte mode)
        {
            return webData.GetNewsByNewsID(newsID, mode);
        }

        /// <summary>
        /// 获取公告
        /// </summary>
        /// <param name="noticeID"></param>
        /// <returns></returns>
        public Notice GetNotice(int noticeID)
        {
            return webData.GetNotice(noticeID);
        }

        #endregion

        #region 网站问题

        /// <summary>
        /// 获取问题列表
        /// </summary>
        /// <param name="issueType"></param>
        /// <param name="top"></param>
        /// <returns></returns>
        public IList<GameIssueInfo> GetTopIssueList(int top)
        {
            return webData.GetTopIssueList(top);
        }

        /// <summary>
        /// 获取问题列表
        /// </summary>
        /// <returns></returns>
        public IList<GameIssueInfo> GetIssueList()
        {
            return webData.GetIssueList();
        }

        /// <summary>
        /// 获取分页问题列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetIssueList(int pageIndex, int pageSize)
        {
            return webData.GetIssueList(pageIndex, pageSize);
        }

        /// <summary>
        /// 获取问题实体
        /// </summary>
        /// <param name="issueID"></param>
        /// <param name="mode">模式选择, 0=当前主题, 1=上一主题, 2=下一主题</param>
        /// <returns></returns>
        public GameIssueInfo GetIssueByIssueID(int issueID, byte mode)
        {
            return webData.GetIssueByIssueID(issueID, mode);
        }
        #endregion

        #region 反馈意见

        /// <summary>
        /// 获取分页反馈意见列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetFeedbacklist(int pageIndex, int pageSize)
        {
            return webData.GetFeedbacklist(pageIndex, pageSize);
        }

        /// <summary>
        /// 获取反馈意见实体
        /// </summary>
        /// <param name="issueID"></param>
        /// <param name="mode">模式选择, 0=当前主题, 1=上一主题, 2=下一主题</param>
        /// <returns></returns>
        public GameFeedbackInfo GetGameFeedBackInfo(int feedID, byte mode)
        {
            return webData.GetGameFeedBackInfo(feedID, mode);
        }

        /// <summary>
        /// 更新浏览量
        /// </summary>
        /// <param name="feedID"></param>
        public void UpdateFeedbackViewCount(int feedID)
        {
            webData.UpdateFeedbackViewCount(feedID);
        }

        /// <summary>
        /// 发表留言
        /// </summary>
        /// <returns></returns>
        public Message PublishFeedback(GameFeedbackInfo info)
        {
            return webData.PublishFeedback(info);
        }

        /// <summary>
        /// 设置问题反馈的图片信息
        /// </summary>
        /// <param name="imageurl"></param>
        public void FeedbackSetImage(int entityid, string imageurl)
        {
            webData.FeedbackSetImage(entityid, imageurl);
        }

        #endregion

        #region 游戏帮助数据

        /// <summary>
        /// 获取推荐游戏详细列表
        /// </summary>
        /// <returns></returns>
        public IList<GameRulesInfo> GetGameHelps(int top)
        {
            return webData.GetGameHelps(top);
        }

        /// <summary>
        /// 获取游戏详细信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        public GameRulesInfo GetGameHelp(int kindID)
        {
            return webData.GetGameHelp(kindID);
        }

        #endregion

        #region 游戏比赛信息

        /// <summary>
        /// 得到比赛列表
        /// </summary>
        /// <returns></returns>
        public IList<GameMatchInfo> GetMatchList()
        {
            return webData.GetMatchList();
        }

        /// <summary>
        /// 得到比赛详细信息
        /// </summary>
        /// <param name="matchID"></param>
        /// <returns></returns>
        public GameMatchInfo GetMatchInfo(int matchID)
        {
            return webData.GetMatchInfo(matchID);
        }

        /// <summary>
        /// 比赛报名
        /// </summary>
        /// <param name="userInfo"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public Message AddGameMatch(GameMatchUserInfo userInfo, string password)
        {
            return webData.AddGameMatch(userInfo, password);
        }

        #endregion

        #region 简易论坛
        /// <summary>
        /// 获取单条栏目信息
        /// </summary>
        /// <returns></returns>
        public InfoCatalog GetInfoCatalogByPid(int pid)
        {
            return webData.GetInfoCatalogByPid(pid);
        }

        /// <summary>
        /// 获取栏目分类列表
        /// </summary>
        /// <returns></returns>
        public IList<InfoCatalog> GetInfoCatalogList(int top)
        {
            return webData.GetInfoCatalogList(top);
        }

        /// <summary>
        /// 获取单条列主题信息
        /// </summary>
        /// <returns></returns>
        public InfoTopic GetInfoTopicByPid(int pid)
        {
            return webData.GetInfoTopicByPid(pid);
        }

        /// <summary>
        /// 获取主题列表
        /// </summary>
        /// <returns></returns>
        public DataSet GetInfoTopicList(int pageindex, int pagesize, string where, string order)
        {
            return webData.GetInfoTopicList(pageindex, pagesize, where, order);
        }

        /// <summary>
        /// 新增主题
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertInfoTopic(InfoTopic entity)
        {
            if (entity == null) throw new Exception("实例不能为空");
            entity.TopicTypeID = 0;
            //entity.CataID = cataid;
            entity.ItemNum = 0;
            //entity.Title = title;
            //entity.Content = content;
            entity.Summary = "";
            entity.Author = "游客";
            entity.Tags = "";
            entity.Hits = 0;
            entity.FlagID = 0;
            entity.DiggTop = 0;
            entity.DiggStep = 0;
            entity.StateID = (int)Game.Type.CommonState.正常;
            entity.CUserID = 0;
            entity.CUserIP = GameRequest.GetUserIP();
            var user = GlobalParameter.Instance.CurrentLoginUser;
            if (user != null)
            {
                entity.CUserID = user.UserID;
            }
            return webData.InsertInfoTopic(entity);
        }

        /// <summary>
        /// 修改主题
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message UpdateInfoTopicByPid(InfoTopic entity)
        {
            if (entity == null) throw new Exception("实例不能为空");
            //entity.Pid = "";
            entity.TopicTypeID = 0;
            //entity.CataID = 0;
            //entity.Title = "";
            //entity.Content = "";
            entity.Summary = "";
            entity.Author = "游客";
            entity.Tags = "";
            entity.FlagID = 0;
            entity.CUserIP = GameRequest.GetUserIP();
            var user = GlobalParameter.Instance.CurrentLoginUser;
            if (user != null)
            {
                entity.EUserID = user.UserID;
            }
            return webData.UpdateInfoTopicByPid(entity);
        }

        /// <summary>
        /// 修改主题点击次数
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message UpdateInfoTopicHitsByPid(InfoTopic entity)
        {
            return webData.UpdateInfoTopicHitsByPid(entity);
        }

        /// <summary>
        /// 删除主题
        /// </summary>
        /// <returns></returns>
        public Message DeleteInfoTopicByPid(InfoTopic entity)
        {
            entity.StateID = (int)Game.Type.CommonState.删除;
            entity.EUserID = 0;
            entity.EUserIP = GameRequest.GetUserIP();
            var user = GlobalParameter.Instance.CurrentLoginUser;
            if (user != null)
            {
                entity.EUserID = user.UserID;
            }
            return webData.DeleteInfoTopicByPid(entity);
        }

        /// <summary>
        /// 获取回复列表
        /// </summary>
        /// <returns></returns>
        public DataSet GetInfoItemList(int pageindex, int pagesize, string where, string order)
        {
            return webData.GetInfoItemList(pageindex, pagesize, where, order);
        }

        /// <summary>
        /// 新增回复
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertInfoItem(InfoItem entity)
        {
            if (entity == null) throw new Exception("新增实例不能为空");
            entity.StateID = (int)Game.Type.CommonState.正常;
            entity.CUserID = 0;
            entity.CUserIP = GameRequest.GetUserIP();
            var user = GlobalParameter.Instance.CurrentLoginUser;
            if (user != null)
            {
                entity.CUserID = user.UserID;
            }
            return webData.InsertInfoItem(entity);
        }

        /// <summary>
        /// 删除回复
        /// </summary>
        /// <returns></returns>
        public Message DeleteInfoItemByPid(InfoItem entity)
        {
            entity.StateID = (int)Game.Type.CommonState.删除;
            entity.EUserID = 0;
            entity.EUserIP = GameRequest.GetUserIP();
            var user = GlobalParameter.Instance.CurrentLoginUser;
            if (user != null)
            {
                entity.EUserID = user.UserID;
            }
            return webData.DeleteInfoItemByPid(entity);
        }

        #region 栏目htmlselect
        public void GetInfoCatalogHtmlSelect(HtmlSelect control, int parentID)
        {
            var dt = this.GetInfoCatalogList(1000);
            GetSelect(control, dt, parentID, 0);
            if (control.Items.Count > 0)
            {
                control.Items[0].Selected = true;
            }
        }
        private void GetSelect(HtmlSelect control, IList<InfoCatalog> dt, int parentID, int step)
        {
            if (parentID == Game.Type.Constant.RootInfoCatalog)
            {
                control.Items.Add(new ListItem() { Text = "栏目根目录", Value = Game.Type.Constant.RootInfoCatalog.ToString() });
            }
            var rows = dt.Where(q => q.ParentPid == parentID).ToList();
            if (rows.Count > 0)
            {
                step++;
                foreach (InfoCatalog item in rows)
                {
                    string _parentid = item.ParentPid + "";
                    string _cataid = item.Pid + "";
                    string _cataname = item.CataName + "";

                    string fg = "";
                    if (_parentid == "0")
                    {
                        fg += ">>";
                    }
                    else
                    {
                        int j = step;
                        if (_parentid != "1") j = (j - 1) * 2;
                        for (int i = 0; i < j; i++) fg += "&nbsp;&nbsp;";
                        fg = HttpUtility.HtmlDecode(fg);
                        fg += ">>";
                    }

                    _cataname = fg + _cataname;
                    ListItem option = new ListItem(_cataname, _cataid);
                    control.Items.Add(option);
                    GetSelect(control, dt, int.Parse(_cataid), step);
                }
            }
        }
        #endregion
        #endregion

        #region 友情链接
        /// <summary>
        /// 获取友情链接列表
        /// </summary>
        /// <returns></returns>
        public DataSet GetFriendLinksList(int pageindex, int pagesize, string where, string order)
        {
            return webData.GetFriendLinksList(pageindex, pagesize, where, order);
        }
        #endregion

        #region 推广系统
        /// <summary>
        /// 新增推广员
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertSpreadUser(SpreadUser entity)
        {
            return webData.InsertSpreadUser(entity);
        }
        /// <summary>
        /// 新增浏览记录
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRecordRecordTrackBrowse(RecordTrackBrowse entity)
        {
            return webData.InsertRecordRecordTrackBrowse(entity);
        }
        /// <summary>
        /// 获取推广员信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        public SpreadUser GetSpreadUserByUserID(int userid)
        {
            return webData.GetSpreadUserByUserID(userid);
        }
        /// <summary>
        /// 新增推广财务信息
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertSpreadFinanceInfo(SpreadFinanceInfo entity)
        {
            return webData.InsertSpreadFinanceInfo(entity);
        }
        /// <summary>
        /// 获取推广员财务信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        public SpreadFinanceInfo GetSpreadFinanceInfoBySpreadUserID(int spreaduserpid)
        {
            return webData.GetSpreadFinanceInfoBySpreadUserID(spreaduserpid);
        }
        /// <summary>
        /// 获取推广员审核的最新信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        public RecordSpreadUserAudit GetSpreadUserLastAuditInfo(int spreaduserid)
        {
            return webData.GetSpreadUserLastAuditInfo(spreaduserid);
        }

        /// <summary>
        /// 获取推广注册记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetSpreadRegRecord(int pageindex, int pagesize, string where, string order)
        {
            return webData.GetSpreadRegRecord(pageindex, pagesize, where, order);
        }
        /// <summary>
        /// 获取推广充值记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetSpreadRechRecord(int pageindex, int pagesize, string where, string order)
        {
            return webData.GetSpreadRechRecord(pageindex, pagesize, where, order);
        }
        /// <summary>
        /// 获取推广浏览记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetSpreadBrowseRecord(int spreaduserid, int pageindex, int pagesize, string where, string order)
        {
            return webData.GetSpreadBrowseRecord(spreaduserid, pageindex, pagesize, where, order);
        }
        /// <summary>
        /// 获取推广浏览记录 按天
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetSpreadBrowseRecordByDay(int spreaduserid, int pageindex, int pagesize, string where, string order)
        {
            return webData.GetSpreadBrowseRecordByDay(spreaduserid, pageindex, pagesize, where, order);
        }
        /// <summary>
        /// 获取推广业绩 按天
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetSpreadRecordByDay(int spreaduserid, int pageindex, int pagesize, string where, string order)
        {
            return webData.GetSpreadRecordByDay(spreaduserid, pageindex, pagesize, where, order);
        }
        /// <summary>
        /// 统计访问量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataRow GetSpreadBrowseTotal(int spreaduserid, string where)
        {
            return webData.GetSpreadBrowseTotal(spreaduserid, where);
        }
        /// <summary>
        /// 统计注册人数
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataRow GetSpreadRegTotal(int spreaduserid, string where)
        {
            return webData.GetSpreadRegTotal(spreaduserid, where);
        }
        /// <summary>
        /// 统计注册人数(通过手机认证)
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataRow GetSpreadRegTelephoneAuthTotal(int spreaduserid, string where)
        {
            return webData.GetSpreadRegTelephoneAuthTotal(spreaduserid, where);
        }
        /// <summary>
        /// 统计注册人数(有效用户 充值金额大于0  and 游戏时间大于20分钟)
        /// </summary>
        /// <param name="spreaduserid"></param>
        /// <param name="where"></param>
        /// <returns></returns>
        public DataRow GetSpreadRegEffectiveTotal(int spreaduserid, string where)
        {
            return webData.GetSpreadRegEffectiveTotal(spreaduserid, where);
        }
        /// <summary>
        /// 统计充值人数
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataRow GetSpreadRechTotal(int spreaduserid, string where)
        {
            return webData.GetSpreadRechTotal(spreaduserid, where);
        }
        /// <summary>
        /// 统计已经兑换兑换码数量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public int GetChannelIDCDKeyTotal(int channelid, string where)
        {
            return webData.GetChannelIDCDKeyTotal(channelid, where);
        }
        /// <summary>
        /// 统计活跃人数
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="where"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataRow GetSpreadActiveTotal(int spreaduserid, string where)
        {
            return webData.GetSpreadActiveTotal(spreaduserid, where);
        }
        /// <summary>
        /// 统计结算提成
        /// </summary>
        /// <param name="spreaduserid"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        public DataRow CalculateSpreadUserCommission(int spreaduserid, DateTime date)
        {
            return webData.CalculateSpreadUserCommission(spreaduserid, date);
        }
        /// <summary>
        /// 获取最近24笔 已经结算的记录
        /// </summary>
        /// <param name="spreaduserpid"></param>
        /// <param name="where"></param>
        /// <returns></returns>
        public DataTable GetSpreadSettlement(int spreaduserpid, string where)
        {
            return webData.GetSpreadSettlement(spreaduserpid, where);
        }
        /// <summary>
        /// 推广处理结算
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="settlementtype"></param>
        /// <returns></returns>
        public Message SpreadSettlementProcess(int pid, int settlementtype)
        {
            return webData.SpreadSettlementProcess(pid, settlementtype);
        }
        #endregion

        #region 生成验证码
        /// <summary>
        /// 手机认证
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="mtelephone"></param>
        public void AuthTelephone(int userid, string mtelephone, string code)
        {
            try
            {
                Message msg = webData.AuthCheck(Type.AuthUseType.验证手机, userid, code, mtelephone, "");
                if (msg.Success)
                {
                    //重新加载用户扩展信息
                    Game.Services.DataInit.ServerCmd(Game.Type.ServerCmdID.重新加载用户扩展信息, 0, userid, 0);
                    //用户金币更新
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, userid, Convert.ToInt32(item["GoldKey"]));
                    }
                }
                else throw new Exception(msg.Content);
            }
            catch (Exception exp)
            {
                throw exp;
            }
        }
         /// <summary>
        /// 认证手机（不需要验证验证码）
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public Message AuthPhone(int userid, string telephone)
        {
            try
            {
                return webData.AuthPhone(userid, telephone);
               
            }
            catch (Exception exp)
            {
                throw exp;
            }
        }
        /// <summary>
        /// 电子邮件认证
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="email"></param>
        public void AuthEmial(int userid, string email, string code)
        {
            Message msg = webData.AuthCheck(Type.AuthUseType.验证邮箱, userid, code, "", email);
            if (msg.Success)
            {
                //重新加载用户扩展信息
                Game.Services.DataInit.ServerCmd(Game.Type.ServerCmdID.重新加载用户扩展信息, 0, userid, 0);
                //用户金币更新
                DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                foreach (DataRow item in dt.Rows)
                {
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, userid, Convert.ToInt32(item["GoldKey"]));
                }
            }
            else throw new Exception(msg.Content);
        }

        /// <summary>
        /// 生成认证Code
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="email"></param>
        public string BuilderCheckCode(Game.Type.AuthUseType type, int userid, string telephone, string email)
        {
            return webData.BuilderCheckCode(type, userid, telephone, email);
        }

        /// <summary>
        /// 验证验证码
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userid"></param>
        /// <param name="code"></param>
        /// <param name="telephone"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public Message VerificationCheckCode(Game.Type.AuthUseType type, int userid, string code, string telephone, string email)
        {
            return webData.VerificationCheckCode(type, userid, code, telephone, email);
        }
        #endregion

        #region 每日签到
        /// <summary>
        /// 每日领取金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRecordDailySign(RecordDailySign entity)
        {
            Message msg = webData.InsertRecordDailySign(entity);
            try
            {
                if (msg.Success)
                {
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, entity.UserID, Convert.ToInt32(item["GoldKey"]));
                    }
                }
            }
            catch (Exception exp)
            {
                msg.ReturnValue = 1;
                msg.Content = exp.Message;
            }
            return msg;
        }
        /// <summary>
        /// 获取当月签到记录
        /// </summary>
        /// <returns></returns>
        public IList<RecordDailySign> GetCurrentMonthDailySignList(int userid)
        {
            return webData.GetCurrentMonthDailySignList(userid);
        }
        #endregion

        #region 许愿活动
        /// <summary>
        /// 获得母亲节许愿活动
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public void InsertActivityWishing(ActivityWishing o)
        {
            webData.InsertActivityWishing(o);
        }

        /// <summary>
        /// 获得母亲节许愿活动
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetActivityWishingList(int pageindex, int pagesize, string wherestr)
        {
            return webData.GetActivityWishingList(pageindex, pagesize, wherestr);
        }
        #endregion

        #region 检测网吧活动
        /// <summary>
        /// 获取网吧信息
        /// </summary>
        /// <param name="ipaddress">IP地址</param>
        /// <returns></returns>
        public ActivityInternetcafe GetActivityInternetcafeByIP(string ipaddress)
        {
            return webData.GetActivityInternetcafeByIP(ipaddress);
        }

        /// <summary>
        /// 获取网吧当日用户是否达到最大次数
        /// </summary>
        /// <param name="ipaddress">IP地址</param>
        /// <returns></returns>
        public bool IsExceedDayFreeNum(ActivityInternetcafe internetcafe, int userid)
        {
            return webData.IsExceedDayFreeNum(internetcafe, userid);
        }
        #endregion

        #region 网站活动 活动记录
        /// <summary>
        /// 活动奖励记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetActivityPlizeRecord(int pageindex, int pagesize, string wherestr)
        {
            return webData.GetActivityPlizeRecord(pageindex, pagesize, wherestr);
        }
        #endregion

        #region 网站活动 黄金挖矿
        /// <summary>
        /// 挖矿(新版20141107) -1金币不足 -2未登录 -3没有手机认证 -4未知的挖矿类型
        /// kuangtype: （1、铜矿3W金币 2、银矿30W金币 3、金矿300W金币）/次
        /// </summary>
        public string ActivityForNWaKuang(int kuangtype, ref int state)
        {
            var user = Game.WebV3.GlobalParameter.Instance.CurrentLoginUser;
            state = 0;
            if (new List<int> { 1, 2, 3 }.Contains(kuangtype) == false)
            {
                state = 1;
                return "未知的挖矿类型！";
            }

            int activitypid = (int)Game.Type.ActivityPid.新版挖矿;
            int expendgold = 0;//消耗金币

            Random rand = new Random();
            int number = rand.Next(1, 10001);
            List<int> exclude = new List<int>();
            while (exclude.Count < 10000) { exclude.Add(exclude.Count + 1); }

            string result = "";
            #region 消耗金币
            switch (kuangtype)
            {
                case 1:
                    {
                        expendgold = 30000;//设置消耗的数量
                        List<int> p_medal_2000 = GetRandomList(2000, exclude);
                        List<int> p_medal_1000 = GetRandomList(1000, exclude);
                        List<int> p_medal_700 = GetRandomList(700, exclude);
                        List<int> p_medal_500 = GetRandomList(500, exclude);
                        List<int> p_medal_400 = GetRandomList(400, exclude);
                        List<int> p_medal_200 = GetRandomList(200, exclude);
                        List<int> p_gold_2000 = GetRandomList(2000, exclude);
                        List<int> p_gold_1200 = GetRandomList(1200, exclude);
                        List<int> p_gold_800 = GetRandomList(800, exclude);
                        List<int> p_gold_500 = GetRandomList(500, exclude);
                        List<int> p_gold_400 = GetRandomList(400, exclude);
                        List<int> p_gold_100 = GetRandomList(100, exclude);
                        List<int> p_member_100 = GetRandomList(100, exclude);
                        List<int> p_member_100_1 = GetRandomList(100, exclude);
                        #region 中奖得到奖牌
                        if (p_medal_2000.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 10, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了10奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_1000.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 20, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了20奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_700.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 30, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了30奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_500.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 40, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了40奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_400.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 50, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了50奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_200.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 100, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了100奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        #region 中奖得到金币
                        else if (p_gold_2000.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 2000, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了2000金币！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_gold_1200.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 3000, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了3000金币！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_gold_800.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 5000, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了5000金币！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_gold_500.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 8000, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了8000金币！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_gold_400.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 10000, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了10000金币！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_gold_100.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 50000, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了50000金币！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        #region 中奖得到会员
                        else if (p_member_100.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 3, 0, 0, (int)Game.Type.MemberLevel.一星会员, 3);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了3天黄钻会员！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_member_100_1.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 3, 0, 0, (int)Game.Type.MemberLevel.二星会员, 3);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了3天蓝钻会员！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        #region 为中奖
                        else
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 100, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "您火太背了，你什么也没有挖到,送你100金币作为鼓励！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        break;
                    }
                case 2:
                    {
                        expendgold = 300000;//设置消耗的数量
                        List<int> p_medal_4000 = GetRandomList(4000, exclude);
                        List<int> p_medal_2000 = GetRandomList(2000, exclude);
                        List<int> p_medal_1000 = GetRandomList(1000, exclude);
                        List<int> p_medal_800 = GetRandomList(800, exclude);
                        List<int> p_medal_500 = GetRandomList(500, exclude);
                        List<int> p_medal_400 = GetRandomList(400, exclude);
                        List<int> p_medal_300 = GetRandomList(300, exclude);
                        List<int> p_medal_250 = GetRandomList(250, exclude);
                        List<int> p_medal_200 = GetRandomList(200, exclude);
                        List<int> p_medal_100 = GetRandomList(100, exclude);
                        List<int> p_gold_100 = GetRandomList(100, exclude);
                        List<int> p_gold_50 = GetRandomList(50, exclude);
                        List<int> p_member_200 = GetRandomList(200, exclude);
                        List<int> p_member_100 = GetRandomList(100, exclude);
                        #region 中奖得到奖牌
                        if (p_medal_4000.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 100, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了100奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_2000.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 200, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了200奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_1000.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 300, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了300奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_800.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 400, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了400奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_500.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 500, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了500奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_400.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 600, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了600奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_300.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 700, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了700奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_250.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 800, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了800奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_200.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 1000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了1000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_100.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 2000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了2000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        #region 中奖得到金币
                        else if (p_gold_100.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 500000, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了500000金币！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_gold_50.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 1000000, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了1000000金币！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        #region 中奖得到会员
                        else if (p_member_200.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 3, 0, 0, (int)Game.Type.MemberLevel.一星会员, 10);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了10天黄钻会员！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_member_100.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 3, 0, 0, (int)Game.Type.MemberLevel.二星会员, 10);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了10天蓝钻会员！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        #region 为中奖
                        else
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 100, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "您火太背了，你什么也没有挖到,送你100金币作为鼓励！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        break;
                    }
                case 3:
                    {
                        expendgold = 3000000;//设置消耗的数量
                        List<int> p_medal_4000 = GetRandomList(4000, exclude);
                        List<int> p_medal_2000 = GetRandomList(2000, exclude);
                        List<int> p_medal_1000 = GetRandomList(1000, exclude);
                        List<int> p_medal_500 = GetRandomList(500, exclude);
                        List<int> p_medal_400 = GetRandomList(400, exclude);
                        List<int> p_medal_350 = GetRandomList(350, exclude);
                        List<int> p_medal_300 = GetRandomList(300, exclude);
                        List<int> p_medal_250 = GetRandomList(250, exclude);
                        List<int> p_medal_200 = GetRandomList(200, exclude);
                        List<int> p_medal_100 = GetRandomList(100, exclude);
                        List<int> p_gold_100 = GetRandomList(100, exclude);
                        List<int> p_gold_50 = GetRandomList(50, exclude);
                        List<int> p_member_500 = GetRandomList(500, exclude);
                        List<int> p_member_250 = GetRandomList(250, exclude);
                        #region 中奖得到奖牌
                        if (p_medal_4000.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 1000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了1000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_2000.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 2000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了2000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_1000.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 3000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了3000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_500.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 4000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了4000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_400.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 5000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了5000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_350.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 6000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了6000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_300.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 7000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了7000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_250.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 8000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了8000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_200.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 10000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了10000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_medal_100.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 2, 0, 20000, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了20000奖牌！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        #region 中奖得到金币
                        else if (p_gold_100.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 5000000, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了5000000金币！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_gold_50.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 10000000, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了10000000金币！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        #region 中奖得到会员
                        else if (p_member_500.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 3, 0, 0, (int)Game.Type.MemberLevel.一星会员, 30);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了30天黄钻会员！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        else if (p_member_250.Contains(number))
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 3, 0, 0, (int)Game.Type.MemberLevel.二星会员, 30);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "恭喜您！你获得了30天蓝钻会员！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        #region 为中奖
                        else
                        {
                            Message msg = this.ActivityHJWK(user.UserID, activitypid, expendgold, true, 1, 100, 0, 0, 0);
                            if (msg.Success)
                            {
                                state = 0;
                                result = "您火太背了，你什么也没有挖到,送你100金币作为鼓励！";
                            }
                            else
                            {
                                state = msg.ReturnValue;
                                result = msg.Content;
                            }
                        }
                        #endregion
                        break;
                    }
            }
            #endregion
            return result;
        }
        /// <summary>
        /// 产生随机的数组
        /// </summary>
        /// <param name="length"></param>
        /// <param name="minValue"></param>
        /// <param name="maxValue"></param>
        /// <returns></returns>
        private List<int> GetRandomList(int length, List<int> exclude)
        {
            Random random = new Random(unchecked((int)DateTime.Now.Ticks));
            List<int> list = new List<int>();
            while (list.Count < length)
            {
                int index = random.Next(0, exclude.Count);
                if (list.Contains(exclude[index]))
                {
                    continue;
                }
                list.Add(exclude[index]);
                exclude.Remove(exclude[index]);
            }
            return list;
        }

        /// <summary>
        /// 网站活动 黄金挖矿
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="activitypid"></param>
        /// <param name="expendgold"></param>
        /// <param name="ispresent"></param>
        /// <param name="presenttype"></param>
        /// <param name="presentgold"></param>
        /// <param name="presentmedal"></param>
        /// <param name="presentmemberorder"></param>
        /// <param name="presentdays"></param>
        /// <returns></returns>
        public Message ActivityHJWK(int userid, int activitypid, long expendgold, bool ispresent, long presenttype, long presentgold, long presentmedal, int presentmemberorder, int presentmemberdays)
        {
            Message msg = webData.ActivityHJWK(userid, activitypid, expendgold, ispresent, presenttype, presentgold, presentmedal, presentmemberorder, presentmemberdays);
            try
            {
                if (msg.Success)
                {
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, userid, Convert.ToInt32(item["GoldKey"]));  
                    }
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, 97);
                }
            }
            catch (Exception exp)
            {
                msg.ReturnValue = 1;
                msg.Content = exp.Message;
            }
            return msg;
        }

        #endregion

        #region 网站活动 欢乐购
        /// <summary>
        /// 欢乐购活动 金豆购买会员送奖牌
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="memberdays"></param>
        /// <returns></returns>
        public Message ActivityHLG(int userid, Game.Type.MemberLevel memberorder, int memberdays)
        {
            return webData.ActivityHLG((int)Game.Type.ActivityPid.会员欢乐购, userid, memberorder, memberdays);
        }
        #endregion

        #region 网站活动 九宫格(定时抽奖)
        /// <summary>
        /// 九宫格(定时抽奖)
        /// </summary>
        /// <param name="state"></param>
        /// <param name="rewardindex"></param>
        /// <returns></returns>
        public string ActivityJGG(ref int state, ref int rewardindex)
        {
            string result = null;
            StringBuilder sbCache = new StringBuilder();
            var user = GlobalParameter.Instance.CurrentLoginUser;
            int activitypid = (int)Game.Type.ActivityPid.九宫格免费抽奖;

            string stime = null;
            string etime = null;
            if (DateTime.Now >= Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd 12:00:00")) && DateTime.Now < Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd 14:00:00")))
            {
                stime = DateTime.Now.ToString("yyyy-MM-dd 12:00:00");
                etime = DateTime.Now.ToString("yyyy-MM-dd 14:00:00");
            }
            else if (DateTime.Now >= Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd 18:00:00")) && DateTime.Now < Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd 20:00:00")))
            {
                stime = DateTime.Now.ToString("yyyy-MM-dd 18:00:00");
                etime = DateTime.Now.ToString("yyyy-MM-dd 20:00:00");
            }
            else if (DateTime.Now >= Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd 21:00:00")) && DateTime.Now < Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd 23:00:00")))
            {
                stime = DateTime.Now.ToString("yyyy-MM-dd 21:00:00");
                etime = DateTime.Now.ToString("yyyy-MM-dd 23:00:00");
            }

            if (string.IsNullOrEmpty(stime) || string.IsNullOrEmpty(etime))
            {
                state = 1000;
                return "此活动还没开始，详情请看活动规则！";
            }

            sbCache.Remove(0, sbCache.Length);
            sbCache.AppendFormat(" and InsertTime>='{0}' and InsertTime<'{1}'", stime, etime);
            int usergamecount = this.GetUserGameCount(user.UserID, sbCache.ToString());

            sbCache.Remove(0, sbCache.Length);
            sbCache.AppendFormat(" and CTime>='{0}' and CTime<'{1}'", stime, etime);
            int userisjoincount = this.GetUserIsJoinActivityJGG(user.UserID, (int)Game.Type.ActivityPid.九宫格免费抽奖, sbCache.ToString());

            if (userisjoincount > 0)
            {
                state = 1000;
                return string.Format("您已经参与过了本次抽奖活动！");
            }
            if (usergamecount < 5)
            {
                state = 1000;
                return string.Format("您还玩{0}局游戏可以参与抽奖", 5 - usergamecount);
            }

            Random rand = new Random();
            int number = rand.Next(1, 10001);
            List<int> exclude = new List<int>();
            while (exclude.Count < 10000) { exclude.Add(exclude.Count + 1); }
            List<int> rand001 = GetRandomList(1, exclude);
            List<int> rand002 = GetRandomList(2, exclude);
            List<int> rand882_1 = GetRandomList(882, exclude);
            List<int> rand882_2 = GetRandomList(882, exclude);
            List<int> rand882_3 = GetRandomList(882, exclude);
            List<int> rand882_4 = GetRandomList(882, exclude);
            List<int> rand882_5 = GetRandomList(882, exclude);
            List<int> rand882_6 = GetRandomList(882, exclude);
            List<int> rand882_7 = GetRandomList(882, exclude);
            List<int> rand882_8 = GetRandomList(882, exclude);
            List<int> rand882_9 = GetRandomList(882, exclude);
            List<int> rand882_10 = GetRandomList(882, exclude);
            List<int> rand882_11 = GetRandomList(882, exclude);

            //当前奖品
            IList<RewardEntity> listRewardEntity = this.ActivityJGGRewardInit(stime, etime);
            RewardEntity entity = null;
            if (rand001.Contains(number))
            {
                entity = listRewardEntity[1];
                rewardindex = 1;
            }
            else if (rand002.Contains(number))
            {
                entity = listRewardEntity[2];
                rewardindex = 2;
            }
            else if (rand882_1.Contains(number))
            {
                entity = listRewardEntity[3];
                rewardindex = 3;
            }
            else if (rand882_2.Contains(number))
            {
                entity = listRewardEntity[4];
                rewardindex = 4;
            }
            else if (rand882_3.Contains(number))
            {
                entity = listRewardEntity[5];
                rewardindex = 5;
            }
            else if (rand882_4.Contains(number))
            {
                entity = listRewardEntity[6];
                rewardindex = 6;
            }
            else if (rand882_5.Contains(number))
            {
                entity = listRewardEntity[7];
                rewardindex = 7;
            }
            else if (rand882_6.Contains(number))
            {
                entity = listRewardEntity[8];
                rewardindex = 8;
            }
            else if (rand882_7.Contains(number))
            {
                entity = listRewardEntity[9];
                rewardindex = 9;
            }
            else if (rand882_8.Contains(number))
            {
                entity = listRewardEntity[10];
                rewardindex = 10;
            }
            else if (rand882_9.Contains(number))
            {
                entity = listRewardEntity[11];
                rewardindex = 11;
            }
            else if (rand882_10.Contains(number))
            {
                entity = listRewardEntity[12];
                rewardindex = 12;
            }
            else if (rand882_11.Contains(number))
            {
                entity = listRewardEntity[13];
                rewardindex = 13;
            }
            else
            {
                rewardindex = rand.Next(3, 14);
                entity = listRewardEntity[rewardindex];
            }

            Message msg = this.ActivityJGGMFCJ(user.UserID, activitypid, entity.rewardtype, entity.number, entity.number, entity.memberorder, entity.number, entity.propertypid, entity.number);
            if (msg.Success)
            {
                result = msg.Content;
            }
            else
            {
                state = msg.ReturnValue;
                result = msg.Content;
            }
            return result;
        }
        /// <summary>
        /// 九宫格奖励初始化
        /// </summary>
        /// <returns></returns>
        public IList<RewardEntity> ActivityJGGRewardInit(string stime, string etime)
        {
            #region 产生奖励
            IList<RewardEntity> listRewardEntity = new List<RewardEntity>();
            //金币
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold1000", rewardtype = 1, number = 1000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币1000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold2000", rewardtype = 1, number = 2000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币2000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold3000", rewardtype = 1, number = 3000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币3000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold5000", rewardtype = 1, number = 5000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币5000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold8000", rewardtype = 1, number = 8000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币8000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold10000", rewardtype = 1, number = 10000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币10000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold12000", rewardtype = 1, number = 12000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币12000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold15000", rewardtype = 1, number = 15000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币15000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold18000", rewardtype = 1, number = 18000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币18000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold20000", rewardtype = 1, number = 20000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币20000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold30000", rewardtype = 1, number = 30000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币30000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold40000", rewardtype = 1, number = 40000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币40000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold50000", rewardtype = 1, number = 50000, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "金币50000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold80000", rewardtype = 1, number = 80000, memberorder = 0, propertypid = 0, percent = 2m, rewardname = "金币80000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold100000", rewardtype = 1, number = 100000, memberorder = 0, propertypid = 0, percent = 2m, rewardname = "金币100000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold120000", rewardtype = 1, number = 120000, memberorder = 0, propertypid = 0, percent = 2m, rewardname = "金币120000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold150000", rewardtype = 1, number = 150000, memberorder = 0, propertypid = 0, percent = 1m, rewardname = "金币150000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold200000", rewardtype = 1, number = 200000, memberorder = 0, propertypid = 0, percent = 1m, rewardname = "金币200000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold1000000", rewardtype = 1, number = 1000000, memberorder = 0, propertypid = 0, percent = 0, rewardname = "金币1000000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "gold5000000", rewardtype = 1, number = 5000000, memberorder = 0, propertypid = 0, percent = 0, rewardname = "金币5000000" });
            //奖牌                                   
            listRewardEntity.Add(new RewardEntity() { rewardpid = "medal10", rewardtype = 2, number = 10, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "奖牌10" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "medal20", rewardtype = 2, number = 20, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "奖牌20" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "medal30", rewardtype = 2, number = 30, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "奖牌30" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "medal50", rewardtype = 2, number = 50, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "奖牌50" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "medal80", rewardtype = 2, number = 80, memberorder = 0, propertypid = 0, percent = 8.82m, rewardname = "奖牌80" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "medal100", rewardtype = 2, number = 100, memberorder = 0, propertypid = 0, percent = 2m, rewardname = "奖牌100" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "medal300", rewardtype = 2, number = 300, memberorder = 0, propertypid = 0, percent = 2m, rewardname = "奖牌300" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "medal600", rewardtype = 2, number = 600, memberorder = 0, propertypid = 0, percent = 2m, rewardname = "奖牌600" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "medal1000", rewardtype = 2, number = 1000, memberorder = 0, propertypid = 0, percent = 1m, rewardname = "奖牌1000" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "medal10000", rewardtype = 2, number = 10000, memberorder = 0, propertypid = 0, percent = 0, rewardname = "奖牌10000" });
            //会员                                   
            listRewardEntity.Add(new RewardEntity() { rewardpid = "member1x1", rewardtype = 3, number = 1, memberorder = (int)Game.Type.MemberLevel.一星会员, propertypid = 0, percent = 8.82m, rewardname = "黄钻会员1天" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "member2x1", rewardtype = 3, number = 1, memberorder = (int)Game.Type.MemberLevel.二星会员, propertypid = 0, percent = 8.82m, rewardname = "蓝钻会员1天" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "member1x3", rewardtype = 3, number = 3, memberorder = (int)Game.Type.MemberLevel.一星会员, propertypid = 0, percent = 2m, rewardname = "黄钻会员3天" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "member2x3", rewardtype = 3, number = 3, memberorder = (int)Game.Type.MemberLevel.二星会员, propertypid = 0, percent = 2m, rewardname = "蓝钻会员3天" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "member1x7", rewardtype = 3, number = 7, memberorder = (int)Game.Type.MemberLevel.一星会员, propertypid = 0, percent = 1m, rewardname = "黄钻会员7天" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "member2x7", rewardtype = 3, number = 7, memberorder = (int)Game.Type.MemberLevel.二星会员, propertypid = 0, percent = 1m, rewardname = "蓝钻会员7天" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "member1x15", rewardtype = 3, number = 15, memberorder = (int)Game.Type.MemberLevel.一星会员, propertypid = 0, percent = 0m, rewardname = "黄钻会员15天" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "member2x15", rewardtype = 3, number = 15, memberorder = (int)Game.Type.MemberLevel.二星会员, propertypid = 0, percent = 0m, rewardname = "蓝钻会员15天" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "member1x30", rewardtype = 3, number = 30, memberorder = (int)Game.Type.MemberLevel.一星会员, propertypid = 0, percent = 0m, rewardname = "黄钻会员30天" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "member2x30", rewardtype = 3, number = 30, memberorder = (int)Game.Type.MemberLevel.二星会员, propertypid = 0, percent = 0m, rewardname = "蓝钻会员30天" });
            //道具
            listRewardEntity.Add(new RewardEntity() { rewardpid = "property1x8", rewardtype = 4, number = 1, memberorder = 0, propertypid = 8, percent = 2m, rewardname = "周赛门票x1" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "property2x8", rewardtype = 4, number = 2, memberorder = 0, propertypid = 8, percent = 2m, rewardname = "周赛门票x2" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "property1x9", rewardtype = 4, number = 1, memberorder = 0, propertypid = 9, percent = 2m, rewardname = "月赛门票x1" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "property2x9", rewardtype = 4, number = 2, memberorder = 0, propertypid = 9, percent = 2m, rewardname = "月赛门票x2" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "property1x17", rewardtype = 4, number = 1, memberorder = 0, propertypid = 17, percent = 1m, rewardname = "记事本x1" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "property1x16", rewardtype = 4, number = 1, memberorder = 0, propertypid = 16, percent = 1m, rewardname = "U盘x1" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "property1x18", rewardtype = 4, number = 1, memberorder = 0, propertypid = 18, percent = 1m, rewardname = "雨伞x1" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "property1x10", rewardtype = 4, number = 1, memberorder = 0, propertypid = 10, percent = 0, rewardname = "100购物券" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "property1x11", rewardtype = 4, number = 1, memberorder = 0, propertypid = 11, percent = 0, rewardname = "300购物券" });
            listRewardEntity.Add(new RewardEntity() { rewardpid = "property1x15", rewardtype = 4, number = 1, memberorder = 0, propertypid = 15, percent = 0, rewardname = "1000加油卡" });

            //随机展示奖励
            IList<RewardEntity> listResult = new List<RewardEntity>();
            Random rand = new Random();
            //概率为0的
            var aa = listRewardEntity.Where(d => d.percent == 0).ToList<RewardEntity>();
            listResult.Add(aa[rand.Next(0, aa.Count)]);
            //概率为1的
            var bb = listRewardEntity.Where(d => d.percent == 1m).ToList<RewardEntity>();
            listResult.Add(bb[rand.Next(0, bb.Count)]);
            //概率为2的
            var cc = listRewardEntity.Where(d => d.percent == 2m).ToList<RewardEntity>();
            listResult.Add(cc[rand.Next(0, cc.Count)]);
            //概率为8.82的
            var dd = listRewardEntity.Where(d => d.percent == 8.82m).ToList<RewardEntity>();
            int count = 0;
            while (count < 11)
            {
                var item = dd[rand.Next(0, dd.Count())];
                if (listResult.Contains(item) == false)
                {
                    listResult.Add(item);
                    count++;
                }
            }
            #endregion
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(listResult);
            Message msg = this.ActivityJGGMFCJReward(json, stime, etime);
            if (msg.Success)
            {
                var entity = (msg.EntityList[0] as ActivityJGGMFCJReward);
                listResult = Newtonsoft.Json.JsonConvert.DeserializeObject<IList<RewardEntity>>(entity.Json);
            }
            return listResult;
        }
        public class RewardEntity
        {
            public string rewardpid { get; set; }
            public int rewardtype { get; set; }
            public int number { get; set; }
            public int memberorder { get; set; }
            public int propertypid { get; set; }
            public decimal percent { get; set; }
            public string rewardname { get; set; }
        }
        /// <summary>
        /// 活动 九宫格免费抽奖
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="memberdays"></param>
        /// <returns></returns>
        public Message ActivityJGGMFCJ(int userid, int activitypid, long presenttype, long presentgold, long presentmedal, int presentmemberorder, int presentmemberdays, int presentproertypid, int presentproerty)
        {
            Message msg = webData.ActivityJGGMFCJ(userid, activitypid, presenttype, presentgold, presentmedal, presentmemberorder, presentmemberdays, presentproertypid, presentproerty);
            try
            {
                if (msg.Success)
                {
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, userid, Convert.ToInt32(item["GoldKey"]));
                    }
                }
            }
            catch (Exception exp)
            {
                msg.ReturnValue = 1;
                msg.Content = exp.Message;
            }
            return msg;
        }
        /// <summary>
        /// 查询用户还须玩的局数
        /// </summary>
        /// <returns></returns>
        public int GetUserGameCount(int userid, string where)
        {
            return webData.GetUserGameCount(userid, where);
        }
        /// <summary>
        /// 查询用户是否参与抽奖次数
        /// </summary>
        /// <returns></returns>
        public int GetUserIsJoinActivityJGG(int userid, int activitypid, string where)
        {
            return webData.GetUserIsJoinActivityJGG(userid, activitypid, where);
        }
        /// <summary>
        /// 活动 九宫格免费抽奖-定时奖励
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="memberdays"></param>
        /// <returns></returns>
        public Message ActivityJGGMFCJReward(string json, string stime, string etime)
        {
            if (string.IsNullOrEmpty(stime)) stime = "";
            if (string.IsNullOrEmpty(etime)) etime = "";
            DateTime sdate = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd 00:00:00"));
            DateTime edate = DateTime.Parse(DateTime.Now.AddDays(1).ToString("yyyy-MM-dd 00:00:00"));
            if (Game.Library.Utility.IsDateTime(stime)) sdate = DateTime.Parse(stime);
            if (Game.Library.Utility.IsDateTime(etime)) edate = DateTime.Parse(etime);
            return webData.ActivityJGGMFCJReward(json, sdate, edate);
        }
        #endregion

        #region QQ邮箱发送记录
        /// <summary>
        /// 新增QQ邮箱发送记录
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRecordSendEmail(RecordSendEmail entity)
        {
            return webData.InsertRecordSendEmail(entity);
        }
        /// <summary>
        /// 修改QQ企业邮箱发送记录状态
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message UpdateRecordSendEmailStateID(int pid, byte stateid)
        {
            return webData.UpdateRecordSendEmailStateID(pid, stateid);
        }
        /// <summary>
        /// 获取QQ邮箱发送记录
        /// </summary>
        /// <returns></returns>
        public RecordSendEmail GetRecordSendEmailLast()
        {
            return webData.GetRecordSendEmailLast();
        }
        #endregion

        #region 战绩榜、财富榜、魅力榜
        /// <summary>
        /// 财富榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingScoreDataList(int RankCounts)
        {
            return webData.RakingScoreDataList(RankCounts);
        }
        /// <summary>
        /// 战绩榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingRecordDataList(int RankCounts)
        {
            return webData.RakingRecordDataList(RankCounts);
        }
        /// <summary>
        /// 魅力榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingLoveLinessDataList(int RankCounts)
        {
            return webData.RakingLoveLinessDataList(RankCounts);
        }
        #endregion

        #region PC蛋蛋
        /// <summary>
        /// PC蛋蛋广告奖励查询接口
        /// </summary>
        /// <param name="gameid"></param>
        /// <returns></returns>
        public DataSet GetPCeggsReward(int gameid)
        {
            return webData.GetPCeggsReward(gameid);
        }
        #endregion

        #region 小游戏 财神到
        /// <summary>
        /// 检查是否可以开始游戏
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="xgameconfigpid">游戏配置ID</param>
        /// <returns></returns>
        public Message XGameCheckUserGame(int userid, int xgameconfigpid)
        {
            return webData.XGameCheckUserGame(userid, xgameconfigpid);
        }
        /// <summary>
        /// 购买游戏次数
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="xgameconfigpid">游戏配置ID</param>
        /// <returns></returns>
        public Message XGamePayGameCount(int userid, int xgameconfigpid)
        {
            return webData.XGamePayGameCount(userid, xgameconfigpid);
        }
        /// <summary>
        /// 财神到游戏写分
        /// </summary>
        /// <param name="recordpid">游戏记录ID</param>
        /// <param name="userid"></param>
        /// <param name="score">分数</param>
        /// <returns></returns>
        public Message XGameCSDWriteScore(int recordpid, int userid, int score)
        {
            Message msg = webData.XGameCSDWriteScore(recordpid, userid, score);
            try
            {
                if (msg.Success)
                {
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, userid, Convert.ToInt32(item["GoldKey"]));
                    }
                }
            }
            catch (Exception exp)
            {
                msg.ReturnValue = 1;
                msg.Content = exp.Message;
            }
            return msg;
        }
        /// <summary>
        /// 西游记游戏写分
        /// </summary>
        /// <param name="recordpid">游戏记录ID</param>
        /// <param name="userid"></param>
        /// <param name="score">分数</param>
        /// <returns></returns>
        public Message XGameXYJWriteScore(int recordpid, int userid, int score)
        {
            Message msg = webData.XGameXYJWriteScore(recordpid, userid, score);
            try
            {
                if (msg.Success)
                {
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, userid, Convert.ToInt32(item["GoldKey"]));
                    }
                }
            }
            catch (Exception exp)
            {
                msg.ReturnValue = 1;
                msg.Content = exp.Message;
            }
            return msg;
        }
        #endregion

        #region 每日签到V2.0
        /// <summary>
        /// 每日签到
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRecordDailySignV2(RecordDailySignV2 entity)
        {
            Message msg = webData.InsertRecordDailySignV2(entity);
            try
            {
                if (msg.Success)
                {
                    //同步现金金币
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, entity.UserID, Convert.ToInt32(item["GoldKey"]));
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, entity.UserID, 1);
                    }
                }
            }
            catch (Exception exp)
            {
                msg.ReturnValue = 1;
                msg.Content = exp.Message;
            }
            return msg;
        }
        /// <summary>
        /// 每日签到（补签）
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRecordDailySignV2Repair(RecordDailySignV2 entity)
        {
            Message msg = webData.InsertRecordDailySignV2Repair(entity);
            try
            {
                if (msg.Success)
                {
                    //同步现金金币
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[1];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, entity.UserID, Convert.ToInt32(item["GoldKey"]));
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, entity.UserID, 1);
                    }
                }
            }
            catch (Exception exp)
            {
                msg.ReturnValue = 1;
                msg.Content = exp.Message;
            }
            return msg;
        }
        /// <summary>
        /// 每日签到（连续签到奖励）
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message DailySignV2ContinuityReward(int userid, int rewardtype)
        {
            Message msg = webData.DailySignV2ContinuityReward(userid, rewardtype);
            try
            {
                if (msg.Success)
                {
                    //同步现金金币
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, userid, Convert.ToInt32(item["GoldKey"]));
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, 1);
                    }
                }
            }
            catch (Exception exp)
            {
                msg.ReturnValue = 1;
                msg.Content = exp.Message;
            }
            return msg;
        }
        /// <summary>
        /// 获取当月签到记录
        /// </summary>
        /// <returns></returns>
        public IList<RecordDailySignV2> GetCurrentMonthDailySignV2List(int userid)
        {
            return webData.GetCurrentMonthDailySignV2List(userid);
        }
        /// <summary>
        /// 获取当月连续签到记录
        /// </summary>
        /// <returns></returns>
        public IList<RecordDailySignV2Reward> GetCurrentMonthDailySignV2RewardList(int userid)
        {
            return webData.GetCurrentMonthDailySignV2RewardList(userid);
        }
        /// <summary>
        /// 获取当月具体签到日期
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public List<int> GetSignDayThisMonth(int UserID)
        {
            return webData.GetSignDayThisMonth(UserID);
        }

        /// <summary>
        /// 获取手游安装包上传管理员Key
        /// </summary>
        /// <returns></returns>
        public string GetUpLoadDeployKey()
        {
            return webData.GetUpLoadDeployKey();
        }
        #endregion

        #region 兑换CDK
        /// <summary>
        /// 兑换CDK
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message ConvertPackageCDKey(int userid, string packagecdkey, int channelid)
        {
            Message msg = webData.ConvertPackageCDKey(userid, packagecdkey, channelid);
            try
            {
                if (msg.Success)
                {
                    //同步现金金币
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, userid, Convert.ToInt32(item["GoldKey"]));
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, 1);
                    }
                    GlobalParameter.Instance.RemoveUser(userid);
                }
            }
            catch (Exception exp)
            {
                msg.ReturnValue = 1;
                msg.Content = exp.Message;
            }
            return msg;
        }
        /// <summary>
        /// 随机生成CDK
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message GenerationPackageCDKey(int packagetypepid, string packagecdkey)
        {
            return webData.GenerationPackageCDKey(packagetypepid, packagecdkey);
        }
        #endregion

        #region 获取自动发送短信池
        /// <summary>
        /// 获取自动发送短信池 未发送的短信记录
        /// </summary>
        /// <returns></returns>
        public IList<AutoSendTelephoneMessage> GetAutoSendTelephoneMessageTopList(int top)
        {
            return webData.GetAutoSendTelephoneMessageTopList(top);
        }
        /// <summary>
        /// 修改短信记录状态
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="status">发送状态 0=未发送 1=已发送</param>
        /// <returns></returns>
        public bool UpdateAutoSendTelephoneMessageStatus(int pid, byte status)
        {
            return webData.UpdateAutoSendTelephoneMessageStatus(pid, status);
        }
        #endregion

        #region 绑定推广员
        /// <summary>
        /// 绑定推广员
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message BindSpread(int userid, int spreadgameid)
        {
            Message msg = webData.BindSpread(userid, spreadgameid);
            try
            {
                if (msg.Success)
                {
                    //同步现金金币
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    foreach (DataRow item in dt.Rows)
                    {
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, userid, Convert.ToInt32(item["GoldKey"]));
                        Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userid, 1);
                    }
                    GlobalParameter.Instance.RemoveUser(userid);
                }
            }
            catch (Exception exp)
            {
                msg.ReturnValue = 1;
                msg.Content = exp.Message;
            }
            return msg;
        }
        #endregion

        #region 获取比赛条件
        /// <summary>
        /// 获取比赛参赛条件
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public DataSet GetMatchCondition(int userid, int matchid)
        {
            return webData.GetMatchCondition(userid, matchid);
        }
        /// <summary>
        /// 获取比赛参赛条件App
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public DataSet GetMatchConditionApp(int matchid)
        {
            return webData.GetMatchConditionApp(matchid);
        }
        #endregion
        #region 下载统计
        /// <summary>
        /// 插入下载记录
        /// </summary>
        /// <param name="DeviceType"></param>
        /// <param name="KindID"></param>
        /// <returns></returns>
        public int InsertDownLoadLog(int deviceType, int kindID)
        {
            return webData.InsertDownLoadLog(deviceType, kindID);
        }
        #endregion
    }
}
