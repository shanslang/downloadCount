﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Game.IData;
using Game.Francis;
using Game.Utils;
using Game.Entity.Accounts;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.Unity;
using Game.Entity.GameMatch;

namespace Game.BusinessLogic
{
    /// <summary>
    /// 网站外观
    /// </summary>
    public class GameMatchFacade
    {
        #region Fields
        private IGameMatchProvider gameMatchData;
        #endregion

        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        public GameMatchFacade()
        {
            gameMatchData = Game.Services.DataInit.GetUnityContainer().Resolve<IGameMatchProvider>();
        }
        #endregion

        /// <summary>
        /// 获取比赛排名表
        /// </summary>
        /// <returns></returns>
        public IList<StreamMatchHistory> GetStreamMatchHistoryList(int matchid, int matchno)
        {
            return gameMatchData.GetStreamMatchHistoryList(matchid, matchno); 
        }
    }
}
