﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Game.IData;
using Microsoft.Practices.Unity;
using Game.Francis;
using Game.Entity.Task;

namespace Game.BusinessLogic
{
    public class TaskFacade
    {
        private ITaskDataProvider oITaskDataProvider;
        #region 构造函数
        public TaskFacade()
        {
            oITaskDataProvider = Game.Services.DataInit.GetUnityContainer().Resolve<ITaskDataProvider>();
        }
        #endregion

        #region 旧版
        /// <summary>
        /// 获取未领取或未完成的任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="serverid"></param>
        /// <param name="gameid"></param>
        /// <returns></returns>
        public DataSet GetTaskInfo(int userid, int serverid)
        {
            return oITaskDataProvider.GetTaskInfo(userid, serverid);
        }

        /// <summary>
        /// 获取已经完成的任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="serverid"></param>
        /// <param name="gameid"></param>
        /// <returns></returns>
        public DataSet GetTaskInfoed(int userid, int serverid)
        {
            return oITaskDataProvider.GetTaskInfoed(userid, serverid);
        }

        /// <summary>
        /// 获取任务奖励详细信息
        /// </summary>
        /// <param name="taskid">任务ID</param>
        /// <param name="sumtaskid">阶段ＩＤ</param>
        /// <returns></returns>
        public IList<TaskRewardCfg> GetTaskRewardList(int taskid, int subtaskid)
        {
            return oITaskDataProvider.GetTaskRewardList(taskid, subtaskid);
        }

        /// <summary>
        /// 领取任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public Message ReceiveTask(int userid, int taskid)
        {
            return oITaskDataProvider.ReceiveTask(userid, taskid);
        }

        /// <summary>
        /// 放弃任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public int GiveupTask(int userid, int taskid)
        {
            return oITaskDataProvider.GiveupTask(userid, taskid);
        }

        /// <summary>
        /// 获取任务领取条件
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public DataSet GetTaskReceiveCondition(int userid, int taskid)
        {
            return oITaskDataProvider.GetTaskReceiveCondition(userid, taskid);
        }
        #endregion

        #region 新版
        /// <summary>
        /// 
        /// </summary>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public NTaskInfo GetNTaskInfoByTaskIDForPlatform(int taskid)
        {
            return oITaskDataProvider.GetNTaskInfoByTaskIDForPlatform(taskid);
        }
        /// <summary>
        /// 获取任务对象
        /// </summary>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public NTaskInfo GetNTaskInfoByTaskID(int taskid)
        {
            return oITaskDataProvider.GetNTaskInfoByTaskID(taskid);
        }
        /// <summary>
        /// 获取任务奖励
        /// </summary>
        /// <returns></returns>
        public IList<NTaskReward> GetNTaskRewardList(int taskid)
        {
            return oITaskDataProvider.GetNTaskRewardList(taskid);
        }
        /// <summary>
        /// 获取任务分组
        /// </summary>
        /// <returns></returns>
        public IList<NTaskGroupInfo> GetNTaskGroupInfoList()
        {
            return oITaskDataProvider.GetNTaskGroupInfoList();
        }
        #endregion
    }
}
