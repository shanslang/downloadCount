﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Game.IData;
using Game.Francis;
using Game.Utils;
using Game.Entity.Treasure;
using System.Data;
using Game.Data;
using System.Data.Common;
using Microsoft.Practices.Unity;
using Game.Entity.GameLog;

namespace Game.BusinessLogic
{
    /// <summary>
    /// 金币库外观
    /// </summary>
    public class TreasureFacade
    {
        #region Fields

        private ITreasureDataProvider treasureData;
        private IAccountsDataProvider accountsData;

        #endregion

        #region 构造函数

        /// <summary>
        /// 构造函数
        /// </summary>
        public TreasureFacade()
        {
            treasureData = Game.Services.DataInit.GetUnityContainer().Resolve<ITreasureDataProvider>();
            accountsData = Game.Services.DataInit.GetUnityContainer().Resolve<IAccountsDataProvider>();
        }

        /// <summary>
        /// 带参构造函数
        /// </summary>
        /// <param name="kindID"></param>
        public TreasureFacade(int kindID)
        {
            string dbconnectionString = new AppConfig().GetDBlink(kindID);
            if (string.IsNullOrEmpty(dbconnectionString))
                treasureData = Game.Services.DataInit.GetUnityContainer().Resolve<ITreasureDataProvider>();
            else
                treasureData = Game.Services.DataInit.GetUnityContainer().Resolve<ITreasureDataProvider>("AssignConnectString", new ParameterOverride(dbconnectionString, null));
        }
        #endregion

        #region 在线充值

        /// <summary>
        /// 生成订单
        /// </summary>
        /// <param name="orderInfo"></param>
        /// <returns></returns>
        public Message RequestOrder(OnLineOrder orderInfo)
        {
            return treasureData.RequestOrder(orderInfo);
        }

        ///// <summary>
        ///// 添加 购买会员服务明细 和订单关联
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //public Message InsertBuyMemberOrderDetails(BuyMemberOrderDetails entity)
        //{
        //    return treasureData.InsertBuyMemberOrderDetails(entity);
        //}

        /// <summary>
        /// 添加 购买会员服务明细 和订单关联1
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertBuyMemberOrderDetails1(BuyMemberOrderDetails1 entity)
        {
            return treasureData.InsertBuyMemberOrderDetails1(entity);
        }

        /// <summary>
        /// 添加 购买道具明细 和订单关联
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertBuyProperDetails(BuyProperDetails entity)
        {
            return treasureData.InsertBuyProperDetails(entity);
        }

        ///// <summary>
        ///// 快钱充值成功 更新订单信息
        ///// </summary>
        ///// <param name="orderInfo"></param>
        ///// <returns></returns>
        //public Message WriteKQRecharge(ReturnKQDetailInfo returnInfo)
        //{
        //    return treasureData.WriteKQRecharge(returnInfo);
        //}

        ///// <summary>
        ///// 支付宝充值成功 更新订单信息
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteZFBRecharge(ReturnZFBDetailInfo returnInfo)
        //{
        //    return treasureData.WriteZFBRecharge(returnInfo); ;
        //}

        ///// <summary>
        ///// 声讯电信充值成功 更新订单信息
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteSXDXRecharge(ReturnSXDXDetailInfo returnInfo)
        //{
        //    return treasureData.WriteSXDXRecharge(returnInfo);
        //}

        ///// <summary>
        ///// 声讯联通充值成功 更新订单信息
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteSXLTRecharge(ReturnSXLTDetailInfo returnInfo)
        //{
        //    return treasureData.WriteSXLTRecharge(returnInfo);
        //}

        ///// <summary>
        ///// 快钱充值卡充值成功 更新订单信息
        ///// Author:xujianbo
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteKQCardRecharge(ReturnKQCardDetailInfo returnInfo)
        //{
        //    return treasureData.WriteKQCardRecharge(returnInfo);
        //}

        ///// <summary>
        ///// 天下付充值成功 更新订单信息
        ///// Author:xujianbo
        ///// </summary>
        ///// <param name="returnInfo"></param>
        ///// <returns></returns>
        //public Message WriteTXFRecharge(string orderID)
        //{
        //    return treasureData.WriteTXFRecharge(orderID);
        //}

        /// <summary>
        /// APPLE IAP充值成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message WriteAppleIAPRecharge(string orderID, string version, ReturnAppleIAPDetailInfo o)
        {
            Message msg = treasureData.WriteAppleIAPRecharge(orderID, version, o);
            if (msg.Success)
            {
                var oOnlineOrder = treasureData.GetOnlineOrder(orderID);
                Game.Library.Log.WriteLogInfo(new Exception(orderID));
                if (oOnlineOrder == null)
                {
                    throw new Exception(string.Format("订单-{0}-不存在！", orderID));
                }

                DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                foreach (DataRow item in dt.Rows)
                {
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, oOnlineOrder.UserID, Convert.ToInt32(item["GoldKey"]));
                }
            }
            return msg;
        }

        ///// <summary>
        ///// 写天天付返回记录
        ///// </summary>
        ///// <param name="returnKQ"></param>
        //public void WriteReturnDayDetail(ReturnDayDetailInfo returnDay)
        //{
        //    treasureData.WriteReturnDayDetail(returnDay);
        //}

        ///// <summary>
        ///// 写快钱返回记录
        ///// </summary>
        ///// <param name="returnKQ"></param>
        //public void WriteReturnKQDetail(ReturnKQDetailInfo returnKQ)
        //{
        //    treasureData.WriteReturnKQDetail(returnKQ);
        //}

        ///// <summary>
        ///// 写电话充值返回记录
        ///// </summary>
        ///// <param name="returnKQ"></param>
        //public Message WriteReturnVBDetail(ReturnVBDetailInfo returnVB)
        //{
        //    return treasureData.WriteReturnVBDetail(returnVB);
        //}

        ///// <summary>
        ///// 写易宝返回记录
        ///// </summary>
        ///// <param name="returnYB"></param>
        //public Message WriteReturnYBDetail(ReturnYPDetailInfo returnYB)
        //{
        //    return treasureData.WriteReturnYBDetail(returnYB);
        //}

        ///// <summary>
        ///// 在线充值
        ///// </summary>
        ///// <param name="olDetial"></param>
        ///// <returns></returns>
        //public Message FilliedOnline(ShareDetialInfo olDetial, int isVB)
        //{
        //    return treasureData.FilliedOnline(olDetial, isVB);
        //}

        ///// <summary>
        ///// 苹果充值
        ///// </summary>
        ///// <param name="olDetial"></param>
        ///// <returns></returns>
        //public Message FilliedApp(ShareDetialInfo olDetial)
        //{
        //    return treasureData.FilliedApp(olDetial);
        //}

        /// <summary>
        /// 实卡充值
        /// </summary>
        /// <param name="associator"></param>
        /// <param name="operUserID"></param>
        /// <param name="accounts"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        public Message FilledLivcard(ShareDetialInfo detialInfo, string password)
        {
            Message msg = treasureData.FilledLivcard(detialInfo, password);
            if (msg.Success)
            {
                DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                foreach (DataRow item in dt.Rows)
                {
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, detialInfo.UserID, Convert.ToInt32(item["GoldKey"]));
                }
            }
            return msg;
        }

        /// <summary>
        /// 获取订单信息
        /// </summary>
        /// <param name="orderID"></param>
        /// <returns></returns>
        public OnLineOrder GetOnlineOrder(string orderID)
        {
            return treasureData.GetOnlineOrder(orderID);
        }

        ///// <summary>
        ///// 获取苹果产品列表
        ///// </summary>
        ///// <returns></returns>
        //public DataSet GetAppList()
        //{
        //    return treasureData.GetAppList();
        //}

        ///// <summary>
        ///// 获取苹果产品列表
        ///// </summary>
        ///// <returns></returns>
        //public DataSet GetAppListByTagID(int tagID)
        //{
        //    return treasureData.GetAppListByTagID(tagID);
        //}

        ///// <summary>
        ///// 获取产品信息
        ///// </summary>
        ///// <param name="ProductID"></param>
        ///// <returns></returns>
        //public DataSet GetAppInfoByProductID(string productID)
        //{
        //    return treasureData.GetAppInfoByProductID(productID);
        //}

        ///// <summary>
        ///// 写苹果返回记录
        ///// </summary>
        ///// <param name="detialInfo"></param>
        ///// <param name="receipt"></param>
        //public void WriteReturnAppDetail(ShareDetialInfo detialInfo, AppReceiptInfo receipt)
        //{
        //    treasureData.WriteReturnAppDetail(detialInfo, receipt);
        //}

        #endregion

        #region 充值记录

        /// <summary>
        /// 充值记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetPayRecord(string whereQuery, int pageIndex, int pageSize)
        {
            return treasureData.GetPayRecord(whereQuery, pageIndex, pageSize);
        }

        /// <summary>
        /// 充值记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="wherestr"></param>
        /// <returns></returns>
        public DataSet GetRechRecord(int pageindex, int pagesize, string wherestr)
        {
            return treasureData.GetRechRecord(pageindex, pagesize, wherestr);
        }

        ///// <summary>
        ///// 查询购买会员明细
        ///// </summary>
        ///// <param name="orderid"></param>
        ///// <returns></returns>
        //public BuyMemberOrderDetails GetBuyMemberOrderDetails(string orderid)
        //{
        //    return treasureData.GetBuyMemberOrderDetails(orderid);
        //}

        #endregion

        #region 推广中心

        /// <summary>
        /// 获取用户推广信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Message GetUserSpreadInfo(int userID)
        {
            return treasureData.GetUserSpreadInfo(userID);
        }

        /// <summary>
        /// 用户推广结算信息
        /// </summary>
        /// <param name="balance"></param>
        /// <param name="userID"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        public Message GetUserSpreadBalance(int balance, int userID, string ip)
        {
            return treasureData.GetUserSpreadBalance(balance, userID, ip);
        }

        /// <summary>
        /// 推广记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetSpreaderRecord(string whereQuery, int pageIndex, int pageSize)
        {
            return treasureData.GetSpreaderRecord(whereQuery, pageIndex, pageSize);
        }

        /// <summary>
        /// 单个用户下所有被推荐人的推广信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetUserSpreaderList(int userID, int pageIndex, int pageSize)
        {
            return treasureData.GetUserSpreaderList(userID, pageIndex, pageSize);
        }

        /// <summary>
        /// 获取单个结算总额
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public long GetUserSpreaderTotal(string sWhere)
        {
            return treasureData.GetUserSpreaderTotal(sWhere);
        }

        /// <summary>
        /// 获取推广配置实体
        /// </summary>
        /// <returns></returns>
        public GlobalSpreadInfo GetGlobalSpreadInfo()
        {
            return treasureData.GetGlobalSpreadInfo();
        }

        #endregion

        #region 银行操作

        /// <summary>
        /// 金币存入
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="TradeScore"></param>
        /// <param name="minTradeScore"></param>
        /// <param name="clientIP"></param>
        /// <param name="note"></param>
        /// <returns></returns>
        public Message InsureIn(int userID, int TradeScore, int minTradeScore, string clientIP, string note)
        {
            return treasureData.InsureIn(userID, TradeScore, minTradeScore, clientIP, note);
        }


        /// <summary>
        /// 金币取出
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="insurePass"></param>
        /// <param name="TradeScore"></param>
        /// <param name="minTradeScore"></param>
        /// <param name="clientIP"></param>
        /// <param name="note"></param>
        /// <returns></returns>
        public Message InsureOut(int userID, string insurePass, int TradeScore, int minTradeScore, string clientIP, string note)
        {
            return treasureData.InsureOut(userID, insurePass, TradeScore, minTradeScore, clientIP, note);
        }

        /// <summary>
        /// 金币转账
        /// </summary>
        /// <param name="srcUserID"></param>
        /// <param name="insurePass"></param>
        /// <param name="dstUserID"></param>
        /// <param name="TradeScore"></param>
        /// <param name="minTradeScore"></param>
        /// <param name="clientIP"></param>
        /// <param name="note"></param>
        /// <returns></returns>
        public Message InsureTransfer(int srcUserID, string insurePass, int dstUserID, int TradeScore, int minTradeScore, string clientIP, string note)
        {
            return treasureData.InsureTransfer(srcUserID, insurePass, dstUserID, TradeScore, minTradeScore, clientIP, note);
        }

        /// <summary>
        /// 游戏记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetInsureTradeRecord(string whereQuery, int pageIndex, int pageSize)
        {
            return treasureData.GetInsureTradeRecord(whereQuery, pageIndex, pageSize);
        }

        #endregion

        #region 获取金币信息

        /// <summary>
        /// 根据用户ID得到金币信息
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public GameScoreInfo GetTreasureInfo2(int UserID)
        {
            if (treasureData == null) return null;
            return treasureData.GetTreasureInfo2(UserID);
        }

        #endregion

        #region 财富排名

        /// <summary>
        /// 财富排名
        /// </summary>
        /// <returns></returns>
        public IList<GameScoreInfo> GetGameScoreInfoOrderByScore()
        {
            return treasureData.GetGameScoreInfoOrderByScore();
        }

        /// <summary>
        /// 财富排名
        /// </summary>
        /// <returns></returns>
        public DataSet GetScoreRanking(int num)
        {
            return treasureData.GetScoreRanking(num);
        }

        #endregion

        #region 会员操作

        /// <summary>
        /// 负分清零
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        public Message ClearGameScore(int userID, string ip)
        {
            return treasureData.ClearGameScore(userID, ip);
        }

        /// <summary>
        /// 逃跑清零
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        public Message ClearGameFlee(int userID, string ip)
        {
            return treasureData.ClearGameFlee(userID, ip);
        }

        #endregion

        #region 游戏记录

        ///// <summary>
        ///// 每桌游戏记录
        ///// </summary>
        ///// <param name="whereQuery"></param>
        ///// <param name="pageIndex"></param>
        ///// <param name="pageSize"></param>
        ///// <returns></returns>
        //public DataSet GetDrawInfoRecord(string whereQuery, int pageIndex, int pageSize)
        //{
        //    return treasureData.GetDrawInfoRecord(whereQuery, pageIndex, pageSize);
        //}

        ///// <summary>
        ///// 每桌详细记录
        ///// </summary>
        ///// <param name="whereQuery"></param>
        ///// <param name="pageIndex"></param>
        ///// <param name="pageSize"></param>
        ///// <returns></returns>
        //public DataSet GetDrawScoreRecord(string whereQuery, int pageIndex, int pageSize)
        //{
        //    return treasureData.GetDrawScoreRecord(whereQuery, pageIndex, pageSize);
        //}

        #endregion

        #region 公共

        /// <summary>
        /// 获取数据
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="pageIndex">页索引</param>
        /// <param name="pageSize">页大小</param>
        /// <param name="pkey">排序或分组</param>
        /// <param name="whereQuery">查询条件</param>
        /// <param name="whereQuery">字段</param>
        public DataSet GetList(int pageIndex, int pageSize, string sqlQuery, string whereQuery, string orderBy)
        {
            return treasureData.GetList(pageIndex, pageSize, sqlQuery, whereQuery, orderBy);
        }

        /// <summary>
        /// 根据sql语句获取数据
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        public DataSet GetDataSetByWhere(string sqlQuery)
        {
            return treasureData.GetDataSetByWhere(sqlQuery);
        }

        /// <summary>
        /// 根据sql获取实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public T GetEntity<T>(string commandText, List<DbParameter> parms)
        {
            return treasureData.GetEntity<T>(commandText, parms);
        }

        /// <summary>
        /// 根据sql获取实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public T GetEntity<T>(string commandText)
        {
            return treasureData.GetEntity<T>(commandText);
        }

        #endregion

        #region 任务系统

        /// <summary>
        /// 每日签到
        /// </summary>
        /// <param name="detialInfo"></param>
        /// <param name="receipt"></param>
        public Message WriteCheckIn(int userID, string strClientIP)
        {
            return treasureData.WriteCheckIn(userID, strClientIP);
        }
        #endregion

        #region 获取卡类型信息
        /// <summary>
        /// 获取卡类型列表
        /// </summary>
        /// <returns></returns>
        public IList<GlobalLivcard> GetGlobalLivcardList(int top, string wherestr)
        {
            return treasureData.GetGlobalLivcardList(top, wherestr);
        }
        #endregion

        #region 喔咕咕交易
        /// <summary>
        /// 喔咕咕 冻结卖家金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message WggFreeze(WguguOrder entity)
        {
            return treasureData.WggFreeze(entity);
        }
        /// <summary>
        /// 喔咕咕 买家购买金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message WggTrade(WguguOrder entity)
        {
            return treasureData.WggTrade(entity);
        }
        /// <summary>
        /// 喔咕咕 解冻卖家金币
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message WggUnfreeze(WguguOrder entity)
        {
            return treasureData.WggUnfreeze(entity);
        }
        #endregion

        #region 网站 砸金蛋 转盘 翻牌 活动
        ///// <summary>
        ///// 大转盘 -1金币不足 -2未登录 -3没有手机认证
        ///// </summary>
        //public string ActivityForDZP(ref int state)
        //{
        //    var user = Game.WebV3.GlobalParameter.Instance.CurrentLoginUser;
        //    if (user == null)
        //    {
        //        state = -2;
        //        return "您还未登录,请登录后在继续！";
        //    }
        //    if (Game.Library.Utility.IsMobileNumber(user.AuthMTelephone) == false)
        //    {
        //        state = -3;
        //        return "只有手机认证用户才能大转盘！";
        //    }
        //    //消耗类型 1金币 2奖牌 3网吧活动
        //    int activitypid = (int)Game.Type.ActivityPid.大转盘;
        //    int exptype = 1;
        //    int expnum = 10000;
        //    string result = "";

        //    #region 网吧活动 停用
        //    //ActivityInternetcafe oActivityInternetcafe = treasureData.GetActivityInternetcafeByIP(GameRequest.GetUserIP());
        //    //if (oActivityInternetcafe != null)
        //    //{
        //    //    bool IsExceedDayFreeNum = treasureData.IsExceedDayFreeNum(oActivityInternetcafe, user.UserID);
        //    //    if (IsExceedDayFreeNum == false)
        //    //    {
        //    //        exptype = 3;
        //    //    }
        //    //    //else return "超过3次了";
        //    //}
        //    //else  return "没有加入活动网吧";
        //    #endregion

        //    #region 扣金币
        //    if (exptype == 1)//扣金币
        //    {
        //        Random rand = new Random();
        //        int number = rand.Next(1, 100001);
        //        List<int> exclude = new List<int>();
        //        while (exclude.Count < 100000) { exclude.Add(exclude.Count + 1); }
        //        List<int> persent00001 = GetRandomList(1, exclude);
        //        List<int> persent00002 = GetRandomList(2, exclude);
        //        List<int> persent00006 = GetRandomList(6, exclude);
        //        List<int> persent00007 = GetRandomList(70, exclude);
        //        List<int> persent00020 = GetRandomList(20, exclude);
        //        List<int> persent00025 = GetRandomList(250, exclude);
        //        List<int> persent00039 = GetRandomList(390, exclude);
        //        if (persent00039.Contains(number))//10000金币
        //        {
        //            state = 6;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 10000, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else result = "恭喜您！你获得了10000金币！";
        //        }
        //        else if (persent00025.Contains(number))//1个奖牌
        //        {
        //            state = 8;
        //            Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 1, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了1个奖牌！";
        //            }
        //        }
        //        else if (persent00020.Contains(number))//1000金币
        //        {
        //            state = 2;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 1000, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else result = "恭喜您！你获得了1000金币！";
        //        }
        //        else if (persent00007.Contains(number))//10个奖牌
        //        {
        //            state = 4;
        //            Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 10, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了10个奖牌！";
        //            }
        //        }
        //        else if (persent00006.Contains(number))//100金币
        //        {
        //            state = 5;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else result = "恭喜您！你获得了100金币！";
        //        }
        //        else if (persent00002.Contains(number))//7天会员
        //        {
        //            state = 7;
        //            Message msg = this.InsertRecordActivityPresentMember(user.UserID, (int)Game.Type.MemberCardType.二星会员, 7, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else result = "恭喜您！你获得了尊贵VIP7天！";
        //        }
        //        else if (persent00001.Contains(number))//40个奖牌
        //        {
        //            state = 3;
        //            Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 40, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else result = "恭喜您！你获得了40个奖牌！";
        //        }
        //        else //没有中奖 默认100金币
        //        {
        //            state = 5;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else result = "恭喜您！你获得了100金币！";
        //        }
        //    }
        //    #endregion

        //    #region 网吧活动 停用
        //    //else if (exptype == 3)//网吧活动
        //    //{
        //    //    Random rand = new Random();
        //    //    int number = rand.Next(1, 1001);
        //    //    List<int> exclude = new List<int>();
        //    //    while (exclude.Count < 1000) { exclude.Add(exclude.Count + 1); }
        //    //    List<int> persent0390 = GetRandomList(390, exclude);
        //    //    List<int> persent0250 = GetRandomList(250, exclude);
        //    //    List<int> persent0200 = GetRandomList(200, exclude);
        //    //    List<int> persent0080 = GetRandomList(80, exclude);
        //    //    List<int> persent0050 = GetRandomList(50, exclude);
        //    //    List<int> persent0020 = GetRandomList(20, exclude);
        //    //    List<int> persent0001 = GetRandomList(1, exclude);
        //    //    if (persent0390.Contains(number))//10000金币
        //    //    {
        //    //        state = 6;
        //    //        Message msg = this.InsertRecordActivityPresentGold(user.UserID, 10000, true, activitypid, exptype, expnum);
        //    //        if (!msg.Success)
        //    //        {
        //    //            state = -1;
        //    //            result = msg.Content;
        //    //        }
        //    //        else result = "恭喜您！你获得了10000金币！";
        //    //    }
        //    //    else if (persent0250.Contains(number))//1个奖牌
        //    //    {
        //    //        state = 8;
        //    //        Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 1, true, activitypid, exptype, expnum);
        //    //        if (!msg.Success)
        //    //        {
        //    //            state = -1;
        //    //            result = msg.Content;
        //    //        }
        //    //        else
        //    //        {
        //    //            result = "恭喜您！你获得了1个奖牌！";
        //    //        }
        //    //    }
        //    //    else if (persent0200.Contains(number))//1000金币
        //    //    {
        //    //        state = 2;
        //    //        Message msg = this.InsertRecordActivityPresentGold(user.UserID, 1000, true, activitypid, exptype, expnum);
        //    //        if (!msg.Success)
        //    //        {
        //    //            state = -1;
        //    //            result = msg.Content;
        //    //        }
        //    //        else result = "恭喜您！你获得了1000金币！";
        //    //    }
        //    //    else if (persent0050.Contains(number))//10个奖牌
        //    //    {
        //    //        state = 4;
        //    //        Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 10, true, activitypid, exptype, expnum);
        //    //        if (!msg.Success)
        //    //        {
        //    //            state = -1;
        //    //            result = msg.Content;
        //    //        }
        //    //        else
        //    //        {
        //    //            result = "恭喜您！你获得了10个奖牌！";
        //    //        }
        //    //    }
        //    //    else if (persent0080.Contains(number))//100金币
        //    //    {
        //    //        state = 5;
        //    //        Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //    //        if (!msg.Success)
        //    //        {
        //    //            state = -1;
        //    //            result = msg.Content;
        //    //        }
        //    //        else result = "恭喜您！你获得了100金币！";
        //    //    }
        //    //    else if (persent0020.Contains(number))//7天会员
        //    //    {
        //    //        state = 7;
        //    //        Message msg = this.InsertRecordActivityPresentMember(user.UserID, (int)Game.Type.MemberCardType.二星会员, 7, true, activitypid, exptype, expnum);
        //    //        if (!msg.Success)
        //    //        {
        //    //            state = -1;
        //    //            result = msg.Content;
        //    //        }
        //    //        else result = "恭喜您！你获得了尊贵VIP7天！";
        //    //    }
        //    //    else if (persent0001.Contains(number))//40个奖牌
        //    //    {
        //    //        state = 3;
        //    //        Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 40, true, activitypid, exptype, expnum);
        //    //        if (!msg.Success)
        //    //        {
        //    //            state = -1;
        //    //            result = msg.Content;
        //    //        }
        //    //        else result = "恭喜您！你获得了40个奖牌！";
        //    //    }
        //    //    else //没有中奖 默认100金币
        //    //    {
        //    //        state = 5;
        //    //        Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //    //        if (!msg.Success)
        //    //        {
        //    //            state = -1;
        //    //            result = msg.Content;
        //    //        }
        //    //        else result = "恭喜您！你获得了100金币！";
        //    //    }
        //    //}
        //    #endregion

        //    return result;
        //}
        ///// <summary>
        ///// 砸金蛋 -1金币不足 -2未登录 -3没有手机认证
        ///// </summary>
        //public string ActivityForZJD(ref int state)
        //{
        //    var user = Game.WebV3.GlobalParameter.Instance.CurrentLoginUser;
        //    if (user == null)
        //    {
        //        state = -2;
        //        return "您还未登录,请登录后在继续！";
        //    }
        //    if (Game.Library.Utility.IsMobileNumber(user.AuthMTelephone) == false)
        //    {
        //        state = -3;
        //        return "只有手机认证用户才能大转盘！";
        //    }

        //    //消耗类型 1金币 2奖牌 3网吧活动
        //    int activitypid = (int)Game.Type.ActivityPid.砸金蛋;
        //    int exptype = 2;
        //    int expnum = 10;

        //    string orderid = PayHelper.GetOrderIDByPrefix("MALL");
        //    int productpid = 0;

        //    Random rand = new Random();
        //    int number = rand.Next(1, 100001);
        //    List<int> exclude = new List<int>();
        //    while (exclude.Count < 100000) { exclude.Add(exclude.Count + 1); }

        //    List<int> persent0400 = GetRandomList(40, exclude);
        //    List<int> persent0350 = GetRandomList(350, exclude);
        //    List<int> persent0080 = GetRandomList(8, exclude);
        //    List<int> persent0060 = GetRandomList(6, exclude);
        //    List<int> persent0050 = GetRandomList(5, exclude);
        //    List<int> persent0030 = GetRandomList(3, exclude);
        //    List<int> persent0020 = GetRandomList(2, exclude);
        //    List<int> persent0010 = GetRandomList(1, exclude);

        //    string result = "";
        //    if (persent0400.Contains(number))
        //    {
        //        state = 1;
        //        Message msg = this.InsertRecordActivityPresentGold(user.UserID, 10000, true, activitypid, exptype, expnum);
        //        if (!msg.Success)
        //        {
        //            state = -1;
        //            result = msg.Content;
        //        }
        //        else result = "恭喜您！你获得了10000金币！";
        //    }
        //    else if (persent0350.Contains(number))
        //    {
        //        state = 2;
        //        Message msg = this.InsertRecordActivityPresentGold(user.UserID, 5000, true, activitypid, exptype, expnum);
        //        if (!msg.Success)
        //        {
        //            state = -1;
        //            result = msg.Content;
        //        }
        //        else result = "恭喜您！你获得了5000金币！";
        //    }
        //    else if (persent0080.Contains(number))
        //    {
        //        state = 3;
        //        productpid = (int)Game.Type.ProductID.腾讯QQ币;
        //        Message msg = this.InsertProductOrderForActivity(orderid, productpid, user.UserID, 1, true, activitypid, exptype, expnum);
        //        if (!msg.Success)
        //        {
        //            state = -1;
        //            result = msg.Content;
        //        }
        //        result = "恭喜您！你获得了1个QQ币！";
        //    }
        //    else if (persent0060.Contains(number))
        //    {
        //        state = 4;
        //        productpid = (int)Game.Type.ProductID.腾讯QQ币;
        //        Message msg = this.InsertProductOrderForActivity(orderid, productpid, user.UserID, 2, true, activitypid, exptype, expnum);
        //        if (!msg.Success)
        //        {
        //            state = -1;
        //            result = msg.Content;
        //        }
        //        result = "恭喜您！你获得了2个QQ币！";
        //    }
        //    else if (persent0050.Contains(number))
        //    {
        //        state = 5;
        //        productpid = (int)Game.Type.ProductID.腾讯QQ币;
        //        Message msg = this.InsertProductOrderForActivity(orderid, productpid, user.UserID, 5, true, activitypid, exptype, expnum);
        //        if (!msg.Success)
        //        {
        //            state = -1;
        //            result = msg.Content;
        //        }
        //        else result = "恭喜您！你获得了5个QQ币！";
        //    }
        //    else if (persent0030.Contains(number))
        //    {
        //        state = 7;
        //        Message msg = this.InsertRecordActivityPresentGold(user.UserID, 200000, true, activitypid, exptype, expnum);
        //        if (!msg.Success)
        //        {
        //            state = -1;
        //            result = msg.Content;
        //        }
        //        else result = "恭喜您！你获得了200000金币！";
        //    }
        //    else if (persent0020.Contains(number))
        //    {
        //        state = 6;
        //        productpid = (int)Game.Type.ProductID.话费10元;
        //        Message msg = this.InsertProductOrderForActivity(orderid, productpid, user.UserID, 1, true, activitypid, exptype, expnum);
        //        if (!msg.Success)
        //        {
        //            state = -1;
        //            result = msg.Content;
        //        }
        //        else result = "恭喜您！你获得了10元话费！";
        //    }
        //    else if (persent0010.Contains(number))
        //    {
        //        state = 8;
        //        productpid = (int)Game.Type.ProductID.话费20元;
        //        Message msg = this.InsertProductOrderForActivity(orderid, productpid, user.UserID, 1, true, activitypid, exptype, expnum);
        //        if (!msg.Success)
        //        {
        //            state = -1;
        //            result = msg.Content;
        //        }
        //        else result = "恭喜您！你获得了20元话费！";
        //    }
        //    else
        //    {
        //        state = 9;
        //        Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //        if (!msg.Success)
        //        {
        //            state = -1;
        //            result = msg.Content;
        //        }
        //        else result = "恭喜您！你获得了100金币！";
        //    }
        //    return result;
        //}
        ///// <summary>
        ///// 翻牌 -1金币不足 -2未登录 -3没有手机认证
        ///// flower 1菊花 2兰花 3梅花
        ///// </summary>
        //public string ActivityForFanPai(ref int state, int flower)
        //{
        //    var user = Game.WebV3.GlobalParameter.Instance.CurrentLoginUser;
        //    if (user == null)
        //    {
        //        state = -2;
        //        return "您还未登录,请登录后在继续！";
        //    }
        //    if (Game.Library.Utility.IsMobileNumber(user.AuthMTelephone) == false)
        //    {
        //        state = -3;
        //        return "只有手机认证用户才能翻牌！";
        //    }
        //    if (flower == 0)
        //    {
        //        state = -4;
        //        return "必须在右边栏选择一种花！";
        //    }

        //    //消耗类型 1金币 2奖牌 3网吧活动
        //    int activitypid = (int)Game.Type.ActivityPid.翻牌;
        //    int exptype = 1;
        //    int expnum = 100000;
        //    List<int> listflower = new List<int>() { 1, 2, 3, 4 };
        //    listflower.Remove(flower);//移除

        //    Random rand = new Random();
        //    int number = rand.Next(1, 100001);
        //    List<int> exclude = new List<int>();
        //    while (exclude.Count < 100000) { exclude.Add(exclude.Count + 1); }
        //    List<int> persent0030 = GetRandomList(3, exclude);
        //    List<int> persent0050a = GetRandomList(5, exclude);
        //    List<int> persent0100b = GetRandomList(10, exclude);
        //    List<int> persent0150c = GetRandomList(15, exclude);
        //    List<int> persent0670 = GetRandomList(67, exclude);

        //    string result = "";
        //    if (persent0030.Contains(number))//中奖
        //    {
        //        state = flower;//相同
        //        Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 100, true, activitypid, exptype, expnum);
        //        if (!msg.Success)
        //        {
        //            state = -1;
        //            result = msg.Content;
        //        }
        //        else
        //        {
        //            result = "恭喜您！你获得了100个奖牌！";
        //        }
        //    }
        //    else
        //    {
        //        if (flower == 1)
        //        {
        //            if (persent0050a.Contains(number))
        //            {
        //                state = listflower[0];
        //            }
        //            else if (persent0100b.Contains(number))
        //            {
        //                state = listflower[1];
        //            }
        //            else state = listflower[2];
        //        }
        //        else if (flower == 2)
        //        {
        //            if (persent0050a.Contains(number))
        //            {
        //                state = listflower[0];
        //            }
        //            else if (persent0100b.Contains(number))
        //            {
        //                state = listflower[1];
        //            }
        //            else state = listflower[2];
        //        }
        //        else if (flower == 3)
        //        {
        //            if (persent0050a.Contains(number))
        //            {
        //                state = listflower[0];
        //            }
        //            else if (persent0100b.Contains(number))
        //            {
        //                state = listflower[1];
        //            }
        //            else state = listflower[2];
        //        }

        //        if (state == 1)//菊花
        //        {
        //            Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 30, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了30个奖牌！";
        //            }
        //        }
        //        else if (state == 2)//兰花
        //        {
        //            Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 20, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了20个奖牌！";
        //            }
        //        }
        //        else if (state == 3)//梅花
        //        {
        //            Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 10, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了10个奖牌！";
        //            }
        //        }
        //        else if (state == 4)//草
        //        {
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 1000, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了1000金币！";
        //            }
        //        }
        //    }
        //    return result;
        //}
        ///// <summary>
        ///// 挖矿 -1金币不足 -2未登录 -3没有手机认证
        ///// flower 1菊花 2兰花 3梅花
        ///// </summary>
        //public string ActivityForWaKuang(ref int state)
        //{
        //    var user = Game.WebV3.GlobalParameter.Instance.CurrentLoginUser;
        //    if (user == null)
        //    {
        //        state = -2;
        //        return "您还未登录,请登录后在继续！";
        //    }
        //    if (Game.Library.Utility.IsMobileNumber(user.AuthMTelephone) == false)
        //    {
        //        state = -3;
        //        return "只有手机认证用户才能翻牌！";
        //    }
        //    //if (DateTime.Now < Convert.ToDateTime("2014-05-01 00:00:00"))
        //    //{
        //    //    state = -101;
        //    //    return "活动还没有开始，活动开始时间为5月1日0点～5月3日24点";
        //    //}
        //    //if (DateTime.Now >= Convert.ToDateTime("2014-05-03 23:59:59"))
        //    //{
        //    //    state = -102;
        //    //    return "活动已经结束，活动开始时间为5月1日0点～5月3日24点";
        //    //}

        //    //消耗类型 1金币 2奖牌 3网吧活动
        //    int activitypid = (int)Game.Type.ActivityPid.挖矿;
        //    int exptype = 1;
        //    int expnum = 100000;

        //    Random rand = new Random();
        //    int number = rand.Next(1, 100001);
        //    List<int> exclude = new List<int>();
        //    while (exclude.Count < 100000) { exclude.Add(exclude.Count + 1); }

        //    string result = "";

        //    int wakuangcount = Game.Utils.Utility.StrToInt(treasureData.GetActivityPlizeRecord(1, 1, "CONVERT(NVARCHAR(30),temp.CTime,23)=CONVERT(NVARCHAR(30),getdate(),23) and temp.userid=" + user.UserID + " and temp.activitypid=" + (int)Game.Type.ActivityPid.挖矿).Tables[1].Rows[0][0], 0);
        //    int rechcount = Game.Utils.Utility.StrToInt(treasureData.GetRechRecord(1, 1, "a.userid=" + user.UserID).Tables[1].Rows[0][0], 0);
        //    if (wakuangcount < 3)
        //    {
        //        expnum = 0;
        //        #region 充值用户
        //        if (rechcount > 0)
        //        {
        //            List<int> persent0600 = GetRandomList(600, exclude);
        //            List<int> persent0100a = GetRandomList(100, exclude);
        //            List<int> persent0100b = GetRandomList(100, exclude);
        //            List<int> persent0050a = GetRandomList(5, exclude);
        //            List<int> persent0050b = GetRandomList(5, exclude);
        //            List<int> persent0040 = GetRandomList(4, exclude);
        //            List<int> persent0030 = GetRandomList(3, exclude);
        //            List<int> persent0020 = GetRandomList(2, exclude);
        //            List<int> persent0010 = GetRandomList(1, exclude);
        //            if (persent0600.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 10000, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了10000金币！";
        //                }
        //            }
        //            else if (persent0100a.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 50000, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了50000金币！";
        //                }
        //            }
        //            else if (persent0100b.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 1, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了1个奖牌！";
        //                }
        //            }
        //            else if (persent0050a.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了100金币！";
        //                }
        //            }
        //            else if (persent0050b.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 80000, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了80000金币！";
        //                }
        //            }
        //            else if (persent0040.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 10, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了10个奖牌！";
        //                }
        //            }
        //            else if (persent0030.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100000, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了100000金币！";
        //                }
        //            }
        //            else if (persent0020.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 150000, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了150000金币！";
        //                }
        //            }
        //            else if (persent0010.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentMember(user.UserID, (int)Game.Type.MemberLevel.二星会员, 7, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了7天黄钻会员！";
        //                }
        //            }
        //            else
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了100金币！";
        //                }
        //            }
        //        }
        //        #endregion
        //        #region 未充值
        //        else
        //        {
        //            List<int> persent0600 = GetRandomList(600, exclude);
        //            List<int> persent0100a = GetRandomList(100, exclude);
        //            List<int> persent0100b = GetRandomList(100, exclude);
        //            List<int> persent0050a = GetRandomList(5, exclude);
        //            List<int> persent0050b = GetRandomList(5, exclude);
        //            List<int> persent0040 = GetRandomList(4, exclude);
        //            List<int> persent0030 = GetRandomList(3, exclude);
        //            List<int> persent0020 = GetRandomList(2, exclude);
        //            List<int> persent0010 = GetRandomList(1, exclude);
        //            if (persent0600.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 5000, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了5000金币！";
        //                }
        //            }
        //            else if (persent0100a.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 50000, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了50000金币！";
        //                }
        //            }
        //            else if (persent0100b.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 1, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了1个奖牌！";
        //                }
        //            }
        //            else if (persent0050a.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了100金币！";
        //                }
        //            }
        //            else if (persent0050b.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 80000, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了80000金币！";
        //                }
        //            }
        //            else if (persent0040.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 10, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了10个奖牌！";
        //                }
        //            }
        //            else if (persent0030.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100000, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了100000金币！";
        //                }
        //            }
        //            else if (persent0020.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 150000, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了150000金币！";
        //                }
        //            }
        //            else if (persent0010.Contains(number))
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentMember(user.UserID, (int)Game.Type.MemberLevel.二星会员, 7, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了7天黄钻会员！";
        //                }
        //            }
        //            else
        //            {
        //                state = 1;
        //                Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //                if (!msg.Success)
        //                {
        //                    state = -1;
        //                    result = msg.Content;
        //                }
        //                else
        //                {
        //                    result = "恭喜您！你获得了100金币！";
        //                }
        //            }
        //        }
        //        #endregion
        //    }
        //    else
        //    {
        //        #region 消耗金币
        //        List<int> persent0550 = GetRandomList(550, exclude);
        //        List<int> persent0150 = GetRandomList(150, exclude);
        //        List<int> persent0100 = GetRandomList(100, exclude);
        //        List<int> persent0050a = GetRandomList(50, exclude);
        //        List<int> persent0050b = GetRandomList(50, exclude);
        //        List<int> persent0040 = GetRandomList(4, exclude);
        //        List<int> persent0030 = GetRandomList(30, exclude);
        //        List<int> persent0020 = GetRandomList(20, exclude);
        //        List<int> persent0010 = GetRandomList(10, exclude);
        //        if (persent0550.Contains(number))
        //        {
        //            state = 1;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 20000, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了20000金币！";
        //            }
        //        }
        //        else if (persent0150.Contains(number))
        //        {
        //            state = 1;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 50000, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了50000金币！";
        //            }
        //        }
        //        else if (persent0100.Contains(number))
        //        {
        //            state = 1;
        //            Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 1, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了1个奖牌！";
        //            }
        //        }
        //        else if (persent0050a.Contains(number))
        //        {
        //            state = 1;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了100金币！";
        //            }
        //        }
        //        else if (persent0050b.Contains(number))
        //        {
        //            state = 1;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 80000, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了80000金币！";
        //            }
        //        }
        //        else if (persent0040.Contains(number))
        //        {
        //            state = 1;
        //            Message msg = this.InsertRecordActivityPresentUserMedal(user.UserID, 10, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了10个奖牌！";
        //            }
        //        }
        //        else if (persent0030.Contains(number))
        //        {
        //            state = 1;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100000, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了100000金币！";
        //            }
        //        }
        //        else if (persent0020.Contains(number))
        //        {
        //            state = 1;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 150000, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了150000金币！";
        //            }
        //        }
        //        else if (persent0010.Contains(number))
        //        {
        //            state = 1;
        //            Message msg = this.InsertRecordActivityPresentMember(user.UserID, (int)Game.Type.MemberLevel.二星会员, 7, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了7天黄钻会员！";
        //            }
        //        }
        //        else
        //        {
        //            state = 1;
        //            Message msg = this.InsertRecordActivityPresentGold(user.UserID, 100, true, activitypid, exptype, expnum);
        //            if (!msg.Success)
        //            {
        //                state = -1;
        //                result = msg.Content;
        //            }
        //            else
        //            {
        //                result = "恭喜您！你获得了100金币！";
        //            }
        //        }
        //        #endregion
        //    }
        //    return result;
        //}

        ///// <summary>
        ///// 活动赠送金币
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //public Message InsertRecordActivityPresentGold(int userid, long gold, bool ispresent, int activitypid, int expendtype, int expendnum)
        //{
        //    Message msg = treasureData.InsertRecordActivityPresentGold(userid, gold, ispresent, activitypid, expendtype, expendnum);
        //    if (msg.Success)
        //    {
        //        //清除用户缓存
        //        Game.WebV3.GlobalParameter.Instance.RemoveUser(userid);
        //    }
        //    return msg;
        //}
        ///// <summary>
        ///// 活动赠送会员
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //public Message InsertRecordActivityPresentMember(int userid, int membercardtypeid, int memberdays, bool ispresent, int activitypid, int expendtype, int expendnum)
        //{
        //    Message msg = treasureData.InsertRecordActivityPresentMember(userid, membercardtypeid, memberdays, ispresent, activitypid, expendtype, expendnum);
        //    if (msg.Success)
        //    {
        //        //清除用户缓存
        //        Game.WebV3.GlobalParameter.Instance.RemoveUser(userid);
        //    }
        //    return msg;
        //}
        ///// <summary>
        ///// 活动赠送奖牌
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //public Message InsertRecordActivityPresentUserMedal(int userid, int usermedal, bool ispresent, int activitypid, int expendtype, int expendnum)
        //{
        //    Message msg = treasureData.InsertRecordActivityPresentUserMedal(userid, usermedal, ispresent, activitypid, expendtype, expendnum);
        //    if (msg.Success)
        //    {
        //        //清除用户缓存
        //        Game.WebV3.GlobalParameter.Instance.RemoveUser(userid);
        //    }
        //    return msg;
        //}



        #endregion



        #region 网站活动 订单管理
        ///// <summary>
        ///// 活动赠送实物及奖品 产生订单
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //public Message InsertProductOrderForActivity(string orderid, int productpid, int userid, int number, bool ispresent, int activitypid, int expendtype, int expendnum)
        //{
        //    Message msg = treasureData.InsertProductOrderForActivity(orderid, productpid, userid, number, ispresent, activitypid, expendtype, expendnum);
        //    if (msg.Success)
        //    {
        //        //清除用户缓存
        //        Game.WebV3.GlobalParameter.Instance.RemoveUser(userid);
        //    }
        //    return msg;
        //}
        /// <summary>
        /// 活动赠送实物及奖品 处理订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message ActivityProductOrderProcess(string orderid, string qqnumber, string telephone, string postcode, string address, string remark)
        {
            return treasureData.ActivityProductOrderProcess(orderid, qqnumber, telephone, postcode, address, remark);
        }
        #endregion



        #region 产品订单管理
        /// <summary>
        /// 商城购买物品 产生订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertProductOrderForMall(string orderid, int productpid, int userid, int number, string name, string qqnumber, string telephone, string postcode, string address, string remark)
        {
            var orderstatus = Game.Type.ProductOrderStatus.人工处理;
            if (productpid == (int)Game.Type.ProductID.腾讯QQ币 ||
                productpid == (int)Game.Type.ProductID.话费10元 ||
                productpid == (int)Game.Type.ProductID.话费20元 ||
                productpid == (int)Game.Type.ProductID.话费30元 ||
                productpid == (int)Game.Type.ProductID.话费50元 ||
                productpid == (int)Game.Type.ProductID.话费100元)
            {
                orderstatus = Game.Type.ProductOrderStatus.人工处理;
            }
            Message msg = treasureData.InsertProductOrderForMall(orderid, productpid, userid, number, name, qqnumber, telephone, postcode, address, remark, orderstatus);
            if (msg.Success)
            {
                //清除用户缓存
                Game.WebV3.GlobalParameter.Instance.RemoveUser(userid);
            }
            return msg;
        }
        /// <summary>
        /// 商城购买物品 处理订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message MallProductOrderProcess(string orderid, Game.Type.ProductOrderStatus status, string remark)
        {
            return treasureData.MallProductOrderProcess(orderid, status, remark);
        }
        /// <summary>
        /// 查询单条产品记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public Product GetProduct(int pid)
        {
            return treasureData.GetProduct(pid);
        }
        /// <summary>
        /// 查询记录数量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public int GetProductCount(string wherestr)
        {
            return treasureData.GetProductCount(wherestr);
        }
        /// <summary>
        /// 查询产品记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public IList<Product> GetProductTopList(int top, string wherestr, string order)
        {
            return treasureData.GetProductTopList(top, wherestr, order);
        }
        /// <summary>
        /// 查询产品记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetProductRecord(int pageindex, int pagesize, string wherestr, string order)
        {
            return treasureData.GetProductRecord(pageindex, pagesize, wherestr, order);
        }
        /// <summary>
        /// 查询单条订单记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public ProductOrder GetProductOrder(string orderid)
        {
            return treasureData.GetProductOrder(orderid);
        }
        /// <summary>
        /// 查询记录数量
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public int GetProductOrderCount(string wherestr)
        {
            return treasureData.GetProductOrderCount(wherestr);
        }
        /// <summary>
        /// 查询订单记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public IList<ProductOrder> GetProductOrderTopList(int top, string wherestr, string order)
        {
            return treasureData.GetProductOrderTopList(top, wherestr, order);
        }
        /// <summary>
        /// 查询订单记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetProductOrderRecord(int pageindex, int pagesize, string wherestr)
        {
            return treasureData.GetProductOrderRecord(pageindex, pagesize, wherestr);
        }

        /// <summary>
        /// 查询订单明细记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public MallBuyDetail GetProductOrderDetailObject(string orderid)
        {
            return treasureData.GetProductOrderDetailObject(orderid);
        }
        /// <summary>
        /// 查询订单明细记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        DataSet GetProductOrderDetailRecord(int pageindex, int pagesize, string wherestr)
        {
            return treasureData.GetProductOrderDetailRecord(pageindex, pagesize, wherestr);
        }
        #endregion

        #region 新版充值 金豆充值
        /// <summary>
        /// 创建充值金豆订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message InsertRechOrder(RechOrder entity)
        {
            return treasureData.InsertRechOrder(entity);
        }

        /// <summary>
        /// 快钱RMB充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechGoldenBeanFromKQRMB(ReturnKQDetailInfo returnInfo)
        {
            Message msg = treasureData.RechGoldenBeanFromKQRMB(returnInfo);
            if (msg.Success)
            {
                RechOrder oRechOrder = treasureData.GetRechOrderByOrderID(returnInfo.OrderID);
                if (oRechOrder != null)
                {
                    Game.WebV3.GlobalParameter.Instance.RemoveUser(oRechOrder.UserID);
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, oRechOrder.UserID, 8);
                }
            }
            return msg;
        }

        /// <summary>
        /// 快钱充值卡充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechGoldenBeanFromKQCARD(ReturnKQCardDetailInfo returnInfo)
        {
            Message msg = treasureData.RechGoldenBeanFromKQCARD(returnInfo);
            if (msg.Success)
            {
                RechOrder oRechOrder = treasureData.GetRechOrderByOrderID(returnInfo.OrderId);
                if (oRechOrder != null)
                {
                    Game.WebV3.GlobalParameter.Instance.RemoveUser(oRechOrder.UserID);
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, oRechOrder.UserID, 8);
                }
            }
            return msg;
        }

        /// <summary>
        /// 支付宝充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechGoldenBeanFromZFB(ReturnZFBDetailInfo returnInfo)
        {
            Message msg = treasureData.RechGoldenBeanFromZFB(returnInfo);
            if (msg.Success)
            {
                RechOrder oRechOrder = treasureData.GetRechOrderByOrderID(returnInfo.Out_trade_no);
                if (oRechOrder != null)
                {
                    Game.WebV3.GlobalParameter.Instance.RemoveUser(oRechOrder.UserID);
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, oRechOrder.UserID, 8);
                }
            }
            return msg;
        }

        /// <summary>
        /// 支付宝充值vip房间道具 更新订单信息
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechVIPFromZFB(ReturnZFBDetailInfo returnInfo)
        {
            Message msg = treasureData.RechVIPFromZFB(returnInfo);
            if (msg.Success)
            {
                RechOrder oRechOrder = treasureData.GetRechOrderByOrderID(returnInfo.Out_trade_no);
                if (oRechOrder != null)
                {
                    Game.WebV3.GlobalParameter.Instance.RemoveUser(oRechOrder.UserID);
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, oRechOrder.UserID, 0x00000020);
                }
            }
            return msg;
        }
        /// <summary>
        /// 微信充值vip房间道具 更新订单信息
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechVIPFromWX(ReturnWeixinDetailInfo returnInfo)
        {
            Message msg = treasureData.RechVIPFromWX(returnInfo);
            if (msg.Success)
            {
                RechOrder oRechOrder = treasureData.GetRechOrderByOrderID(returnInfo.out_trade_no);
                if (oRechOrder != null)
                {
                    Game.WebV3.GlobalParameter.Instance.RemoveUser(oRechOrder.UserID);
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, oRechOrder.UserID, 0x00000020);
                }
            }
            return msg;
        }
        /// <summary>
        /// 微信二维码充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechGoldenBeanFromWeixin(ReturnWeixinDetailInfo returnInfo)
        {
            Message msg = treasureData.RechGoldenBeanFromWeixin(returnInfo);
            if (msg.Success)
            {
                RechOrder oRechOrder = treasureData.GetRechOrderByOrderID(returnInfo.out_trade_no);
                if (oRechOrder != null)
                {
                    Game.WebV3.GlobalParameter.Instance.RemoveUser(oRechOrder.UserID);
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, oRechOrder.UserID, 8);
                }
            }
            return msg;
        }

        /// <summary>
        /// 天下付充值金豆成功 更新订单信息
        /// Author:xujianbo
        /// </summary>
        /// <param name="returnInfo"></param>
        /// <returns></returns>
        public Message RechGoldenBeanFromTXF(string orderID)
        {
            Message msg = treasureData.RechGoldenBeanFromTXF(orderID);
            if (msg.Success)
            {
                RechOrder oRechOrder = treasureData.GetRechOrderByOrderID(orderID);
                if (oRechOrder != null)
                {
                    Game.WebV3.GlobalParameter.Instance.RemoveUser(oRechOrder.UserID);
                    Game.Services.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, oRechOrder.UserID, 8);
                }
            }
            return msg;
        }

        /// <summary>
        /// 查询用户金豆信息
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public UserGoldenBean GetUserGoldenBean(int userid)
        {
            return treasureData.GetUserGoldenBean(userid);
        }

        /// <summary>
        /// 查询充值金豆订单信息
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public RechOrder GetRechOrderByOrderID(string orderid)
        {
            return treasureData.GetRechOrderByOrderID(orderid);
        }

        ///// <summary>
        ///// 使用金豆购买会员和金币
        ///// </summary>
        ///// <param name="userid"></param>
        ///// <param name="memberorder"></param>
        ///// <param name="number"></param>
        ///// <returns></returns>
        //public Message ConvertGoldenBeanToMemberAndGold(int userid, int number)
        //{
        //    return treasureData.ConvertGoldenBeanToMemberAndGold(userid, number);
        //}

        /// <summary>
        /// 查询充值金豆规则
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="memberorder"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public Message QueryRechRules(int userid, decimal orderamount)
        {
            return treasureData.QueryRechRules(userid, orderamount);
        }

        /// <summary>
        /// 查询金豆交易记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public DataSet GetRecordUserGoldenBean(int pageindex, int pagesize, string wherestr)
        {
            return treasureData.GetRecordUserGoldenBean(pageindex, pagesize, wherestr);
        }
        #endregion

        #region 新版奖牌、魅力值
        /// <summary>
        /// 查询用户金豆信息
        /// author:francis
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public GameScoreInfoEx GetGameScoreInfoEx(int userid)
        {
            return treasureData.GetGameScoreInfoEx(userid);
        }
        #endregion

        #region 新版任务系统
        /// <summary>
        /// 查询任务记录
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pagesize"></param>
        /// <param name="wherestr"></param>
        /// <param name="order"></param>
        /// <returns></returns>
        public DataSet GetUserTaskRecord(int pageindex, int pagesize, string wherestr, string order)
        {
            return treasureData.GetUserTaskRecord(pageindex, pagesize, wherestr, order);
        }
        /// <summary>
        /// 修改任务状态
        /// </summary>
        /// <param name="taskid"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public bool UpdateUserTaskStatusByTaskID(int taskid, int userid)
        {
            return treasureData.UpdateUserTaskStatusByTaskID(taskid, userid);
        }
        #endregion

        #region 美女视频
        /// <summary>
        /// 美女扣费记录
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Message ProcessMeinvFee(RecordMeinvFee entity)
        {
            return treasureData.ProcessMeinvFee(entity);
        }

        /// <summary>
        /// 新增美女主播浏览记录
        /// </summary>
        /// <param name="entity"></param>
        public void InsertRecordMeinvSPBrowse(RecordMeinvSPBrowse entity)
        {
            treasureData.InsertRecordMeinvSPBrowse(entity);
        }
        #endregion

        #region vip房间充值配置获取
        /// <summary>
        /// vip房间充值配置获取
        /// </summary>
        public DataSet GetVipRechargeReward()
        {
            return treasureData.GetVipRechargeReward();
        }
        /// <summary>
        /// 查询返利记录
        /// </summary>
        public DataSet GetRebateDetail(int pageindex, int pagesize, int userid, string stime, string etime)
        {
            return treasureData.GetRebateDetail(pageindex, pagesize, userid, stime, etime);
        }
        /// <summary>
        /// 根据条件获取返利数量
        /// </summary>
        /// <param name="where"></param>
        /// <returns></returns>
        public int GetRebateCount(string where)
        {
            return treasureData.GetRebateCount(where);
        }
        #endregion
    }
}
