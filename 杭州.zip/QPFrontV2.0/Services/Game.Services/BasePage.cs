﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Security.Cryptography;

using Game.Entity.Accounts;
using Game.Entity.NativeWeb;
using Game.Utils;
using Game.Francis;
using Game.IData;
using Game.BusinessLogic;
using System.Web.Security;

namespace Game.WebV3
{
    public class BasePage : System.Web.UI.Page
    {
        #region 业务逻辑
        protected AccountsFacade oAccountsFacade = new AccountsFacade();
        protected GameMatchFacade oGameMatchFacade = new GameMatchFacade();
        protected GamePropertyFacade oGamePropertyFacade = new GamePropertyFacade();
        protected GameScoreFacade oGameScoreFacade = new GameScoreFacade();
        protected NativeWebFacade oNativeWebFacade = new NativeWebFacade();
        protected PlatformFacade oPlatformFacade = new PlatformFacade();
        protected QPMatchFacade oQPMatchFacade = new QPMatchFacade();
        protected RecordFacade oRecordFacade = new RecordFacade();
        protected TaskFacade oTaskFacade = new TaskFacade();
        protected TreasureFacade oTreasureFacade = new TreasureFacade();
        #endregion

        #region 构造函数
        /// <summary>
        /// 初始化页面基类
        /// </summary>
        public BasePage()
        {
            LoginUrl = "/login.html";
            RawUrl = Utils.GameRequest.GetUrl();
        }
        #endregion

        #region 页面事件
        /// <summary>
        /// 读取或初始化控件属性
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            UserLogon();
        }
        /// <summary>
        /// 读取和更新控件属性
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
        }
        /// <summary>
        /// 对需要加载页上的所有其他控件的任务使用该事件
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoadComplete(EventArgs e)
        {
            #region 添加页面参数
            System.Type type = base.GetType();
            string key = "__ISPAGE__";
            ClientScriptManager clientScript = this.Page.ClientScript;
            if (!clientScript.IsClientScriptBlockRegistered(type, key))
            {
                string json = "{}";
                string name = type.BaseType.Name;
                this.PageDataDictionary.Add("pagename", name);
                if (this.PageDataDictionary.Count > 0)
                {
                    json = Newtonsoft.Json.JsonConvert.SerializeObject(this.PageDataDictionary);
                }
                ResetCache();
                sbCache.Append("<script type=\"text/javascript\">").Append("thisPage.initialize(\"").Append(name).Append("\",").Append(json).Append(");").Append("</script>");
                clientScript.RegisterClientScriptBlock(type, key, sbCache.ToString());
            }
            #endregion

            #region CDN缓存
            if (this.PageCDNState)
            {
                if (this.PageCDNCacheTime <= 0) throw new Exception("CDN缓存时间必须大于0");
                Response.Cache.SetNoServerCaching();
                Response.Cache.SetLastModified(DateTime.Now);
                Response.Cache.SetCacheability(HttpCacheability.Public);
                Response.Cache.SetMaxAge(TimeSpan.FromSeconds(this.PageCDNCacheTime));
            }
            #endregion

            base.OnLoadComplete(e);
        }
        #endregion

        #region 通用属性 for xujianbo
        public StringBuilder sbCache = null;
        /// <summary>
        /// 缓存
        /// </summary>
        public void ResetCache()
        {
            if (this.sbCache == null)
            {
                this.sbCache = new StringBuilder();
            }
            else
            {
                this.sbCache.Length = 0;
            }
        }
        private int _PageIndex;
        /// <summary>
        /// 页码
        /// </summary>
        protected int PageIndex
        {
            get
            {
                _PageIndex = GameRequest.GetQueryInt("page", 1);
                return this._PageIndex;
            }
        }
        /// <summary>
        /// 页记录条数
        /// </summary>
        protected virtual int PageSize
        {
            get { return 30; }
        }
        /// <summary>
        /// 分页控件显示
        /// </summary>
        protected virtual int PageNumber
        {
            get { return 6; }
        }
        private string _LoginUrl;
        /// <summary>
        /// 登录地址
        /// </summary>
        protected virtual string LoginUrl
        {
            get { return _LoginUrl; }
            set { _LoginUrl = value; }
        }
        private string _RawUrl;
        /// <summary>
        /// 当前页面地址
        /// </summary>
        protected virtual string RawUrl
        {
            get { return _RawUrl; }
            set { _RawUrl = value; }
        }
        /// <summary>
        /// 登录返回页面地址
        /// </summary>
        protected virtual string LoginReturnUrl
        {
            get
            {
                return GameRequest.GetQueryString("url");
            }
        }
        private bool _IsAuthenticatedUser = false;
        /// <summary>
        /// 是否验证身份
        /// </summary>
        protected virtual bool IsAuthenticatedUser
        {
            get { return _IsAuthenticatedUser; }
        }
        private readonly IDictionary<string, object> _lazyPageDataDictionary = new Dictionary<string, object>();
        /// <summary>
        /// 添加页面初始化数据 提供个JS调用
        /// </summary>
        private IDictionary<string, object> PageDataDictionary
        {
            get
            {
                return this._lazyPageDataDictionary;
            }
        }
        /// <summary>
        /// 当前登录用户
        /// </summary>
        protected UserInfo CurrentUser
        {
            get
            {
                if (GlobalParameter.Instance.CurrentLoginUser != null)
                {
                    return GlobalParameter.Instance.CurrentLoginUser;
                }
                return null;
            }
        }
        /// <summary>
        /// 是否开启CDN缓存 和PageCDNCacheTime一起使用 
        /// </summary>
        protected virtual bool PageCDNState
        {
            get 
            {
                return false;
            }
        }
        /// <summary>
        /// CDN缓存时间 一起使用 
        /// </summary>
        protected virtual double PageCDNCacheTime
        {
            get 
            {
                return 1000*60;
            }
        }
        #endregion

        #region 公共方法
        /// <summary>
        /// 添加页面初始化数据 供JS调用
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        protected void AddPageData(string key, object value)
        {
            if (string.IsNullOrEmpty(key))
            {
                throw new ArgumentException("AddPageData KEY不能为空！");
            }
            if (this.PageDataDictionary.ContainsKey(key))
            {
                throw new ArgumentException("名为：" + key + " 的数据已经存在！");
            }
            this.PageDataDictionary.Add(key, value);
        }
        #endregion

        #region 消息提示框
        /// <summary>
        /// 显示消息提示对话框
        /// </summary>
        /// <param name="msg">提示信息</param>
        public void Show(string msg)
        {
            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", "<script language='javascript' defer>alert('" + msg.ToString() + "');</script>");
        }
        /// <summary>
        /// 控件点击 消息确认提示框
        /// </summary>
        /// <param name="page">当前页面指针，一般为this</param>
        /// <param name="msg">提示信息</param>
        public static void ShowConfirm(System.Web.UI.WebControls.WebControl Control, string msg)
        {
            Control.Attributes.Add("onclick", "return confirm('" + msg + "');");
        }
        /// <summary>
        /// 显示消息提示对话框，并进行页面跳转
        /// </summary>
        /// <param name="page">当前页面指针，一般为this</param>
        /// <param name="msg">提示信息</param>
        /// <param name="url">跳转的目标URL</param>
        public void ShowAndRedirect(string msg, string url)
        {
            ResetCache();
            sbCache.Append("<script language='javascript' defer>");
            sbCache.AppendFormat("alert('{0}');", msg);
            sbCache.AppendFormat("top.location.href='{0}'", url);
            sbCache.Append("</script>");
            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", sbCache.ToString());

        }
        #endregion

        #region 页面跳转
        /// <summary>
        /// 跳转
        /// </summary>
        /// <param name="url"></param>
        protected virtual void Redirect(string url)
        {
            Response.Redirect(url);
        }
        /// <summary>
        /// 跳转
        /// </summary>
        /// <param name="url"></param>
        protected virtual void Redirect301(string url)
        {
            Response.Clear();
            Response.StatusCode = 301;
            Response.AppendHeader("location", url);
            Response.End();
        }
        #endregion

        #region 验证登录
        /// <summary>
        /// 用户登录
        /// </summary>
        protected void UserLogon()
        {
            if (this.IsAuthenticatedUser == false) return;          
            if (Game.WebV3.GlobalParameter.Instance.IsAuthenticated == false || GlobalParameter.Instance.CurrentLoginUser == null||GlobalParameter.Instance.CurrentLoginUser.IsAgent==0||GlobalParameter.Instance.CurrentLoginUser.Nullity==1)
            {
                string url = String.Format("{0}?url={1}", LoginUrl, RawUrl);
                Redirect(url);
            }
            if (((FormsIdentity)HttpContext.Current.User.Identity) != null && ((FormsIdentity)System.Web.HttpContext.Current.User.Identity).Ticket != null)
            {
                if (((FormsIdentity)HttpContext.Current.User.Identity).Ticket.UserData != GlobalParameter.Instance.CurrentLoginUser.LogonPass)
                {
                    string url = String.Format("{0}?url={1}", LoginUrl, RawUrl);
                    Redirect(url);
                }
            }
        }

        #endregion

        #region 获取推广员信息
        /// <summary>
        /// 写入推广员COOKIE到客户端
        /// </summary>
        protected UserInfo GetSpreadUserInfo()
        {
            //HttpCookie spreaduser = Request.Cookies[Game.WebV3.Constant.SpreadUserCookieKey];
            //if (spreaduser != null)
            //{
            //    int gameid = Convert.ToInt32(spreaduser.Values["gameid"]);
            //    var user = oAccountsFacade.GetUserFullInfoByGameID(gameid);
            //    if (user != null) return user;
            //}
            return null;
        }
        #endregion
    }
}
