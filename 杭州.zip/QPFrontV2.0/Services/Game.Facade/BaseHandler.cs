﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.SessionState;

namespace Game.Web
{
    public class BaseHandler : IHttpHandler, IRequiresSessionState
    {
        private object _responsePackage = null;
        public StringBuilder sbCache = null;

        protected void CallBackData(bool status, string message, object data)
        {
            Hashtable hashtable = new Hashtable();
            hashtable.Add("status", status);
            hashtable.Add("message", message);
            hashtable.Add("data", data);
            this.ResponsePackage = hashtable;
        }

        protected string GetParms(string key)
        {
            return HttpContext.Current.Request[key];
        }

        protected virtual void HandlerAuthorizationRequired()
        {
        }

        protected virtual void HandlerBegin()
        {
        }

        protected virtual void HandlerEnd()
        {
        }

        public virtual void ProcessRequest(HttpContext context)
        {
            HttpRequest request = context.Request;
            HttpResponse response = context.Response;
            string str = HttpContext.Current.Request["m"];
            try
            {
                this.HandlerBegin();
                if (string.IsNullOrEmpty(str)) throw new Exception("服务器不接受此次请求处理！");
                MethodInfo method = base.GetType().GetMethod(str);
                if (method == null) throw new Exception("服务器不接受此次请求处理！");
                object[] customAttributes = method.GetCustomAttributes(typeof(AjaxMethodAttribute), false);
                ParameterInfo[] infoArray = (from param in method.GetParameters()
                                             orderby param.Position
                                             select param).ToArray<ParameterInfo>();
                if (customAttributes.Length > 0)
                {
                    AjaxMethodAttribute attribute = (AjaxMethodAttribute)customAttributes[0];
                    if (attribute.AuthorizationRequired)
                    {
                        this.HandlerAuthorizationRequired();
                    }
                }
                object[] parameters = null;
                if (infoArray.Length > 0)
                {
                    StreamReader reader = new StreamReader(request.InputStream);
                    string json = reader.ReadToEnd();
                    reader.Dispose();
                    JObject obj2 = JsonEncoder.Deserialize(json) as JObject;
                    if (obj2 == null)
                    {
                        throw new Exception("参数格式不正确！");
                    }
                    List<object> list = new List<object>();
                    foreach (ParameterInfo info2 in infoArray)
                    {
                        JToken token;
                        if (!obj2.TryGetValue(info2.Name, out token))
                        {
                            throw new Exception("缺少参数！");
                        }
                        object item = JsonConvert.DeserializeObject(token.ToString(), info2.ParameterType);
                        list.Add(item);
                    }
                    parameters = list.ToArray();
                }
                method.Invoke(this, parameters);
                this.HandlerEnd();
            }
            catch (Exception exception)
            {
                //throw exception;
                Exception exp = (exception.InnerException != null) ? exception.InnerException : exception;
                Game.Library.Log.WriteLogInfo("handler", exp);
                this.CallBackData(false, exp.Message, -1);
            }
            finally
            {
                response.CacheControl = "no-cache";
                response.ContentEncoding = Encoding.Default;
                string s = JsonConvert.SerializeObject(this._responsePackage);
                response.ContentType = "application/json";
                response.Write(s);
                response.End();
            }
        }

        public void ResetCache()
        {
            if (this.sbCache == null)
            {
                this.sbCache = new StringBuilder();
            }
            else
            {
                this.sbCache.Length = 0;
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public object ResponsePackage
        {
            get
            {
                return this._responsePackage;
            }
            set
            {
                this._responsePackage = value;
            }
        }
    }

    public static class JsonEncoder
    {
        public static object Deserialize(string json)
        {
            return JsonConvert.DeserializeObject(json);
        }

        public static T Deserialize<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }

        public static string Serialize(object obj)
        {
            IsoDateTimeConverter converter = new IsoDateTimeConverter
            {
                DateTimeFormat = "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFK"
            };
            return JsonConvert.SerializeObject(obj, Formatting.None, new JsonConverter[] { converter });
        }

        public static string Serialize(object obj, bool javaScriptDate)
        {
            return JsonConvert.SerializeObject(obj, Formatting.None, new JsonConverter[] { new JavaScriptDateTimeConverter() });
        }
    }

    [AttributeUsage(AttributeTargets.Method)]
    public sealed class AjaxMethodAttribute : Attribute
    {
        public AjaxMethodAttribute()
        {
            this.AuthorizationRequired = false;
        }

        public bool AuthorizationRequired { get; set; }
    }
}
