﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

namespace Game.Web
{
    public class BaseUserControl : System.Web.UI.UserControl
    {
        /// <summary>
        /// 初始化类
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            //EnableViewState = false;
        }

        protected System.Text.StringBuilder sbCache = null;
        /// <summary>
        /// 临时缓存
        /// </summary>
        protected void ResetCache()
        {
            if (this.sbCache == null)
            {
                this.sbCache = new System.Text.StringBuilder();
            }
            else
            {
                this.sbCache.Length = 0;
            }
        }
    }
}