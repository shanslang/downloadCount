﻿
using Game.Entity.Accounts;
using Game.Facade;
using Game.Francis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Game.Web
{
    public sealed partial class GlobalParameter
    {
        #region 构造
        private GlobalParameter() { }

        /// <summary>
        /// 取得全局类的单实例。
        /// </summary>
        public static GlobalParameter Instance
        {
            get { return Nested.instance; }
        }

        /// <summary>
        /// 辅助实现单件模式的嵌套类。
        /// </summary>
        sealed class Nested
        {
            static Nested() { }
            internal static readonly GlobalParameter instance = new GlobalParameter();
        }
        #endregion

        #region 属性
        private AccountsFacade oAccountsFacade = new AccountsFacade();
        private IDictionary<int, UserInfo> onlineUsers = new Dictionary<int, UserInfo>();
        #endregion

        /// <summary>
        /// 获取当前登录用户
        /// </summary>
        public UserInfo CurrentLoginUser
        {
            get
            {
                UserInfo user = null;
                UserTicketInfo uti = Fetch.GetUserCookie();
                if (uti != null)
                {
                    int userid = Fetch.GetUserCookie().UserID;
                    user = oAccountsFacade.GetUserFullInfoByUserID(userid);
                    //if (onlineUsers.ContainsKey(userid))
                    //{
                    //    user = onlineUsers[userid];
                    //}
                    //else
                    //{
                    //    user = oAccountsFacade.GetUserFullInfoByUserID(userid);
                    //    if (onlineUsers.ContainsKey(user.UserID))
                    //    {
                    //        onlineUsers.Remove(user.UserID);
                    //    }
                    //    onlineUsers.Add(user.UserID, user);
                    //}
                }
                return user;
            }
        }

        #region 从缓存区移除用户
        ///// <summary>
        ///// 从缓存区移除用户
        ///// </summary>
        //public void RemoveUser()
        //{
        //    RemoveUser(CurrentLoginUser.UserID);
        //}
        ///// <summary>
        ///// 从缓存区移除用户
        ///// </summary>
        ///// <param name="pid"></param>
        //public void RemoveUser(int pid)
        //{
        //    if (onlineUsers.ContainsKey(pid))
        //    {
        //        onlineUsers.Remove(pid);
        //    }
        //}
        #endregion

        /// <summary>
        /// 判断指示是否登录成功
        /// </summary>
        public bool IsAuthenticated
        {
            get
            {
                return Fetch.IsUserOnline();
            }
        }

        /// <summary>
        /// 登出
        /// </summary>
        public UserInfo Logout()
        {
            if (this.IsAuthenticated)
            {
                var user = this.CurrentLoginUser;
                if (user != null)
                {
                    if (onlineUsers.ContainsKey(user.UserID))
                    {
                        onlineUsers.Remove(user.UserID);
                    }
                }
                Fetch.DeleteUserCookie();
                return user;
            }
            return null;
        }

        #region 登录
        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="loginName"></param>
        /// <param name="passWord"></param>
        /// <param name="checkCode"></param>
        /// <returns></returns>
        public UserInfo Login(string loginName, string passWord, string checkCode)
        {
            if (string.IsNullOrEmpty(checkCode)) throw new Exception("验证码不能为空.");
            //验证码错误
            if (!checkCode.Trim().Equals(Fetch.GetVerifyCode(), StringComparison.InvariantCultureIgnoreCase))
            {
                throw new Exception("抱歉！您输入的验证码错误了。");
            }
            var result = Login(loginName, passWord);
            return result;
        }

        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="loginName"></param>
        /// <param name="passWord"></param>
        /// <returns></returns>
        public UserInfo Login(string loginName, string passWord)
        {
            if (string.IsNullOrEmpty(loginName)) throw new Exception("用户名不能为空.");
            if (string.IsNullOrEmpty(passWord)) throw new Exception("密码不能为空.");
            UserInfo user = null;
            Message umsg = oAccountsFacade.Logon(loginName, passWord);
            if (umsg.Success)
            {
                user = umsg.EntityList[0] as UserInfo;
                Login(user.UserID);
            }
            else
            {
                throw new Exception(umsg.Content);
            }
            return user;
        }
        /// <summary>
        /// 登录方法
        /// </summary>
        /// <param name="userid"></param>
        public void Login(int userid)
        {
            UserInfo user = oAccountsFacade.GetUserFullInfoByUserID(userid);
            Fetch.SetUserCookie(user.ToUserTicketInfo());
            ////更新缓存
            //if (onlineUsers.ContainsKey(user.UserID))
            //{
            //    onlineUsers.Remove(user.UserID);
            //}
            ////添加缓存
            //onlineUsers.Add(user.UserID, user);
        }
        #endregion

        #region 验证码
        /// <summary>
        /// 验证码验证
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public string ValidationCode(string code)
        {
            string msgResult = string.Empty;
            System.Web.SessionState.HttpSessionState session = HttpContext.Current.Session;
            string strValidateCode = Fetch.GetVerifyCode();
            if (!code.Trim().Equals(strValidateCode, StringComparison.InvariantCultureIgnoreCase))
            {
                msgResult = "您输入的验证码错误或者已经过期了，请更换验证码！";
            }
            else
            {
                int count = 0;
                string strLastValidateCode = (string)session["LastValidateCode"];
                if (strLastValidateCode != strValidateCode)
                {
                    session["LastValidateCode"] = strValidateCode;
                }
                else
                {
                    count = Game.Utils.Utility.StrToInt(session["ValidateCount"], 0);
                }

                if (count >= 10)
                {
                    msgResult = "您输入的验证码错误或者已经过期了，请更换验证码！";
                }
                else
                {
                    count++;
                    session["ValidateCount"] = count;
                }
            }
            return msgResult;
        }
        #endregion

    }
}
