﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Security.Cryptography;

using Game.Entity.Accounts;
using Game.Entity.NativeWeb;
using Game.Utils;
using Game.Francis;
using Game.IData;

namespace Game.Facade
{
    public class BasePageMobile : System.Web.UI.Page
    {
        #region 构造函数
        /// <summary>
        /// 初始化页面基类
        /// </summary>
        public BasePageMobile()
        {
        }
        #endregion

        #region 页面事件
        /// <summary>
        /// 读取或初始化控件属性
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
        }
        /// <summary>
        /// 读取和更新控件属性
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
        }
        /// <summary>
        /// 对需要加载页上的所有其他控件的任务使用该事件
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoadComplete(EventArgs e)
        {
            base.OnLoadComplete(e);
        }
        #endregion

        #region 通用属性 for xujianbo
        public StringBuilder sbCache = null;
        /// <summary>
        /// 缓存
        /// </summary>
        public void ResetCache()
        {
            if (this.sbCache == null)
            {
                this.sbCache = new StringBuilder();
            }
            else
            {
                this.sbCache.Length = 0;
            }
        }
        #endregion

        #region 手机显示网页 实际尺寸
        /// <summary>
        /// 手机宽度
        /// </summary>
        public float MWidth
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryFloat("mwidth", 0);
            }
        }
        /// <summary>
        /// 手机宽度
        /// </summary>
        public float MHeight
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryFloat("mheight", 0);
            }
        }
        #endregion
    }
}
