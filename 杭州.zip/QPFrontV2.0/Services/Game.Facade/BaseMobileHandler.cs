﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.SessionState;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using Game.Facade;
using Game.Entity.Accounts;
using Game.Facade.Facade;
using System.Drawing;
using System.Drawing.Imaging;
using System.Security.Cryptography;
using Game.Type;
using System.Text.RegularExpressions;

namespace Game.Web
{
    public class BaseMobileHandler : IHttpHandler, IRequiresSessionState
    {
        #region 公共属性
        protected TreasureFacade oTreasureFacade = new TreasureFacade();
        protected AccountsFacade oAccountsFacade = new AccountsFacade();
        protected NativeWebFacade oNativeWebFacade = new NativeWebFacade();
        protected GamePropertyFacade oGamePropertyFacade = new GamePropertyFacade();
        protected PlatformFacade oPlatformFacade = new PlatformFacade();
        protected MobileAppFacade oMobileAppFacade = new MobileAppFacade();
        protected TaskFacade oTaskFacade = new TaskFacade();
        protected QPMatchFacade oMatchFacade = new QPMatchFacade();
        protected static List<string> sandboxOrderList = new List<string>();
        public StringBuilder sbCache = null;
        public void ResetCache()
        {
            if (this.sbCache == null)
            {
                this.sbCache = new StringBuilder();
            }
            else
            {
                this.sbCache.Length = 0;
            }
        }
        public string GetstringValue(Dictionary<string, object> dic, string key)
        {
            object _value = "";
            if (dic != null && dic.ContainsKey(key))
            {
                dic.TryGetValue(key, out _value);
            }
            if (_value == null)
            {
                return "";
            }
            return _value.ToString();
        }
        public int GetIntValue(Dictionary<string, object> dic, string key)
        {
            object _value = 0;
            if (dic != null && dic.ContainsKey(key))
            {
                dic.TryGetValue(key, out _value);
            }
            if (_value == null)
            {
                return 0;
            }
            return Convert.ToInt32(_value);
        }
        public int GetIntValue(Dictionary<string, object> dic, string key, int defaultvalue)
        {
            object _value = defaultvalue;
            if (dic != null && dic.ContainsKey(key))
            {
                dic.TryGetValue(key, out _value);
            }
            if (_value == null)
            {
                return defaultvalue;
            }
            return Convert.ToInt32(_value);
        }
        public string FiterWeiXin(string name)
        {
            var temp = name.ToCharArray();
            StringBuilder sb = new StringBuilder(name);
            for (int i = 0; i < name.Length; i++)
            {
                if (temp[i] >= 0x4e00 && temp[i] <= 0x9fa5)
                {
                    continue;
                }
                if (temp[i] >= 'a' && temp[i] <= 'z')
                {
                    continue;
                }
                if (temp[i] >= 'A' && temp[i] <= 'Z')
                {
                    continue;
                }
                if (temp[i] >= '0' && temp[i] <= '9')
                {
                    continue;
                }
                if (temp[i] == '?')
                {
                    continue;
                }
                sb = sb.Replace(temp[i], '?');
            }
            if (sb.Length > 31)
            {
                return sb.ToString().Substring(0, 31);
            }
            return sb.ToString();
        }
        /// <summary>
        /// 请求命令
        /// </summary>
        public string RequestCMD { set; get; }

        /// <summary>
        /// 随机一个字母
        /// </summary>
        public string RdmLtter
        {
            get
            {
                string[] Ltterlist = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z".Split(',');
                Random rdm = new Random();
                return Ltterlist[rdm.Next(0, Ltterlist.Length)];
            }
        }

        /// <summary>
        /// 随机数字(5位数)
        /// </summary>
        public int RdmNum
        {
            get
            {
                Random rdm = new Random();
                return rdm.Next(10000, 99999);
            }
        }
        /// <summary>
        /// 随机9位数
        /// </summary>
        public int RdmNum9
        {
            get
            {
                Random rdm = new Random();
                return rdm.Next(100000000, 999999999);
            }
        }
        /// <summary>
        /// 域名
        /// </summary>
        public string hostaddress
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["AppHosturl"].ToString();
            }
        }
        /// <summary>
        /// 处理二进制图片
        /// </summary>
        /// <param name="saveurl"></param>
        /// <param name="binarydata"></param>
        /// <param name="datalenth"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        protected void BinaryPicFormat(string saveurl, byte[] binarydata, int datalenth, int width, int height)
        {
            HttpContext contenxt = HttpContext.Current;

            System.IO.MemoryStream ms = new System.IO.MemoryStream(binarydata);
            System.Drawing.Image img = System.Drawing.Image.FromStream(ms);
            img.Save(saveurl);


            try
            {
                //byte[] bytes = new byte[datalenth];
                //for (int i = 0; i < datalenth / 4; i++)
                //{
                //    bytes[i * 4 + 0] = binarydata[i * 4 + 0];
                //    bytes[i * 4 + 1] = binarydata[i * 4 + 1];
                //    bytes[i * 4 + 2] = binarydata[i * 4 + 2];
                //    bytes[i * 4 + 3] = 0xff;
                //}

                //BitmapData bmpData = bmp.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
                //IntPtr ptr = bmpData.Scan0;
                //System.Runtime.InteropServices.Marshal.Copy(bytes, 0, ptr, width * height * 4);
                //bmp.UnlockBits(bmpData);
                //bmp.Save(saveurl, System.Drawing.Imaging.ImageFormat.Bmp);
                //bmp.Dispose();

            }
            catch (Exception)
            {

            }
            finally
            {
                ms.Dispose();
                img.Dispose();
            }
        }
        public string GetFilename(string filePath)
        {
            try
            {
                if (filePath.Length > 0 && filePath.Contains('/'))
                {
                    int index = filePath.LastIndexOf('/') + 1;
                    int lenth = filePath.Length - index;
                    string filename = filePath.Substring(index, lenth);
                    return filename;
                }
                return "";
            }
            catch (Exception)
            {
                throw new Exception("获取文件名称失败！");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string LoadFileMD5(string filepath)
        {
            try
            {
                if (File.Exists(filepath))
                {
                    FileStream file = new FileStream(filepath, System.IO.FileMode.Open);
                    MD5 md5 = new MD5CryptoServiceProvider();
                    byte[] retVal = md5.ComputeHash(file);
                    file.Close();
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < retVal.Length; i++)
                    {
                        sb.Append(retVal[i].ToString("x2"));
                    }
                    return sb.ToString();
                }
                return "";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        /// <summary>
        /// 如果 IHttpHandler 实例可再次使用，则为 true；否则为 false。
        /// </summary>
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// 返回数据格式 
        /// </summary>
        private BaseMobileHandlerResponseFormat _ResponseDataFormat = BaseMobileHandlerResponseFormat.JSONObject;
        public BaseMobileHandlerResponseFormat ResponseDataFormat
        {
            get { return _ResponseDataFormat; }
            set { _ResponseDataFormat = value; }
        }

        /// <summary>
        /// 返回数据包对象
        /// </summary>
        private object _ResponsePackage = null;
        public object ResponsePackage
        {
            get
            {
                return this._ResponsePackage;
            }
            set
            {
                this._ResponsePackage = value;
            }
        }
        #endregion

        #region 公共方法
        /// <summary>
        /// 设置发送数据包
        /// </summary>
        /// <param name="status"></param>
        /// <param name="message"></param>
        /// <param name="data"></param>
        protected void SetResponseData(BaseMobileHandlerResponseFormat responseformat, object data)
        {
            this.ResponseDataFormat = responseformat;
            this.ResponsePackage = data;
        }
        /// <summary>
        /// 设置发送数据包 JSON对象格式专用
        /// </summary>
        /// <param name="status">状态</param>
        /// <param name="message">消息</param>
        /// <param name="sign">数据包签名</param>
        /// <param name="data">数据包</param>
        protected void SetResponseData(bool status, string message, string sign, int cmd, object data)
        {
            this.ResponseDataFormat = BaseMobileHandlerResponseFormat.JSONObject;
            Hashtable hashtable = new Hashtable();
            hashtable.Add("cmd", cmd);
            hashtable.Add("sign", sign);
            hashtable.Add("status", status);
            hashtable.Add("message", message);
            hashtable.Add("data", data);
            this.ResponsePackage = hashtable;
        }

        /// <summary>
        /// 获取Form参数
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        protected string GetFormParam(string key)
        {
            return HttpContext.Current.Request.Form[key];
        }
        /// <summary>
        /// 获取GET参数
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        protected string GetQueryStringParam(string key)
        {
            return HttpContext.Current.Request.QueryString[key];
        }
        /// <summary>
        /// 身份验证执行
        /// </summary>
        protected virtual void HandlerAuthorizationRequired()
        {
        }
        /// <summary>
        /// 请求开始执行
        /// </summary>
        protected virtual void HandlerBegin()
        {
        }
        /// <summary>
        /// 请求结束执行
        /// </summary>
        protected virtual void HandlerEnd()
        {
        }
        #endregion

        #region 公共逻辑方法
        /// <summary>
        /// 验证用户
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        protected UserInfo ValidateUser(int userid)
        {
            //验证用户信息
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            if (oUserInfo == null) throw new Exception("用户无效！");
            //返回用户信息
            return oUserInfo;
        }

        /// <summary>
        /// 验证签名(棱镜支付回调)
        /// </summary>
        /// <param name="sign"></param>
        /// <param name="requestdata"></param>
        protected bool ValidateSign(string sign, List<object> requestdatalist, string keyLJ)
        {
            if (requestdatalist == null) return false;
            ResetCache();
            foreach (object item in requestdatalist) { sbCache.Append(item); }
            string signserver = Game.Utils.TextEncrypt.MD5EncryptPassword(sbCache.ToString() + keyLJ);
            if (sign.ToLower() != signserver.ToLower()) return false;
            return true;
        }
        /// <summary>
        /// 验证签名(未登陆)
        /// </summary>
        /// <param name="sign"></param>
        /// <param name="requestdata"></param>
        protected void ValidateSign(string sign, string requestdata)
        {
            string signserver = Game.Utils.TextEncrypt.MD5EncryptPassword(Constant.MobileSignKey + requestdata);
            if (sign.ToLower() != signserver.ToLower()) throw new Exception("验证签名无效！");
        }
        /// <summary>
        /// 验证签名(已登陆)
        /// </summary>
        /// <param name="devicetype">设备类型 1=PC 2=IOS 3=Android</param>
        /// <param name="userid">用户UserID</param>
        /// <param name="sign">客户端签名</param>
        /// <param name="requestdata">客户端发送数据包</param>
        /// <returns></returns>
        protected UserInfo ValidateSign(byte devicetype, int userid, string sign, string requestdata)
        {
            //验证用户信息
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            if (oUserInfo == null) throw new Exception("用户无效！");
            //验证签名
            string md5key = null;
            switch (devicetype)
            {
                case (int)Game.Type.DeviceType.IOS:
                    {
                        md5key = oUserInfo.IOSWebKey;
                        break;
                    }
                case (int)Game.Type.DeviceType.Android:
                    {
                        md5key = oUserInfo.AndroidWebKey;
                        break;
                    }
                case (int)Game.Type.DeviceType.PC:
                    {
                        md5key = oUserInfo.PCWebKey;
                        break;
                    }
            }
            if (md5key == null) throw new Exception("设备类型无效！");
            string signserver = Game.Utils.TextEncrypt.MD5EncryptPassword(md5key + requestdata);
            if (sign.ToLower() != signserver.ToLower()) throw new Exception("验证签名无效！");
            return oUserInfo;
        }
        /// <summary>
        /// 验证签名(已登陆)
        /// </summary>
        /// <param name="devicetype">设备类型  0x00=PC 0x40=IOS 0x10=Android</param>
        /// <param name="userid">用户UserID</param>
        /// <param name="sign">客户端签名</param>
        /// <param name="requestdata">客户端发送数据包</param>
        /// <returns></returns>
        protected UserInfo ValidateSign(int devicetype, int userid, string sign, string requestdata)
        {
            //验证用户信息
            UserInfo oUserInfo = UserManager.instance.Get(userid);
            if (oUserInfo != null)
            {
                if (ValidateSign(oUserInfo, devicetype, userid, sign, requestdata))//通过缓存用户信息验证签名，验证不通过从服务器获取一次用户信息
                {
                    return oUserInfo;
                }
            }//如果缓存中不存在，或者验证签名不通过，则从新从数据库获取数据后验证(登录服务器时key会刷新，网站不知道用户是否从新登录)
            oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            UserManager.instance.Insert(oUserInfo, 10);
            if (!ValidateSign(oUserInfo, devicetype, userid, sign, requestdata))
            {
                throw new Exception("验证签名无效！");
            }
            return oUserInfo;
        }

        bool ValidateSign(UserInfo oUserInfo, int devicetype, int userid, string sign, string requestdata)
        {
            if (oUserInfo == null) throw new Exception("用户无效！");
            //验证签名
            string md5key = null;
            if (devicetype == (int)SigninEquipment.PCSignIn) { md5key = oUserInfo.PCWebKey; };
            if (devicetype != (int)SigninEquipment.PCSignIn) { md5key = oUserInfo.IOSWebKey; };

            if (md5key == null) throw new Exception("设备类型无效！");
            string signserver = Game.Utils.TextEncrypt.MD5EncryptPassword(md5key + requestdata);

            return sign.ToLower() == signserver.ToLower();
        }

        /// <summary>
        /// 返回签名(未登陆)
        /// </summary>
        /// <param name="sign"></param>
        /// <param name="requestdata"></param>
        protected string ValidateResponseKey(object data)
        {
            data = Newtonsoft.Json.JsonConvert.SerializeObject(data);
            return Game.Utils.TextEncrypt.MD5EncryptPassword(Constant.MobileSignKey + data.ToString());
        }
        /// <summary>
        /// 联通签名验证
        /// </summary>
        /// <param name="sign"></param>
        /// <param name="requestdata"></param>
        protected string ValidateResponseKey(Game.Entity.MobileApp.callbackReq data)
        {
            string str = string.Format("orderid={0}&ordertime={1}&cpid={2}&appid={3}&fid={4}&consumeCode={5}&payfee={6}&payType={7}&hRet={8}&status={9}&Key=",
                                  data.orderid, data.ordertime, data.cpid, data.appid, data.fid, data.consumeCode, data.payfee, data.payType, data.hRet, data.status);
            return Game.Utils.TextEncrypt.MD5EncryptPassword(str + Constant.LTSignKey);
        }
        /// <summary>
        /// 联通订单校验验证
        /// </summary>
        /// <param name="sign"></param>
        /// <param name="requestdata"></param>
        protected string ValidateResponseKey(Game.Entity.MobileApp.checkOrderIdReq data)
        {
            string str = string.Format("orderid={0}&Key=", data.orderid);
            return Game.Utils.TextEncrypt.MD5EncryptPassword(str + Constant.LTSignKey);
        }
        /// <summary>
        /// 返回签名(已登陆)
        /// </summary>
        /// <param name="devicetype">SigninEquipment</param>
        /// <param name="userid"></param>
        /// <param name="responsedata"></param>
        /// <returns></returns>
        protected string ValidateResponseKey(int devicetype, int userid, object responsedata)
        {
            UserInfo oUserInfo = UserManager.instance.Get(userid);
            if (oUserInfo == null)
            {
                oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            }
            //UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            if (oUserInfo == null) throw new Exception("用户无效！");
            //验证签名
            string md5key = null;
            if (devicetype == (int)SigninEquipment.PCSignIn) { md5key = oUserInfo.PCWebKey; };
            if (devicetype != (int)SigninEquipment.PCSignIn) { md5key = oUserInfo.IOSWebKey; };
            //switch (devicetype)
            //{
            //    case (int)SigninEquipment.IPhoneSignIn:
            //        md5key = oUserInfo.IOSWebKey;
            //        break;
            //    case (int)SigninEquipment.AndroidSignIn:
            //        md5key = oUserInfo.AndroidWebKey;
            //        break;
            //    case (int)SigninEquipment.PCSignIn:
            //        md5key = oUserInfo.PCWebKey;
            //        break;
            //}
            if (md5key == null) throw new Exception("设备类型无效！");
            responsedata = Newtonsoft.Json.JsonConvert.SerializeObject(responsedata);
            return Game.Utils.TextEncrypt.MD5EncryptPassword(md5key + responsedata);
        }
        #endregion

        #region ProcessRequest
        /// <summary>
        /// 基础请求
        /// </summary>
        /// <param name="context"></param>
        public virtual void ProcessRequest(HttpContext context)
        {
#if DEBUG

            Game.Library.Log.WriteLogInfo("BaseMobileHandler", new Exception(HttpContext.Current.Request.Url.ToString()));
#endif

            HttpRequest request = context.Request;
            HttpResponse response = context.Response;
            this.RequestCMD = HttpContext.Current.Request["m"];
            try
            {
                this.HandlerBegin();//开始执行

                //通过命令获取执行方法
                MethodInfo method = null;
                MethodInfo[] aryMethodInfo = base.GetType().GetMethods();
                foreach (var item in aryMethodInfo)
                {
                    object[] customAttributes = item.GetCustomAttributes(typeof(MobileMethodAttribute), false);
                    if (customAttributes.Length <= 0) continue;
                    MobileMethodAttribute attribute = (MobileMethodAttribute)customAttributes[0];
                    if (attribute.RequestCMD == this.RequestCMD)
                    {
                        method = item;
                        break;
                    }
                }
                if (method == null) throw new Exception("服务器不接受此次请求处理！");

                //方法特性
                object[] methodAttributes = method.GetCustomAttributes(typeof(MobileMethodAttribute), false);
                if (methodAttributes.Length > 0)
                {
                    MobileMethodAttribute attribute = (MobileMethodAttribute)methodAttributes[0];
                    if (attribute.AuthorizationRequired)
                    {
                        this.HandlerAuthorizationRequired();
                    }
                }


                ParameterInfo[] infoArray = (from param in method.GetParameters() orderby param.Position select param).ToArray<ParameterInfo>();
                object[] parameters = null;
                if (infoArray.Length > 0)
                {
                    List<object> list = new List<object>();
                    bool ispost = false;
                    //获取方法POST参数
                    if (request.InputStream != null && this.RequestCMD != "1049")
                    {
                        StreamReader reader = new StreamReader(request.InputStream);
                        string json = reader.ReadToEnd();
                        reader.Dispose();
                        if (json != null && json.Trim().Length > 0)
                        {
                            if (infoArray.Length == 1 && infoArray[0].Name == "postString")
                            {
                                // object item = JsonConvert.DeserializeObject(json, infoArray[0].ParameterType);
                                list.Add(json);
                            }
                            else
                            {
                                JObject obj2 = JsonEncoder.Deserialize(json) as JObject;
                                if (obj2 == null) throw new Exception("参数格式不正确！");
                                foreach (ParameterInfo info2 in infoArray)
                                {
                                    JToken token;
                                    if (!obj2.TryGetValue(info2.Name, out token)) throw new Exception("缺少参数！");
                                    object item = JsonConvert.DeserializeObject(token.ToString(), info2.ParameterType);
                                    list.Add(item);
                                }
                            }
                            ispost = true;
                        }
                    }

                    if (ispost == false)
                    {
                        //获取方法GET参数
                        foreach (ParameterInfo info2 in infoArray)
                        {
                            if (request.QueryString[info2.Name] == null) throw new Exception("缺少参数！");
                            // object item = JsonConvert.DeserializeObject(request.QueryString[info2.Name], info2.ParameterType);
                            list.Add(request.QueryString[info2.Name]);
                        }
                    }
                    parameters = list.ToArray();
                }


                //执行方法
                method.Invoke(this, parameters);

                //结束执行
                this.HandlerEnd();
            }
            catch (Exception exception)
            {
                Exception exp = (exception.InnerException != null) ? exception.InnerException : exception;
                Game.Library.Log.WriteLogInfo("BaseMobileHandler", exp);
                this.ResponseDataFormat = BaseMobileHandlerResponseFormat.JSONObject;
                // this.SetResponseData(false, "出现异常，请联系管理员", null, 0, null);
                this.SetResponseData(false, exp.Message, null, 0, null);
            }
            finally
            {
                response.Clear();
                response.CacheControl = "no-cache";
                response.ContentEncoding = Encoding.UTF8;
                response.AddHeader("Access-Control-Allow-Origin", "*");
                switch (this.ResponseDataFormat)
                {
                    case BaseMobileHandlerResponseFormat.JSON:
                        {
                            response.ContentType = "application/json";
                            response.Write(this.ResponsePackage);
                            break;
                        }
                    case BaseMobileHandlerResponseFormat.JSONObject:
                        {
                            response.ContentType = "application/json";
                            IsoDateTimeConverter timeConverter = new IsoDateTimeConverter();
                            //这里使用自定义日期格式，如果不使用的话，默认是ISO8601格式
                            timeConverter.DateTimeFormat = "yyyy-MM-dd HH:mm:ss:ffff";
                            string json = JsonConvert.SerializeObject(this.ResponsePackage, timeConverter);
                            response.Write(json);
                            break;
                        }
                    case BaseMobileHandlerResponseFormat.XML:
                        {
                            response.ContentType = "application/xml";
                            response.Write(this.ResponsePackage);
                            break;
                        }
                    case BaseMobileHandlerResponseFormat.Binary:
                        {
                            response.ContentType = "application/octet-stream";
                            response.BinaryWrite((this.ResponsePackage as byte[]));
                            break;
                        }
                    case BaseMobileHandlerResponseFormat.Text:
                        {
                            response.Write(this.ResponsePackage);
                            break;
                        }
                }
                response.End();
            }
        }
        #endregion
    }

    /// <summary>
    /// 方法属性
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class MobileMethodAttribute : Attribute
    {
        public MobileMethodAttribute()
        {
            this.AuthorizationRequired = false;
            this.RequestCMD = null;
        }
        public bool AuthorizationRequired { get; set; }
        public string RequestCMD { get; set; }
    }
    /// <summary>
    /// 返回数据格式
    /// </summary>
    public enum BaseMobileHandlerResponseFormat
    {
        JSON = 1,
        JSONObject = 2,
        XML = 3,
        Binary = 4,
        Text = 5,
    }

    /// <summary>
    /// 公告信息
    /// </summary>
    public class NoticInfo
    {
        /// <summary>
        /// 游戏ID
        /// </summary>
        public int KindID { set; get; }
        /// <summary>
        /// 公告图片
        /// </summary>
        public string NoticPic { set; get; }
        /// <summary>
        /// 公告版本
        /// </summary>
        public string NoticVersion { set; get; }
    }
}
