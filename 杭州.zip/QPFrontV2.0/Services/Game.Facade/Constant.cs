﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace Game.Web
{
    /// <summary>
    /// 常量类
    /// </summary>
    public static partial class Constant
    {
        #region 网站域名根
        /// <summary>
        /// 网站域名根
        /// </summary>
        public static string SiteDomain
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["SiteDomain"].ToString();
            }
        }
        #endregion

        #region 网站基础配置
        /// <summary>
        /// 网站全称
        /// </summary>
        public static string SiteFullName
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["SiteFullName"].ToString();
            }
        }

        /// <summary>
        /// 网站后缀
        /// </summary>
        public static string SiteFullSuffix
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["SiteFullSuffix"].ToString();
            }
        }

        /// <summary>
        /// 网站关键字
        /// </summary>
        public static string MetaKeywords
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["MetaKeywords"].ToString();
            }
        }

        /// <summary>
        /// 网站描述
        /// </summary>
        public static string MetaDescription
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["MetaDescription"].ToString();
            }
        }
        #endregion

        #region 凌凯短信
        /// <summary>
        /// 用户名
        /// </summary>
        public static string LKSMSAccount
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["LKSMSAccount"].ToString();
            }
        }
        /// <summary>
        /// 密码
        /// </summary>
        public static string LKSMSPass
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["LKSMSPass"].ToString();
            }
        }
        /// <summary>
        /// 签名
        /// </summary>
        public static string LKSMSSign
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["LKSMSSign"].ToString();
            }
        }
        #endregion

        #region 凌凯短信（验证码）
        /// <summary>
        /// 用户名
        /// </summary>
        public static string LKSMSYZMAccount
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["LKSMSYZMAccount"].ToString();
            }
        }
        /// <summary>
        /// 密码
        /// </summary>
        public static string LKSMSYZMPass
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["LKSMSYZMPass"].ToString();
            }
        }
        /// <summary>
        /// 签名
        /// </summary>
        public static string LKSMSYZMSign
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["LKSMSYZMSign"].ToString();
            }
        }
        #endregion

        #region 易维万德短信
        /// <summary>
        /// 用户名
        /// </summary>
        public static string YWWDAccount
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["YWWDAccount"].ToString();
            }
        }
        /// <summary>
        /// 密码
        /// </summary>
        public static string YWWDPass
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["YWWDPass"].ToString();
            }
        }
        /// <summary>
        /// 签名
        /// </summary>
        public static string YWWDSign
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["YWWDSign"].ToString();
            }
        }
        #endregion

        #region 系统邮箱发送
        /// <summary>
        /// 邮件服务器地址
        /// </summary>
        public static string SYSMailServer
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["SYSMailServer"].ToString();
            }
        }
        /// <summary>
        /// 发送人邮件地址
        /// </summary>
        public static string SYSSendfromMailAddress
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["SYSSendfromMailAddress"].ToString();
            }
        }
        /// <summary>
        /// 发送人邮件密码
        /// </summary>
        public static string SYSSendfromMailPassWord
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["SYSSendfromMailPassWord"].ToString();
            }
        }
        #endregion

        #region 客户端统一版本号
        /// <summary>
        /// 客户端统一版本号
        /// </summary>
        public static string ClientVersion
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["ClientVersion"].ToString();
            }
        }
        #endregion

        #region 客户端文件
        /// <summary>
        /// 客户端统一路径
        /// </summary>
        public static string ClientFilePath
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["ClientFilePath"].ToString();
            }
        }
        #endregion

        #region 论坛管理员
        /// <summary>
        /// 论坛管理员账号
        /// </summary>
        public static IList<string> BBSManagerAccounts
        {
            get
            {
                IList<string> result = new List<string>();
                string[] aryaccounts = System.Configuration.ConfigurationManager.AppSettings["BBSManagerAccounts"].Split(new char[] { ',', '|' });
                foreach (string item in aryaccounts)
                {
                    if (!string.IsNullOrEmpty(item)) result.Add(item);
                }
                return result;
            }
        }
        #endregion

        #region 常用KEY
        /// <summary>
        /// 推广员CookieKey
        /// </summary>
        public static string SpreadUserCookieKey
        {
            get
            {
                return "SPREADUSERINFO";
            }
        }
        #endregion

        #region 协调服务器配置
        /// <summary>
        /// 协调服务器IP地址
        /// </summary>
        public static string CoordinationServerIP
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["CoordinationServerIP"];
            }
        }
        /// <summary>
        /// 协调服务器端口号
        /// </summary>
        public static uint CoordinationServerPort
        {
            get
            {
                return Convert.ToUInt32(System.Configuration.ConfigurationManager.AppSettings["CoordinationServerPort"]);
            }
        }
        #endregion

        #region 移动端验证签名KEY

        /// <summary>
        /// 移动端验证签名KEY
        /// </summary>
        public static string MobileSignKey
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["MobileSignKey"];
            }
        }
        #endregion

        #region 联通验证签名KEY

        /// <summary>
        ///联通验证签名KEY
        /// </summary>
        public static string LTSignKey
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["LTSignKey"];
            }
        }
        #endregion

        #region 百度sdk血流appid
        public static string BDAppidXL
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["BDAppidXL"];
            }
        }
        public static string BDSecretkeyXL
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["BDSecretkeyXL"];
            }
        }
        #endregion
        #region 百度sdk扎金花appid
        public static string BDAppidZJH
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["BDAppidZJH"];
            }
        }
        public static string BDSecretkeyZJH
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["BDSecretkeyZJH"];
            }
        }
        #endregion
        #region 百度sdk牛牛appid
        public static string BDAppidNN
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["BDAppidNN"];
            }
        }
        public static string BDSecretkeyNN
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["BDSecretkeyNN"];
            }
        }
        #endregion

        #region 互联星空
        public static string VnetSPID
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["VnetSPID"];
            }
        }
        public static string VnetServiceID
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["VnetServiceID"];
            }
        }
        #endregion
    }
}
