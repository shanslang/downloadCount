﻿using Game.IData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Practices.Unity;
using Game.Entity.MobileApp;
using System.Data;
using Game.Francis;
using Game.Type;


namespace Game.Facade.Facade
{
    public class MobileAppFacade
    {
        #region Fields

        private IMobileAppDataProvider mobileAppData;

        #endregion

        #region 构造函数

        /// <summary>
        /// 构造函数
        /// </summary>
        public MobileAppFacade()
        {
            mobileAppData = Game.Web.DataInit.GetUnityContainer().Resolve<IMobileAppDataProvider>();
        }
        #endregion

        /// <summary>
        /// 获取登陆服务器地址
        /// </summary>
        /// <returns></returns>
        public IList<AppServerAddressCFG> GetLogonServerAddress(int versionid, int userid)
        {
            return mobileAppData.GetLogonServerAddress(versionid, userid);
        }

        /// <summary>
        /// 获取接口访问地址
        /// </summary>
        /// <returns></returns>
        public AppVisitAddressCFG GetAppVisitAddress(int versionid)
        {
            return mobileAppData.GetAppVisitAddress(versionid);
        }

        /// <summary>
        /// 获取app游戏渠道配置
        /// </summary> 
        public DataSet GetGameAppUrlCFG(int gameID, int chanelID, int userId)
        {
            return mobileAppData.GetGameAppUrlCFG(gameID, chanelID, userId);
        }

        /// <summary>
        /// 新增手游戏渠道配置
        /// </summary> 
        public void AddGameAppUrlCFG(string GameID, string ChanelID, string AppURL, string EngineVersion, string Description, string UpdateInFo, string ApkMD5)
        {
            mobileAppData.AddGameAppUrlCFG(GameID, ChanelID, AppURL, EngineVersion, Description, UpdateInFo, ApkMD5);
        }

        /// <summary>
        /// 获取游戏下载地址(IOS AppID)
        /// </summary>
        /// <param name="SerType"></param>
        /// <returns></returns>
        public GameAppIDInfo APPIDInfoGet(AppSerType SerType)
        {
            GameAppIDInfo appinfo = mobileAppData.APPIDInfoGet(SerType);
            if (appinfo == null || appinfo.Pid == 0)
            {
                appinfo = new GameAppIDInfo();
                appinfo.Andorid = "";
                appinfo.APPID = "";
                appinfo.SerType = 0;
            }
            return appinfo;
        }
        /// <summary>
        ///获取游戏场次数据
        /// </summary>
        /// <returns></returns>
        public IList<GameScreenings> GameScreeningsList(string wherecase, string orderbywhere)
        {
            return mobileAppData.GameScreeningsList(wherecase, orderbywhere);
        }
        /// <summary>
        /// 游戏场次信息房间数据
        /// </summary>
        /// <param name="ScreenID"></param>
        /// <returns></returns>
        public IList<GameScreeningsSerCFG> GameScreenServerList(int ScreenID)
        {
            return mobileAppData.GameScreenServerList(ScreenID);
        }
        /// <summary>
        /// 获取更多游戏数据信息
        /// </summary>
        /// <param name="whereCase"></param>
        /// <returns></returns>
        public DataSet MoreGameList(string whereCase, int UserID)
        {
            return mobileAppData.MoreGameList(whereCase, UserID);
        }
        /// <summary>
        /// 获取公告配置信息
        /// </summary>
        /// <returns></returns>
        public NoticeCFG AppNoticeInfo()
        {
            return mobileAppData.AppNoticeCFGInfo();
        }
        /// <summary>
        /// 最近一次获奖记录
        /// </summary>
        /// <returns></returns>
        public string AppNoticeReword()
        {
            return mobileAppData.AppNoticeReword();
        }
        /// <summary>
        /// 获取公告列表
        /// </summary>
        /// <param name="wherecase"></param>
        /// <returns></returns>
        public DataSet NoticeList(string wherecase)
        {
            return mobileAppData.NoticeList(wherecase);
        }
        /// <summary>
        /// 获取某个用户的排名名次
        /// </summary>
        /// <param name="Userid"></param>
        /// <returns></returns>
        public DataSet RakingDataByUser(int Userid)
        {
            return mobileAppData.RakingDataByUser(Userid);
        }
        /// <summary>
        /// 财富榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingScoreDataList(int RankCounts)
        {
            return mobileAppData.RakingScoreDataList(RankCounts);
        }

        /// <summary>
        /// 战绩榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingRecordDataList(int RankCounts)
        {
            return mobileAppData.RakingRecordDataList(RankCounts);
        }
        /// <summary>
        /// 魅力榜
        /// </summary>
        /// <param name="RankCounts"></param>
        /// <returns></returns>
        public DataSet RakingLoveLinessDataList(int RankCounts)
        {
            return mobileAppData.RakingLoveLinessDataList(RankCounts);
        }
        /// <summary>
        /// 游戏下载奖励信息
        /// </summary>
        /// <param name="Gameid"></param>
        /// <returns></returns>
        public GameDownloadReward GetDownloadReward(int Gameid)
        {
            return mobileAppData.GetDownloadReward(Gameid);
        }
        /// <summary>
        /// 领取奖励(更多游戏下载)
        /// </summary>
        /// <param name="RewardID"></param>
        /// <returns></returns>
        public Message MoreGameReward(int GameID, int UserID)
        {
            Message msg = mobileAppData.MoreGameReward(GameID, UserID);
            DataTable dt = new DataTable();
            Message rtmsg = new Message();
            if (msg.Success)
            {
                dt = (msg.EntityList[0] as DataSet).Tables[0];
                rtmsg.ReturnValue = Convert.ToInt32(dt.Rows[0]["RewardValue"]);
                if (dt.Rows[0]["RewardType"].ToString() == "1")   //金币变动
                {
                    try
                    {
                        int GoldKey = Convert.ToInt32(dt.Rows[0]["GoldKey"]);
                        Game.Web.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, UserID, GoldKey);
                        Game.Web.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, UserID, 1);
                    }
                    catch (Exception ex)
                    {
                        Game.Library.Log.WriteLogInfo("MoreGameReward", new Exception("奖励金币数据同步异常 " + "  " + ex));
                    }

                }
            }
            rtmsg.Success = msg.Success;
            rtmsg.Content = msg.Content;

            return rtmsg;
        }
        #region 商城
        /// <summary>
        /// 获取商城数据
        /// </summary>
        /// <param name="wherecase"></param>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public DataSet AppProductList(string wherecase, string orderbywhere)
        {
            return mobileAppData.AppProductList(wherecase, orderbywhere);
        }

        /// <summary>
        /// 购买记录
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="identifier"></param>
        /// <param name="orderid"></param>
        public void AppInsertAppBuyHistoty(int userid, string identifier, string orderid)
        {
            mobileAppData.AppInsertAppBuyHistoty(userid, identifier, orderid);
        }
        /// <summary>
        /// 是否已经购买过只能购买一次的产品
        /// </summary>
        /// <returns></returns>
        public bool RtRepeatBuy(int userID, string Identifier)
        {
            return mobileAppData.RtRepeatBuy(userID, Identifier);
        }
        #endregion

        #region 比赛
        /// <summary>
        /// 获取比赛奖励信息
        /// </summary>
        /// <param name="Matchid"></param>
        /// <param name="Roundid"></param>
        /// <returns></returns>
        public IList<Modulehelp> AppLoadMatchReward(int Matchid, int Roundid)
        {
            return mobileAppData.AppLoadMatchReward(Matchid, Roundid);
        }
        /// <summary>
        /// 获取比赛信息(手游获取指定字段信息)
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public Message GetMobileMatchInfo(int matchid, int roundid)
        {
            return mobileAppData.GetMobileMatchInfo(matchid, roundid);
        }
        /// <summary>
        /// 获取比赛组信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        public DataSet GetMobileGroupInfo(int kindID)
        {
            return mobileAppData.GetMobileGroupInfo(kindID);
        }
        /// <summary>
        /// 获取多个房间准入金币信息
        /// </summary>
        /// <param name="wherecase"></param>
        /// <returns></returns>
        public DataSet GameScreenServerList(string wherecase)
        {
            return mobileAppData.GameScreenServerList(wherecase);
        }
        #endregion

        /// <summary>
        /// 录入渠道注册信息
        /// </summary> 
        public void InsertChannelLoginHistoty(string accounts, string channelId, string channelAccount, string channelToken, string type, int gameId)
        {
            mobileAppData.InsertChannelLoginHistoty(accounts, channelId, channelAccount, channelToken, type, gameId);
        }

        /// <summary>
        /// 获取版本过滤信息
        /// </summary>
        /// <param name="GameId"></param>
        /// <param name="Version"></param>
        /// <returns></returns>
        public DataSet GetAppVerfilterList(string GameId, string Version)
        {
            return mobileAppData.GetAppVerfilterList(GameId, Version);
        }

        #region 获取GameAppUrlCFG
        /// <summary>
        /// 获取app游戏渠道配置
        /// author:Francis
        /// </summary>
        /// <param name="gameid"></param>
        /// <param name="channelid"></param>
        /// <returns></returns>
        public GameAppUrlCFG GetGameAppUrlCFG(int gameid, int channelid)
        {
            return mobileAppData.GetGameAppUrlCFG(gameid, channelid);
        }
        #endregion

        #region 获取小游戏开关配置

        /// <summary>
        /// 获取小游戏配置
        /// </summary>
        /// <param name="kindId"></param>
        /// <returns></returns>
        public DataSet GetGameEnabledConfig(int kindId)
        {
            return mobileAppData.GetGameEnabledConfig(kindId);
        }
        #endregion
        #region 获取快充配置
        /// <summary>
        /// 获取快充配置
        /// </summary>
        /// <param name="kindId"></param>
        /// <returns></returns>
        public DataSet GetFastChargeConfig(int kindId)
        {
            return mobileAppData.GetFastChargeConfig(kindId);
        }
        #endregion

        #region 获取游戏客服信息
        public string GetGameKFInfo(int kindID)
        {
            return mobileAppData.GetGameKFInfo(kindID);
        }
        #endregion
        public DataSet GameAllServerList()
        {
            return mobileAppData.GameAllServerList();
        }
    }
}
