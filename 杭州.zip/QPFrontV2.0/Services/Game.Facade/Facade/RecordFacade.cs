﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Game.IData;
using Game.Francis;
using Game.Utils;
using Game.Entity.Record;
using System.Data;
using Microsoft.Practices.Unity;

namespace Game.Facade
{
    /// <summary>
    /// 记录库外观
    /// </summary>
    public class RecordFacade
    {
        #region Fields
        IRecordDataProvider recordData;
        #endregion

        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        public RecordFacade()
        {
            recordData = Game.Web.DataInit.GetUnityContainer().Resolve<IRecordDataProvider>();
        }
        #endregion

        #region 查询记录

        /// <summary>
        /// 魅力兑换记录
        /// </summary>
        /// <param name="whereQuery"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetLovesRecord(string whereQuery, int pageIndex, int pageSize)
        {
            return recordData.GetLovesRecord(whereQuery, pageIndex, pageSize);
        }

        /// <summary>
        /// 奖牌兑换记录
        /// </summary>
        /// <param name="whereQuery">查询条件</param>
        /// <param name="pageIndex">页索引</param>
        /// <param name="pageSize">页大小</param>
        /// <returns></returns>
        public DataSet GetMedalConvertRecord(string whereQuery, int pageIndex, int pageSize)
        {
            return recordData.GetMedalConvertRecord(whereQuery, pageIndex, pageSize);
        }

        #endregion
       
    }
}
