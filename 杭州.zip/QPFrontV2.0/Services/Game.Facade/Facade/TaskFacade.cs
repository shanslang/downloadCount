﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Game.IData;
using Microsoft.Practices.Unity;
using Game.Francis;
using Game.Entity.Task;

namespace Game.Facade
{
    public class TaskFacade
    {
        private ITaskDataProvider oITaskDataProvider;
        #region 构造函数
        public TaskFacade()
        {
            oITaskDataProvider = Game.Web.DataInit.GetUnityContainer().Resolve<ITaskDataProvider>();
        }
        #endregion

        #region 旧版
        /// <summary>
        /// 获取未领取或未完成的任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="serverid"></param>
        /// <param name="gameid"></param>
        /// <returns></returns>
        public DataSet GetTaskInfo(int userid, int serverid)
        {
            return oITaskDataProvider.GetTaskInfo(userid, serverid);
        }

        /// <summary>
        /// 获取已经完成的任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="serverid"></param>
        /// <param name="gameid"></param>
        /// <returns></returns>
        public DataSet GetTaskInfoed(int userid, int serverid)
        {
            return oITaskDataProvider.GetTaskInfoed(userid, serverid);
        }

        /// <summary>
        /// 获取任务奖励详细信息
        /// </summary>
        /// <param name="taskid">任务ID</param>
        /// <param name="sumtaskid">阶段ＩＤ</param>
        /// <returns></returns>
        public IList<TaskRewardCfg> GetTaskRewardList(int taskid, int subtaskid)
        {
            return oITaskDataProvider.GetTaskRewardList(taskid, subtaskid);
        }

        /// <summary>
        /// 领取任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public Message ReceiveTask(int userid, int taskid)
        {
            return oITaskDataProvider.ReceiveTask(userid, taskid);
        }

        /// <summary>
        /// 放弃任务
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public int GiveupTask(int userid, int taskid)
        {
            return oITaskDataProvider.GiveupTask(userid, taskid);
        }

        /// <summary>
        /// 获取任务领取条件
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public DataSet GetTaskReceiveCondition(int userid, int taskid)
        {
            return oITaskDataProvider.GetTaskReceiveCondition(userid, taskid);
        }
        /// <summary>
        /// 获取任务阶段列表
        /// </summary>
        /// <param name="TaskID"></param>
        /// <returns></returns>
        public DataSet GetTaskTargetList(string TaskIDList, int Userid)
        {
            return oITaskDataProvider.GetTaskTargetList(TaskIDList, Userid);
        }
        /// <summary>
        ///获取任务奖励信息
        /// </summary>
        /// <param name="TaskID"></param>
        /// <returns></returns>
        public IList<TaskRewardCfg> GetTaskReward(int TaskID, int subid)
        {
            return oITaskDataProvider.GetTaskReward(TaskID, subid);
        }
        /// <summary>
        /// 发放任务奖励
        /// </summary>
        /// <param name="TaskID"></param>
        /// <param name="ServerID"></param>
        /// <param name="subTaskID"></param>
        /// <returns></returns>
        public DataSet TaskReceiveReward(int TaskID, int ServerID, int subTaskID, int Userid)
        {
            DataSet ds = oITaskDataProvider.TaskReceiveReward(TaskID, ServerID, subTaskID, Userid);
            DataTable dt = ds.Tables[0];
            foreach (DataRow item in dt.Rows)
            {
                Game.Web.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, Userid, Convert.ToInt32(item[5]));
                Game.Web.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, Userid, 1);
            }
            return ds;
        }
        #endregion

        #region 新版
        /// <summary>
        /// 
        /// </summary>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public NTaskInfo GetNTaskInfoByTaskIDForPlatform(int taskid)
        {
            return oITaskDataProvider.GetNTaskInfoByTaskIDForPlatform(taskid);
        }
        public NTaskInfo GetNTaskInfoByTaskIDForMobile(int taskid)
        {
            return oITaskDataProvider.GetNTaskInfoByTaskIDForMobile(taskid);
        }
        /// <summary>
        /// 获取任务对象
        /// </summary>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public NTaskInfo GetNTaskInfoByTaskID(int taskid)
        {
            return oITaskDataProvider.GetNTaskInfoByTaskID(taskid);
        }
        /// <summary>
        /// 获取任务奖励
        /// </summary>
        /// <returns></returns>
        public IList<NTaskReward> GetNTaskRewardList(int taskid)
        {
            return oITaskDataProvider.GetNTaskRewardList(taskid);
        }
        /// <summary>
        /// 获取任务分组
        /// </summary>
        /// <returns></returns>
        public IList<NTaskGroupInfo> GetNTaskGroupInfoList()
        {
            return oITaskDataProvider.GetNTaskGroupInfoList();
        }
        /// <summary>
        ///获取全部任务信息
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        public IList<NTaskInfo> GetTaskList(int kindID)
        {
            return oITaskDataProvider.GetTaskList(kindID);
        }
        #endregion
        /// <summary>
        /// 获取宝箱数据
        /// </summary>
        /// <returns></returns>
        public DataSet GetChestsReward()
        {
            return oITaskDataProvider.GetChestsReward();
        }
    }
}
