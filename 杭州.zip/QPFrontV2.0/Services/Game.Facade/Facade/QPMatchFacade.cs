﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Game.IData;
using Game.Francis;
using Game.Utils;
using Game.Entity.Accounts;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.Unity;
using Game.Entity.QPMatch;

namespace Game.Facade
{
    /// <summary>
    /// 网站外观
    /// </summary>
    public class QPMatchFacade
    {
        #region Fields
        private IQPMatchProvider oIQPMatchProvider;
        #endregion

        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        public QPMatchFacade()
        {
            oIQPMatchProvider = Game.Web.DataInit.GetUnityContainer().Resolve<IQPMatchProvider>();
        }
        #endregion

        /// <summary>
        /// 获取比赛信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public MatchInfo GetMatchInfoByMatchID(int matchid)
        {
            return oIQPMatchProvider.GetMatchInfoByMatchID(matchid);
        }

        /// <summary>
        /// 获取比赛信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public MatchInfo GetMatchInfoByMatchID(int matchid, int roundid)
        {
            return oIQPMatchProvider.GetMatchInfoByMatchID(matchid, roundid);
        }

        /// <summary>
        /// 获取比赛信息 提供个游戏的接口
        /// </summary>
        /// <returns></returns>
        public MatchInfo GetMatchInfo(int matchid)
        {
            return oIQPMatchProvider.GetMatchInfo(matchid);
        }

        /// <summary>
        /// 获取比赛信息 新版
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public string GetMatchInfoV1Xml(int matchid)
        {
            return oIQPMatchProvider.GetMatchInfoV1Xml(matchid);
        }

        /// <summary>
        /// 获取比赛记录信息 最后的记录
        /// </summary>
        /// <param name="matchid"></param>
        /// <param name="matchsubid"></param>
        /// <returns></returns>
        public DataSet GetMatchLogByMatchID(int matchid)
        {
            return oIQPMatchProvider.GetMatchLogByMatchID(matchid);
        }

        /// <summary>
        /// 获取比赛记录信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <param name="matchsubid"></param>
        /// <returns></returns>
        public DataSet GetMatchLogByMatchID(int matchid, int matchsubid)
        {
            return oIQPMatchProvider.GetMatchLogByMatchID(matchid, matchsubid);
        }

        /// <summary>
        /// 获取比赛奖励信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public IList<MatchReward> GetMatchRewardByMatchID(int matchid)
        {
            return oIQPMatchProvider.GetMatchRewardByMatchID(matchid);
        }

        /// <summary>
        /// 获取比赛组信息
        /// </summary>
        /// <param name="matchid"></param>
        /// <returns></returns>
        public IList<MatchGroupInfo> GetMatchGroupInfo()
        {
            return oIQPMatchProvider.GetMatchGroupInfo();
        }
        /// <summary>
        /// 获取比赛列表信息
        /// </summary>
        /// <param name="orderbywhere"></param>
        /// <returns></returns>
        public IList<MatchInfo> GetMatchInfoList(string wherestr)
        {
            return oIQPMatchProvider.GetMatchInfoList(wherestr);
        }
        /// <summary>
        /// 获取个人比赛成绩和奖励
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public DataSet GetUserMatchReward(int userID)
        {
            return oIQPMatchProvider.GetUserMatchReward(userID);
        }
        /// <summary>
        /// 个人单场比赛奖励
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="matchID"></param>
        /// <param name="roundID"></param>
        /// <returns></returns>
        public DataSet GetUserMatchReward(int userID, int matchID, int roundID)
        {
            return oIQPMatchProvider.GetUserMatchReward(userID, matchID, roundID);
        }
    }
}
