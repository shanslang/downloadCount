﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Game.Francis;
using Game.IData;
using Game.Entity.Accounts;
using System.Data.Common;
using System.Data;
using Microsoft.Practices.Unity;

namespace Game.Facade
{
    public class GameScoreFacade
    {
        #region Fields
        private IGameScoreDataProvider gameScoreData;
        #endregion

        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        public GameScoreFacade()
        {
            gameScoreData = Game.Web.DataInit.GetUnityContainer().Resolve<IGameScoreDataProvider>();
        }
        #endregion

        /// <summary>
        /// 获取游戏道具列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetGamePropertyList(int pageIndex, int pageSize)
        {
            return gameScoreData.GetGamePropertyList(pageIndex, pageSize);
        }
    }
}
