﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Game.IData;
using Game.Francis;
using Game.Utils;
using Game.Entity.Accounts;
using System.Data;
using System.IO;
using System.Drawing;
using Microsoft.Practices.Unity;

namespace Game.Facade
{
    /// <summary>
    /// 用户外观
    /// </summary>
    public class AccountsFacade
    {
        #region Fields

        private IAccountsDataProvider accountsData;
        private ITreasureDataProvider treasureData;

        #endregion

        #region 构造函数

        /// <summary>
        /// 构造函数
        /// </summary>
        public AccountsFacade()
        {
            accountsData = Game.Web.DataInit.GetUnityContainer().Resolve<IAccountsDataProvider>();
            treasureData = Game.Web.DataInit.GetUnityContainer().Resolve<ITreasureDataProvider>();
        }
        #endregion

        #region 用户登录、注册

        /// <summary>
        /// 用户登录
        /// </summary>
        public Message Logon(UserInfo user, bool isEncryptPasswd)
        {
            Message umsg;
            if (!isEncryptPasswd)
            {
                user.LogonPass = TextEncrypt.EncryptPassword(user.LogonPass);
            }

            umsg = accountsData.Login(user);
            return umsg;
        }

        /// <summary>
        /// 用户登录，登录密码必须是密文。并且验证登录参数
        /// </summary>
        /// <param name="stationID">站点标识</param>
        /// <param name="accounts">用户名</param>
        /// <param name="logonPasswd">密文密码</param>
        /// <param name="ip">登录地址</param>
        /// <returns>返回网站消息，若登录成功将携带用户对象</returns>
        public Message Logon(string accounts, string logonPasswd)
        {
            UserInfo suInfo = new UserInfo(0, accounts, 0, logonPasswd);
            suInfo.LastLogonIP = GameRequest.GetUserIP();

            return Logon(suInfo, false);
        }
        public Message Logon(string accounts, string logonPasswd, bool isEncryptPasswd)
        {
            UserInfo suInfo = new UserInfo(0, accounts, 0, logonPasswd);
            suInfo.LastLogonIP = GameRequest.GetUserIP();

            return Logon(suInfo, isEncryptPasswd);
        }
        /// <summary>
        /// 用户注册
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public Message Register(UserInfo user, string parentAccount, int pceggid, string pceggadid)
        {
            return accountsData.Register(user, parentAccount, pceggid, pceggadid);
        }


        /// <summary>
        /// 判断用户名是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        public Message IsAccountsExist(string accounts)
        {
            return accountsData.IsAccountsExist(accounts);
        }

        /// <summary>
        /// 判断昵称是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        public bool IsNickNameExist(string nickName)
        {
            return accountsData.IsNickNameExist(nickName);
        }

        /// <summary>
        /// 判断认证手机是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        public bool IsAuthTelephoneExist(string telephone)
        {
            return accountsData.IsAuthTelephoneExist(telephone);
        }
        /// <summary>
        /// 判断认证手机或用户名是否存在手机号
        /// </summary>
        /// <param name="telephone"></param>
        /// <returns> 1;官网注册 2;渠道用户注册0;没有记录</returns>
        public int IsAuthTelephoneOrRegisterAccounts(string telephone)
        {
            return accountsData.IsAuthTelephoneOrRegisterAccounts(telephone);
        }
        /// <summary>
        /// 判断认证电子邮件是否存在
        /// </summary>
        /// <param name="accounts"></param>
        /// <returns></returns>
        public bool IsAuthEmailExist(string email)
        {
            return accountsData.IsAuthEmailExist(email);
        }

        /// <summary>
        /// 用户MAC与账号关联
        /// </summary>
        public void UserMacthineInsert(int UserID, string Mac)
        {
            accountsData.UserMacthineInsert(UserID, Mac);
        }
        /// <summary>
        /// 根据MAC地址查询用户信息
        /// </summary>
        /// <param name="mac"></param>
        /// <returns></returns>
        public int UserMachineInfoGet(string mac, int Regmark, int kindID)
        {
            return accountsData.UserMachineInfoGet(mac, Regmark, kindID);
        }
        /// <summary>
        /// 根据百度账号查询用户信息
        /// </summary>
        /// <param name="mac"></param>
        /// <returns></returns>
        public int BaiduInfoGet(long baiduID)
        {
            return accountsData.BaiduInfoGet(baiduID);
        }
        /// <summary>
        /// 百度账号关联
        /// </summary>
        public void BaiduUserInsert(int UserID, long baiduUID)
        {
            accountsData.BaiduUserInsert(UserID, baiduUID);
        }
        /// <summary>
        /// 根据互联星空账号查询用户信息
        /// </summary>
        /// <param name="mac"></param>
        /// <returns></returns>
        public int VnetInfoGet(string vnetID)
        {
            return accountsData.VnetInfoGet(vnetID);
        }
        /// <summary>
        /// 互联星空账号关联
        /// </summary>
        public void VnetUserInsert(int UserID, string vnetID, string Tel, string imsi)
        {
            accountsData.VnetUserInsert(UserID, vnetID, Tel, imsi);
        }
        /// <summary>
        /// 获取互联星空账号信息
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public VnetEntity VnetInfoGet(int UserID)
        {
            return accountsData.VnetInfoGet(UserID);
        }
        /// <summary>
        /// 根据AnySDK查询用户信息
        /// </summary>
        public int AnySDKInfoGet(string UID, string channel)
        {
            return accountsData.AnySDKInfoGet(UID, channel);
        }
        /// <summary>
        /// AnySDK账号关联
        /// </summary>
        public void AnySDKUserInsert(int UserID, string Channel, string UserSdk, string UID)
        {
            accountsData.AnySDKUserInsert(UserID, Channel, UserSdk, UID);
        }
        /// <summary>
        /// 根据微信获取用户帐号
        /// </summary>
        /// <param name="OpenID"></param>
        /// <returns></returns>
        public int WeiXinUserGet(string OpenID)
        {
            return accountsData.WeiXinUserGet(OpenID);
        }
        /// <summary>
        /// 根据微信获取用户信息
        /// </summary>
        public Message WeiXinUserInfoGet(string OpenID, string unionID)
        {
            return accountsData.WeiXinUserInfoGet(OpenID, unionID);
        }
        /// <summary>
        /// 查询是否绑定
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public bool IsBindWeixin(int userId)
        {
            return accountsData.IsBindWeixin(userId);
        }
        /// <summary>
        /// 微信公众平台关注
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="OpenID"></param>
        public void WeiXinUserInsert(int UserID, string openid, string unionID, string headurl)
        {
            accountsData.WeiXinUserInsert(UserID, openid, unionID, headurl);
        }
        #endregion

        #region 获取用户信息

        /// <summary>
        /// 根据用户昵称获取用户ID
        /// </summary>
        /// <param name="nickName"></param>
        /// <returns></returns>
        public int GetUserIDByNickName(string nickName)
        {
            return accountsData.GetUserIDByNickName(nickName);
        }

        /// <summary>
        /// 获取基本用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserBaseInfoByUserID(int userID)
        {
            return accountsData.GetUserBaseInfoByUserID(userID);
        }

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserFullInfoByUserID(int userID)
        {
            UserInfo result = accountsData.GetUserFullInfoByUserID(userID);
            if (result != null)
            {
                result.GameScoreInfo = treasureData.GetTreasureInfo2(result.UserID);
                result.GameScoreInfoEx = treasureData.GetGameScoreInfoEx(result.UserID);
                result.UserGoldenBean = treasureData.GetUserGoldenBean(result.UserID);
                result.AccountsConfig = accountsData.GetAccountsConfigByUserID(result.UserID);
                result.AccountsMemberList = accountsData.GetAccountsMemberList(result.UserID);
            }
            return result;
        }

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserFullInfoByAccountsOrGameID(string accountsorid)
        {
            UserInfo result = accountsData.GetUserFullInfoByAccountsOrGameID(accountsorid);
            if (result != null)
            {
                result.GameScoreInfo = treasureData.GetTreasureInfo2(result.UserID);
                result.GameScoreInfoEx = treasureData.GetGameScoreInfoEx(result.UserID);
                result.UserGoldenBean = treasureData.GetUserGoldenBean(result.UserID);
                result.AccountsConfig = accountsData.GetAccountsConfigByUserID(result.UserID);
                result.AccountsMemberList = accountsData.GetAccountsMemberList(result.UserID);
            }
            return result;
        }
        /// <summary>
        /// 获取用户基本信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserInfoByUserID(int UserID)
        {
            return accountsData.GetUserInfoByUserID(UserID);
        }
        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserFullInfoByAccounts(string accounts)
        {
            UserInfo result = accountsData.GetUserFullInfoByAccounts(accounts);
            if (result != null)
            {
                result.GameScoreInfo = treasureData.GetTreasureInfo2(result.UserID);
                result.GameScoreInfoEx = treasureData.GetGameScoreInfoEx(result.UserID);
                result.UserGoldenBean = treasureData.GetUserGoldenBean(result.UserID);
                result.AccountsConfig = accountsData.GetAccountsConfigByUserID(result.UserID);
                result.AccountsMemberList = accountsData.GetAccountsMemberList(result.UserID);
            }
            return result;
        }

        /// <summary>
        /// 获取全部用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo GetUserFullInfoByGameID(int gameid)
        {
            UserInfo result = accountsData.GetUserFullInfoByGameID(gameid);
            if (result != null)
            {
                result.GameScoreInfo = treasureData.GetTreasureInfo2(result.UserID);
                result.GameScoreInfoEx = treasureData.GetGameScoreInfoEx(result.UserID);
                result.UserGoldenBean = treasureData.GetUserGoldenBean(result.UserID);
                result.AccountsConfig = accountsData.GetAccountsConfigByUserID(result.UserID);
                result.AccountsMemberList = accountsData.GetAccountsMemberList(result.UserID);
            }
            return result;
        }

        /// <summary>
        /// 获取用户配置信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public AccountsConfig GetAccountsConfigByUserID(int userid)
        {
            return accountsData.GetAccountsConfigByUserID(userid);
        }

        /// <summary>
        /// 获取指定用户联系信息
        /// </summary>
        /// <param name="user">用户</param>
        /// <returns></returns> 		
        public IndividualDatum GetUserContactInfoByUserID(int userID)
        {
            return accountsData.GetUserContactInfoByUserID(userID);
        }

        /// <summary>
        /// 获取用户全局信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="gameID"></param>
        /// <param name="Accounts"></param>
        /// <returns></returns>
        [Obsolete("此方法已经弃用")]
        public Message GetUserGlobalInfo(int userID, int gameID, String Accounts)
        {
            return accountsData.GetUserGlobalInfo(userID, gameID, Accounts);
        }

        /// <summary>
        /// 获取用户头像信息 返回图片地址
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public string GetUserFaceByUserID(int userID)
        {
            string result = null;
            try
            {
                var account = accountsData.GetUserFullInfoByUserID(userID);
                //return string.Format("/images/face/face{0}.png", account.FaceID);
                if (account.CustomID == 0 && account.FaceID == 0)
                {
                    result = string.Format("/images/face/face.png", account.FaceID);
                }
                else if (account.CustomID == 0)
                {
                    result = string.Format("/images/face/face{0}.png", account.FaceID);
                }
                else
                {
                    result = string.Format("/face/{0}/{1}/{2}", account.UserID, account.FaceID, account.CustomID);
                }
            }
            catch
            {
                result = "/images/face/face.png";
            }
            return result;
        }

        /// <summary>
        /// 获取用户头像信息 返回图片对象
        /// </summary>
        /// <param name="faceid"></param>
        /// <returns></returns>
        public AccountsFace GetUserFaceByFaceID(int faceid)
        {
            return accountsData.GetUserFaceByFaceID(faceid);
        }

        /// <summary>
        /// 获取用户头像信息 返回图片对象
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="faceid"></param>
        /// <returns></returns>
        public AccountsFace GetUserFaceByFaceID(int userid, int faceid)
        {
            return accountsData.GetUserFaceByFaceID(userid, faceid);
        }

        /// <summary>
        /// 获取密保卡序列号
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <returns></returns>
        public string GetPasswordCardByUserID(int userId)
        {
            return accountsData.GetPasswordCardByUserID(userId);
        }
        /// <summary>
        /// 通过手机号获取用户ID
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        public int GetUserIDByPhone(string phone)
        {
            return accountsData.GetUserIDByPhone(phone);
        }
        #endregion

        #region	 密码管理

        /// <summary>
        /// 重置登录密码
        /// </summary>
        /// <param name="sInfo">密保信息</param>       
        /// <returns></returns>
        public Message ResetLogonPasswd(AccountsProtect sInfo)
        {
            return accountsData.ResetLogonPasswd(sInfo);
        }

        /// <summary>
        /// 重置银行密码
        /// </summary>
        /// <param name="sInfo">密保信息</param>       
        /// <returns></returns>
        public Message ResetInsurePasswd(AccountsProtect sInfo)
        {
            return accountsData.ResetInsurePasswd(sInfo);
        }

        /// <summary>
        /// 修改登录密码
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="srcPassword">旧密码</param>
        /// <param name="dstPassword">新密码</param>
        /// <param name="ip">连接地址</param>
        /// <returns></returns>
        public Message ModifyLogonPasswd(int userID, string srcPassword, string dstPassword, string ip)
        {
            return accountsData.ModifyLogonPasswd(userID, srcPassword, dstPassword, ip);
        }

        /// <summary>
        /// 修改银行密码
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="srcPassword">旧密码</param>
        /// <param name="dstPassword">新密码</param>
        /// <param name="ip">连接地址</param>
        /// <returns></returns>
        public Message ModifyInsurePasswd(int userID, string srcPassword, string dstPassword, string ip)
        {
            return accountsData.ModifyInsurePasswd(userID, srcPassword, dstPassword, ip);
        }

        /// <summary>
        /// 编辑登录密码 自带加密
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="dstPassword">新密码</param>
        /// <returns></returns>
        public Message EditLogonPasswd(int userID, string dstPassword)
        {
            dstPassword = TextEncrypt.EncryptPassword(dstPassword);
            return accountsData.EditLogonPasswd(userID, dstPassword, Game.Utils.GameRequest.GetUserIP());
        }

        /// <summary>
        /// 编辑银行密码 自带加密
        /// </summary>
        /// <param name="userID">玩家标识</param>
        /// <param name="dstPassword">新密码</param>
        /// <returns></returns>
        public Message EditInsurePasswd(int userID, string dstPassword)
        {
            dstPassword = TextEncrypt.EncryptPassword(dstPassword);
            return accountsData.EditInsurePasswd(userID, dstPassword, Game.Utils.GameRequest.GetUserIP());
        }

        #endregion

        #region  密码保护管理

        /// <summary>
        /// 申请帐号保护
        /// </summary>
        /// <param name="sInfo">密保信息</param>
        /// <returns></returns>
        public Message ApplyUserSecurity(AccountsProtect sInfo)
        {
            return accountsData.ApplyUserSecurity(sInfo);
        }

        /// <summary>
        /// 修改帐号保护
        /// </summary>
        /// <param name="oldInfo">旧密保信息</param>
        /// <param name="newInfo">新密保信息</param>
        /// <returns></returns>
        public Message ModifyUserSecurity(AccountsProtect newInfo)
        {
            return accountsData.ModifyUserSecurity(newInfo);
        }

        /// <summary>
        /// 获取密保信息 (userID)
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Message GetUserSecurityByUserID(int userID)
        {
            return accountsData.GetUserSecurityByUserID(userID);
        }

        /// <summary>
        /// 获取密保信息 (gameID)
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Message GetUserSecurityByGameID(int gameID)
        {
            return accountsData.GetUserSecurityByGameID(gameID);
        }

        /// <summary>
        /// 获取密保信息 (Accounts)
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Message GetUserSecurityByAccounts(string accounts)
        {
            return accountsData.GetUserSecurityByAccounts(accounts);
        }

        /// <summary>
        /// 密保确认
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public Message ConfirmUserSecurity(AccountsProtect info)
        {
            return accountsData.ConfirmUserSecurity(info);
        }

        #endregion

        #region 安全管理

        #region 固定机器

        /// <summary>
        /// 申请机器绑定
        /// </summary>
        /// <param name="sInfo">密保信息</param>
        /// <returns></returns>
        public Message ApplyUserMoorMachine(AccountsProtect sInfo)
        {
            return accountsData.ApplyUserMoorMachine(sInfo);
        }

        /// <summary>
        /// 解除机器绑定
        /// </summary>
        /// <param name="sInfo">密保信息</param>
        /// <returns></returns>
        public Message RescindUserMoorMachine(AccountsProtect sInfo)
        {
            return accountsData.RescindUserMoorMachine(sInfo);
        }

        #endregion 固定机器结束

        #endregion

        #region 资料管理

        /// <summary>
        /// 更新个人资料
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public Message ModifyUserIndividual(IndividualDatum user)
        {
            return accountsData.ModifyUserIndividual(user);
        }

        /// <summary>
        /// 更新用户头像
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="faceID"></param>
        /// <returns></returns>
        public Message ModifyUserFace(int userID, int faceID)
        {
            return accountsData.ModifyUserFace(userID, faceID);
        }

        /// <summary>
        /// 更新用户昵称
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="faceID"></param>
        /// <returns></returns>
        public Message ModifyUserNickname(int userID, string nickName, string ip)
        {
            return accountsData.ModifyUserNickname(userID, nickName, ip);
        }
        /// <summary>
        /// 更新微信信息
        /// </summary>
        public bool UpdateWeiXinInfo(int userId, string weixinName, int sex)
        {
            return accountsData.UpdateWeiXinInfo(userId, weixinName, sex);
        }
        #endregion

        #region 魅力兑换

        /// <summary>
        /// 魅力值兑换
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="present"></param>
        /// <param name="rate"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        public Message UserConvertPresent(int userID, int present, int rate, string ip)
        {
            Message msg = accountsData.UserConvertPresent(userID, present, rate, ip);
            if (msg.Success)
            {
                Game.Web.DataInit.ServerCmd(Game.Type.ServerCmdID.重新加载用户信息, 0, userID, 1);

                DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                foreach (DataRow item in dt.Rows)
                {
                    Game.Web.DataInit.ServerCmd(Type.ServerCmdID.用户金币更新, 0, userID, Convert.ToInt32(item["GoldKey"]));
                }
            }
            return msg;
        }

        /// <summary>
        /// 根据用户魅力排名(前10名)
        /// </summary>
        /// <returns></returns>
        public IList<UserInfo> GetUserInfoOrderByLoves()
        {
            return accountsData.GetUserInfoOrderByLoves();
        }

        /// <summary>
        /// 获取魅力排行榜
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public DataSet GetLovesRanking(int num)
        {
            return accountsData.GetLovesRanking(num);
        }

        #endregion

        #region 奖牌兑换

        public Message UserConvertMedal(int userID, int medals, int rate, string ip)
        {
            return accountsData.UserConvertMedal(userID, medals, rate, ip);
        }

        #endregion

        #region 密保卡

        /// <summary>
        /// 检测密保卡序列号是否存在
        /// </summary>
        /// <param name="serialNumber">密保卡序列号</param>
        /// <returns></returns>
        public bool PasswordIDIsEnable(string serialNumber)
        {
            return accountsData.PasswordIDIsEnable(serialNumber);
        }

        /// <summary>
        /// 检测用户是否绑定了密保卡
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <param name="serialNumber">密保卡序列号</param>
        /// <returns></returns>
        public bool userIsBindPasswordCard(int userId)
        {
            return accountsData.userIsBindPasswordCard(userId);
        }


        /// <summary>
        /// 更新用户密保卡序列号
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <param name="serialNumber">密保卡序列号</param>
        /// <returns></returns>
        public bool UpdateUserPasswordCardID(int userId, int serialNumber)
        {
            return accountsData.UpdateUserPasswordCardID(userId, serialNumber);
        }

        /// <summary>
        /// 取消密保卡绑定
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public bool ClearUserPasswordCardID(int userId)
        {
            return accountsData.ClearUserPasswordCardID(userId);
        }

        #endregion

        #region 获取用户会员列表
        /// <summary>
        /// 根据用户ID获取会员列表
        /// </summary>
        /// <param name="nickName"></param>
        /// <returns></returns>
        public IList<AccountsMember> GetAccountsMemberList(int userid)
        {
            return accountsData.GetAccountsMemberList(userid);
        }
        /// <summary>
        /// 根据条件获取会员列表
        /// </summary>
        /// <param name="nickName"></param>
        /// <returns></returns>
        public IList<AccountsMember> GetAccountsMemberList(string wherecase, string orderwhere)
        {
            return accountsData.GetAccountsMemberList(wherecase, orderwhere);
        }
        #endregion

        #region 公共

        /// <summary>
        /// 根据SQL语句查询一个值
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        public object GetObjectBySql(string sqlQuery)
        {
            return accountsData.GetObjectBySql(sqlQuery);
        }

        #endregion

        #region 手游
        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        public DataSet GetMAccountInfo(int userid)
        {
            return accountsData.GetMAccountInfo(userid);
        }
        /// <summary>
        /// 获取用户头像信息
        /// </summary>
        /// <param name="FaceID"></param>
        /// <returns></returns>
        public AccountsUploadFace GetUserFaceInfo(int Userid, int FaceID)
        {
            return accountsData.GetUserFaceInfo(Userid, FaceID);
        }
        /// <summary>
        /// 更新用户自定义头像(用户上传图片，更新图片地址)
        /// </summary>
        /// <param name="Userid"></param>
        /// <param name="facelink"></param>
        /// <param name="picmd5"></param>
        /// <returns></returns>
        public Message UploadAccountUserFace(int Userid, string FileMd5, int CustomId, bool IsPC)
        {
            Message msg = accountsData.UploadAccountUserFace(Userid, FileMd5, CustomId, IsPC);
            if (msg.Success && FileMd5.Trim().Length > 0)
            {
                try
                {
                    Game.Web.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, Userid, 2);
                }
                catch (Exception ex)
                {
                    Game.Library.Log.WriteLogInfo("WebClientDLL", new Exception("加载用户头像" + ex));
                }
            }
            return msg;
        }
        /// <summary>
        /// 获取新手奖励
        /// </summary>
        /// <param name="kindID"></param>
        /// <returns></returns>
        public DataSet GetNoviceAwardList(int kindID)
        {
            return accountsData.GetNoviceAwardList(kindID);
        }
        /// <summary>
        /// 根据用户ID获取开房道具数量
        /// </summary>
        /// <param name="gameId"></param>
        /// <returns></returns>
        public int GetUserPropertybyUserID(int userid)
        {
            return accountsData.GetUserPropertybyUserID(userid);
        }
        #endregion
        public DataSet GetWeiXinUserInfo(string table, string unionID)
        {
            return accountsData.GetWeiXinUserInfo(table, unionID);
        }
        public void InsertWeiXinUser(int UserID, string openid, string unionID, string headurl, string table)
        {
            accountsData.InsertWeiXinUser(UserID, openid, unionID, headurl, table);
        }
        public void UpdateWeiXinHead(string unionID, string headurl, string table)
        {
            accountsData.UpdateWeiXinHead(unionID, headurl, table);
        }
        /// <summary>
        /// 获取用户战绩
        /// </summary>
        public Message GetUserScore(int userID, int kindID)
        {
            return accountsData.GetUserScore(userID, kindID);
        }
        public Message GetUserScore(int drawID)
        {
            return accountsData.GetUserScore(drawID);
        }
        /// <summary>
        /// 绑定代理商
        /// </summary>
        public Message BindAgent(int userID, int agentID)
        {
            var msg = accountsData.BindAgent(userID, agentID);
            if (msg.Success)
            {
                Web.DataInit.ServerCmd(Type.ServerCmdID.绑定代理商, 65536, userID, agentID);
                Web.DataInit.ServerCmd(Type.ServerCmdID.用户信息重新加载, 65536, userID, 32);
            }
            return msg;
        }
        public Message GetRankList(int userid, int type)
        {
            return accountsData.GetRankList(userid, type);
        }
        public long GetRankScore(int userid, int type)
        {
            return accountsData.GetRankScore(userid, type);
        }
        public Message Register(string openid, string machineid, int platformid, string devicemodel, string nickname, string unionid)
        {
            return accountsData.Register(openid, machineid, platformid, devicemodel, nickname, unionid);
        }
    }
}
