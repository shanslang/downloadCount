﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.SessionState;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using Game.Facade;
using Game.Entity.Accounts;
using System.Security.Cryptography;

namespace Game.Web
{
    public class BaseExHandler : IHttpHandler, IRequiresSessionState
    {
        #region 公共属性
        protected TreasureFacade oTreasureFacade = new TreasureFacade();
        protected AccountsFacade oAccountsFacade = new AccountsFacade();
        protected NativeWebFacade oNativeWebFacade = new NativeWebFacade();
        protected GamePropertyFacade oGamePropertyFacade = new GamePropertyFacade();
        protected PlatformFacade oPlatformFacade = new PlatformFacade();
        protected QPMatchFacade oQPMatchFacade = new QPMatchFacade();

        public StringBuilder sbCache = null;
        public void ResetCache()
        {
            if (this.sbCache == null)
            {
                this.sbCache = new StringBuilder();
            }
            else
            {
                this.sbCache.Length = 0;
            }
        }

        /// <summary>
        /// 请求命令
        /// </summary>
        public string RequestCMD { set; get; }

        /// <summary>
        /// 随机一个字母
        /// </summary>
        public string RdmLtter
        {
            get
            {
                string[] Ltterlist = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z".Split(',');
                Random rdm = new Random();
                return Ltterlist[rdm.Next(0, Ltterlist.Length)];
            }
        }
        /// <summary>
        /// 获取文件MD5
        /// </summary>
        /// <returns></returns>
        public string LoadFileMD5(string filepath)
        {
            try
            {
                if (File.Exists(filepath))
                {
                    FileStream file = new FileStream(filepath, System.IO.FileMode.Open);
                    MD5 md5 = new MD5CryptoServiceProvider();
                    byte[] retVal = md5.ComputeHash(file);
                    file.Close();
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < retVal.Length; i++)
                    {
                        sb.Append(retVal[i].ToString("x2"));
                    }
                    return sb.ToString();
                }
                return "";
            }
            catch (Exception ex)
            {
                Game.Library.Log.WriteLogInfo("PCFaceGetMD5", ex);
                return "";
            }
        }
        /// <summary>
        /// 随机数字(5位数)
        /// </summary>
        public int RdmNum
        {
            get
            {
                Random rdm = new Random();
                return rdm.Next(10000, 99999);
            }
        }


        /// <summary>
        /// 如果 IHttpHandler 实例可再次使用，则为 true；否则为 false。
        /// </summary>
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// 返回数据格式 
        /// </summary>
        private BaseExHandlerResponseFormat _ResponseDataFormat = BaseExHandlerResponseFormat.JSONObject;
        public BaseExHandlerResponseFormat ResponseDataFormat
        {
            get { return _ResponseDataFormat; }
            set { _ResponseDataFormat = value; }
        }

        /// <summary>
        /// 返回数据包对象
        /// </summary>
        private object _ResponsePackage = null;
        public object ResponsePackage
        {
            get
            {
                return this._ResponsePackage;
            }
            set
            {
                this._ResponsePackage = value;
            }
        }

        /// <summary>
        /// 返回数据包编码
        /// </summary>
        private Encoding _ResponseEncoding = System.Text.Encoding.UTF8;
        public Encoding ResponseEncoding
        {
            get
            {
                return this._ResponseEncoding;
            }
            set
            {
                this._ResponseEncoding = value;
            }
        }

        private bool _ResponeIsCache = false;
        /// <summary>
        /// 是否缓存
        /// </summary>
        private bool ResponeIsCache
        {
            get
            {
                return this._ResponeIsCache;
            }
            set
            {
                this._ResponeIsCache = value;
            }
        }

        /// <summary>
        /// 设置缓存间隔时间
        /// </summary>
        private TimeSpan ResponseCacheSetMaxAge
        {
            set;
            get;
        }
        #endregion

        #region 公共方法
        /// <summary>
        /// 设置发送数据包
        /// </summary>
        /// <param name="status"></param>
        /// <param name="message"></param>
        /// <param name="data"></param>
        protected void SetResponseData(BaseExHandlerResponseFormat responseformat, Encoding responseencoding,TimeSpan cacheTimeSpan, object data)
        {
            this.ResponseDataFormat = responseformat;
            this.ResponseEncoding = responseencoding;
            this.ResponsePackage = data;
            this.ResponeIsCache = true;
            this.ResponseCacheSetMaxAge = cacheTimeSpan;
        }
        /// <summary>
        /// 设置发送数据包
        /// </summary>
        /// <param name="status"></param>
        /// <param name="message"></param>
        /// <param name="data"></param>
        protected void SetResponseData(BaseExHandlerResponseFormat responseformat, Encoding responseencoding, object data)
        {
            this.ResponseDataFormat = responseformat;
            this.ResponseEncoding = responseencoding;
            this.ResponsePackage = data;
        }
        /// <summary>
        /// 设置发送数据包
        /// </summary>
        /// <param name="status"></param>
        /// <param name="message"></param>
        /// <param name="data"></param>
        protected void SetResponseData(BaseExHandlerResponseFormat responseformat, object data)
        {
            this.ResponseDataFormat = responseformat;
            this.ResponsePackage = data;
        }
        /// <summary>
        /// 设置发送数据包 JSON对象格式专用
        /// </summary>
        /// <param name="status">状态</param>
        /// <param name="message">消息</param>
        /// <param name="sign">数据包签名</param>
        /// <param name="data">数据包</param>
        protected void SetResponseData(bool status, string message, object data)
        {
            this.ResponseDataFormat = BaseExHandlerResponseFormat.JSONObject;
            Hashtable hashtable = new Hashtable();
            hashtable.Add("status", status);
            hashtable.Add("message", message);
            hashtable.Add("data", data);
            this.ResponsePackage = hashtable;
        }
        /// <summary>
        /// 设置发送数据包 JSON对象格式专用
        /// </summary>
        /// <param name="status">状态 0表示成功，大于0表示失败</param>
        /// <param name="message">消息</param>
        /// <param name="sign">数据包签名</param>
        /// <param name="data">数据包</param>
        protected void SetResponseData(int status, string message, object data)
        {
            this.ResponseDataFormat = BaseExHandlerResponseFormat.JSONObject;
            Hashtable hashtable = new Hashtable();
            hashtable.Add("status", status);
            hashtable.Add("message", message);
            hashtable.Add("data", data);
            this.ResponsePackage = hashtable;
        }
        /// <summary>
        /// 获取Form参数
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        protected string GetFormParam(string key)
        {
            return HttpContext.Current.Request.Form[key];
        }
        /// <summary>
        /// 获取GET参数
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        protected string GetQueryStringParam(string key)
        {
            return HttpContext.Current.Request.QueryString[key];
        }
        /// <summary>
        /// 身份验证执行
        /// </summary>
        protected virtual void HandlerAuthorizationRequired()
        {
        }
        /// <summary>
        /// 请求开始执行
        /// </summary>
        protected virtual void HandlerBegin()
        {
        }
        /// <summary>
        /// 请求结束执行
        /// </summary>
        protected virtual void HandlerEnd()
        {
        }
        /// <summary>
        /// 请求异常执行
        /// </summary>
        protected virtual void HandlerException(Exception exception)
        {
            Exception exp = (exception.InnerException != null) ? exception.InnerException : exception;
            Game.Library.Log.WriteLogInfo("BaseExHandler", exp);
        }
        #endregion

        #region 公共逻辑方法
        /// <summary>
        /// 验证用户
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        protected UserInfo ValidateUser(int userid)
        {
            //验证用户信息
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            if (oUserInfo == null) throw new Exception("用户无效！");
            //返回用户信息
            return oUserInfo;
        }
        /// <summary>
        /// 验证签名
        /// </summary>
        /// <param name="sign"></param>
        /// <param name="requestdata"></param>
        protected void ValidateSign(string sign, string requestdata)
        {
            string signserver = Game.Utils.TextEncrypt.MD5EncryptPassword("md5key" + requestdata);
            if (sign.ToLower() != signserver.ToLower()) throw new Exception("验证签名无效！");
        }
        /// <summary>
        /// 验证签名
        /// </summary>
        /// <param name="devicetype">设备类型 1=PC 2=IOS 3=Android</param>
        /// <param name="userid">用户UserID</param>
        /// <param name="sign">客户端签名</param>
        /// <param name="requestdata">客户端发送数据包</param>
        /// <returns></returns>
        protected UserInfo ValidateSign(byte devicetype, int userid, string sign, string requestdata)
        {
            //验证用户信息
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            if (oUserInfo == null) throw new Exception("用户无效！");
            //验证签名
            string md5key = null;
            switch (devicetype)
            {
                case (int)Game.Type.DeviceType.IOS:
                    {
                        md5key = oUserInfo.IOSWebKey;
                        break;
                    }
                case (int)Game.Type.DeviceType.Android:
                    {
                        md5key = oUserInfo.AndroidWebKey;
                        break;
                    }
                default:
                    {
                        md5key = oUserInfo.PCWebKey;
                        break;
                    }
            }
            string signserver = Game.Utils.TextEncrypt.MD5EncryptPassword(md5key + requestdata);
            if (sign.ToLower() != signserver.ToLower()) throw new Exception("验证签名无效！");
            //返回用户信息
            return oUserInfo;
        }
        #endregion

        /// <summary>
        /// 基础请求
        /// </summary>
        /// <param name="context"></param>
        public virtual void ProcessRequest(HttpContext context)
        {
            HttpRequest request = context.Request;
            HttpResponse response = context.Response;
            this.RequestCMD = HttpContext.Current.Request["m"];
            try
            {
                this.HandlerBegin();//开始执行

                //通过命令获取执行方法
                MethodInfo method = null;
                MethodInfo[] aryMethodInfo = base.GetType().GetMethods();
                foreach (var item in aryMethodInfo)
                {
                    object[] customAttributes = item.GetCustomAttributes(typeof(BaseExMethodAttribute), false);
                    if (customAttributes.Length <= 0) continue;
                    BaseExMethodAttribute attribute = (BaseExMethodAttribute)customAttributes[0];
                    if (attribute.RequestCMD == this.RequestCMD)
                    {
                        method = item;
                        break;
                    }
                }
                if (method == null) throw new Exception("服务器不接受此次请求处理！");

                //方法特性
                object[] methodAttributes = method.GetCustomAttributes(typeof(BaseExMethodAttribute), false);
                if (methodAttributes.Length > 0)
                {
                    BaseExMethodAttribute attribute = (BaseExMethodAttribute)methodAttributes[0];
                    if (attribute.AuthorizationRequired)
                    {
                        this.HandlerAuthorizationRequired();
                    }
                }

                //方法参数
                ParameterInfo[] infoArray = (from param in method.GetParameters() orderby param.Position select param).ToArray<ParameterInfo>();
                object[] parameters = null;
                if (infoArray.Length > 0)
                {
                    StreamReader reader = new StreamReader(request.InputStream);
                    string json = reader.ReadToEnd();
                    reader.Dispose();
                    JObject obj2 = JsonEncoder.Deserialize(json) as JObject;
                    if (obj2 == null) throw new Exception("参数格式不正确！");
                    List<object> list = new List<object>();
                    foreach (ParameterInfo info2 in infoArray)
                    {
                        JToken token;
                        if (!obj2.TryGetValue(info2.Name, out token)) throw new Exception("缺少参数！");
                        object item = JsonConvert.DeserializeObject(token.ToString(), info2.ParameterType);
                        list.Add(item);
                    }
                    parameters = list.ToArray();
                }

                //执行方法
                method.Invoke(this, parameters);

                //结束执行
                this.HandlerEnd();
            }
            catch (Exception exception)
            {
                this.HandlerException(exception);
            }
            finally
            {
                response.Clear();
                if (this.ResponeIsCache)
                {
                    response.Cache.SetLastModified(DateTime.Now);
                    response.Cache.SetCacheability(HttpCacheability.Public);
                    response.Cache.SetMaxAge(this.ResponseCacheSetMaxAge);
                }
                else 
                {
                    response.CacheControl = "no-cache";
                }
                response.ContentEncoding = this.ResponseEncoding;
                switch (this.ResponseDataFormat)
                {
                    case BaseExHandlerResponseFormat.JSON:
                        {
                            response.ContentType = "application/json";
                            response.Write(this.ResponsePackage);
                            break;
                        }
                    case BaseExHandlerResponseFormat.JSONObject:
                        {
                            response.ContentType = "application/json";
                            string json = JsonConvert.SerializeObject(this.ResponsePackage);
                            response.Write(json);
                            break;
                        }
                    case BaseExHandlerResponseFormat.XML:
                        {
                            response.ContentType = "application/xml";
                            response.Write(this.ResponsePackage);
                            break;
                        }
                    case BaseExHandlerResponseFormat.Binary:
                        {
                            response.ContentType = "application/octet-stream";
                            response.BinaryWrite((this.ResponsePackage as byte[]));
                            break;
                        }
                    case BaseExHandlerResponseFormat.Default:
                        {
                            response.Write(this.ResponsePackage);
                            break;
                        }
                }
                response.End();
            }
        }
    }

    /// <summary>
    /// 方法属性
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class BaseExMethodAttribute : Attribute
    {
        public BaseExMethodAttribute()
        {
            this.AuthorizationRequired = false;
            this.RequestCMD = null;
        }
        public bool AuthorizationRequired { get; set; }
        public string RequestCMD { get; set; }
    }
    /// <summary>
    /// 返回数据格式
    /// </summary>
    public enum BaseExHandlerResponseFormat
    {
        JSON = 1,
        JSONObject = 2,
        XML = 3,
        Binary = 4,
        Default = 5
    }

}
