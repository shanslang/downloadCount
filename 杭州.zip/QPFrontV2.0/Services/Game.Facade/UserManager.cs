﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Game.Entity.Accounts;
using Game.IData;
using Microsoft.Practices.Unity;
using System.Threading;
namespace Game.Facade
{
    public class UserManager
    {
        public static List<User> listUser = new List<User>();
        private UserManager()
        {
            //开线程定期移除过期用户
            Thread thread = new Thread(n =>
            {
                while (true)
                {
                    lock (listUser)
                    {
                        if (listUser.RemoveAll(m => m.TimeOut < DateTime.Now) > 0)
                        {
                            GC.Collect();
                        }
                    }
                    Thread.Sleep(60000);//一分钟移除一次
                }
            });
            thread.Start();
        }
        public static readonly UserManager instance = new UserManager();//创建单例
        /// <summary>
        /// 插入用户信息
        /// </summary>
        /// <param name="user"></param>
        public void Insert(UserInfo userinfo,int Minutes)
        {
            lock (listUser)
            {
                User user = new User() { ID = userinfo.UserID, userInfo = userinfo, TimeOut = DateTime.Now.AddMinutes(Minutes) };
                int i = listUser.FindIndex(n => n.ID == userinfo.UserID);
                if (i > -1)
                {
                    listUser[i] = user;
                }
                else {
                    listUser.Add(user);
                }
            }
        }
        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public UserInfo Get(int userID)
        {
            var user= listUser.Where(n => n.ID == userID).FirstOrDefault();
            if (user!=null&&user.userInfo!=null)
            {
                return user.userInfo;
            }
            return null;
        }
    }
    public class User
    {
        public int ID { set; get; }
        public DateTime TimeOut { set; get; }
        public UserInfo userInfo { set; get; }
    }
}
