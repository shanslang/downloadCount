﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Web
{
    public class RewriterUrl
    {
        public static string CurrentHost
        {
            get
            {
                return System.Web.HttpContext.Current.Request.Url.Host;
            }
        }
        public static string CurrentHttpHost
        {
            get
            {
                return "http://"+System.Web.HttpContext.Current.Request.Url.Host;
            }
        }

        #region 推广链接
        /// <summary>
        /// 获取用户推广链接
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        public static string GetSpreadUserLink(int gameid)
        {
            string result = "{0}/spreaduser/{1}";
            result = string.Format(result, CurrentHttpHost, gameid);
            return result;
        }
        #endregion
    }
}
