/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-06-16 16:43:14*/
/*Table:PropertyCFG*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.GameProperty
{
    public class PropertyCFG
    {
        #region 构造函数
        public PropertyCFG() { }
        #endregion

        #region 私有变量
        /// <summary>
        /// 表名
        /// </summary>
        public const string Tablename = "PropertyCFG";

        /// <summary>
        /// 
        /// </summary>
        public const string _PID = "PID";

        /// <summary>
        /// 
        /// </summary>
        public const string _Name = "Name";

        /// <summary>
        /// 
        /// </summary>
        public const string _Gold = "Gold";

        /// <summary>
        /// 
        /// </summary>
        public const string _GoldBeans = "GoldBeans";

        /// <summary>
        /// 
        /// </summary>
        public const string _HeapCount = "HeapCount";

        /// <summary>
        /// 道具每次使用消耗的个数（用于碎片合成）
        /// </summary>
        public const string _PerUseCount = "PerUseCount";

        /// <summary>
        /// 房间限制 0表示不限制
        /// </summary>
        public const string _ServerID = "ServerID";

        /// <summary>
        /// 游戏限制 0表示不限制
        /// </summary>
        public const string _GameID = "GameID";

        /// <summary>
        /// 房间类型限制 0表示不限制
        /// </summary>
        public const string _ServerType = "ServerType";

        /// <summary>
        /// 可自用
        /// </summary>
        public const string _SelfUse = "SelfUse";

        /// <summary>
        /// 可对他人使用
        /// </summary>
        public const string _TargetUse = "TargetUse";

        /// <summary>
        /// 可赠送
        /// </summary>
        public const string _CanGive = "CanGive";

        /// <summary>
        /// 唯一
        /// </summary>
        public const string _IsSole = "IsSole";

        /// <summary>
        /// 
        /// </summary>
        public const string _Nullity = "Nullity";

        /// <summary>
        /// 
        /// </summary>
        public const string _SortID = "SortID";

        /// <summary>
        /// 0不自动执行 1自动执行
        /// </summary>
        public const string _IsAuto = "IsAuto";

        /// <summary>
        /// 道具图片地址
        /// </summary>
        public const string _ImgUrl = "ImgUrl";

        /// <summary>
        /// 
        /// </summary>
        public const string _IsConvert = "IsConvert";

        /// <summary>
        /// 
        /// </summary>
        public const string _ConvertProductPid = "ConvertProductPid";

        /// <summary>
        /// 道具类型(1=金币礼包 2=红钻会员 3=黄钻会员 4=蓝钻会员 5=其它道具)
        /// </summary>
        public const string _PropType = "PropType";

        /// <summary>
        /// 
        /// </summary>
        public const string _Explain = "Explain";
        /// <summary>
        /// 
        /// </summary>
        private const string _PicMD5 = "PicMD5";
        /// <summary>
        /// 
        /// </summary>
        private const string _Recommend = "Recommend";
        /// <summary>
        /// 
        /// </summary>
        private const string _AppleProductID = "AppleProductID";

        private const string _IsCDKConvert = "IsCDKConvert";
        #endregion

        #region 私有变量
        private int m_PID;//
        private string m_Name;//
        private long m_Gold;//
        private int m_GoldBeans;//
        private int m_HeapCount;//
        private int m_PerUseCount;//道具每次使用消耗的个数（用于碎片合成）
        private int m_ServerID;//房间限制 0表示不限制
        private int m_GameID;//游戏限制 0表示不限制
        private byte m_ServerType;//房间类型限制 0表示不限制
        private byte m_SelfUse;//可自用
        private byte m_TargetUse;//可对他人使用
        private byte m_CanGive;//可赠送
        private byte m_IsSole;//唯一
        private byte m_Nullity;//
        private int m_SortID;//
        private byte m_IsAuto;//0不自动执行 1自动执行
        private string m_ImgUrl;//道具图片地址
        private byte m_IsConvert;//
        private int m_ConvertProductPid;//
        private byte m_PropType;//道具类型(1=金币礼包 2=会员道具 3=门票道具 4=实物道具)
        private string m_Explain;//
        private string m_PicMD5;
        private string m_Recommend;//是否推荐
        private string m_AppleProductID;//后台提交到苹果服务器的产品ID
        private string _shortName;
        private byte m_IsCDKConvert;

        #endregion

        #region 公开属性

        /// <summary>
        /// 
        /// </summary>
        public int PID
        {
            get { return m_PID; }
            set { m_PID = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Name
        {
            get { return m_Name; }
            set { m_Name = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public long Gold
        {
            get { return m_Gold; }
            set { m_Gold = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int GoldBeans
        {
            get { return m_GoldBeans; }
            set { m_GoldBeans = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int HeapCount
        {
            get { return m_HeapCount; }
            set { m_HeapCount = value; }
        }

        /// <summary>
        /// 道具每次使用消耗的个数（用于碎片合成）
        /// </summary>
        public int PerUseCount
        {
            get { return m_PerUseCount; }
            set { m_PerUseCount = value; }
        }

        /// <summary>
        /// 房间限制 0表示不限制
        /// </summary>
        public int ServerID
        {
            get { return m_ServerID; }
            set { m_ServerID = value; }
        }

        /// <summary>
        /// 游戏限制 0表示不限制
        /// </summary>
        public int GameID
        {
            get { return m_GameID; }
            set { m_GameID = value; }
        }

        /// <summary>
        /// 房间类型限制 0表示不限制
        /// </summary>
        public byte ServerType
        {
            get { return m_ServerType; }
            set { m_ServerType = value; }
        }

        /// <summary>
        /// 可自用
        /// </summary>
        public byte SelfUse
        {
            get { return m_SelfUse; }
            set { m_SelfUse = value; }
        }

        /// <summary>
        /// 可对他人使用
        /// </summary>
        public byte TargetUse
        {
            get { return m_TargetUse; }
            set { m_TargetUse = value; }
        }

        /// <summary>
        /// 可赠送
        /// </summary>
        public byte CanGive
        {
            get { return m_CanGive; }
            set { m_CanGive = value; }
        }

        /// <summary>
        /// 唯一
        /// </summary>
        public byte IsSole
        {
            get { return m_IsSole; }
            set { m_IsSole = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public byte Nullity
        {
            get { return m_Nullity; }
            set { m_Nullity = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int SortID
        {
            get { return m_SortID; }
            set { m_SortID = value; }
        }

        /// <summary>
        /// 0不自动执行 1自动执行
        /// </summary>
        public byte IsAuto
        {
            get { return m_IsAuto; }
            set { m_IsAuto = value; }
        }

        /// <summary>
        /// 道具图片地址
        /// </summary>
        public string ImgUrl
        {
            get { return m_ImgUrl; }
            set { m_ImgUrl = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public byte IsConvert
        {
            get { return m_IsConvert; }
            set { m_IsConvert = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int ConvertProductPid
        {
            get { return m_ConvertProductPid; }
            set { m_ConvertProductPid = value; }
        }

        /// <summary>
        /// 道具类型(1=金币礼包 2=红钻会员 3=黄钻会员 4=蓝钻会员 5=其它道具)
        /// </summary>
        public byte PropType
        {
            get { return m_PropType; }
            set { m_PropType = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Explain
        {
            get { return m_Explain; }
            set { m_Explain = value; }
        }
        public string PicMD5
        {
            get { return m_PicMD5; }
            set { m_PicMD5 = value; }
        }
        /// <summary>
        /// 是否推荐(0=否 1=是)
        /// </summary>
        public string Recommend
        {
            get { return m_Recommend; }
            set { m_Recommend = value; }
        }
        /// <summary>
        /// 后台提交到苹果服务器的产品ID
        /// </summary>
        public string AppleProductID
        {
            get { return m_AppleProductID; }
            set { m_AppleProductID = value; }
        }
        public string ShortName
        {
            get { return _shortName; }
            set { _shortName = value; }
        }

        public byte IsCDKConvert
        {
            get { return m_IsCDKConvert; }
            set { m_IsCDKConvert = value; }
        }
        #endregion

    }

    public class PropertyCFGInfo
    {
        #region 构造函数
        public PropertyCFGInfo() { }
        #endregion

        #region 私有变量
        /// <summary>
        /// 表名
        /// </summary>
        public const string Tablename = "PropertyCFG";

        /// <summary>
        /// 
        /// </summary>
        public const string _PID = "PID";

          /// <summary>
        /// 
        /// </summary>
        public const string _SortID = "SortID"; 
          
        /// <summary>
        /// 
        /// </summary>
        public const string _Gold = "Price1";

        /// <summary>
        /// 
        /// </summary>
        public const string _GoldBeans = "Price2";
         
        /// <summary>
        /// 道具图片 
        /// </summary>
        public const string _ImgName = "ImgName";
         
        #endregion

        #region 私有变量
        private string m_PID;
        private string m_SortID;
        private string m_Price1;
        private string m_Price2;
        private string m_ImgName; 


        #endregion

        #region 公开属性

        /// <summary>
        /// 
        /// </summary>
        public string PID
        {
            get { return m_PID; }
            set { m_PID = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string SortID
        {
            get { return m_SortID; }
            set { m_SortID = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Price1
        {
            get { return m_Price1; }
            set { m_Price1 = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Price2
        {
            get { return m_Price2; }
            set { m_Price2 = value; }
        }
         
        /// <summary>
        /// 道具图片地址
        /// </summary>
        public string ImgName
        {
            get { return m_ImgName; }
            set { m_ImgName = value; }
        }
   
        #endregion

    }

    public class UserPropertyCFGInfo
    {
        #region 构造函数
        public UserPropertyCFGInfo() { }
        #endregion 

        #region 私有变量
        private int m_PID;
        private string m_PCount;
        private string m_SortID;
        private string m_IsConvert;
        private string m_HeapCount; 
        private string m_ImgName;
         private string m_SelfUse;
         private string m_ConvertProductPid; 

        #endregion

        #region 公开属性

        /// <summary>
        /// 
        /// </summary>
        public int PID
        {
            get { return m_PID; }
            set { m_PID = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string PCount
        {
            get { return m_PCount; }
            set { m_PCount = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string SortID
        {
            get { return m_SortID; }
            set { m_SortID = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string IsConvert
        {
            get { return m_IsConvert; }
            set { m_IsConvert = value; }
        }
         
        /// <summary>
        /// 
        /// </summary>
        public string HeapCount
        {
            get { return m_HeapCount; }
            set { m_HeapCount = value; }
        }

        /// <summary>
        /// 道具图片地址
        /// </summary>
        public string ImgName
        {
            get { return m_ImgName; }
            set { m_ImgName = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string SelfUse
        {
            get { return m_SelfUse; }
            set { m_SelfUse = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string ConvertProductPid
        {
            get { return m_ConvertProductPid; }
            set { m_ConvertProductPid = value; }
        }
         
        #endregion

    }
}