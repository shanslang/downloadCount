/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-01-08 12:02:21*/
/*Table:UserProperty*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.GameProperty
{
	public class UserProperty
	{
		#region 构造函数
		public UserProperty(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "UserProperty";

		/// <summary>
		/// 
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 
		/// </summary>
		public const string _PID = "PID";

		/// <summary>
		/// 
		/// </summary>
		public const string _PCount = "PCount";

		#endregion

		#region 私有变量
		private int m_UserID;//
		private int m_PID;//
		private int m_PCount;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int PID
		{
			get { return m_PID; }
			set { m_PID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int PCount
		{
			get { return m_PCount; }
			set { m_PCount = value; }
		}

		#endregion

	}
}
