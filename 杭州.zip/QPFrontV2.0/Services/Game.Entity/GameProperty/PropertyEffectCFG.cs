/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-01-08 12:02:17*/
/*Table:PropertyEffectCFG*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.GameProperty
{
	public class PropertyEffectCFG
	{
		#region 构造函数
		public PropertyEffectCFG(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "PropertyEffectCFG";

		/// <summary>
		/// 
		/// </summary>
		public const string _PID = "PID";

		/// <summary>
		/// 影响类型 0-金币 1-魅力值
		/// </summary>
		public const string _EffectType = "EffectType";

		/// <summary>
		/// 
		/// </summary>
		public const string _EffectValue = "EffectValue";

		#endregion

		#region 私有变量
		private int m_PID;//
		private int m_EffectType;//影响类型 0-金币 1-魅力值
		private long m_EffectValue;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int PID
		{
			get { return m_PID; }
			set { m_PID = value; }
		}

		/// <summary>
		/// 影响类型 0-金币 1-魅力值
		/// </summary>
		public int EffectType
		{
			get { return m_EffectType; }
			set { m_EffectType = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public long EffectValue
		{
			get { return m_EffectValue; }
			set { m_EffectValue = value; }
		}

		#endregion

	}
}
