/*
 * 版本：4.0
 * 时间：2011-5-17
 * 作者：http://www.foxuc.com
 *
 * 描述：实体类
 *
 */

using System;
using System.Collections.Generic;

namespace Game.Entity.Accounts
{
    /// <summary>
    /// 实体类 AccountsInfo。(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    public partial class UserInfo
    {
        #region UserShortInfo 对象 到 UserTicketInfo 转换

        /// <summary>
        /// UserShortInfo 对象 到 UserTicketInfo 转换
        /// </summary>
        /// <returns></returns>
        public UserTicketInfo ToUserTicketInfo()
        {
            return ToUserTicketInfo(this);
        }

        /// <summary>
        /// UserShortInfo 对象 到 UserTicketInfo 转换
        /// </summary>
        /// <param name="suInfo"></param>
        /// <returns></returns>
        public UserTicketInfo ToUserTicketInfo(UserInfo suInfo)
        {
            return new UserTicketInfo(suInfo.UserID, suInfo.GameID, suInfo.Accounts, suInfo.LogonPass, suInfo.ProtectID);
        }

        #endregion

        /// <summary>
        /// 用户金币信息
        /// </summary>
        public Game.Entity.Treasure.GameScoreInfo GameScoreInfo
        {
            get;
            set;
        }

        /// <summary>
        /// 用户奖牌、魅力值信息
        /// </summary>
        public Game.Entity.Treasure.GameScoreInfoEx GameScoreInfoEx
        {
            get;
            set;
        }

        /// <summary>
        /// 用户金豆信息
        /// </summary>
        public Game.Entity.Treasure.UserGoldenBean UserGoldenBean
        {
            get;
            set;
        }

        /// <summary>
        /// 用户配置信息
        /// </summary>
        public Game.Entity.Accounts.AccountsConfig AccountsConfig
        {
            get;
            set;
        }

        /// <summary>
        /// 用户会员信息
        /// </summary>
        public IList<Game.Entity.Accounts.AccountsMember> AccountsMemberList
        {
            get;
            set;
        }
        /// <summary>
        /// 注册扩展信息
        /// </summary>
        public string ExternalMsg
        {
            set;
            get;
        }
        /// <summary>
        /// 经销商绑定确认
        /// </summary>
        public int IsConfirm { set; get; }
    }
}
