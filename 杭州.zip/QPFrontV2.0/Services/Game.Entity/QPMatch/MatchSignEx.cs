/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-08-11 14:38:45*/
/*Table:MatchSign*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
	public partial class MatchSign
	{
        /// <summary>
        /// 用户昵称
        /// </summary>
        public string NickName { get; set; }
	}
}
