/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-12-04 14:36:07*/
/*Table:MatchInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
    [XmlRoot("MatchInfo")]
	public partial class MatchInfoV1Xml
	{
        /// <summary>
        /// 标题图片
        /// </summary>
        public int LogoID { get; set; }
        /// <summary>
        /// 排序Id
        /// </summary>
        public int SortID { get; set; }
        /// <summary>
        /// 组权位
        /// </summary>
        public int GroupMask { get; set; }
        /// <summary>
        /// 比赛最高奖励
        /// </summary>
        public string SignMaxReward { get; set; }
        /// <summary>
        /// 报名条件
        /// </summary>
        public string SignCondition { get; set; }
        /// <summary>
        /// 有奖名次
        /// </summary>
        public int RewardCount { set; get; }
        /// <summary>
        /// 兑换开关：0是关  1是开
        /// </summary>
        public byte CDKey { get; set; }

        #region CDKeyWidth，CDKeyHeight
        /// <summary>
        /// 兑换页面宽度
        /// </summary>
        public int CDKeyWidth { set; get; }
        /// <summary>
        /// 兑换页面高度
        /// </summary>
        public int CDKeyHeight { set; get; }
        #endregion

        #region ClientVersion ImageVersion SoundVersion
        public int ClientVersion { get; set; }
        public int ImageVersion { get; set; }
        public int SoundVersion { get; set; }
        #endregion

        /// <summary>
        /// 广告图片Id, 为0则没有广告
        /// </summary>
        public int SlogansId { get; set; }
        /// <summary>
        /// 广告帧数
        /// </summary>
        public int SlogansFrameCount { get; set; }
        /// <summary>
        /// 广告播放速度
        /// </summary>
        public int SlogansFrameSpeed { get; set; }
        /// <summary>
        /// 广告点击事件-跳转到网页
        /// </summary>
        public string SlogansTouchEvent { get; set; }

        public DataTable MatchType0 { get; set; }

        public DataTable MatchType1 { get; set; }
	}
}
