/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-07-29 18:04:32*/
/*Table:MatchReward*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
	public partial class MatchReward
	{
        /// <summary>
        /// 比赛奖励内容
        /// </summary>
        public string RewardContent { get; set; }
	}
}
