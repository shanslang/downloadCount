/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-06-04 17:42:01*/
/*Table:MatchByTime*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
	public class MatchByTime
	{
		#region 构造函数
		public MatchByTime(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "MatchByTime";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchID = "MatchID";

		/// <summary>
		/// 比赛时长（单位秒）
		/// </summary>
		public const string _GameSec = "GameSec";

		/// <summary>
		/// 底分，0表示动态底分，要去动态底分库查询
		/// </summary>
		public const string _CellScore = "CellScore";

		/// <summary>
		/// 淘汰分数，低于此分将被淘汰，0表示不淘汰
		/// </summary>
		public const string _OutScore = "OutScore";

		/// <summary>
		/// 停止分配时间
		/// </summary>
		public const string _StopDispatchSec = "StopDispatchSec";

		/// <summary>
		/// 最小游戏局数
		/// </summary>
		public const string _minGameCount = "minGameCount";

		#endregion

		#region 私有变量
		private int m_MatchID;//
		private int m_GameSec;//比赛时长（单位秒）
		private long m_CellScore;//底分，0表示动态底分，要去动态底分库查询
		private long m_OutScore;//淘汰分数，低于此分将被淘汰，0表示不淘汰
		private int m_StopDispatchSec;//停止分配时间
		private int m_minGameCount;//最小游戏局数
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int MatchID
		{
			get { return m_MatchID; }
			set { m_MatchID = value; }
		}

		/// <summary>
		/// 比赛时长（单位秒）
		/// </summary>
		public int GameSec
		{
			get { return m_GameSec; }
			set { m_GameSec = value; }
		}

		/// <summary>
		/// 底分，0表示动态底分，要去动态底分库查询
		/// </summary>
		public long CellScore
		{
			get { return m_CellScore; }
			set { m_CellScore = value; }
		}

		/// <summary>
		/// 淘汰分数，低于此分将被淘汰，0表示不淘汰
		/// </summary>
		public long OutScore
		{
			get { return m_OutScore; }
			set { m_OutScore = value; }
		}

		/// <summary>
		/// 停止分配时间
		/// </summary>
		public int StopDispatchSec
		{
			get { return m_StopDispatchSec; }
			set { m_StopDispatchSec = value; }
		}

		/// <summary>
		/// 最小游戏局数
		/// </summary>
		public int minGameCount
		{
			get { return m_minGameCount; }
			set { m_minGameCount = value; }
		}

		#endregion

	}
}
