/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-12-08 14:28:11*/
/*Table:MatchByRound*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
	public class MatchByRound
	{
		#region 构造函数
		public MatchByRound(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "MatchByRound";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchID = "MatchID";

		/// <summary>
		/// 轮次
		/// </summary>
		public const string _Round = "Round";

		/// <summary>
		/// 本轮次局数
		/// </summary>
		public const string _PlayCount = "PlayCount";

		/// <summary>
		/// 直接晋级名次(桌)
		/// </summary>
		public const string _DirectRiseRank = "DirectRiseRank";

		/// <summary>
		/// 总晋级人数
		/// </summary>
		public const string _RiseRank = "RiseRank";

		/// <summary>
		/// 
		/// </summary>
		public const string _ScoreFun = "ScoreFun";

		/// <summary>
		/// 底分
		/// </summary>
		public const string _CellScore = "CellScore";

		#endregion

		#region 私有变量
		private int m_MatchID;//
		private int m_Round;//轮次
		private int m_PlayCount;//本轮次局数
		private int m_DirectRiseRank;//直接晋级名次(桌)
		private int m_RiseRank;//总晋级人数
		private string m_ScoreFun;//
		private long m_CellScore;//底分
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
        [XmlIgnore]
		public int MatchID
		{
			get { return m_MatchID; }
			set { m_MatchID = value; }
		}

		/// <summary>
		/// 轮次
		/// </summary>
        [XmlElement("rd")]
		public int Round
		{
			get { return m_Round; }
			set { m_Round = value; }
		}

		/// <summary>
		/// 本轮次局数
		/// </summary>
        [XmlElement("pcnt")]
		public int PlayCount
		{
			get { return m_PlayCount; }
			set { m_PlayCount = value; }
		}

		/// <summary>
		/// 直接晋级名次(桌)
		/// </summary>
        [XmlElement("drrank")]
		public int DirectRiseRank
		{
			get { return m_DirectRiseRank; }
			set { m_DirectRiseRank = value; }
		}

		/// <summary>
		/// 总晋级人数
		/// </summary>
        [XmlElement("rrank")]
		public int RiseRank
		{
			get { return m_RiseRank; }
			set { m_RiseRank = value; }
		}

		/// <summary>
		/// 
		/// </summary>
        [XmlIgnore]
		public string ScoreFun
		{
			get { return m_ScoreFun; }
			set { m_ScoreFun = value; }
		}

		/// <summary>
		/// 底分
		/// </summary>
        [XmlIgnore]
		public long CellScore
		{
			get { return m_CellScore; }
			set { m_CellScore = value; }
		}

		#endregion

	}
}
