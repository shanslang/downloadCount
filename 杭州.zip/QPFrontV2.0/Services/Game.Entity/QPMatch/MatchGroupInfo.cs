/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-11-25 16:43:47*/
/*Table:MatchGroupInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
	public class MatchGroupInfo
	{
		#region 构造函数
		public MatchGroupInfo(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "MatchGroupInfo";

		/// <summary>
		/// 
		/// </summary>
		public const string _Id = "Id";

		/// <summary>
		/// 
		/// </summary>
		public const string _KindId = "KindId";

		/// <summary>
		/// 
		/// </summary>
		public const string _Mask = "Mask";

		/// <summary>
		/// 
		/// </summary>
		public const string _SortID = "SortID";

		#endregion

		#region 私有变量
		private int m_Id;//
		private int m_KindId;//
		private int m_Mask;//
		private int m_SortID;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int Id
		{
			get { return m_Id; }
			set { m_Id = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int KindId
		{
			get { return m_KindId; }
			set { m_KindId = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int Mask
		{
			get { return m_Mask; }
			set { m_Mask = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int SortID
		{
			get { return m_SortID; }
			set { m_SortID = value; }
		}

		#endregion

	}
}
