/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-07-29 18:04:32*/
/*Table:MatchReward*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
    public partial class MatchReward
	{
		#region 构造函数
		public MatchReward(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "MatchReward";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchID = "MatchID";

		/// <summary>
		/// 奖励名次 0为安慰奖
		/// </summary>
		public const string _Rank = "Rank";

		/// <summary>
		/// 奖励类型 1-金币 2-经验值 3-奖牌 4-黄钻 5-红钻 6-蓝钻 65536以后是道具ID
		/// </summary>
		public const string _RewardType = "RewardType";

		/// <summary>
		/// 
		/// </summary>
		public const string _RewardValue = "RewardValue";

		/// <summary>
		/// 金币价值（用于实物计算改动多少房间控制）
		/// </summary>
		public const string _GoldWorth = "GoldWorth";

		#endregion

		#region 私有变量
		private int m_MatchID;//
		private int m_Rank;//奖励名次 0为安慰奖
		private int m_RewardType;//奖励类型 1-金币 2-经验值 3-奖牌 4-黄钻 5-红钻 6-蓝钻 65536以后是道具ID
		private long m_RewardValue;//
		private long m_GoldWorth;//金币价值（用于实物计算改动多少房间控制）
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int MatchID
		{
			get { return m_MatchID; }
			set { m_MatchID = value; }
		}

		/// <summary>
		/// 奖励名次 0为安慰奖
		/// </summary>
		public int Rank
		{
			get { return m_Rank; }
			set { m_Rank = value; }
		}

		/// <summary>
		/// 奖励类型 1-金币 2-经验值 3-奖牌 4-黄钻 5-红钻 6-蓝钻 65536以后是道具ID
		/// </summary>
		public int RewardType
		{
			get { return m_RewardType; }
			set { m_RewardType = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public long RewardValue
		{
			get { return m_RewardValue; }
			set { m_RewardValue = value; }
		}

		/// <summary>
		/// 金币价值（用于实物计算改动多少房间控制）
		/// </summary>
		public long GoldWorth
		{
			get { return m_GoldWorth; }
			set { m_GoldWorth = value; }
		}

		#endregion

	}
}
