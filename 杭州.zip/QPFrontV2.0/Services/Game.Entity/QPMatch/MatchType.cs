/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-12-04 15:19:34*/
/*Table:MatchType*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
	public class MatchTypeV1
	{
		#region 构造函数
        public MatchTypeV1() { }
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "MatchType";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchType = "MatchType";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchTypeName = "MatchTypeName";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchDll = "MatchDll";

		/// <summary>
		/// 
		/// </summary>
		public const string _TypeConfigTable = "TypeConfigTable";

		#endregion

		#region 私有变量
		private int m_MatchType;//
		private string m_MatchTypeName;//
		private string m_MatchDll;//
		private string m_TypeConfigTable;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int MatchType
		{
			get { return m_MatchType; }
			set { m_MatchType = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string MatchTypeName
		{
			get { return m_MatchTypeName; }
			set { m_MatchTypeName = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string MatchDll
		{
			get { return m_MatchDll; }
			set { m_MatchDll = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string TypeConfigTable
		{
			get { return m_TypeConfigTable; }
			set { m_TypeConfigTable = value; }
		}

		#endregion

	}
}
