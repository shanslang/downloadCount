/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-12-11 17:08:16*/
/*Table:MatchInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
	public partial class MatchInfo
	{
		#region 构造函数
		public MatchInfo(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "MatchInfo";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchID = "MatchID";

		/// <summary>
		/// 下一场比赛的子ID
		/// </summary>
		public const string _MatchRoundID = "MatchRoundID";

		/// <summary>
		/// 标题图片
		/// </summary>
		public const string _LogoID = "LogoID";

		/// <summary>
		/// 
		/// </summary>
		public const string _SortID = "SortID";

		/// <summary>
		/// 
		/// </summary>
		public const string _KindID = "KindID";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchName = "MatchName";

		/// <summary>
		/// 开赛模式， 1-定时开赛 2-人满开赛
		/// </summary>
		public const string _StartType = "StartType";

		/// <summary>
		/// 赛制类型
		/// </summary>
		public const string _MatchType = "MatchType";

		/// <summary>
		/// 一局游戏时间
		/// </summary>
		public const string _OneGameSec = "OneGameSec";

		/// <summary>
		/// 初始积分
		/// </summary>
		public const string _InitScore = "InitScore";

		/// <summary>
		/// 有效时间（开始）
		/// </summary>
		public const string _ValidStartTime = "ValidStartTime";

		/// <summary>
		/// 有效时间（结束）
		/// </summary>
		public const string _ValidEndTime = "ValidEndTime";

		/// <summary>
		/// 赛前N秒显示，0表示一直显示
		/// </summary>
		public const string _ValidShowSec = "ValidShowSec";

		/// <summary>
		/// 有效报名时间（比赛开始前的秒数）0表示不限制
		/// </summary>
		public const string _ValidSignSec = "ValidSignSec";

		/// <summary>
		/// 有效退赛时间（比赛开始前秒数）0表示随时可退赛
		/// </summary>
		public const string _ValidUnSignSec = "ValidUnSignSec";

		/// <summary>
		/// 下场开赛时间
		/// </summary>
		public const string _NextMatchStart = "NextMatchStart";

		/// <summary>
		/// 
		/// </summary>
		public const string _LoopStartTime = "LoopStartTime";

		/// <summary>
		/// 
		/// </summary>
		public const string _LoopEndTime = "LoopEndTime";

		/// <summary>
		/// 小循环，循环类型 0-不循环 1-每N天 2-每N周 3-每N月 4-每N秒
		/// </summary>
		public const string _LoopinsideType = "LoopinsideType";

		/// <summary>
		/// 
		/// </summary>
		public const string _LoopinsideValue = "LoopinsideValue";

		/// <summary>
		/// 大循环，循环类型 0-不循环 1-每N天 2-每N周 3-每N月
		/// </summary>
		public const string _LoopoutsideType = "LoopoutsideType";

		/// <summary>
		/// 
		/// </summary>
		public const string _LoopoutsideValue = "LoopoutsideValue";

		/// <summary>
		/// 最小报名人数 0为不限
		/// </summary>
		public const string _MinSignCount = "MinSignCount";

		/// <summary>
		/// 最大报名人数 0为不限
		/// </summary>
		public const string _MaxSignCount = "MaxSignCount";

		/// <summary>
		/// 发送参赛者列表数，0表示不发送列表及当前排名
		/// </summary>
		public const string _UserListCount = "UserListCount";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchRemarkInfo = "MatchRemarkInfo";

		/// <summary>
		/// 组权位
		/// </summary>
		public const string _GroupMask = "GroupMask";

		/// <summary>
		/// 冠名合作赛冠名名称展示
		/// </summary>
		public const string _MatchSlogans = "MatchSlogans";

		/// <summary>
		/// 
		/// </summary>
		public const string _SignMaxReward = "SignMaxReward";

		/// <summary>
		/// 
		/// </summary>
		public const string _SignCondition = "SignCondition";

		/// <summary>
		/// 兑换开关：0是关  1是开
		/// </summary>
		public const string _CDKey = "CDKey";

		/// <summary>
		/// 
		/// </summary>
		public const string _HideByChannel = "HideByChannel";

		/// <summary>
		/// 广告图片Id, 为0则没有广告
		/// </summary>
		public const string _SlogansId = "SlogansId";

		/// <summary>
		/// 广告帧数
		/// </summary>
		public const string _SlogansFrameCount = "SlogansFrameCount";

		/// <summary>
		/// 广告播放速度
		/// </summary>
		public const string _SlogansFrameSpeed = "SlogansFrameSpeed";

		/// <summary>
		/// 广告点击事件-跳转到网页
		/// </summary>
		public const string _SlogansTouchEvent = "SlogansTouchEvent";

		/// <summary>
		/// 
		/// </summary>
		public const string _NextMatchID = "NextMatchID";

		/// <summary>
		/// 
		/// </summary>
		public const string _AndroidTempId = "AndroidTempId";

		/// <summary>
		/// 
		/// </summary>
		public const string _AndroidSignFuc = "AndroidSignFuc";

		#endregion

		#region 私有变量
		private int m_MatchID;//
		private int m_MatchRoundID;//下一场比赛的子ID
		private int m_LogoID;//标题图片
		private int m_SortID;//
		private int m_KindID;//
		private string m_MatchName;//
		private byte m_StartType;//开赛模式， 1-定时开赛 2-人满开赛
		private int m_MatchType;//赛制类型
		private int m_OneGameSec;//一局游戏时间
		private long m_InitScore;//初始积分
		private DateTime m_ValidStartTime;//有效时间（开始）
		private DateTime m_ValidEndTime;//有效时间（结束）
		private int m_ValidShowSec;//赛前N秒显示，0表示一直显示
		private int m_ValidSignSec;//有效报名时间（比赛开始前的秒数）0表示不限制
		private int m_ValidUnSignSec;//有效退赛时间（比赛开始前秒数）0表示随时可退赛
		private DateTime m_NextMatchStart;//下场开赛时间
		private DateTime m_LoopStartTime;//
		private DateTime m_LoopEndTime;//
		private byte m_LoopinsideType;//小循环，循环类型 0-不循环 1-每N天 2-每N周 3-每N月 4-每N秒
		private int m_LoopinsideValue;//
		private byte m_LoopoutsideType;//大循环，循环类型 0-不循环 1-每N天 2-每N周 3-每N月
		private int m_LoopoutsideValue;//
		private int m_MinSignCount;//最小报名人数 0为不限
		private int m_MaxSignCount;//最大报名人数 0为不限
		private int m_UserListCount;//发送参赛者列表数，0表示不发送列表及当前排名
		private string m_MatchRemarkInfo;//
		private int m_GroupMask;//组权位
		private string m_MatchSlogans;//冠名合作赛冠名名称展示
		private string m_SignMaxReward;//
		private string m_SignCondition;//
		private byte m_CDKey;//兑换开关：0是关  1是开
		private byte m_HideByChannel;//
		private int m_SlogansId;//广告图片Id, 为0则没有广告
		private int m_SlogansFrameCount;//广告帧数
		private int m_SlogansFrameSpeed;//广告播放速度
		private string m_SlogansTouchEvent;//广告点击事件-跳转到网页
		private int m_NextMatchID;//
		private int m_AndroidTempId;//
		private string m_AndroidSignFuc;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int MatchID
		{
			get { return m_MatchID; }
			set { m_MatchID = value; }
		}

		/// <summary>
		/// 下一场比赛的子ID
		/// </summary>
		public int MatchRoundID
		{
			get { return m_MatchRoundID; }
			set { m_MatchRoundID = value; }
		}

		/// <summary>
		/// 标题图片
		/// </summary>
		public int LogoID
		{
			get { return m_LogoID; }
			set { m_LogoID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int SortID
		{
			get { return m_SortID; }
			set { m_SortID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int KindID
		{
			get { return m_KindID; }
			set { m_KindID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string MatchName
		{
			get { return m_MatchName; }
			set { m_MatchName = value; }
		}

		/// <summary>
		/// 开赛模式， 1-定时开赛 2-人满开赛
		/// </summary>
		public byte StartType
		{
			get { return m_StartType; }
			set { m_StartType = value; }
		}

		/// <summary>
		/// 赛制类型
		/// </summary>
		public int MatchType
		{
			get { return m_MatchType; }
			set { m_MatchType = value; }
		}

		/// <summary>
		/// 一局游戏时间
		/// </summary>
		public int OneGameSec
		{
			get { return m_OneGameSec; }
			set { m_OneGameSec = value; }
		}

		/// <summary>
		/// 初始积分
		/// </summary>
		public long InitScore
		{
			get { return m_InitScore; }
			set { m_InitScore = value; }
		}

		/// <summary>
		/// 有效时间（开始）
		/// </summary>
		public DateTime ValidStartTime
		{
			get { return m_ValidStartTime; }
			set { m_ValidStartTime = value; }
		}

		/// <summary>
		/// 有效时间（结束）
		/// </summary>
		public DateTime ValidEndTime
		{
			get { return m_ValidEndTime; }
			set { m_ValidEndTime = value; }
		}

		/// <summary>
		/// 赛前N秒显示，0表示一直显示
		/// </summary>
		public int ValidShowSec
		{
			get { return m_ValidShowSec; }
			set { m_ValidShowSec = value; }
		}

		/// <summary>
		/// 有效报名时间（比赛开始前的秒数）0表示不限制
		/// </summary>
		public int ValidSignSec
		{
			get { return m_ValidSignSec; }
			set { m_ValidSignSec = value; }
		}

		/// <summary>
		/// 有效退赛时间（比赛开始前秒数）0表示随时可退赛
		/// </summary>
		public int ValidUnSignSec
		{
			get { return m_ValidUnSignSec; }
			set { m_ValidUnSignSec = value; }
		}

		/// <summary>
		/// 下场开赛时间
		/// </summary>
		public DateTime NextMatchStart
		{
			get { return m_NextMatchStart; }
			set { m_NextMatchStart = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime LoopStartTime
		{
			get { return m_LoopStartTime; }
			set { m_LoopStartTime = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime LoopEndTime
		{
			get { return m_LoopEndTime; }
			set { m_LoopEndTime = value; }
		}

		/// <summary>
		/// 小循环，循环类型 0-不循环 1-每N天 2-每N周 3-每N月 4-每N秒
		/// </summary>
		public byte LoopinsideType
		{
			get { return m_LoopinsideType; }
			set { m_LoopinsideType = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int LoopinsideValue
		{
			get { return m_LoopinsideValue; }
			set { m_LoopinsideValue = value; }
		}

		/// <summary>
		/// 大循环，循环类型 0-不循环 1-每N天 2-每N周 3-每N月
		/// </summary>
		public byte LoopoutsideType
		{
			get { return m_LoopoutsideType; }
			set { m_LoopoutsideType = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int LoopoutsideValue
		{
			get { return m_LoopoutsideValue; }
			set { m_LoopoutsideValue = value; }
		}

		/// <summary>
		/// 最小报名人数 0为不限
		/// </summary>
		public int MinSignCount
		{
			get { return m_MinSignCount; }
			set { m_MinSignCount = value; }
		}

		/// <summary>
		/// 最大报名人数 0为不限
		/// </summary>
		public int MaxSignCount
		{
			get { return m_MaxSignCount; }
			set { m_MaxSignCount = value; }
		}

		/// <summary>
		/// 发送参赛者列表数，0表示不发送列表及当前排名
		/// </summary>
		public int UserListCount
		{
			get { return m_UserListCount; }
			set { m_UserListCount = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string MatchRemarkInfo
		{
			get { return m_MatchRemarkInfo; }
			set { m_MatchRemarkInfo = value; }
		}

		/// <summary>
		/// 组权位
		/// </summary>
		public int GroupMask
		{
			get { return m_GroupMask; }
			set { m_GroupMask = value; }
		}

		/// <summary>
		/// 冠名合作赛冠名名称展示
		/// </summary>
		public string MatchSlogans
		{
			get { return m_MatchSlogans; }
			set { m_MatchSlogans = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string SignMaxReward
		{
			get { return m_SignMaxReward; }
			set { m_SignMaxReward = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string SignCondition
		{
			get { return m_SignCondition; }
			set { m_SignCondition = value; }
		}

		/// <summary>
		/// 兑换开关：0是关  1是开
		/// </summary>
		public byte CDKey
		{
			get { return m_CDKey; }
			set { m_CDKey = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public byte HideByChannel
		{
			get { return m_HideByChannel; }
			set { m_HideByChannel = value; }
		}

		/// <summary>
		/// 广告图片Id, 为0则没有广告
		/// </summary>
		public int SlogansId
		{
			get { return m_SlogansId; }
			set { m_SlogansId = value; }
		}

		/// <summary>
		/// 广告帧数
		/// </summary>
		public int SlogansFrameCount
		{
			get { return m_SlogansFrameCount; }
			set { m_SlogansFrameCount = value; }
		}

		/// <summary>
		/// 广告播放速度
		/// </summary>
		public int SlogansFrameSpeed
		{
			get { return m_SlogansFrameSpeed; }
			set { m_SlogansFrameSpeed = value; }
		}

		/// <summary>
		/// 广告点击事件-跳转到网页
		/// </summary>
		public string SlogansTouchEvent
		{
			get { return m_SlogansTouchEvent; }
			set { m_SlogansTouchEvent = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int NextMatchID
		{
			get { return m_NextMatchID; }
			set { m_NextMatchID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int AndroidTempId
		{
			get { return m_AndroidTempId; }
			set { m_AndroidTempId = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string AndroidSignFuc
		{
			get { return m_AndroidSignFuc; }
			set { m_AndroidSignFuc = value; }
		}

		#endregion

	}
}
