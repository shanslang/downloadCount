/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-08-11 14:38:45*/
/*Table:MatchSign*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
    public partial class MatchSign
	{
		#region 构造函数
		public MatchSign(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "MatchSign";

		/// <summary>
		/// 
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchID = "MatchID";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchSubID = "MatchSubID";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchTicket = "MatchTicket";

		/// <summary>
		/// 
		/// </summary>
		public const string _InsertTime = "InsertTime";

		#endregion

		#region 私有变量
		private int m_UserID;//
		private int m_MatchID;//
		private int m_MatchSubID;//
		private string m_MatchTicket;//
		private DateTime m_InsertTime;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int MatchID
		{
			get { return m_MatchID; }
			set { m_MatchID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int MatchSubID
		{
			get { return m_MatchSubID; }
			set { m_MatchSubID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string MatchTicket
		{
			get { return m_MatchTicket; }
			set { m_MatchTicket = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime InsertTime
		{
			get { return m_InsertTime; }
			set { m_InsertTime = value; }
		}

		#endregion

	}
}
