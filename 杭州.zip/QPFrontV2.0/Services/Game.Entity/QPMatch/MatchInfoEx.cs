/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-06-04 17:29:38*/
/*Table:MatchInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.QPMatch
{
    public partial class MatchInfo
    {
        /// <summary>
        /// 比赛配置表名
        /// </summary>
        public string TypeConfigTable { get; set; }

        #region 公开属性

        /// <summary>
        /// 比赛时长（单位秒）
        /// </summary>
        public int GameSec
        {
            get;
            set;
        }

        /// <summary>
        /// 底分，0表示动态底分，要去动态底分库查询
        /// </summary>
        public long CellScore
        {
            get;
            set;
        }

        /// <summary>
        /// 淘汰分数，低于此分将被淘汰，0表示不淘汰
        /// </summary>
        public long OutScore
        {
            get;
            set;
        }

        /// <summary>
        /// 停止分配时间
        /// </summary>
        public int StopDispatchSec
        {
            get;
            set;
        }

        /// <summary>
        /// 最小游戏局数
        /// </summary>
        public int minGameCount
        {
            get;
            set;
        }

        /// <summary>
        /// 这个字段就是表明了有多少个获奖的 前多少名有奖，那么后面的就是淘汰了
        /// </summary>
        public int RewardCount
        {
            get;
            set;
        }

        /// <summary>
        /// 报名条件
        /// </summary>
        public string SignCond
        {
            get;
            set;
        }

        // <summary>
        /// 最高奖励
        /// </summary>
        public string Reward
        {
            get;
            set;
        }

        #endregion

        #region 时间Format
        public double ValidStartTimeEx
        {
            set { }
            get
            {
                return (this.ValidStartTime - DateTime.Parse("2000-01-01 00:00:00")).TotalSeconds;
            }
        }
        public double ValidEndTimeEx
        {
            set { }
            get
            {
                return (ValidEndTime - DateTime.Parse("2000-01-01 00:00:00")).TotalSeconds;
            }
        }
        public double NextMatchStartEx
        {
            set { }
            get
            {
                return (NextMatchStart - DateTime.Parse("2000-01-01 00:00:00")).TotalSeconds;
            }
        }
        public double LoopStartTimeEx
        {
            set { }
            get
            {
                return (LoopStartTime - DateTime.Parse("2000-01-01 00:00:00")).TotalSeconds;
            }
        }
        public double LoopEndTimeEx
        {
            set { }
            get
            {
                return (LoopEndTime - DateTime.Parse("2000-01-01 00:00:00")).TotalSeconds;
            }
        }
        #endregion

        #region ClientVersion ImageVersion SoundVersion
        public int ClientVersion { get; set; }
        public int ImageVersion { get; set; }
        public int SoundVersion { get; set; }
        #endregion

        #region CDKeyWidth，CDKeyHeight
        /// <summary>
        /// 兑换页面宽度
        /// </summary>
        public int CDKeyWidth { set; get; }
        /// <summary>
        /// 兑换页面高度
        /// </summary>
        public int CDKeyHeight { set; get; }
        #endregion

        [XmlElement("mrcnt")]
        public int MatchByRoundItemsCount { set; get; }
        [XmlArray("mritems"), XmlArrayItem("i")]
        public List<MatchByRound> MatchByRoundItems { set; get; }

        #region MatchCost
        public string MatchCost { set; get; }
        #endregion
        public int HideMatchView { set; get; }
    }
}
