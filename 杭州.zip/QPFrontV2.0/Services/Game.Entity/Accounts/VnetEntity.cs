﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Entity.Accounts
{
    public class VnetEntity
    {
        public int ID { set; get; }
        public string UserID { set; get; }
        public string VnetID { set; get; }
        public string Tel { set; get; }
        public string ImSi { set; get; }
    }
}
