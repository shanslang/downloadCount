/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-05-13 14:18:07*/
/*Table:AccountsInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Accounts
{
	public class AccountsInfo
	{
		#region 构造函数
		public AccountsInfo(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "AccountsInfo";

		/// <summary>
		/// 用户标识
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 游戏标识
		/// </summary>
		public const string _GameID = "GameID";

		/// <summary>
		/// 密保标识
		/// </summary>
		public const string _ProtectID = "ProtectID";

		/// <summary>
		/// 口令索引
		/// </summary>
		public const string _PasswordID = "PasswordID";

		/// <summary>
		/// 推广员标识
		/// </summary>
		public const string _SpreaderID = "SpreaderID";

		/// <summary>
		/// 用户帐号
		/// </summary>
		public const string _Accounts = "Accounts";

		/// <summary>
		/// 用户昵称
		/// </summary>
		public const string _NickName = "NickName";

		/// <summary>
		/// 注册帐号
		/// </summary>
		public const string _RegAccounts = "RegAccounts";

		/// <summary>
		/// 个性签名
		/// </summary>
		public const string _UnderWrite = "UnderWrite";

		/// <summary>
		/// 身份证号
		/// </summary>
		public const string _PassPortID = "PassPortID";

		/// <summary>
		/// 真实名字
		/// </summary>
		public const string _Compellation = "Compellation";

		/// <summary>
		/// 登录密码
		/// </summary>
		public const string _LogonPass = "LogonPass";

		/// <summary>
		/// 安全密码
		/// </summary>
		public const string _InsurePass = "InsurePass";

		/// <summary>
		/// 头像标识
		/// </summary>
		public const string _FaceID = "FaceID";

		/// <summary>
		/// 自定标识
		/// </summary>
		public const string _CustomID = "CustomID";

		/// <summary>
		/// 赠送礼物
		/// </summary>
		public const string _Present = "Present";

		/// <summary>
		/// 经验数值
		/// </summary>
		public const string _Experience = "Experience";

		/// <summary>
		/// 用户权限
		/// </summary>
		public const string _UserRight = "UserRight";

		/// <summary>
		/// 管理权限
		/// </summary>
		public const string _MasterRight = "MasterRight";

		/// <summary>
		/// 服务权限
		/// </summary>
		public const string _ServiceRight = "ServiceRight";

		/// <summary>
		/// 管理等级
		/// </summary>
		public const string _MasterOrder = "MasterOrder";

		/// <summary>
		/// 会员等级
		/// </summary>
		public const string _MemberOrder = "MemberOrder";

		/// <summary>
		/// 过期日期
		/// </summary>
		public const string _MemberOverDate = "MemberOverDate";

		/// <summary>
		/// 切换时间
		/// </summary>
		public const string _MemberSwitchDate = "MemberSwitchDate";

		/// <summary>
		/// 头像版本
		/// </summary>
		public const string _CustomFaceVer = "CustomFaceVer";

		/// <summary>
		/// 用户性别
		/// </summary>
		public const string _Gender = "Gender";

		/// <summary>
		/// 禁止服务
		/// </summary>
		public const string _Nullity = "Nullity";

		/// <summary>
		/// 禁止时间
		/// </summary>
		public const string _NullityOverDate = "NullityOverDate";

		/// <summary>
		/// 关闭标志
		/// </summary>
		public const string _StunDown = "StunDown";

		/// <summary>
		/// 固定机器
		/// </summary>
		public const string _MoorMachine = "MoorMachine";

		/// <summary>
		/// 是否机器人
		/// </summary>
		public const string _IsAndroid = "IsAndroid";

		/// <summary>
		/// 登录次数
		/// </summary>
		public const string _WebLogonTimes = "WebLogonTimes";

		/// <summary>
		/// 登录次数
		/// </summary>
		public const string _GameLogonTimes = "GameLogonTimes";

		/// <summary>
		/// 游戏时间
		/// </summary>
		public const string _PlayTimeCount = "PlayTimeCount";

		/// <summary>
		/// 在线时间
		/// </summary>
		public const string _OnLineTimeCount = "OnLineTimeCount";

		/// <summary>
		/// 登录地址
		/// </summary>
		public const string _LastLogonIP = "LastLogonIP";

		/// <summary>
		/// 登录时间
		/// </summary>
		public const string _LastLogonDate = "LastLogonDate";

		/// <summary>
		/// 登录手机
		/// </summary>
		public const string _LastLogonMobile = "LastLogonMobile";

		/// <summary>
		/// 登录机器
		/// </summary>
		public const string _LastLogonMachine = "LastLogonMachine";

		/// <summary>
		/// 注册地址
		/// </summary>
		public const string _RegisterIP = "RegisterIP";

		/// <summary>
		/// 注册时间
		/// </summary>
		public const string _RegisterDate = "RegisterDate";

		/// <summary>
		/// 注册手机
		/// </summary>
		public const string _RegisterMobile = "RegisterMobile";

		/// <summary>
		/// 注册机器
		/// </summary>
		public const string _RegisterMachine = "RegisterMachine";

		/// <summary>
		/// 注册来源 0-PC 1-网页 2-手机
		/// </summary>
		public const string _RegisterMode = "RegisterMode";

		/// <summary>
		/// 
		/// </summary>
		public const string _PlatformID = "PlatformID";

		/// <summary>
		/// 
		/// </summary>
		public const string _UserUin = "UserUin";

		/// <summary>
		/// 
		/// </summary>
		public const string _AuthMTelephone = "AuthMTelephone";

		/// <summary>
		/// 
		/// </summary>
		public const string _AuthMTelephoneDate = "AuthMTelephoneDate";

		/// <summary>
		/// 
		/// </summary>
		public const string _AuthEmail = "AuthEmail";

		/// <summary>
		/// 
		/// </summary>
		public const string _AuthEmailDate = "AuthEmailDate";

		/// <summary>
		/// 
		/// </summary>
		public const string _LastUserTask = "LastUserTask";

		/// <summary>
		/// 
		/// </summary>
		public const string _PCWebKey = "PCWebKey";

		/// <summary>
		/// 
		/// </summary>
		public const string _IOSWebKey = "IOSWebKey";

		/// <summary>
		/// 
		/// </summary>
		public const string _AndroidWebKey = "AndroidWebKey";

		/// <summary>
		/// 玩家可以看到的房间权位
		/// </summary>
		public const string _ServerRight = "ServerRight";

		/// <summary>
		/// 推广来源ID
		/// </summary>
		public const string _AdID = "AdID";

		#endregion

		#region 私有变量
		private int m_UserID;//用户标识
		private int m_GameID;//游戏标识
		private int m_ProtectID;//密保标识
		private int m_PasswordID;//口令索引
		private int m_SpreaderID;//推广员标识
		private string m_Accounts;//用户帐号
		private string m_NickName;//用户昵称
		private string m_RegAccounts;//注册帐号
		private string m_UnderWrite;//个性签名
		private string m_PassPortID;//身份证号
		private string m_Compellation;//真实名字
		private string m_LogonPass;//登录密码
		private string m_InsurePass;//安全密码
		private int m_FaceID;//头像标识
		private int m_CustomID;//自定标识
		private int m_Present;//赠送礼物
		private int m_Experience;//经验数值
		private int m_UserRight;//用户权限
		private int m_MasterRight;//管理权限
		private int m_ServiceRight;//服务权限
		private byte m_MasterOrder;//管理等级
		private byte m_MemberOrder;//会员等级
		private DateTime m_MemberOverDate;//过期日期
		private DateTime m_MemberSwitchDate;//切换时间
		private byte m_CustomFaceVer;//头像版本
		private byte m_Gender;//用户性别
		private byte m_Nullity;//禁止服务
		private DateTime m_NullityOverDate;//禁止时间
		private byte m_StunDown;//关闭标志
		private byte m_MoorMachine;//固定机器
		private byte m_IsAndroid;//是否机器人
		private int m_WebLogonTimes;//登录次数
		private int m_GameLogonTimes;//登录次数
		private int m_PlayTimeCount;//游戏时间
		private int m_OnLineTimeCount;//在线时间
		private string m_LastLogonIP;//登录地址
		private DateTime m_LastLogonDate;//登录时间
		private string m_LastLogonMobile;//登录手机
		private string m_LastLogonMachine;//登录机器
		private string m_RegisterIP;//注册地址
		private DateTime m_RegisterDate;//注册时间
		private string m_RegisterMobile;//注册手机
		private string m_RegisterMachine;//注册机器
		private byte m_RegisterMode;//注册来源 0-PC 1-网页 2-手机
		private byte m_PlatformID;//
		private string m_UserUin;//
		private string m_AuthMTelephone;//
		private DateTime m_AuthMTelephoneDate;//
		private string m_AuthEmail;//
		private DateTime m_AuthEmailDate;//
		private DateTime m_LastUserTask;//
		private string m_PCWebKey;//
		private string m_IOSWebKey;//
		private string m_AndroidWebKey;//
		private int m_ServerRight;//玩家可以看到的房间权位
		private int m_AdID;//推广来源ID
		#endregion

		#region 公开属性

		/// <summary>
		/// 用户标识
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 游戏标识
		/// </summary>
		public int GameID
		{
			get { return m_GameID; }
			set { m_GameID = value; }
		}

		/// <summary>
		/// 密保标识
		/// </summary>
		public int ProtectID
		{
			get { return m_ProtectID; }
			set { m_ProtectID = value; }
		}

		/// <summary>
		/// 口令索引
		/// </summary>
		public int PasswordID
		{
			get { return m_PasswordID; }
			set { m_PasswordID = value; }
		}

		/// <summary>
		/// 推广员标识
		/// </summary>
		public int SpreaderID
		{
			get { return m_SpreaderID; }
			set { m_SpreaderID = value; }
		}

		/// <summary>
		/// 用户帐号
		/// </summary>
		public string Accounts
		{
			get { return m_Accounts; }
			set { m_Accounts = value; }
		}

		/// <summary>
		/// 用户昵称
		/// </summary>
		public string NickName
		{
			get { return m_NickName; }
			set { m_NickName = value; }
		}

		/// <summary>
		/// 注册帐号
		/// </summary>
		public string RegAccounts
		{
			get { return m_RegAccounts; }
			set { m_RegAccounts = value; }
		}

		/// <summary>
		/// 个性签名
		/// </summary>
		public string UnderWrite
		{
			get { return m_UnderWrite; }
			set { m_UnderWrite = value; }
		}

		/// <summary>
		/// 身份证号
		/// </summary>
		public string PassPortID
		{
			get { return m_PassPortID; }
			set { m_PassPortID = value; }
		}

		/// <summary>
		/// 真实名字
		/// </summary>
		public string Compellation
		{
			get { return m_Compellation; }
			set { m_Compellation = value; }
		}

		/// <summary>
		/// 登录密码
		/// </summary>
		public string LogonPass
		{
			get { return m_LogonPass; }
			set { m_LogonPass = value; }
		}

		/// <summary>
		/// 安全密码
		/// </summary>
		public string InsurePass
		{
			get { return m_InsurePass; }
			set { m_InsurePass = value; }
		}

		/// <summary>
		/// 头像标识
		/// </summary>
		public int FaceID
		{
			get { return m_FaceID; }
			set { m_FaceID = value; }
		}

		/// <summary>
		/// 自定标识
		/// </summary>
		public int CustomID
		{
			get { return m_CustomID; }
			set { m_CustomID = value; }
		}

		/// <summary>
		/// 赠送礼物
		/// </summary>
		public int Present
		{
			get { return m_Present; }
			set { m_Present = value; }
		}

		/// <summary>
		/// 经验数值
		/// </summary>
		public int Experience
		{
			get { return m_Experience; }
			set { m_Experience = value; }
		}

		/// <summary>
		/// 用户权限
		/// </summary>
		public int UserRight
		{
			get { return m_UserRight; }
			set { m_UserRight = value; }
		}

		/// <summary>
		/// 管理权限
		/// </summary>
		public int MasterRight
		{
			get { return m_MasterRight; }
			set { m_MasterRight = value; }
		}

		/// <summary>
		/// 服务权限
		/// </summary>
		public int ServiceRight
		{
			get { return m_ServiceRight; }
			set { m_ServiceRight = value; }
		}

		/// <summary>
		/// 管理等级
		/// </summary>
		public byte MasterOrder
		{
			get { return m_MasterOrder; }
			set { m_MasterOrder = value; }
		}

		/// <summary>
		/// 会员等级
		/// </summary>
		public byte MemberOrder
		{
			get { return m_MemberOrder; }
			set { m_MemberOrder = value; }
		}

		/// <summary>
		/// 过期日期
		/// </summary>
		public DateTime MemberOverDate
		{
			get { return m_MemberOverDate; }
			set { m_MemberOverDate = value; }
		}

		/// <summary>
		/// 切换时间
		/// </summary>
		public DateTime MemberSwitchDate
		{
			get { return m_MemberSwitchDate; }
			set { m_MemberSwitchDate = value; }
		}

		/// <summary>
		/// 头像版本
		/// </summary>
		public byte CustomFaceVer
		{
			get { return m_CustomFaceVer; }
			set { m_CustomFaceVer = value; }
		}

		/// <summary>
		/// 用户性别
		/// </summary>
		public byte Gender
		{
			get { return m_Gender; }
			set { m_Gender = value; }
		}

		/// <summary>
		/// 禁止服务
		/// </summary>
		public byte Nullity
		{
			get { return m_Nullity; }
			set { m_Nullity = value; }
		}

		/// <summary>
		/// 禁止时间
		/// </summary>
		public DateTime NullityOverDate
		{
			get { return m_NullityOverDate; }
			set { m_NullityOverDate = value; }
		}

		/// <summary>
		/// 关闭标志
		/// </summary>
		public byte StunDown
		{
			get { return m_StunDown; }
			set { m_StunDown = value; }
		}

		/// <summary>
		/// 固定机器
		/// </summary>
		public byte MoorMachine
		{
			get { return m_MoorMachine; }
			set { m_MoorMachine = value; }
		}

		/// <summary>
		/// 是否机器人
		/// </summary>
		public byte IsAndroid
		{
			get { return m_IsAndroid; }
			set { m_IsAndroid = value; }
		}

		/// <summary>
		/// 登录次数
		/// </summary>
		public int WebLogonTimes
		{
			get { return m_WebLogonTimes; }
			set { m_WebLogonTimes = value; }
		}

		/// <summary>
		/// 登录次数
		/// </summary>
		public int GameLogonTimes
		{
			get { return m_GameLogonTimes; }
			set { m_GameLogonTimes = value; }
		}

		/// <summary>
		/// 游戏时间
		/// </summary>
		public int PlayTimeCount
		{
			get { return m_PlayTimeCount; }
			set { m_PlayTimeCount = value; }
		}

		/// <summary>
		/// 在线时间
		/// </summary>
		public int OnLineTimeCount
		{
			get { return m_OnLineTimeCount; }
			set { m_OnLineTimeCount = value; }
		}

		/// <summary>
		/// 登录地址
		/// </summary>
		public string LastLogonIP
		{
			get { return m_LastLogonIP; }
			set { m_LastLogonIP = value; }
		}

		/// <summary>
		/// 登录时间
		/// </summary>
		public DateTime LastLogonDate
		{
			get { return m_LastLogonDate; }
			set { m_LastLogonDate = value; }
		}

		/// <summary>
		/// 登录手机
		/// </summary>
		public string LastLogonMobile
		{
			get { return m_LastLogonMobile; }
			set { m_LastLogonMobile = value; }
		}

		/// <summary>
		/// 登录机器
		/// </summary>
		public string LastLogonMachine
		{
			get { return m_LastLogonMachine; }
			set { m_LastLogonMachine = value; }
		}

		/// <summary>
		/// 注册地址
		/// </summary>
		public string RegisterIP
		{
			get { return m_RegisterIP; }
			set { m_RegisterIP = value; }
		}

		/// <summary>
		/// 注册时间
		/// </summary>
		public DateTime RegisterDate
		{
			get { return m_RegisterDate; }
			set { m_RegisterDate = value; }
		}

		/// <summary>
		/// 注册手机
		/// </summary>
		public string RegisterMobile
		{
			get { return m_RegisterMobile; }
			set { m_RegisterMobile = value; }
		}

		/// <summary>
		/// 注册机器
		/// </summary>
		public string RegisterMachine
		{
			get { return m_RegisterMachine; }
			set { m_RegisterMachine = value; }
		}

		/// <summary>
		/// 注册来源 0-PC 1-网页 2-手机
		/// </summary>
		public byte RegisterMode
		{
			get { return m_RegisterMode; }
			set { m_RegisterMode = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public byte PlatformID
		{
			get { return m_PlatformID; }
			set { m_PlatformID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string UserUin
		{
			get { return m_UserUin; }
			set { m_UserUin = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string AuthMTelephone
		{
			get { return m_AuthMTelephone; }
			set { m_AuthMTelephone = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime AuthMTelephoneDate
		{
			get { return m_AuthMTelephoneDate; }
			set { m_AuthMTelephoneDate = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string AuthEmail
		{
			get { return m_AuthEmail; }
			set { m_AuthEmail = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime AuthEmailDate
		{
			get { return m_AuthEmailDate; }
			set { m_AuthEmailDate = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime LastUserTask
		{
			get { return m_LastUserTask; }
			set { m_LastUserTask = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string PCWebKey
		{
			get { return m_PCWebKey; }
			set { m_PCWebKey = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string IOSWebKey
		{
			get { return m_IOSWebKey; }
			set { m_IOSWebKey = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string AndroidWebKey
		{
			get { return m_AndroidWebKey; }
			set { m_AndroidWebKey = value; }
		}

		/// <summary>
		/// 玩家可以看到的房间权位
		/// </summary>
		public int ServerRight
		{
			get { return m_ServerRight; }
			set { m_ServerRight = value; }
		}

		/// <summary>
		/// 推广来源ID
		/// </summary>
		public int AdID
		{
			get { return m_AdID; }
			set { m_AdID = value; }
		}

		#endregion

	}
}
