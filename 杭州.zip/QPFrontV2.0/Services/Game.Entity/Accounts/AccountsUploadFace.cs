﻿
using System;
namespace Game.Entity.Accounts
{
    /// <summary>
    /// AccountsUploadFace:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class AccountsUploadFace
    {
        public AccountsUploadFace()
        { }
        #region Model
        private int _userid;
        private int _customid;
        private string _filemd5 = "";
        private DateTime _inserttime = DateTime.Now;
        private int _approvestatus = 0;
        private string _approveremarks = "";
        /// <summary>
        /// 
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int CustomId
        {
            set { _customid = value; }
            get { return _customid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string FileMD5
        {
            set { _filemd5 = value; }
            get { return _filemd5; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime InsertTime
        {
            set { _inserttime = value; }
            get { return _inserttime; }
        }
        /// <summary>
        /// 状态 (0 审核中 1 通过 2未通过)
        /// </summary>
        public int ApproveStatus
        {
            set { _approvestatus = value; }
            get { return _approvestatus; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ApproveRemarks
        {
            set { _approveremarks = value; }
            get { return _approveremarks; }
        }
        #endregion Model

    }
}

