/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-06-27 09:36:26*/
/*Table:AccountsConfig*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Accounts
{
	public class AccountsConfig
	{
		#region 构造函数
		public AccountsConfig(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "AccountsConfig";

		/// <summary>
		/// 自增长编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 用户编号
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 类型 1黑名单 2白名单 3优质客户 4 新用户  5 长时间不登录客户
		/// </summary>
		public const string _GroupType = "GroupType";

		#endregion

		#region 私有变量
		private int m_Pid;//自增长编号
		private int m_UserID;//用户编号
		private int m_GroupType;//类型 1黑名单 2白名单 3优质客户 4 新用户  5 长时间不登录客户
		#endregion

		#region 公开属性

		/// <summary>
		/// 自增长编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 用户编号
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 类型 1黑名单 2白名单 3优质客户 4 新用户  5 长时间不登录客户
		/// </summary>
		public int GroupType
		{
			get { return m_GroupType; }
			set { m_GroupType = value; }
		}

		#endregion

	}
}
