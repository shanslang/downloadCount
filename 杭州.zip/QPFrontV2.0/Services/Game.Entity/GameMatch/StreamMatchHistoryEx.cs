/*
 * 版本：4.0
 * 时间：2012-2-28
 * 作者：http://www.foxuc.com
 *
 * 描述：实体类
 *
 */

using System;
using System.Collections.Generic;

namespace Game.Entity.GameMatch
{
	/// <summary>
	/// 实体类 StreamMatchHistory。(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	public partial class StreamMatchHistory  
	{
        /// <summary>
        /// 用户昵称
        /// </summary>
        public string NickName
        {
            get;
            set;
        }
	}
}
