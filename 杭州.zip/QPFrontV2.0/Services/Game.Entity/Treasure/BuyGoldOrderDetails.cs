﻿
using System;
namespace Game.Entity.Treasure
{
    /// <summary>
    /// BuyGoldOrderDetails:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class BuyGoldOrderDetails
    {
        public BuyGoldOrderDetails()
        { }
        #region Model
        private int _pid;
        private string _orderid;
        private int _pricegold;
        private int _buycount;
        /// <summary>
        /// 
        /// </summary>
        public int Pid
        {
            set { _pid = value; }
            get { return _pid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string OrderID
        {
            set { _orderid = value; }
            get { return _orderid; }
        }
        /// <summary>
        /// 金币价值(单价)
        /// </summary>
        public int PriceGold
        {
            set { _pricegold = value; }
            get { return _pricegold; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int BuyCount
        {
            set { _buycount = value; }
            get { return _buycount; }
        }
        #endregion Model

    }
}

