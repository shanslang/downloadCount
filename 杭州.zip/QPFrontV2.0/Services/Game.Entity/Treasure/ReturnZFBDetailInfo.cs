/*
 * 版本：4.0
 * 时间：2011-10-18
 * 作者：http://www.foxuc.com
 *
 * 描述：实体类
 *
 */

using System;
using System.Collections.Generic;

namespace Game.Entity.Treasure
{
    /// <summary>
    /// 实体类 ReturnZFBDetailInfo。(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class ReturnZFBDetailInfo
    {
        #region 常量
        /// <summary>
        /// 表名
        /// </summary>
        public const string Tablename = "ReturnZFBDetailInfo";
        public const string _Is_success        ="Is_success";
        public const string _Sign_type         ="Sign_type";
        public const string _Sign              ="Sign";
        public const string _Out_trade_no      ="Out_trade_no";
        public const string _Subject           ="Subject";
        public const string _Payment_type      ="Payment_type";
        public const string _Exterface         ="Exterface";
        public const string _Trade_no          ="Trade_no";
        public const string _Trade_status      ="Trade_status";
        public const string _Notify_id         ="Notify_id";
        public const string _Notify_time       ="Notify_time";
        public const string _Notify_type       ="Notify_type";
        public const string _Seller_email      ="Seller_email";
        public const string _Buyer_email       ="Buyer_email";
        public const string _Seller_id         ="Seller_id";
        public const string _Buyer_id          ="Buyer_id";
        public const string _Total_fee         ="Total_fee";
        public const string _Body              ="Body";
        public const string _Extra_common_param="Extra_common_param";
        public const string _Agent_user_id     ="Agent_user_id";
        #endregion

        #region 私有变量
        private string m_Is_success;
        private string m_Sign_type;
        private string m_Sign;
        private string m_Out_trade_no;
        private string m_Subject;
        private string m_Payment_type;
        private string m_Exterface;
        private string m_Trade_no;
        private string m_Trade_status;
        private string m_Notify_id;
        private DateTime m_Notify_time;
        private string m_Notify_type;
        private string m_Seller_email;
        private string m_Buyer_email;
        private string m_Seller_id;
        private string m_Buyer_id;
        private decimal m_Total_fee;
        private string m_Body;
        private string m_Extra_common_param;
        private string m_Agent_user_id;
        #endregion

        #region 构造方法
        /// <summary>
        /// 初始化ReturnZFBDetailInfo
        /// </summary>
        public ReturnZFBDetailInfo()
        {
            m_Is_success = "";
            m_Sign_type = "";
            m_Sign = "";
            m_Out_trade_no = "";
            m_Subject = "";
            m_Payment_type = "";
            m_Exterface = "";
            m_Trade_no = "";
            m_Trade_status = "";
            m_Notify_id = "";
            m_Notify_time = DateTime.Now;
            m_Notify_type = "";
            m_Seller_email = "";
            m_Buyer_email = "";
            m_Seller_id = "";
            m_Buyer_id = "";
            m_Total_fee = 0.00m;
            m_Body = "";
            m_Extra_common_param = "";
            m_Agent_user_id = "";
        }
        #endregion

        #region 公共属性
        public string Is_success
        {
            get { return m_Is_success; }
            set { m_Is_success = value; }
        }
        public string Sign_type
        {
            get { return m_Sign_type; }
            set { m_Sign_type = value; }
        }
        public string Sign
        {
            get { return m_Sign; }
            set { m_Sign = value; }
        }
        public string Out_trade_no
        {
            get { return m_Out_trade_no; }
            set { m_Out_trade_no = value; }
        }
        public string Subject
        {
            get { return m_Subject; }
            set { m_Subject = value; }
        }
        public string Payment_type
        {
            get { return m_Payment_type; }
            set { m_Payment_type = value; }
        }
        public string Exterface
        {
            get { return m_Exterface; }
            set { m_Exterface = value; }
        }
        public string Trade_no
        {
            get { return m_Trade_no; }
            set { m_Trade_no = value; }
        }
        public string Trade_status
        {
            get { return m_Trade_status; }
            set { m_Trade_status = value; }
        }
        public string Notify_id
        {
            get { return m_Notify_id; }
            set { m_Notify_id = value; }
        }
        public DateTime Notify_time
        {
            get { return m_Notify_time; }
            set { m_Notify_time = value; }
        }
        public string Notify_type
        {
            get { return m_Notify_type; }
            set { m_Notify_type = value; }
        }
        public string Seller_email
        {
            get { return m_Seller_email; }
            set { m_Seller_email = value; }
        }
        public string Buyer_email
        {
            get { return m_Buyer_email; }
            set { m_Buyer_email = value; }
        }
        public string Seller_id
        {
            get { return m_Seller_id; }
            set { m_Seller_id = value; }
        }
        public string Buyer_id
        {
            get { return m_Buyer_id; }
            set { m_Buyer_id = value; }
        }
        public decimal Total_fee
        {
            get { return m_Total_fee; }
            set { m_Total_fee = value; }
        }
        public string Body
        {
            get { return m_Body; }
            set { m_Body = value; }
        }
        public string Extra_common_param
        {
            get { return m_Extra_common_param; }
            set { m_Extra_common_param = value; }
        }
        public string Agent_user_id
        {
            get { return m_Agent_user_id; }
            set { m_Agent_user_id = value; }
        }
        #endregion
    }
}
