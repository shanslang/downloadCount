/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-01-06 10:05:30*/
/*Table:ReturnWeixinDetailInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public class ReturnWeixinDetailInfo
	{
		#region 构造函数
		public ReturnWeixinDetailInfo(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "ReturnWeixinDetailInfo";

		/// <summary>
		/// 
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 
		/// </summary>
		public const string _return_code = "return_code";

		/// <summary>
		/// 
		/// </summary>
		public const string _return_msg = "return_msg";

		/// <summary>
		/// 
		/// </summary>
		public const string _appid = "appid";

		/// <summary>
		/// 
		/// </summary>
		public const string _mch_id = "mch_id";

		/// <summary>
		/// 
		/// </summary>
		public const string _device_info = "device_info";

		/// <summary>
		/// 
		/// </summary>
		public const string _nonce_str = "nonce_str";

		/// <summary>
		/// 
		/// </summary>
		public const string _sign = "sign";

		/// <summary>
		/// 
		/// </summary>
		public const string _result_code = "result_code";

		/// <summary>
		/// 
		/// </summary>
		public const string _err_code = "err_code";

		/// <summary>
		/// 
		/// </summary>
		public const string _err_code_des = "err_code_des";

		/// <summary>
		/// 
		/// </summary>
		public const string _openid = "openid";

		/// <summary>
		/// 
		/// </summary>
		public const string _is_subscribe = "is_subscribe";

		/// <summary>
		/// 
		/// </summary>
		public const string _trade_type = "trade_type";

		/// <summary>
		/// 
		/// </summary>
		public const string _bank_type = "bank_type";

		/// <summary>
		/// 
		/// </summary>
		public const string _total_fee = "total_fee";

		/// <summary>
		/// 
		/// </summary>
		public const string _coupon_fee = "coupon_fee";

		/// <summary>
		/// 
		/// </summary>
		public const string _fee_type = "fee_type";

		/// <summary>
		/// 
		/// </summary>
		public const string _transaction_id = "transaction_id";

		/// <summary>
		/// 
		/// </summary>
		public const string _out_trade_no = "out_trade_no";

		/// <summary>
		/// 
		/// </summary>
		public const string _attach = "attach";

		/// <summary>
		/// 
		/// </summary>
		public const string _time_end = "time_end";

		/// <summary>
		/// 
		/// </summary>
		public const string _json = "json";

		/// <summary>
		/// 
		/// </summary>
		public const string _CTime = "CTime";

		#endregion

		#region 私有变量
		private int m_Pid;//
		private string m_return_code;//
		private string m_return_msg;//
		private string m_appid;//
		private string m_mch_id;//
		private string m_device_info;//
		private string m_nonce_str;//
		private string m_sign;//
		private string m_result_code;//
		private string m_err_code;//
		private string m_err_code_des;//
		private string m_openid;//
		private string m_is_subscribe;//
		private string m_trade_type;//
		private string m_bank_type;//
		private int m_total_fee;//
		private int m_coupon_fee;//
		private string m_fee_type;//
		private string m_transaction_id;//
		private string m_out_trade_no;//
		private string m_attach;//
		private string m_time_end;//
		private string m_json;//
		private DateTime m_CTime;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string return_code
		{
			get { return m_return_code; }
			set { m_return_code = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string return_msg
		{
			get { return m_return_msg; }
			set { m_return_msg = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string appid
		{
			get { return m_appid; }
			set { m_appid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string mch_id
		{
			get { return m_mch_id; }
			set { m_mch_id = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string device_info
		{
			get { return m_device_info; }
			set { m_device_info = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string nonce_str
		{
			get { return m_nonce_str; }
			set { m_nonce_str = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string sign
		{
			get { return m_sign; }
			set { m_sign = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string result_code
		{
			get { return m_result_code; }
			set { m_result_code = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string err_code
		{
			get { return m_err_code; }
			set { m_err_code = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string err_code_des
		{
			get { return m_err_code_des; }
			set { m_err_code_des = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string openid
		{
			get { return m_openid; }
			set { m_openid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string is_subscribe
		{
			get { return m_is_subscribe; }
			set { m_is_subscribe = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string trade_type
		{
			get { return m_trade_type; }
			set { m_trade_type = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string bank_type
		{
			get { return m_bank_type; }
			set { m_bank_type = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int total_fee
		{
			get { return m_total_fee; }
			set { m_total_fee = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int coupon_fee
		{
			get { return m_coupon_fee; }
			set { m_coupon_fee = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string fee_type
		{
			get { return m_fee_type; }
			set { m_fee_type = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string transaction_id
		{
			get { return m_transaction_id; }
			set { m_transaction_id = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string out_trade_no
		{
			get { return m_out_trade_no; }
			set { m_out_trade_no = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string attach
		{
			get { return m_attach; }
			set { m_attach = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string time_end
		{
			get { return m_time_end; }
			set { m_time_end = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string json
		{
			get { return m_json; }
			set { m_json = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		#endregion

	}
}
