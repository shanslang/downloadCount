/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-07-02 11:57:23*/
/*Table:RechOrder*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public class RechOrder
	{
		#region 构造函数
		public RechOrder(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "RechOrder";

		/// <summary>
		/// 
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 订单号码
		/// </summary>
		public const string _OrderID = "OrderID";

		/// <summary>
		/// 用户标识
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 操作用户
		/// </summary>
		public const string _OperUserID = "OperUserID";

		/// <summary>
		/// 服务标识
		/// </summary>
		public const string _ShareID = "ShareID";

		/// <summary>
		/// 订单金额
		/// </summary>
		public const string _OrderAmount = "OrderAmount";

		/// <summary>
		/// 折扣比例
		/// </summary>
		public const string _DiscountScale = "DiscountScale";

		/// <summary>
		/// 实付金额
		/// </summary>
		public const string _PayAmount = "PayAmount";

		/// <summary>
		/// 订单状态 0、未付款 1、处理完成 2、处理中
		/// </summary>
		public const string _OrderStatus = "OrderStatus";

		/// <summary>
		/// IP地址
		/// </summary>
		public const string _ClientIP = "ClientIP";

		/// <summary>
		/// 订单日期
		/// </summary>
		public const string _ApplyDate = "ApplyDate";

		#endregion

		#region 私有变量
		private int m_Pid;//
		private string m_OrderID;//订单号码
		private int m_UserID;//用户标识
		private int m_OperUserID;//操作用户
		private int m_ShareID;//服务标识
		private decimal m_OrderAmount;//订单金额
		private decimal m_DiscountScale;//折扣比例
		private decimal m_PayAmount;//实付金额
		private byte m_OrderStatus;//订单状态 0、未付款 1、处理完成 2、处理中
		private string m_ClientIP;//IP地址
		private DateTime m_ApplyDate;//订单日期
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 订单号码
		/// </summary>
		public string OrderID
		{
			get { return m_OrderID; }
			set { m_OrderID = value; }
		}

		/// <summary>
		/// 用户标识
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 操作用户
		/// </summary>
		public int OperUserID
		{
			get { return m_OperUserID; }
			set { m_OperUserID = value; }
		}

		/// <summary>
		/// 服务标识
		/// </summary>
		public int ShareID
		{
			get { return m_ShareID; }
			set { m_ShareID = value; }
		}

		/// <summary>
		/// 订单金额
		/// </summary>
		public decimal OrderAmount
		{
			get { return m_OrderAmount; }
			set { m_OrderAmount = value; }
		}

		/// <summary>
		/// 折扣比例
		/// </summary>
		public decimal DiscountScale
		{
			get { return m_DiscountScale; }
			set { m_DiscountScale = value; }
		}

		/// <summary>
		/// 实付金额
		/// </summary>
		public decimal PayAmount
		{
			get { return m_PayAmount; }
			set { m_PayAmount = value; }
		}

		/// <summary>
		/// 订单状态 0、未付款 1、处理完成 2、处理中
		/// </summary>
		public byte OrderStatus
		{
			get { return m_OrderStatus; }
			set { m_OrderStatus = value; }
		}

		/// <summary>
		/// IP地址
		/// </summary>
		public string ClientIP
		{
			get { return m_ClientIP; }
			set { m_ClientIP = value; }
		}

		/// <summary>
		/// 订单日期
		/// </summary>
		public DateTime ApplyDate
		{
			get { return m_ApplyDate; }
			set { m_ApplyDate = value; }
		}

		#endregion

	}
}
