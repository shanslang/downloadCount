/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-07-03 11:44:33*/
/*Table:UserGoldenBean*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public class UserGoldenBean
	{
		#region 构造函数
		public UserGoldenBean(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "UserGoldenBean";

		/// <summary>
		/// 
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 用户ID
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 金豆数量
		/// </summary>
		public const string _GoldenBean = "GoldenBean";

		/// <summary>
		/// 修改时间
		/// </summary>
		public const string _ETime = "ETime";

		/// <summary>
		/// 创建时间
		/// </summary>
		public const string _CTime = "CTime";

		#endregion

		#region 私有变量
		private int m_Pid;//
		private int m_UserID;//用户ID
		private long m_GoldenBean;//金豆数量
		private DateTime m_ETime;//修改时间
		private DateTime m_CTime;//创建时间
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 用户ID
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 金豆数量
		/// </summary>
		public long GoldenBean
		{
			get { return m_GoldenBean; }
			set { m_GoldenBean = value; }
		}

		/// <summary>
		/// 修改时间
		/// </summary>
		public DateTime ETime
		{
			get { return m_ETime; }
			set { m_ETime = value; }
		}

		/// <summary>
		/// 创建时间
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		#endregion

	}
}
