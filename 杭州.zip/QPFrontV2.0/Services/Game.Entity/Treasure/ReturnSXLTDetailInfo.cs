/*
 * 版本：4.0
 * 时间：2011-10-18
 * 作者：http://www.foxuc.com
 *
 * 描述：实体类
 *
 */

using System;
using System.Collections.Generic;

namespace Game.Entity.Treasure
{
    /// <summary>
    /// 实体类 ReturnSXLTDetailInfo。(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class ReturnSXLTDetailInfo
    {
        #region 常量
        /// <summary>
        /// 表名
        /// </summary>
        public const string Tablename = "ReturnSXDXDetailInfo";
        public const string _P0_Result        ="P0_Result";
        public const string _P1_Mode          ="P1_Mode";
        public const string _Pc_User          ="Pc_User";
        public const string _Pc_SubArea       ="Pc_SubArea";
        public const string _Pc_SubAreaFee    ="Pc_SubAreaFee";
        public const string _Pb_Gate          ="Pb_Gate";
        public const string _Pb_Channel       ="Pb_Channel";
        public const string _P5_OrderNo       ="P5_OrderNo";
        public const string _P6_Fee           ="P6_Fee";
        public const string _P11_TransactionNo="P11_TransactionNo";
        public const string _P12_ResultDesc   ="P12_ResultDesc";
        public const string _P9_ExtData       ="P9_ExtData";
        public const string _P10_MD5Str       ="P10_MD5Str";
        #endregion

        #region 私有变量
        private string m_P0_Result;        
        private string m_P1_Mode;        
        private string m_Pc_User;        
        private string m_Pc_SubArea;        
        private string m_Pc_SubAreaFee;        
        private string m_Pb_Gate;        
        private string m_Pb_Channel;        
        private string m_P5_OrderNo;        
        private decimal m_P6_Fee;        
        private string m_P11_TransactionNo;        
        private string m_P12_ResultDesc;        
        private string m_P9_ExtData;        
        private string m_P10_MD5Str;        
        #endregion

        #region 构造方法
        /// <summary>
        /// 初始化ReturnSXLTDetailInfo
        /// </summary>
        public ReturnSXLTDetailInfo()
        {
            m_P0_Result   ="";     
            m_P1_Mode          ="";
            m_Pc_User          ="";
            m_Pc_SubArea       ="";
            m_Pc_SubAreaFee    ="";
            m_Pb_Gate          ="";
            m_Pb_Channel       ="";
            m_P5_OrderNo       ="";
            m_P6_Fee           =0;
            m_P11_TransactionNo="";
            m_P12_ResultDesc   ="";
            m_P9_ExtData = "";
            m_P10_MD5Str = "";
        }
        #endregion

        #region 公共属性
        public string P0_Result
        {
            get { return m_P0_Result; }
            set { m_P0_Result = value; }
        }
        public string P1_Mode
        {
            get { return m_P1_Mode; }
            set { m_P1_Mode = value; }
        }
        public string Pc_User
        {
            get { return m_Pc_User; }
            set { m_Pc_User = value; }
        }
        public string Pc_SubArea
        {
            get { return m_Pc_SubArea; }
            set { m_Pc_SubArea = value; }
        }
        public string Pc_SubAreaFee
        {
            get { return m_Pc_SubAreaFee; }
            set { m_Pc_SubAreaFee = value; }
        }
        public string Pb_Gate
        {
            get { return m_Pb_Gate; }
            set { m_Pb_Gate = value; }
        }
        public string Pb_Channel
        {
            get { return m_Pb_Channel; }
            set { m_Pb_Channel = value; }
        }
        public string P5_OrderNo
        {
            get { return m_P5_OrderNo; }
            set { m_P5_OrderNo = value; }
        }
        public decimal P6_Fee
        {
            get { return m_P6_Fee; }
            set { m_P6_Fee = value; }
        }
        public string P11_TransactionNo
        {
            get { return m_P11_TransactionNo; }
            set { m_P11_TransactionNo = value; }
        }
        public string P12_ResultDesc
        {
            get { return m_P12_ResultDesc; }
            set { m_P12_ResultDesc = value; }
        }
        public string P9_ExtData
        {
            get { return m_P9_ExtData; }
            set { m_P9_ExtData = value; }
        }
        public string P10_MD5Str
        {
            get { return m_P10_MD5Str; }
            set { m_P10_MD5Str = value; }
        }
        #endregion
    }
}
