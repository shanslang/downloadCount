/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-03-12 15:40:01*/
/*Table:RecordActivityInternetcafe*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public class RecordActivityInternetcafe
	{
		#region 构造函数
		public RecordActivityInternetcafe(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "RecordActivityInternetcafe";

		/// <summary>
		/// Pid(自动编号)
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// UserID(用户ID)
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// ActivityInternetcafePid(活动网吧PID)
		/// </summary>
		public const string _ActivityInternetcafePid = "ActivityInternetcafePid";

		/// <summary>
		/// CTime(创建时间)
		/// </summary>
		public const string _CTime = "CTime";

		#endregion

		#region 私有变量
		private int m_Pid;//Pid(自动编号)
		private int m_UserID;//UserID(用户ID)
		private int m_ActivityInternetcafePid;//ActivityInternetcafePid(活动网吧PID)
		private DateTime m_CTime;//CTime(创建时间)
		#endregion

		#region 公开属性

		/// <summary>
		/// Pid(自动编号)
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// UserID(用户ID)
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// ActivityInternetcafePid(活动网吧PID)
		/// </summary>
		public int ActivityInternetcafePid
		{
			get { return m_ActivityInternetcafePid; }
			set { m_ActivityInternetcafePid = value; }
		}

		/// <summary>
		/// CTime(创建时间)
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		#endregion

	}
}
