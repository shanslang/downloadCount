/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-12-23 11:59:08*/
/*Table:RechActivityRules*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public class RechActivityRules
	{
		#region 构造函数
		public RechActivityRules(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "RechActivityRules";

		/// <summary>
		/// 自动编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 名称
		/// </summary>
		public const string _Name = "Name";

		/// <summary>
		/// 充值类型 1=账号首充 2=每日首充 3=常规活动
		/// </summary>
		public const string _RechType = "RechType";

		/// <summary>
		/// 开始时间
		/// </summary>
		public const string _StartDate = "StartDate";

		/// <summary>
		/// 结束时间
		/// </summary>
		public const string _EndDate = "EndDate";

		/// <summary>
		/// 充值金额
		/// </summary>
		public const string _RechAmount = "RechAmount";

		/// <summary>
		/// 赠送金豆类型 1=金豆数量 2=金豆百分比
		/// </summary>
		public const string _PresentGoldenBeanType = "PresentGoldenBeanType";

		/// <summary>
		/// 赠送金豆
		/// </summary>
		public const string _PresentGoldenBean = "PresentGoldenBean";

		/// <summary>
		/// 状态值 1=开启 2=关闭
		/// </summary>
		public const string _StateID = "StateID";

		#endregion

		#region 私有变量
		private int m_Pid;//自动编号
		private string m_Name;//名称
		private byte m_RechType;//充值类型 1=账号首充 2=每日首充 3=常规活动
		private DateTime m_StartDate;//开始时间
		private DateTime m_EndDate;//结束时间
		private decimal m_RechAmount;//充值金额
		private byte m_PresentGoldenBeanType;//赠送金豆类型 1=金豆数量 2=金豆百分比
		private long m_PresentGoldenBean;//赠送金豆
		private byte m_StateID;//状态值 1=开启 2=关闭
		#endregion

		#region 公开属性

		/// <summary>
		/// 自动编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 名称
		/// </summary>
		public string Name
		{
			get { return m_Name; }
			set { m_Name = value; }
		}

		/// <summary>
		/// 充值类型 1=账号首充 2=每日首充 3=常规活动
		/// </summary>
		public byte RechType
		{
			get { return m_RechType; }
			set { m_RechType = value; }
		}

		/// <summary>
		/// 开始时间
		/// </summary>
		public DateTime StartDate
		{
			get { return m_StartDate; }
			set { m_StartDate = value; }
		}

		/// <summary>
		/// 结束时间
		/// </summary>
		public DateTime EndDate
		{
			get { return m_EndDate; }
			set { m_EndDate = value; }
		}

		/// <summary>
		/// 充值金额
		/// </summary>
		public decimal RechAmount
		{
			get { return m_RechAmount; }
			set { m_RechAmount = value; }
		}

		/// <summary>
		/// 赠送金豆类型 1=金豆数量 2=金豆百分比
		/// </summary>
		public byte PresentGoldenBeanType
		{
			get { return m_PresentGoldenBeanType; }
			set { m_PresentGoldenBeanType = value; }
		}

		/// <summary>
		/// 赠送金豆
		/// </summary>
		public long PresentGoldenBean
		{
			get { return m_PresentGoldenBean; }
			set { m_PresentGoldenBean = value; }
		}

		/// <summary>
		/// 状态值 1=开启 2=关闭
		/// </summary>
		public byte StateID
		{
			get { return m_StateID; }
			set { m_StateID = value; }
		}

		#endregion

	}
}
