/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-05-19 16:58:08*/
/*Table:Product*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
    public partial class Product
	{
		#region 构造函数
		public Product(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "Product";

		/// <summary>
		/// 自动编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 产品名称
		/// </summary>
		public const string _ProductName = "ProductName";

		/// <summary>
		/// 产品类型 1、虚拟物品 2、实物
		/// </summary>
		public const string _ProductType = "ProductType";

		/// <summary>
		/// UnitPriceType(单价类型) 1、人民币 2、金币 3、奖牌
		/// </summary>
		public const string _UnitPriceType = "UnitPriceType";

		/// <summary>
		/// UnitPriceRmb(人民币单价)
		/// </summary>
		public const string _UnitPriceRmb = "UnitPriceRmb";

		/// <summary>
		/// UnitPriceGold(金币单价)
		/// </summary>
		public const string _UnitPriceGold = "UnitPriceGold";

		/// <summary>
		/// UnitPriceMedal(奖牌单价)
		/// </summary>
		public const string _UnitPriceMedal = "UnitPriceMedal";

		/// <summary>
		/// 
		/// </summary>
		public const string _UnitPriceProperty = "UnitPriceProperty";

		/// <summary>
		/// 
		/// </summary>
		public const string _PropertyPid = "PropertyPid";

		/// <summary>
		/// 
		/// </summary>
		public const string _PropertyName = "PropertyName";

		/// <summary>
		/// Number(数量)
		/// </summary>
		public const string _Number = "Number";

		/// <summary>
		/// Summary(简介)
		/// </summary>
		public const string _Summary = "Summary";

		/// <summary>
		/// Content(描述内容)
		/// </summary>
		public const string _Content = "Content";

		/// <summary>
		/// 创建时间
		/// </summary>
		public const string _CTime = "CTime";

		/// <summary>
		/// IP地址
		/// </summary>
		public const string _ClientIP = "ClientIP";

		/// <summary>
		/// 1=正常 2=归档 3=禁用
		/// </summary>
		public const string _StateID = "StateID";

		/// <summary>
		/// 
		/// </summary>
		public const string _Picurl = "Picurl";

		#endregion

		#region 私有变量
		private int m_Pid;//自动编号
		private string m_ProductName;//产品名称
		private int m_ProductType;//产品类型 1、虚拟物品 2、实物
		private int m_UnitPriceType;//UnitPriceType(单价类型) 1、人民币 2、金币 3、奖牌
		private decimal m_UnitPriceRmb;//UnitPriceRmb(人民币单价)
		private long m_UnitPriceGold;//UnitPriceGold(金币单价)
		private long m_UnitPriceMedal;//UnitPriceMedal(奖牌单价)
		private long m_UnitPriceProperty;//
		private int m_PropertyPid;//
		private string m_PropertyName;//
		private int m_Number;//Number(数量)
		private string m_Summary;//Summary(简介)
		private string m_Content;//Content(描述内容)
		private DateTime m_CTime;//创建时间
		private string m_ClientIP;//IP地址
		private byte m_StateID;//1=正常 2=归档 3=禁用
		private string m_Picurl;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 自动编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 产品名称
		/// </summary>
		public string ProductName
		{
			get { return m_ProductName; }
			set { m_ProductName = value; }
		}

		/// <summary>
		/// 产品类型 1、虚拟物品 2、实物
		/// </summary>
		public int ProductType
		{
			get { return m_ProductType; }
			set { m_ProductType = value; }
		}

		/// <summary>
		/// UnitPriceType(单价类型) 1、人民币 2、金币 3、奖牌
		/// </summary>
		public int UnitPriceType
		{
			get { return m_UnitPriceType; }
			set { m_UnitPriceType = value; }
		}

		/// <summary>
		/// UnitPriceRmb(人民币单价)
		/// </summary>
		public decimal UnitPriceRmb
		{
			get { return m_UnitPriceRmb; }
			set { m_UnitPriceRmb = value; }
		}

		/// <summary>
		/// UnitPriceGold(金币单价)
		/// </summary>
		public long UnitPriceGold
		{
			get { return m_UnitPriceGold; }
			set { m_UnitPriceGold = value; }
		}

		/// <summary>
		/// UnitPriceMedal(奖牌单价)
		/// </summary>
		public long UnitPriceMedal
		{
			get { return m_UnitPriceMedal; }
			set { m_UnitPriceMedal = value; }
		}
        /// <summary>
        /// UnitPriceBillvolume(话费券)
        /// </summary>
        public long UnitPriceBillvolume
        {
            get;
            set;
        }

		/// <summary>
		/// 
		/// </summary>
		public long UnitPriceProperty
		{
			get { return m_UnitPriceProperty; }
			set { m_UnitPriceProperty = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int PropertyPid
		{
			get { return m_PropertyPid; }
			set { m_PropertyPid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string PropertyName
		{
			get { return m_PropertyName; }
			set { m_PropertyName = value; }
		}

		/// <summary>
		/// Number(数量)
		/// </summary>
		public int Number
		{
			get { return m_Number; }
			set { m_Number = value; }
		}

		/// <summary>
		/// Summary(简介)
		/// </summary>
		public string Summary
		{
			get { return m_Summary; }
			set { m_Summary = value; }
		}

		/// <summary>
		/// Content(描述内容)
		/// </summary>
		public string Content
		{
			get { return m_Content; }
			set { m_Content = value; }
		}

		/// <summary>
		/// 创建时间
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		/// <summary>
		/// IP地址
		/// </summary>
		public string ClientIP
		{
			get { return m_ClientIP; }
			set { m_ClientIP = value; }
		}

		/// <summary>
		/// 1=正常 2=归档 3=禁用
		/// </summary>
		public byte StateID
		{
			get { return m_StateID; }
			set { m_StateID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string Picurl
		{
			get { return m_Picurl; }
			set { m_Picurl = value; }
		}

		#endregion

	}
}
