/*
 * 版本：4.0
 * 时间：2011-10-18
 * 作者：http://www.foxuc.com
 *
 * 描述：实体类
 *
 */

using System;
using System.Collections.Generic;

namespace Game.Entity.Treasure
{
	/// <summary>
    /// 实体类 ReturnKQCardDetailInfo。(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class ReturnKQCardDetailInfo  
	{
		#region 常量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "ReturnKQDetailInfo" ;
        public const string _MerchantAcctId ="MerchantAcctId";
        public const string _Version        ="Version";
        public const string _Language       ="Language";
        public const string _PayType        ="PayType";
        public const string _CardNumber     ="CardNumber";
        public const string _CardPwd        ="CardPwd";
        public const string _OrderId        ="OrderId";
        public const string _OrderAmount    ="OrderAmount";
        public const string _DealId         ="DealId";
        public const string _OrderTime      ="OrderTime";
        public const string _Ext1           ="Ext1";
        public const string _Ext2           ="Ext2";
        public const string _PayAmount      ="PayAmount";
        public const string _BillOrderTime  ="BillOrderTime";
        public const string _PayResult      ="PayResult";
        public const string _SignType       ="SignType";
        public const string _BossType       ="BossType";
        public const string _ReceiveBossType="ReceiveBossType";
        public const string _ReceiverAcctId ="ReceiverAcctId";
        public const string _SignMsg        ="SignMsg";

		#endregion

		#region 私有变量
        private string m_MerchantAcctId;
        private string m_Version;
        private string m_Language;
        private string m_PayType;
        private string m_CardNumber;
        private string m_CardPwd;
        private string m_OrderId;
        private decimal m_OrderAmount;
        private string m_DealId;
        private string m_OrderTime;
        private string m_Ext1;
        private string m_Ext2;
        private decimal m_PayAmount;
        private string m_BillOrderTime;
        private string m_PayResult;
        private string m_SignType;
        private string m_BossType;
        private string m_ReceiveBossType;
        private string m_ReceiverAcctId;
        private string m_SignMsg;
		#endregion

		#region 构造方法

		/// <summary>
		/// 初始化ReturnKQDetailInfo
		/// </summary>
        public ReturnKQCardDetailInfo()
		{
            m_MerchantAcctId = "MerchantAcctId";
            m_Version = "Version";
            m_Language = "Language";
            m_PayType = "PayType";
            m_CardNumber = "CardNumber";
            m_CardPwd = "CardPwd";
            m_OrderId = "OrderId";
            m_OrderAmount = 0;
            m_DealId = "DealId";
            m_OrderTime = "OrderTime";
            m_Ext1 = "Ext1";
            m_Ext2 = "Ext2";
            m_PayAmount = 0;
            m_BillOrderTime = "BillOrderTime";
            m_PayResult = "PayResult";
            m_SignType = "SignType";
            m_BossType = "BossType";
            m_ReceiveBossType = "ReceiveBossType";
            m_ReceiverAcctId = "ReceiverAcctId";
            m_SignMsg = "SignMsg";
		}

		#endregion

		#region 公共属性
        public string MerchantAcctId
        {
            get { return m_MerchantAcctId; }
            set { m_MerchantAcctId = value; }
        }
        public string Version
        {
            get { return m_Version; }
            set { m_Version = value; }
        }
        public string Language
        {
            get { return m_Language; }
            set { m_Language = value; }
        }
        public string PayType
        {
            get { return m_PayType; }
            set { m_PayType = value; }
        }
        public string CardNumber
        {
            get { return m_CardNumber; }
            set { m_CardNumber = value; }
        }
        public string CardPwd
        {
            get { return m_CardPwd; }
            set { m_CardPwd = value; }
        }
        public string OrderId
        {
            get { return m_OrderId; }
            set { m_OrderId = value; }
        }
        public decimal OrderAmount
        {
            get { return m_OrderAmount; }
            set { m_OrderAmount = value; }
        }
        public string DealId
        {
            get { return m_DealId; }
            set { m_DealId = value; }
        }
        public string OrderTime
        {
            get { return m_OrderTime; }
            set { m_OrderTime = value; }
        }
        public string Ext1
        {
            get { return m_Ext1; }
            set { m_Ext1 = value; }
        }
        public string Ext2
        {
            get { return m_Ext2; }
            set { m_Ext2 = value; }
        }
        public decimal PayAmount
        {
            get { return m_PayAmount; }
            set { m_PayAmount = value; }
        }
        public string BillOrderTime
        {
            get { return m_BillOrderTime; }
            set { m_BillOrderTime = value; }
        }
        public string PayResult
        {
            get { return m_PayResult; }
            set { m_PayResult = value; }
        }
        public string SignType
        {
            get { return m_SignType; }
            set { m_SignType = value; }
        }
        public string BossType
        {
            get { return m_BossType; }
            set { m_BossType = value; }
        }
        public string ReceiveBossType
        {
            get { return m_ReceiveBossType; }
            set { m_ReceiveBossType = value; }
        }
        public string ReceiverAcctId
        {
            get { return m_ReceiverAcctId; }
            set { m_ReceiverAcctId = value; }
        }
        public string SignMsg
        {
            get { return m_SignMsg; }
            set { m_SignMsg = value; }
        }
		#endregion
	}
}
