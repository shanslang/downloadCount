/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-05-26 13:53:07*/
/*Table:ReturnAppleIAPDetailInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public class ReturnAppleIAPDetailInfo
	{
		#region 构造函数
		public ReturnAppleIAPDetailInfo(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "ReturnAppleIAPDetailInfo";

		/// <summary>
		/// 
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 
		/// </summary>
		public const string _original_purchase_date_pst = "original_purchase_date_pst";

		/// <summary>
		/// 
		/// </summary>
		public const string _purchase_date_ms = "purchase_date_ms";

		/// <summary>
		/// 
		/// </summary>
		public const string _unique_identifier = "unique_identifier";

		/// <summary>
		/// 
		/// </summary>
		public const string _original_transaction_id = "original_transaction_id";

		/// <summary>
		/// 
		/// </summary>
		public const string _bvrs = "bvrs";

		/// <summary>
		/// 
		/// </summary>
		public const string _transaction_id = "transaction_id";

		/// <summary>
		/// 
		/// </summary>
		public const string _quantity = "quantity";

		/// <summary>
		/// 
		/// </summary>
		public const string _unique_vendor_identifier = "unique_vendor_identifier";

		/// <summary>
		/// 
		/// </summary>
		public const string _item_id = "item_id";

		/// <summary>
		/// 
		/// </summary>
		public const string _product_id = "product_id";

		/// <summary>
		/// 
		/// </summary>
		public const string _purchase_date = "purchase_date";

		/// <summary>
		/// 
		/// </summary>
		public const string _original_purchase_date = "original_purchase_date";

		/// <summary>
		/// 
		/// </summary>
		public const string _purchase_date_pst = "purchase_date_pst";

		/// <summary>
		/// 
		/// </summary>
		public const string _bid = "bid";

		/// <summary>
		/// 
		/// </summary>
		public const string _original_purchase_date_ms = "original_purchase_date_ms";

		/// <summary>
		/// 
		/// </summary>
		public const string _json = "json";

		/// <summary>
		/// 
		/// </summary>
		public const string _orderid = "orderid";

		/// <summary>
		/// 
		/// </summary>
		public const string _orderamount = "orderamount";

		/// <summary>
		/// 
		/// </summary>
		public const string _iap_transaction = "iap_transaction";

		#endregion

		#region 私有变量
		private int m_Pid;//
		private string m_original_purchase_date_pst;//
		private string m_purchase_date_ms;//
		private string m_unique_identifier;//
		private string m_original_transaction_id;//
		private string m_bvrs;//
		private string m_transaction_id;//
		private string m_quantity;//
		private string m_unique_vendor_identifier;//
		private string m_item_id;//
		private string m_product_id;//
		private string m_purchase_date;//
		private string m_original_purchase_date;//
		private string m_purchase_date_pst;//
		private string m_bid;//
		private string m_original_purchase_date_ms;//
		private string m_json;//
		private string m_orderid;//
		private decimal m_orderamount;//
		private string m_iap_transaction;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string original_purchase_date_pst
		{
			get { return m_original_purchase_date_pst; }
			set { m_original_purchase_date_pst = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string purchase_date_ms
		{
			get { return m_purchase_date_ms; }
			set { m_purchase_date_ms = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string unique_identifier
		{
			get { return m_unique_identifier; }
			set { m_unique_identifier = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string original_transaction_id
		{
			get { return m_original_transaction_id; }
			set { m_original_transaction_id = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string bvrs
		{
			get { return m_bvrs; }
			set { m_bvrs = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string transaction_id
		{
			get { return m_transaction_id; }
			set { m_transaction_id = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string quantity
		{
			get { return m_quantity; }
			set { m_quantity = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string unique_vendor_identifier
		{
			get { return m_unique_vendor_identifier; }
			set { m_unique_vendor_identifier = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string item_id
		{
			get { return m_item_id; }
			set { m_item_id = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string product_id
		{
			get { return m_product_id; }
			set { m_product_id = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string purchase_date
		{
			get { return m_purchase_date; }
			set { m_purchase_date = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string original_purchase_date
		{
			get { return m_original_purchase_date; }
			set { m_original_purchase_date = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string purchase_date_pst
		{
			get { return m_purchase_date_pst; }
			set { m_purchase_date_pst = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string bid
		{
			get { return m_bid; }
			set { m_bid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string original_purchase_date_ms
		{
			get { return m_original_purchase_date_ms; }
			set { m_original_purchase_date_ms = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string json
		{
			get { return m_json; }
			set { m_json = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string orderid
		{
			get { return m_orderid; }
			set { m_orderid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public decimal orderamount
		{
			get { return m_orderamount; }
			set { m_orderamount = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string iap_transaction
		{
			get { return m_iap_transaction; }
			set { m_iap_transaction = value; }
		}

		#endregion

	}
}
