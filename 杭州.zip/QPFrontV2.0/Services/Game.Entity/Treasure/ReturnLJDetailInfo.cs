﻿
using System;
namespace Game.Entity.Treasure
{
    /// <summary>
    /// ReturnLJCallBackDetailInfo:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class ReturnLJDetailInfo
    {
        public ReturnLJDetailInfo()
        { }
        #region Model
        private string _orderid;
        private int? _price;
        private string _channelcode;
        private string _callbackinfo;
        private string _signmsg;
        private string _channellabel;
        /// <summary>
        /// 订单ID，每一笔订单的唯一标识
        /// </summary>
        public string orderId
        {
            set { _orderid = value; }
            get { return _orderid; }
        }
        /// <summary>
        /// 本次充值金额，整数，单位分
        /// </summary>
        public int? price
        {
            set { _price = value; }
            get { return _price; }
        }
        /// <summary>
        /// 渠道编码，同客户端接入文档中的channelID
        /// </summary>
        public string channelCode
        {
            set { _channelcode = value; }
            get { return _channelcode; }
        }
        /// <summary>
        /// 透传参数（经过base64编码）
        /// </summary>
        public string callbackInfo
        {
            set { _callbackinfo = value; }
            get { return _callbackinfo; }
        }
        /// <summary>
        /// 签名(md5(orderId+price+callbackInfo+productSecret))
        /// </summary>
        public string signmsg
        {
            set { _signmsg = value; }
            get { return _signmsg; }
        }
        /// <summary>
        /// 渠道标识
        /// </summary>
        public string channelLabel
        {
            set { _channellabel = value; }
            get { return _channellabel; }
        }
        #endregion Model

    }
}

