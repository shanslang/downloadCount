﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Entity.Treasure
{
    public class ReturnBDDetailInfo
    {
        public long UID { set; get; }
        public string MerchandiseName { set; get; }
        public decimal OrderMoney { set; get; }
        public DateTime StartDateTime { set; get; }
        public DateTime BankDateTime { set; get; }
        public int OrderStatus { set; get; }
        public string StatusMsg { set; get; }
        public string ExtInfo { set; get; }
        public int VoucherMoney { set; get; }
    }
}
