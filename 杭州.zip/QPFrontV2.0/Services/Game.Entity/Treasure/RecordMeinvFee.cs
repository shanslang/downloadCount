/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-06-10 14:02:34*/
/*Table:RecordMeinvFee*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public partial class RecordMeinvFee
	{
		#region 构造函数
		public RecordMeinvFee(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "RecordMeinvFee";

		/// <summary>
		/// 第三方用户账号
		/// </summary>
		public const string _uId = "uId";

		/// <summary>
		/// 交易流水号(唯一的)
		/// </summary>
		public const string _transactionId = "transactionId";

		/// <summary>
		/// 购买礼物编号
		/// </summary>
		public const string _goodsId = "goodsId";

		/// <summary>
		/// 购买礼物名称
		/// </summary>
		public const string _goodsName = "goodsName";

		/// <summary>
		/// 价格
		/// </summary>
		public const string _goodsPrice = "goodsPrice";

		/// <summary>
		/// 购买礼物数量
		/// </summary>
		public const string _goodsItems = "goodsItems";

		/// <summary>
		/// 总价格
		/// </summary>
		public const string _totalPrice = "totalPrice";

		/// <summary>
		/// 货币类型,云娃分配
		/// </summary>
		public const string _currency = "currency";

		/// <summary>
		/// 
		/// </summary>
		public const string _ClientIP = "ClientIP";

		/// <summary>
		/// 
		/// </summary>
		public const string _CTime = "CTime";

		#endregion

		#region 私有变量
		private string m_uId;//第三方用户账号
		private string m_transactionId;//交易流水号(唯一的)
		private string m_goodsId;//购买礼物编号
		private string m_goodsName;//购买礼物名称
		private int m_goodsPrice;//价格
		private int m_goodsItems;//购买礼物数量
		private int m_totalPrice;//总价格
		private string m_currency;//货币类型,云娃分配
		private string m_ClientIP;//
		private DateTime m_CTime;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 第三方用户账号
		/// </summary>
		public string uId
		{
			get { return m_uId; }
			set { m_uId = value; }
		}

		/// <summary>
		/// 交易流水号(唯一的)
		/// </summary>
		public string transactionId
		{
			get { return m_transactionId; }
			set { m_transactionId = value; }
		}

		/// <summary>
		/// 购买礼物编号
		/// </summary>
		public string goodsId
		{
			get { return m_goodsId; }
			set { m_goodsId = value; }
		}

		/// <summary>
		/// 购买礼物名称
		/// </summary>
		public string goodsName
		{
			get { return m_goodsName; }
			set { m_goodsName = value; }
		}

		/// <summary>
		/// 价格
		/// </summary>
		public int goodsPrice
		{
			get { return m_goodsPrice; }
			set { m_goodsPrice = value; }
		}

		/// <summary>
		/// 购买礼物数量
		/// </summary>
		public int goodsItems
		{
			get { return m_goodsItems; }
			set { m_goodsItems = value; }
		}

		/// <summary>
		/// 总价格
		/// </summary>
		public int totalPrice
		{
			get { return m_totalPrice; }
			set { m_totalPrice = value; }
		}

		/// <summary>
		/// 货币类型,云娃分配
		/// </summary>
		public string currency
		{
			get { return m_currency; }
			set { m_currency = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string ClientIP
		{
			get { return m_ClientIP; }
			set { m_ClientIP = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		#endregion

	}
}
