/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2013-12-27 16:03:46*/
/*Table:WguguOrder*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public class WguguOrder
	{
		#region 构造函数
		public WguguOrder(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "WguguOrder";

		/// <summary>
		/// 主键编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 喔咕咕订单号
		/// </summary>
		public const string _OrderID = "OrderID";

		/// <summary>
		/// 卖家游戏帐号
		/// </summary>
		public const string _PlayerID = "PlayerID";

		/// <summary>
		/// 物品编码
		/// </summary>
		public const string _WareID = "WareID";

        /// <summary>
        /// 商品编号
        /// </summary>
        public const string _ProID = "ProID";

		/// <summary>
		/// 游戏币数量
		/// </summary>
		public const string _WareNum = "WareNum";

		/// <summary>
		/// 喔咕咕订单时间
		/// </summary>
		public const string _WGGTime = "WGGTime";

		/// <summary>
		/// 创建时间
		/// </summary>
		public const string _CTime = "CTime";

		/// <summary>
		/// 订单状态1、正常2、完结3、作废
		/// </summary>
		public const string _StateID = "StateID";

		/// <summary>
		/// 
		/// </summary>
		public const string _ClientIP = "ClientIP";

		#endregion

		#region 私有变量
		private int m_Pid;//主键编号
		private string m_OrderID;//喔咕咕订单号
		private string m_PlayerID;//卖家游戏帐号
		private string m_WareID;//物品编码
        private string m_ProID;//商品编码
		private long m_WareNum;//游戏币数量
		private DateTime m_WGGTime;//喔咕咕订单时间
		private DateTime m_CTime;//创建时间
		private int m_StateID;//订单状态1、正常2、完结3、作废
		private string m_ClientIP;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 主键编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 喔咕咕订单号
		/// </summary>
		public string OrderID
		{
			get { return m_OrderID; }
			set { m_OrderID = value; }
		}

		/// <summary>
		/// 卖家游戏帐号
		/// </summary>
		public string PlayerID
		{
			get { return m_PlayerID; }
			set { m_PlayerID = value; }
		}

		/// <summary>
		/// 物品编码
		/// </summary>
		public string WareID
		{
			get { return m_WareID; }
			set { m_WareID = value; }
		}

        /// <summary>
        /// 商品编码
        /// </summary>
        public string ProID
        {
            get { return m_ProID; }
            set { m_ProID = value; }
        }

		/// <summary>
		/// 游戏币数量
		/// </summary>
		public long WareNum
		{
			get { return m_WareNum; }
			set { m_WareNum = value; }
		}

		/// <summary>
		/// 喔咕咕订单时间
		/// </summary>
		public DateTime WGGTime
		{
			get { return m_WGGTime; }
			set { m_WGGTime = value; }
		}

		/// <summary>
		/// 创建时间
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		/// <summary>
		/// 订单状态1、正常2、完结3、作废
		/// </summary>
		public int StateID
		{
			get { return m_StateID; }
			set { m_StateID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string ClientIP
		{
			get { return m_ClientIP; }
			set { m_ClientIP = value; }
		}

		#endregion

	}
}
