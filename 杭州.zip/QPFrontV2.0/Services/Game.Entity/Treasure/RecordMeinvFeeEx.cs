/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-06-10 14:02:34*/
/*Table:RecordMeinvFee*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public partial class RecordMeinvFee
	{
        /// <summary>
        /// 房间ID
        /// </summary>
        public int ServerID { get; set; }
	}
}
