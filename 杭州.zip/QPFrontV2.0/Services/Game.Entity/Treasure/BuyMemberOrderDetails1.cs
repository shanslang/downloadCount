/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-12-04 16:19:37*/
/*Table:BuyMemberOrderDetails1*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public class BuyMemberOrderDetails1
	{
		#region 构造函数
		public BuyMemberOrderDetails1(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "BuyMemberOrderDetails1";

		/// <summary>
		/// Pid
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// OrderID(订单ID)
		/// </summary>
		public const string _OrderID = "OrderID";

		/// <summary>
		/// CardTypeID(会员卡类型ID)
		/// </summary>
		public const string _MemberOrder = "MemberOrder";

		/// <summary>
		/// MemberDayNum(购买月数)
		/// </summary>
		public const string _MemberDays = "MemberDays";

		#endregion

		#region 私有变量
		private int m_Pid;//Pid
		private string m_OrderID;//OrderID(订单ID)
		private int m_MemberOrder;//CardTypeID(会员卡类型ID)
		private int m_MemberDays;//MemberDayNum(购买月数)
		#endregion

		#region 公开属性

		/// <summary>
		/// Pid
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// OrderID(订单ID)
		/// </summary>
		public string OrderID
		{
			get { return m_OrderID; }
			set { m_OrderID = value; }
		}

		/// <summary>
		/// CardTypeID(会员卡类型ID)
		/// </summary>
		public int MemberOrder
		{
			get { return m_MemberOrder; }
			set { m_MemberOrder = value; }
		}

		/// <summary>
		/// MemberDayNum(购买月数)
		/// </summary>
		public int MemberDays
		{
			get { return m_MemberDays; }
			set { m_MemberDays = value; }
		}

		#endregion

	}
}
