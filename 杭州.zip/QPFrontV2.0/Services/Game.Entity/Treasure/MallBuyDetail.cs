/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-02-15 15:45:47*/
/*Table:MallBuyDetail*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public class MallBuyDetail
	{
		#region 构造函数
		public MallBuyDetail(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "MallBuyDetail";

		/// <summary>
		/// Pid(自动编号)
		/// </summary>
		public const string _OrderID = "OrderID";

		/// <summary>
		/// UserID(用户ID)
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// ProductPid(产品ID)
		/// </summary>
		public const string _ProductPid = "ProductPid";

		/// <summary>
		/// QQNumber(QQ号码)
		/// </summary>
		public const string _QQNumber = "QQNumber";

		/// <summary>
		/// TelePhone(联系电话)
		/// </summary>
		public const string _TelePhone = "TelePhone";

		/// <summary>
		/// PostCode(邮编)
		/// </summary>
		public const string _PostCode = "PostCode";

		/// <summary>
		/// Address(邮寄地址)
		/// </summary>
		public const string _Address = "Address";

		/// <summary>
		/// Remark(备注)
		/// </summary>
		public const string _Remark = "Remark";

		/// <summary>
		/// CTime(创建时间)
		/// </summary>
		public const string _CTime = "CTime";

		/// <summary>
		/// ClientIP(IP地址)
		/// </summary>
		public const string _ClientIP = "ClientIP";

		#endregion

		#region 私有变量
		private int m_OrderID;//Pid(自动编号)
		private int m_UserID;//UserID(用户ID)
		private int m_ProductPid;//ProductPid(产品ID)
		private string m_QQNumber;//QQNumber(QQ号码)
		private string m_TelePhone;//TelePhone(联系电话)
		private string m_PostCode;//PostCode(邮编)
		private string m_Address;//Address(邮寄地址)
		private string m_Remark;//Remark(备注)
		private DateTime m_CTime;//CTime(创建时间)
		private string m_ClientIP;//ClientIP(IP地址)
		#endregion

		#region 公开属性

		/// <summary>
		/// Pid(自动编号)
		/// </summary>
		public int OrderID
		{
			get { return m_OrderID; }
			set { m_OrderID = value; }
		}

		/// <summary>
		/// UserID(用户ID)
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// ProductPid(产品ID)
		/// </summary>
		public int ProductPid
		{
			get { return m_ProductPid; }
			set { m_ProductPid = value; }
		}

		/// <summary>
		/// QQNumber(QQ号码)
		/// </summary>
		public string QQNumber
		{
			get { return m_QQNumber; }
			set { m_QQNumber = value; }
		}

		/// <summary>
		/// TelePhone(联系电话)
		/// </summary>
		public string TelePhone
		{
			get { return m_TelePhone; }
			set { m_TelePhone = value; }
		}

		/// <summary>
		/// PostCode(邮编)
		/// </summary>
		public string PostCode
		{
			get { return m_PostCode; }
			set { m_PostCode = value; }
		}

		/// <summary>
		/// Address(邮寄地址)
		/// </summary>
		public string Address
		{
			get { return m_Address; }
			set { m_Address = value; }
		}

		/// <summary>
		/// Remark(备注)
		/// </summary>
		public string Remark
		{
			get { return m_Remark; }
			set { m_Remark = value; }
		}

		/// <summary>
		/// CTime(创建时间)
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		/// <summary>
		/// ClientIP(IP地址)
		/// </summary>
		public string ClientIP
		{
			get { return m_ClientIP; }
			set { m_ClientIP = value; }
		}

		#endregion

	}
}
