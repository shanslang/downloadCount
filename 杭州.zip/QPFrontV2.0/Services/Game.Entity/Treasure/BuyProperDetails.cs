/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-01-30 14:59:15*/
/*Table:BuyProperDetails*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public class BuyProperDetails
	{
		#region 构造函数
		public BuyProperDetails(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "BuyProperDetails";

		/// <summary>
		/// Pid
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// OrderID(订单ID)
		/// </summary>
		public const string _OrderID = "OrderID";

		/// <summary>
		/// CardTypeID(会员卡类型ID)
		/// </summary>
		public const string _ProperPid = "ProperPid";

		/// <summary>
		/// MemberDayNum(购买月数)
		/// </summary>
		public const string _ProperNumber = "ProperNumber";

		#endregion

		#region 私有变量
		private int m_Pid;//Pid
		private string m_OrderID;//OrderID(订单ID)
		private int m_ProperPid;//CardTypeID(会员卡类型ID)
		private int m_ProperNumber;//MemberDayNum(购买月数)
		#endregion

		#region 公开属性

		/// <summary>
		/// Pid
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// OrderID(订单ID)
		/// </summary>
		public string OrderID
		{
			get { return m_OrderID; }
			set { m_OrderID = value; }
		}

		/// <summary>
		/// CardTypeID(会员卡类型ID)
		/// </summary>
		public int ProperPid
		{
			get { return m_ProperPid; }
			set { m_ProperPid = value; }
		}

		/// <summary>
		/// MemberDayNum(购买月数)
		/// </summary>
		public int ProperNumber
		{
			get { return m_ProperNumber; }
			set { m_ProperNumber = value; }
		}

		#endregion

	}
}
