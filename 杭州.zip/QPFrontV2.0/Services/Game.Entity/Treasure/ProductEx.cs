/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-02-12 10:32:30*/
/*Table:Product*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
    public partial class Product
    {
        /// <summary>
        /// 价格显示
        /// </summary>
        public string UnitPriceDisplayName
        {
            get
            {
                string result = "";
                string name = Game.Library.Function.GetEmnuEntity<Game.Type.ProductUnitPriceType>(this.UnitPriceType).DisplayName;
                if (this.UnitPriceType == (int)Game.Type.ProductUnitPriceType.人民币)
                {
                    result = this.UnitPriceRmb + name;
                }
                else if (this.UnitPriceType == (int)Game.Type.ProductUnitPriceType.金币)
                {
                    result = this.UnitPriceGold + name;
                }
                else if (this.UnitPriceType == (int)Game.Type.ProductUnitPriceType.奖牌)
                {
                    result = this.UnitPriceMedal + name;
                }
                else if (this.UnitPriceType == (int)Game.Type.ProductUnitPriceType.道具)
                {
                    result = this.PropertyName + "(道具)x" + this.UnitPriceProperty;
                }
                else if (this.UnitPriceType == (int)Game.Type.ProductUnitPriceType.道具)
                {
                    result = this.PropertyName + "(道具)x" + this.UnitPriceBillvolume;
                }
                return result;
            }
        }
    }
}
