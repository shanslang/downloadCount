/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-02-12 09:43:08*/
/*Table:ProductOrder*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public partial class ProductOrder
	{
        /// <summary>
        /// 账号
        /// </summary>
        public string Accounts { get; set; }
        /// <summary>
        /// 昵称
        /// </summary>
        public string NickName { get; set; }
        /// <summary>
        /// 产品名称
        /// </summary>
        public string ProductName { get; set; }
        /// <summary>
        /// 产品类型
        /// </summary>
        private int ProductType { get; set; }
	}
}
