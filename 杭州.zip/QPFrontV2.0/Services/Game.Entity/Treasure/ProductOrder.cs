/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-02-12 09:43:08*/
/*Table:ProductOrder*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
	public partial class ProductOrder
	{
		#region 构造函数
		public ProductOrder(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "ProductOrder";

		/// <summary>
		/// Pid(自动编号)
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// OperUserID(操作用户)
		/// </summary>
		public const string _OperUserID = "OperUserID";

		/// <summary>
		/// UserID(用户标识)
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// OrderID(订单编号)
		/// </summary>
		public const string _OrderID = "OrderID";

		/// <summary>
		/// ProductPid(产品编号)
		/// </summary>
		public const string _ProductPid = "ProductPid";

		/// <summary>
		/// Number(数量)
		/// </summary>
		public const string _Number = "Number";

		/// <summary>
		/// OrderAmount(订单金额)
		/// </summary>
		public const string _OrderAmount = "OrderAmount";

		/// <summary>
		/// OrderGold(订单金币)
		/// </summary>
		public const string _OrderGold = "OrderGold";

		/// <summary>
		/// OrderMedal(订单奖牌)
		/// </summary>
		public const string _OrderMedal = "OrderMedal";

		/// <summary>
		/// Remark(备注说明)
		/// </summary>
		public const string _Remark = "Remark";

		/// <summary>
		/// 订单状态 0:未付款;1:已付款待处理;2:处理完成
		/// </summary>
		public const string _OrderStatus = "OrderStatus";

		/// <summary>
		/// IPAddress(IP地址)
		/// </summary>
		public const string _IPAddress = "IPAddress";

		/// <summary>
		/// CTime(订单日期)
		/// </summary>
		public const string _CTime = "CTime";

		#endregion

		#region 私有变量
		private int m_Pid;//Pid(自动编号)
		private int m_OperUserID;//OperUserID(操作用户)
		private int m_UserID;//UserID(用户标识)
		private string m_OrderID;//OrderID(订单编号)
		private int m_ProductPid;//ProductPid(产品编号)
		private int m_Number;//Number(数量)
		private decimal m_OrderAmount;//OrderAmount(订单金额)
		private long m_OrderGold;//OrderGold(订单金币)
		private long m_OrderMedal;//OrderMedal(订单奖牌)
		private string m_Remark;//Remark(备注说明)
		private int m_OrderStatus;//订单状态 0:未付款;1:已付款待处理;2:处理完成
		private string m_IPAddress;//IPAddress(IP地址)
		private DateTime m_CTime;//CTime(订单日期)
		#endregion

		#region 公开属性

		/// <summary>
		/// Pid(自动编号)
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// OperUserID(操作用户)
		/// </summary>
		public int OperUserID
		{
			get { return m_OperUserID; }
			set { m_OperUserID = value; }
		}

		/// <summary>
		/// UserID(用户标识)
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// OrderID(订单编号)
		/// </summary>
		public string OrderID
		{
			get { return m_OrderID; }
			set { m_OrderID = value; }
		}

		/// <summary>
		/// ProductPid(产品编号)
		/// </summary>
		public int ProductPid
		{
			get { return m_ProductPid; }
			set { m_ProductPid = value; }
		}

		/// <summary>
		/// Number(数量)
		/// </summary>
		public int Number
		{
			get { return m_Number; }
			set { m_Number = value; }
		}

		/// <summary>
		/// OrderAmount(订单金额)
		/// </summary>
		public decimal OrderAmount
		{
			get { return m_OrderAmount; }
			set { m_OrderAmount = value; }
		}

		/// <summary>
		/// OrderGold(订单金币)
		/// </summary>
		public long OrderGold
		{
			get { return m_OrderGold; }
			set { m_OrderGold = value; }
		}

		/// <summary>
		/// OrderMedal(订单奖牌)
		/// </summary>
		public long OrderMedal
		{
			get { return m_OrderMedal; }
			set { m_OrderMedal = value; }
		}

		/// <summary>
		/// Remark(备注说明)
		/// </summary>
		public string Remark
		{
			get { return m_Remark; }
			set { m_Remark = value; }
		}

		/// <summary>
		/// 订单状态 0:未付款;1:已付款待处理;2:处理完成
		/// </summary>
		public int OrderStatus
		{
			get { return m_OrderStatus; }
			set { m_OrderStatus = value; }
		}

		/// <summary>
		/// IPAddress(IP地址)
		/// </summary>
		public string IPAddress
		{
			get { return m_IPAddress; }
			set { m_IPAddress = value; }
		}

		/// <summary>
		/// CTime(订单日期)
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		#endregion

	}
}
