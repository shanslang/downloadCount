/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-01-10 16:41:58*/
/*Table:GameScoreInfoEx*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Treasure
{
    public class GameScoreInfoEx
    {
        #region 构造函数
        public GameScoreInfoEx() { }
        #endregion

        #region 私有变量
        /// <summary>
        /// 表名
        /// </summary>
        public const string Tablename = "GameScoreInfoEx";

        /// <summary>
        /// 
        /// </summary>
        public const string _UserId = "UserId";

        /// <summary>
        /// 
        /// </summary>
        public const string _UserMedal = "UserMedal";

        /// <summary>
        /// 
        /// </summary>
        public const string _LoveLiness = "LoveLiness";
        /// <summary>
        /// 
        /// </summary>
        public const string _BillVolume = "BillVolume";

        #endregion

        #region 私有变量
        private int m_UserId;//
        private int m_UserMedal;//
        private int m_LoveLiness;//
        private int m_BillVolume;//

        #endregion

        #region 公开属性

        /// <summary>
        /// 
        /// </summary>
        public int UserId
        {
            get { return m_UserId; }
            set { m_UserId = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int UserMedal
        {
            get { return m_UserMedal; }
            set { m_UserMedal = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int LoveLiness
        {
            get { return m_LoveLiness; }
            set { m_LoveLiness = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int BillVolume
        {
            get { return m_BillVolume; }
            set { m_BillVolume = value; }
        }
        #endregion

    }
}
