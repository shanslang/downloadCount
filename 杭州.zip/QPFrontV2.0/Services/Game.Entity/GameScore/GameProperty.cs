﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Entity.GameScore
{
    [Serializable]
    public class GameProperty
    {
        #region 常量
        /// <summary>
        /// 表名
        /// </summary>
        public const string Tablename = "GameProperty";

        /// <summary>
        /// 
        /// </summary>
        public const string _ID = "ID";

        /// <summary>
        /// 
        /// </summary>
        public const string _Name = "Name";

        /// <summary>
        /// 
        /// </summary>
        public const string _Cash = "Cash";

        /// <summary>
        /// 
        /// </summary>
        public const string _Discount = "Discount";

        /// <summary>
        /// 
        /// </summary>
        public const string _IssueArea = "IssueArea";

        /// <summary>
        /// 
        /// </summary>
        public const string _ServiceArea = "ServiceArea";

        /// <summary>
        /// 
        /// </summary>
        public const string _SendLoveLiness = "SendLoveLiness";

        /// <summary>
        /// 
        /// </summary>
        public const string _RecvLoveLiness = "RecvLoveLiness";

        /// <summary>
        /// 
        /// </summary>
        public const string _RegulationsInfo = "RegulationsInfo";

        /// <summary>
        /// 
        /// </summary>
        public const string _Nullity = "Nullity";
        #endregion

        #region 私有变量
        private int m_ID;						//
        private string m_Name;					//用户标识
        private decimal m_Cash;		            //
        private long m_Gold;			        //
        private int m_Discount;			        //登录地址
        private int m_IssueArea;			    //
        private int m_ServiceArea;			    //
        private long m_SendLoveLiness;			//
        private long m_RecvLoveLiness;			//
        private string m_RegulationsInfo;       //
        private int m_Nullity;                  //
        #endregion

        #region 构造方法

        /// <summary>
        /// 初始化AccountsFace
        /// </summary>
        public GameProperty()
        {
            m_ID = 0;						//
            m_Name = "";					//用户标识
            m_Cash = 0;		            //
            m_Gold = 0;			        //
            m_Discount = 0;			        //登录地址
            m_IssueArea = 0;			    //
            m_ServiceArea = 0;			    //
            m_SendLoveLiness = 0;			//
            m_RecvLoveLiness = 0;			//
            m_RegulationsInfo = "";       //
            m_Nullity = 0;                  //
        }

        #endregion

        #region 公共属性
        public int ID
        {
            get { return m_ID; }
            set { m_ID = value; }
        }
        public string Name
        {
            get { return m_Name; }
            set { m_Name = value; }
        }
        public decimal Cash
        {
            get { return m_Cash; }
            set { m_Cash = value; }
        }
        public long Gold
        {
            get { return m_Gold; }
            set { m_Gold = value; }
        }
        public int Discount
        {
            get { return m_Discount; }
            set { m_Discount = value; }
        }
        public int IssueArea
        {
            get { return m_IssueArea; }
            set { m_IssueArea = value; }
        }
        public int ServiceArea
        {
            get { return m_ServiceArea; }
            set { m_ServiceArea = value; }
        }
        public long SendLoveLiness
        {
            get { return m_SendLoveLiness; }
            set { m_SendLoveLiness = value; }
        }
        public long RecvLoveLiness
        {
            get { return m_RecvLoveLiness; }
            set { m_RecvLoveLiness = value; }
        }
        public string RegulationsInfo
        {
            get { return m_RegulationsInfo; }
            set { m_RegulationsInfo = value; }
        }
        public int Nullity
        {
            get { return m_Nullity; }
            set { m_Nullity = value; }
        }
        #endregion
    }
}
