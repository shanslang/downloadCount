﻿
using System;
namespace Game.Entity.MobileApp
{
    /// <summary>
    /// NoticeInfo:实体类(公告配置信息)
    /// </summary>
    [Serializable]
    public partial class NoticeInfo
    {
        public NoticeInfo()
        { }
        #region Model
        private int _id;
        private string _title;
        private int _gameid = 0;
        private int _serverid = 0;
        private DateTime? _starttime;
        private DateTime? _endtime;
        private int _isloginsend = 0;
        private string _info = "";
        private DateTime _ctime;
        private int _GameType;
        /// <summary>
        /// 
        /// </summary>
        public int Id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 标题
        /// </summary>
        public string Title
        {
            set { _title = value; }
            get { return _title; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int GameID
        {
            set { _gameid = value; }
            get { return _gameid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? StartTime
        {
            set { _starttime = value; }
            get { return _starttime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? EndTime
        {
            set { _endtime = value; }
            get { return _endtime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int IsLoginSend
        {
            set { _isloginsend = value; }
            get { return _isloginsend; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Info
        {
            set { _info = value; }
            get { return _info; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime Ctime
        {
            set { _ctime = value; }
            get { return _ctime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int GameType
        {
            get { return _GameType; }
            set { _GameType = value; }
        }
        #endregion Model

    }
}

