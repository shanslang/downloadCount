﻿
using System;
namespace Game.Entity.MobileApp
{
    /// <summary>
    /// GameAppIDInfo:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class GameAppIDInfo
    {
        public GameAppIDInfo()
        { }
        #region Model
        private int _pid = 0;
        private string _appid = "";
        private string _andorid = "";
        private int _sertype = 0;

        public int Pid
        {
            get { return _pid; }
            set { _pid = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string APPID
        {
            set { _appid = value; }
            get { return _appid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Andorid
        {
            set { _andorid = value; }
            get { return _andorid; }
        }
        /// <summary>
        /// 1=血流 2=牛牛 3=金花
        /// </summary>
        public int SerType
        {
            set { _sertype = value; }
            get { return _sertype; }
        }
        #endregion Model

    }
}

