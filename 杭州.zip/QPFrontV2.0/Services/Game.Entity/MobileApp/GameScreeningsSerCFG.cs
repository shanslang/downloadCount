﻿
using System;
namespace Game.Entity.MobileApp
{
    /// <summary>
    /// GameScreeningsSerCFG:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class GameScreeningsSerCFG
    {
        public GameScreeningsSerCFG()
        { }
        #region Model
        private int _id;
        private int _screenid;
        private int _serverid;
        private DateTime _ctime = DateTime.Now;
        private long _accessGold = 0;


        /// <summary>
        /// 
        /// </summary>
        public int Id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int ScreenID
        {
            set { _screenid = value; }
            get { return _screenid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime CTime
        {
            set { _ctime = value; }
            get { return _ctime; }
        }
        /// <summary>
        /// 房间准入金币
        /// </summary>
        public long AccessGold
        {
            get { return _accessGold; }
            set { _accessGold = value; }
        }
        #endregion Model

    }
}

