﻿
using System;
namespace Game.Entity.MobileApp
{
    /// <summary>
    /// AppServerAddressCFG:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class AppServerAddressCFG
    {
        public AppServerAddressCFG()
        { }
        #region Model
        private int _versionid = 0;
        private string _logonserveraddress = "";
        private int _logonserverport = 0;
        private int _isDefense = 0;
        /// <summary>
        /// 
        /// </summary>
        public int VersionID
        {
            set { _versionid = value; }
            get { return _versionid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string LogonServerAddress
        {
            set { _logonserveraddress = value; }
            get { return _logonserveraddress; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int LogonServerPort
        {
            set { _logonserverport = value; }
            get { return _logonserverport; }
        }
        public int IsDefense
        {
            set { _isDefense = value; }
            get { return _isDefense; }
        }
        #endregion Model

    }
}

