﻿
using System;
namespace Game.Entity.MobileApp
{
    /// <summary>
    /// AppVisitAddressCFG:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class AppVisitAddressCFG
    {
        public AppVisitAddressCFG()
        { }
        #region Model
        private int _versionid = 0;
        private string _appweb_url = "";
        private string _appfilerec = "";
        private string _appUpdate_url = "";
        /// <summary>
        /// 
        /// </summary>
        public int VersionID
        {
            set { _versionid = value; }
            get { return _versionid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Appweb_url
        {
            set { _appweb_url = value; }
            get { return _appweb_url; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string AppFileRec
        {
            set { _appfilerec = value; }
            get { return _appfilerec; }
        }
         
        public string AppUpdate_url
        {
            set { _appUpdate_url = value; }
            get { return _appUpdate_url; }
        }
        /// <summary>
        /// 是否启用屏蔽0：不启用，1启用
        /// </summary>
        public int IsEnble
        {
            set;
            get;
        }
        #endregion Model

    }
}

