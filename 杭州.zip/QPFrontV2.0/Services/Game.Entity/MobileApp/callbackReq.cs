﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Game.Entity.MobileApp
{
    [Serializable]
    public class callbackReq
    {

        private string m_orderid;
        private string m_ordertime;
        private string m_cpid;
        private string m_appid;
        private string m_fid;
        private string m_payfee;
        private string m_consumeCode;


        [XmlElement("orderid")]
        public string orderid
        {

            get { return m_orderid; }

            set { m_orderid = value; }

        }

        [XmlElement("ordertime")]
        public string ordertime
        {

            get { return m_ordertime; }

            set { m_ordertime = value; }

        }
        [XmlElement("cpid")]
        public string cpid
        {

            get { return m_cpid; }

            set { m_cpid = value; }

        }

        [XmlElement("appid")]
        public string appid
        {

            get { return m_appid; }

            set { m_appid = value; }

        }
        [XmlElement("fid")]
        public string fid
        {

            get { return m_fid; }

            set { m_fid = value; }

        }

        [XmlElement("consumeCode")]
        public string consumeCode
        {

            get { return m_consumeCode; }

            set { m_consumeCode = value; }

        }

        [XmlElement("payfee")]
        public string payfee
        {

            get { return m_payfee; }

            set { m_payfee = value; }

        }
        private string m_payType;
        [XmlElement("payType")]
        public string payType
        {

            get { return m_payType; }

            set { m_payType = value; }

        }

        private string m_hRet;
        [XmlElement("hRet")]
        public string hRet
        {

            get { return m_hRet; }

            set { m_hRet = value; }

        }

        private string m_status;
        [XmlElement("status")]
        public string status
        {

            get { return m_status; }

            set { m_status = value; }

        }
        private string m_signMsg;
        [XmlElement("signMsg")]
        public string signMsg
        {

            get { return m_signMsg; }

            set { m_signMsg = value; }

        }

    }

    [Serializable]
    public class checkOrderIdReq
    {

        private string m_orderid;
        private string m_signMsg; 
        private string m_usercode;
        private string m_provinceid;
        private string m_cityid; 


        [XmlElement("orderid")]
        public string orderid
        {

            get { return m_orderid; }

            set { m_orderid = value; }

        }

        [XmlElement("usercode")]
        public string usercode
        {

            get { return m_usercode; }

            set { m_usercode = value; }

        }

        [XmlElement("provinceid")]
        public string provinceid
        {

            get { return m_provinceid; }

            set { m_provinceid = value; }

        }

        [XmlElement("cityid")]
        public string cityid
        {

            get { return m_cityid; }

            set { m_cityid = value; }

        }
          
        [XmlElement("signMsg")]
        public string signMsg
        {

            get { return m_signMsg; }

            set { m_signMsg = value; }

        }

    }
}
