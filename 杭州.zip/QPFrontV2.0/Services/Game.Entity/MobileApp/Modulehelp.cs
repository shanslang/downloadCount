﻿
using System;
namespace Game.Entity.MobileApp
{
    /// <summary>
    /// Modulehelp:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class Modulehelp
    {
        public Modulehelp()
        { }
        #region Model
        private int _id = 0;
        private int _num = 0;
        private int _value = 0;
        private string _content = "";
        private string _remarks = "";
        /// <summary>
        /// ID 信息
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 编号信息
        /// </summary>
        public int Num
        {
            set { _num = value; }
            get { return _num; }
        }
        /// <summary>
        /// 数值信息
        /// </summary>
        public int Value
        {
            set { _value = value; }
            get { return _value; }
        }
        /// <summary>
        /// 内容信息
        /// </summary>
        public string Content
        {
            set { _content = value; }
            get { return _content; }
        }
        /// <summary>
        /// 备注信息
        /// </summary>
        public string Remarks
        {
            set { _remarks = value; }
            get { return _remarks; }
        }
        #endregion Model

    }
}

