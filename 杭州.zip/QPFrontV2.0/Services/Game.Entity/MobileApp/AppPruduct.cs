﻿
using System;
namespace Game.Entity.MobileApp
{
    /// <summary>
    /// AppPruduct:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class AppPruduct
    {
        public AppPruduct()
        { }
        #region Model
        private int _id;
        private string _name;
        private string _shortname;
        private decimal _pricermb;
        private int _pricegold = 0;
        private int _ptype;
        private string _identifier;
        private int _recommend = 0;
        private string _appleid;
        private int _nullity = 0;
        private string _pid = "0";
        private DateTime _ctime = DateTime.Now;
        private string _explain;

        /// <summary>
        /// 
        /// </summary>
        public int Id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 名称
        /// </summary>
        public string Name
        {
            set { _name = value; }
            get { return _name; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ShortName
        {
            set { _shortname = value; }
            get { return _shortname; }
        }
        /// <summary>
        /// 人民币价格
        /// </summary>
        public decimal PriceRMB
        {
            set { _pricermb = value; }
            get { return _pricermb; }
        }
        /// <summary>
        /// 金币价值
        /// </summary>
        public int PriceGold
        {
            set { _pricegold = value; }
            get { return _pricegold; }
        }
        /// <summary>
        /// 商品类型(1 - 金币  2 - 红钻 3 - 黄钻 4 - 蓝钻 5=道具)
        /// </summary>
        public int Ptype
        {
            set { _ptype = value; }
            get { return _ptype; }
        }
        /// <summary>
        /// 提交到苹果服务器的产品ID
        /// </summary>
        public string Identifier
        {
            set { _identifier = value; }
            get { return _identifier; }
        }
        /// <summary>
        /// 是否推荐
        /// </summary>
        public int Recommend
        {
            set { _recommend = value; }
            get { return _recommend; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string AppleID
        {
            set { _appleid = value; }
            get { return _appleid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int Nullity
        {
            set { _nullity = value; }
            get { return _nullity; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string PID
        {
            set { _pid = value; }
            get { return _pid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime CTime
        {
            set { _ctime = value; }
            get { return _ctime; }
        }
        public string Explain
        {
            get { return _explain; }
            set { _explain = value; }
        }
        #endregion Model

    }
}

