﻿
using System;
namespace Game.Entity.MobileApp
{
    /// <summary>
    /// GameDownloadReward:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class GameDownloadReward
    {
        public GameDownloadReward()
        { }
        #region Model
        private int _gameid;
        private int _rewardvalue;
        private int _rewardtype;
        private string _awarddescription;
        /// <summary>
        /// 
        /// </summary>
        public int GameID
        {
            set { _gameid = value; }
            get { return _gameid; }
        }
        /// <summary>
        /// 奖励值 65536以上为道具
        /// </summary>
        public int RewardValue
        {
            set { _rewardvalue = value; }
            get { return _rewardvalue; }
        }
        /// <summary>
        /// 奖励类型 1=金币 2=奖牌 3=道具  
        /// </summary>
        public int RewardType
        {
            set { _rewardtype = value; }
            get { return _rewardtype; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Awarddescription
        {
            set { _awarddescription = value; }
            get { return _awarddescription; }
        }
        #endregion Model

    }
}

