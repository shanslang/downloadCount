/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-11-16 17:11:40*/
/*Table:GameAppUrlCFG*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.MobileApp
{
	public class GameAppUrlCFG
	{
		#region 构造函数
		public GameAppUrlCFG(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "GameAppUrlCFG";

		/// <summary>
		/// 
		/// </summary>
		public const string _ID = "ID";

		/// <summary>
		/// 
		/// </summary>
		public const string _GameID = "GameID";

		/// <summary>
		/// 渠道ID  0-IOS appStore ； 1-IOS越狱；  2-Android官方渠道 ；3-Android360渠道；4-Android联通渠道
		/// </summary>
		public const string _ChanelID = "ChanelID";

		/// <summary>
		/// 
		/// </summary>
		public const string _AppURL = "AppURL";

		/// <summary>
		/// 引擎版本号
		/// </summary>
		public const string _EngineVersion = "EngineVersion";

		/// <summary>
		/// 
		/// </summary>
		public const string _Description = "Description";

		/// <summary>
		/// 
		/// </summary>
		public const string _IsDisable = "IsDisable";

		/// <summary>
		/// 
		/// </summary>
		public const string _UpdateInFo = "UpdateInFo";

		#endregion

		#region 私有变量
		private int m_ID;//
		private int m_GameID;//
		private int m_ChanelID;//渠道ID  0-IOS appStore ； 1-IOS越狱；  2-Android官方渠道 ；3-Android360渠道；4-Android联通渠道
		private string m_AppURL;//
		private int m_EngineVersion;//引擎版本号
		private string m_Description;//
		private byte m_IsDisable;//
		private string m_UpdateInFo;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int ID
		{
			get { return m_ID; }
			set { m_ID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int GameID
		{
			get { return m_GameID; }
			set { m_GameID = value; }
		}

		/// <summary>
		/// 渠道ID  0-IOS appStore ； 1-IOS越狱；  2-Android官方渠道 ；3-Android360渠道；4-Android联通渠道
		/// </summary>
		public int ChanelID
		{
			get { return m_ChanelID; }
			set { m_ChanelID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string AppURL
		{
			get { return m_AppURL; }
			set { m_AppURL = value; }
		}

		/// <summary>
		/// 引擎版本号
		/// </summary>
		public int EngineVersion
		{
			get { return m_EngineVersion; }
			set { m_EngineVersion = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string Description
		{
			get { return m_Description; }
			set { m_Description = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public byte IsDisable
		{
			get { return m_IsDisable; }
			set { m_IsDisable = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string UpdateInFo
		{
			get { return m_UpdateInFo; }
			set { m_UpdateInFo = value; }
		}

		#endregion

	}
}
