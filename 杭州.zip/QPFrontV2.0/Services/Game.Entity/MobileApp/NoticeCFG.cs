﻿
using System;
namespace Game.Entity.MobileApp
{
    /// <summary>
    /// NoticeCFG:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class NoticeCFG
    {
        public NoticeCFG()
        { }
        #region Model
        private int _id;
        private int _noticeid = 0;
        private string _pagelink = "#";
        private int _pagewidth = 0;
        private int _pageheight = 0;
        private string _title = "";
        private int _androidWidth = 0;
        private int _androidHeight = 0;

        /// <summary>
        /// 公告标题
        /// </summary>
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int Id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int NoticeID
        {
            set { _noticeid = value; }
            get { return _noticeid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string PageLink
        {
            set { _pagelink = value; }
            get { return _pagelink; }
        }
        /// <summary>
        /// IOS设备宽度尺寸
        /// </summary>
        public int PageWidth
        {
            set { _pagewidth = value; }
            get { return _pagewidth; }
        }
        /// <summary>
        ///  IOS设备高度尺寸
        /// </summary>
        public int PageHeight
        {
            set { _pageheight = value; }
            get { return _pageheight; }
        }
        /// <summary>
        ///  Android设备宽度尺寸
        /// </summary>
        public int AndroidWidth
        {
            get { return _androidWidth; }
            set { _androidWidth = value; }
        }
        /// <summary>
        ///  Android设备高度尺寸
        /// </summary>
        public int AndroidHeight
        {
            get { return _androidHeight; }
            set { _androidHeight = value; }
        }
        #endregion Model

    }
}

