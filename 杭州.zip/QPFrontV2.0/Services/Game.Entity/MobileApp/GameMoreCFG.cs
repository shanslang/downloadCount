﻿
using System;
namespace Game.Entity.MobileApp
{
    /// <summary>
    /// GameMoreCFG:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class GameMoreCFG
    {
        public GameMoreCFG()
        { }
        #region Model
        private int _gameid;
        private int _iconid = 0;
        private string _iconmd5;
        private string _iconurl;
        private string _gamedescription;
        private string _url;

        /// <summary>
        /// 游戏 ID
        /// </summary>
        public int GameId
        {
            set { _gameid = value; }
            get { return _gameid; }
        }
        /// <summary>
        /// ICON 名称
        /// </summary>
        public int IconId
        {
            set { _iconid = value; }
            get { return _iconid; }
        }
        /// <summary>
        /// ICON md5
        /// </summary>
        public string Iconmd5
        {
            set { _iconmd5 = value; }
            get { return _iconmd5; }
        }
        /// <summary>
        /// ICON url
        /// </summary>
        public string IconUrl
        {
            set { _iconurl = value; }
            get { return _iconurl; }
        }
        /// <summary>
        /// 游戏简要说明
        /// </summary>
        public string Gamedescription
        {
            set { _gamedescription = value; }
            get { return _gamedescription; }
        }

        /// <summary>
        /// 地址 如果是IOS平台此地址为AppSore的跳转地址；若是android则为下载地址；
        /// </summary>
        public string Url
        {
            set { _url = value; }
            get { return _url; }
        }
        #endregion Model

    }
}

