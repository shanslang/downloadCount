﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Entity.MobileApp
{
    [Serializable]
    public class GameScreenings
    {
        public GameScreenings()
        { }
        #region Model
        private int _id;
        private string _name;
        private string _slogans;
        private int _accessgold;
        private int _serType;
        /// <summary>
        /// 
        /// </summary>
        public int Id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 场次名称
        /// </summary>
        public string Name
        {
            set { _name = value; }
            get { return _name; }
        }
        /// <summary>
        /// 宣传口号（广告语）
        /// </summary>
        public string Slogans
        {
            set { _slogans = value; }
            get { return _slogans; }
        }
        /// <summary>
        /// 准入金币
        /// </summary>
        public int AccessGold
        {
            set { _accessgold = value; }
            get { return _accessgold; }
        }

        /// <summary>
        /// 准入金币
        /// </summary>
        public int SerType
        {
            set { _serType = value; }
            get { return _serType; }
        }
        /// <summary>
        /// 排序ID（以准入金币排序）
        /// </summary>
        public int SortID
        {
            set;
            get;
        }
        #endregion
    }
}

