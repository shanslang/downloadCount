/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2016-01-13 14:30:18*/
/*Table:NTaskReward*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;
using Newtonsoft.Json;

namespace Game.Entity.Task
{
	public class NTaskReward
	{
		#region 构造函数
		public NTaskReward(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "NTaskReward";

		/// <summary>
		/// 任务ID
		/// </summary>
		public const string _TaskId = "TaskId";

		/// <summary>
		/// 奖励类型 1-金币 2-经验值 3-奖牌 4-黄钻 5-红钻 6-蓝钻 65536以后是道具ID
		/// </summary>
		public const string _RewardType = "RewardType";

		/// <summary>
		/// 奖励值
		/// </summary>
		public const string _RewardValue = "RewardValue";

		/// <summary>
		/// 奖励概率
		/// </summary>
		public const string _RewardRate = "RewardRate";

		#endregion

		#region 私有变量
		private int m_TaskId;//任务ID
		private int m_RewardType;//奖励类型 1-金币 2-经验值 3-奖牌 4-黄钻 5-红钻 6-蓝钻 65536以后是道具ID
		private int m_RewardValue;//奖励值
		private byte m_RewardRate;//奖励概率
		#endregion

		#region 公开属性

		/// <summary>
		/// 任务ID
		/// </summary>
        [XmlElement("tId")]
        [JsonProperty(PropertyName = "tId")]
		public int TaskId
		{
			get { return m_TaskId; }
			set { m_TaskId = value; }
		}

		/// <summary>
		/// 奖励类型 1-金币 2-经验值 3-奖牌 4-黄钻 5-红钻 6-蓝钻 65536以后是道具ID
		/// </summary>
        [XmlElement("rType")]
        [JsonProperty(PropertyName = "rType")]
		public int RewardType
		{
			get { return m_RewardType; }
			set { m_RewardType = value; }
		}

		/// <summary>
		/// 奖励值
		/// </summary>
        [XmlElement("rValue")]
        [JsonProperty(PropertyName = "rValue")]
		public int RewardValue
		{
			get { return m_RewardValue; }
			set { m_RewardValue = value; }
		}

		/// <summary>
		/// 奖励概率
		/// </summary>
        [XmlElement("rRate")]
        [JsonProperty(PropertyName = "rRate")]
		public byte RewardRate
		{
			get { return m_RewardRate; }
			set { m_RewardRate = value; }
		}
        /// <summary>
        /// 名字
        /// </summary>
        [XmlElement("rName")]
        [JsonProperty(PropertyName = "rName")]
        public string Name
        {
            set;
            get;
        }
        /// <summary>
        /// 说明
        /// </summary>
        [XmlElement("rExplain")]
        [JsonProperty(PropertyName = "rExplain")]
        public string Explain
        {
            set;
            get;
        }
		#endregion

	}
}
