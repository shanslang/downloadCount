/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2016-01-13 14:30:05*/
/*Table:NTaskGroupInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;
using Newtonsoft.Json;

namespace Game.Entity.Task
{
	public class NTaskGroupInfo
	{
		#region 构造函数
		public NTaskGroupInfo(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "NTaskGroupInfo";

		/// <summary>
		/// 任务组ID
		/// </summary>
		public const string _GroupId = "GroupId";

		/// <summary>
		/// 任务组描述
		/// </summary>
		public const string _GroupDesc = "GroupDesc";

		/// <summary>
		/// 任务组排序ID 越小越靠前
		/// </summary>
		public const string _GroupSort = "GroupSort";

		/// <summary>
		/// 任务组TAB页MASK（针对于客户端TAB页状态 0x01为大厅 0x02为游戏 0x10为是否显示标记 0x20为操作标记，如果MASK为4时，高16位有值，则是针对于特定游戏的MASK）
		/// </summary>
		public const string _GroupMask = "GroupMask";

		#endregion

		#region 私有变量
		private int m_GroupId;//任务组ID
		private string m_GroupDesc;//任务组描述
		private int m_GroupSort;//任务组排序ID 越小越靠前
		private int m_GroupMask;//任务组TAB页MASK（针对于客户端TAB页状态 0x01为大厅 0x02为游戏 0x10为是否显示标记 0x20为操作标记，如果MASK为4时，高16位有值，则是针对于特定游戏的MASK）
		#endregion

		#region 公开属性

		/// <summary>
		/// 任务组ID
		/// </summary>
        [XmlElement("gId")]
        [JsonProperty(PropertyName = "gId")]
		public int GroupId
		{
			get { return m_GroupId; }
			set { m_GroupId = value; }
		}

		/// <summary>
		/// 任务组描述
		/// </summary>
        [XmlElement("gDesc")]
        [JsonProperty(PropertyName = "gDesc")]
		public string GroupDesc
		{
			get { return m_GroupDesc; }
			set { m_GroupDesc = value; }
		}

		/// <summary>
		/// 任务组排序ID 越小越靠前
		/// </summary>
        [XmlElement("gSort")]
        [JsonProperty(PropertyName = "gSort")]
		public int GroupSort
		{
			get { return m_GroupSort; }
			set { m_GroupSort = value; }
		}

		/// <summary>
		/// 任务组TAB页MASK（针对于客户端TAB页状态 0x01为大厅 0x02为游戏 0x10为是否显示标记 0x20为操作标记，如果MASK为4时，高16位有值，则是针对于特定游戏的MASK）
		/// </summary>
        [XmlElement("gMask")]
        [JsonProperty(PropertyName = "gMask")]
		public int GroupMask
		{
			get { return m_GroupMask; }
			set { m_GroupMask = value; }
		}

		#endregion

	}
}
