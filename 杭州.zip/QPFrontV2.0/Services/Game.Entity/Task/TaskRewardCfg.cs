/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-11-13 14:07:29*/
/*Table:TaskRewardCfg*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Task
{
	public class TaskRewardCfg
	{
		#region 构造函数
		public TaskRewardCfg(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "TaskRewardCfg";

		/// <summary>
		/// 
		/// </summary>
		public const string _TaskID = "TaskID";

		/// <summary>
		/// 
		/// </summary>
		public const string _subTaskID = "subTaskID";

		/// <summary>
		/// 奖励类型 1-金币 2-经验值 3-奖牌 4-黄钻 5-红钻 6-蓝钻 65536以后是道具ID
		/// </summary>
		public const string _RewardType = "RewardType";

		/// <summary>
		/// 
		/// </summary>
		public const string _RewardValue = "RewardValue";

		#endregion

		#region 私有变量
		private int m_TaskID;//
		private int m_subTaskID;//
		private int m_RewardType;//奖励类型 1-金币 2-经验值 3-奖牌 4-黄钻 5-红钻 6-蓝钻 65536以后是道具ID
		private long m_RewardValue;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int TaskID
		{
			get { return m_TaskID; }
			set { m_TaskID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int subTaskID
		{
			get { return m_subTaskID; }
			set { m_subTaskID = value; }
		}

		/// <summary>
		/// 奖励类型 1-金币 2-经验值 3-奖牌 4-黄钻 5-红钻 6-蓝钻 65536以后是道具ID
		/// </summary>
		public int RewardType
		{
			get { return m_RewardType; }
			set { m_RewardType = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public long RewardValue
		{
			get { return m_RewardValue; }
			set { m_RewardValue = value; }
		}

		#endregion

	}
}
