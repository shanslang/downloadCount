﻿
using System;
namespace Game.Entity.Task
{
    /// <summary>
    /// TaskInfo:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class TaskInfoHelper
    {
        public TaskInfoHelper()
        { }
        #region Model
        private int _taskid;
        private string _taskname;
        private int _curvalue;
        private decimal _progress;

        /// <summary>
        /// 
        /// </summary>
        public int TaskID
        {
            set { _taskid = value; }
            get { return _taskid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string TaskName
        {
            set { _taskname = value; }
            get { return _taskname; }
        }
        /// <summary>
        /// 当前任务进度
        /// </summary>
        public int Curvalue
        {
            get { return _curvalue; }
            set { _curvalue = value; }
        }
        /// <summary>
        /// 任务进度
        /// </summary>
        public decimal Progress
        {
            get { return _progress; }
            set { _progress = value; }
        }
        #endregion Model

    }
}

