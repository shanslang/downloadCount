/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2016-01-13 14:30:15*/
/*Table:NTaskInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Task
{
    public partial class NTaskInfo
	{
		#region 构造函数
		public NTaskInfo(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "NTaskInfo";

		/// <summary>
		/// 任务ID
		/// </summary>
		public const string _TaskId = "TaskId";

		/// <summary>
		/// 任务信息Key
		/// </summary>
		public const string _TaskInfoKey = "TaskInfoKey";

		/// <summary>
		/// 任务名
		/// </summary>
		public const string _TaskName = "TaskName";

		/// <summary>
		/// 任务描述
		/// </summary>
		public const string _TaskDesc = "TaskDesc";

		/// <summary>
		/// 任务图标
		/// </summary>
		public const string _TaskIcon = "TaskIcon";

		/// <summary>
		/// 任务排序ID 越小越靠前
		/// </summary>
		public const string _TaskSort = "TaskSort";

		/// <summary>
		/// 任务所属组ID
		/// </summary>
		public const string _TaskGroup = "TaskGroup";

		/// <summary>
		/// 任务显示MASK 参考任务组MASK
		/// </summary>
		public const string _TaskMask = "TaskMask";

		/// <summary>
		/// 任务重置ID
		/// </summary>
		public const string _TaskResetId = "TaskResetId";

		/// <summary>
		/// 任务重置类型
		/// </summary>
		public const string _TaskResetType = "TaskResetType";

		/// <summary>
		/// 任务重置值
		/// </summary>
		public const string _TaskResetValue = "TaskResetValue";

		/// <summary>
		/// 任务重置时间
		/// </summary>
		public const string _TaskLastResetTime = "TaskLastResetTime";

		/// <summary>
		/// 任务有效期-开始
		/// </summary>
		public const string _TaskTimeBegin = "TaskTimeBegin";

		/// <summary>
		/// 任务有效期-结束
		/// </summary>
		public const string _TaskTimeEnd = "TaskTimeEnd";

		/// <summary>
		/// 子任务ID
		/// </summary>
		public const string _TaskNextId = "TaskNextId";

		#endregion

		#region 私有变量
		private int m_TaskId;//任务ID
		private int m_TaskInfoKey;//任务信息Key
		private string m_TaskName;//任务名
		private string m_TaskDesc;//任务描述
		private int m_TaskIcon;//任务图标
		private int m_TaskSort;//任务排序ID 越小越靠前
		private int m_TaskGroup;//任务所属组ID
		private int m_TaskMask;//任务显示MASK 参考任务组MASK
		private int m_TaskResetId;//任务重置ID
		private int m_TaskResetType;//任务重置类型
		private int m_TaskResetValue;//任务重置值
		private DateTime m_TaskLastResetTime;//任务重置时间
		private DateTime m_TaskTimeBegin;//任务有效期-开始
		private DateTime m_TaskTimeEnd;//任务有效期-结束
		private int m_TaskNextId;//子任务ID
		#endregion

		#region 公开属性

		/// <summary>
		/// 任务ID
		/// </summary>
		public int TaskId
		{
			get { return m_TaskId; }
			set { m_TaskId = value; }
		}

		/// <summary>
		/// 任务信息Key
		/// </summary>
		public int TaskInfoKey
		{
			get { return m_TaskInfoKey; }
			set { m_TaskInfoKey = value; }
		}

		/// <summary>
		/// 任务名
		/// </summary>
		public string TaskName
		{
			get { return m_TaskName; }
			set { m_TaskName = value; }
		}

		/// <summary>
		/// 任务描述
		/// </summary>
		public string TaskDesc
		{
			get { return m_TaskDesc; }
			set { m_TaskDesc = value; }
		}

		/// <summary>
		/// 任务图标
		/// </summary>
		public int TaskIcon
		{
			get { return m_TaskIcon; }
			set { m_TaskIcon = value; }
		}

		/// <summary>
		/// 任务排序ID 越小越靠前
		/// </summary>
		public int TaskSort
		{
			get { return m_TaskSort; }
			set { m_TaskSort = value; }
		}

		/// <summary>
		/// 任务所属组ID
		/// </summary>
		public int TaskGroup
		{
			get { return m_TaskGroup; }
			set { m_TaskGroup = value; }
		}

		/// <summary>
		/// 任务显示MASK 参考任务组MASK
		/// </summary>
		public int TaskMask
		{
			get { return m_TaskMask; }
			set { m_TaskMask = value; }
		}

		/// <summary>
		/// 任务重置ID
		/// </summary>
		public int TaskResetId
		{
			get { return m_TaskResetId; }
			set { m_TaskResetId = value; }
		}

		/// <summary>
		/// 任务重置类型
		/// </summary>
		public int TaskResetType
		{
			get { return m_TaskResetType; }
			set { m_TaskResetType = value; }
		}

		/// <summary>
		/// 任务重置值
		/// </summary>
		public int TaskResetValue
		{
			get { return m_TaskResetValue; }
			set { m_TaskResetValue = value; }
		}

		/// <summary>
		/// 任务重置时间
		/// </summary>
		public DateTime TaskLastResetTime
		{
			get { return m_TaskLastResetTime; }
			set { m_TaskLastResetTime = value; }
		}

		/// <summary>
		/// 任务有效期-开始
		/// </summary>
		public DateTime TaskTimeBegin
		{
			get { return m_TaskTimeBegin; }
			set { m_TaskTimeBegin = value; }
		}

		/// <summary>
		/// 任务有效期-结束
		/// </summary>
		public DateTime TaskTimeEnd
		{
			get { return m_TaskTimeEnd; }
			set { m_TaskTimeEnd = value; }
		}

		/// <summary>
		/// 子任务ID
		/// </summary>
		public int TaskNextId
		{
			get { return m_TaskNextId; }
			set { m_TaskNextId = value; }
		}

		#endregion

	}
}
