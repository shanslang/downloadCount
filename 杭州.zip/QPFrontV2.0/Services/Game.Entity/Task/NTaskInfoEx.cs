/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2016-01-13 14:30:15*/
/*Table:NTaskInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Task
{
	public partial class NTaskInfo
	{
        /// <summary>
        /// 
        /// </summary>
        public IList<NTaskReward> ListNTaskReward { set; get; }
	}
}
