/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-06-21 10:50:39*/
/*Table:SpreadFinanceInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class SpreadFinanceInfo
	{
		#region 构造函数
		public SpreadFinanceInfo(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "SpreadFinanceInfo";

		/// <summary>
		/// 自动编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 推广员Pid
		/// </summary>
		public const string _SpreadUserPid = "SpreadUserPid";

		/// <summary>
		/// 财务性质 1、个人  2、公司
		/// </summary>
		public const string _FinanceNature = "FinanceNature";

		/// <summary>
		/// 收款银行
		/// </summary>
		public const string _BankName = "BankName";

		/// <summary>
		/// 开户地
		/// </summary>
		public const string _BankAddress = "BankAddress";

		/// <summary>
		/// 银行账号
		/// </summary>
		public const string _BankAccount = "BankAccount";

		/// <summary>
		/// 收款人
		/// </summary>
		public const string _BankPerson = "BankPerson";

		/// <summary>
		/// 身份证号
		/// </summary>
		public const string _IdentityCode = "IdentityCode";

		/// <summary>
		/// 创建时间
		/// </summary>
		public const string _CTime = "CTime";

		#endregion

		#region 私有变量
		private int m_Pid;//自动编号
		private int m_SpreadUserPid;//推广员Pid
		private int m_FinanceNature;//财务性质 1、个人  2、公司
		private string m_BankName;//收款银行
		private string m_BankAddress;//开户地
		private string m_BankAccount;//银行账号
		private string m_BankPerson;//收款人
		private string m_IdentityCode;//身份证号
		private DateTime m_CTime;//创建时间
		#endregion

		#region 公开属性

		/// <summary>
		/// 自动编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 推广员Pid
		/// </summary>
		public int SpreadUserPid
		{
			get { return m_SpreadUserPid; }
			set { m_SpreadUserPid = value; }
		}

		/// <summary>
		/// 财务性质 1、个人  2、公司
		/// </summary>
		public int FinanceNature
		{
			get { return m_FinanceNature; }
			set { m_FinanceNature = value; }
		}

		/// <summary>
		/// 收款银行
		/// </summary>
		public string BankName
		{
			get { return m_BankName; }
			set { m_BankName = value; }
		}

		/// <summary>
		/// 开户地
		/// </summary>
		public string BankAddress
		{
			get { return m_BankAddress; }
			set { m_BankAddress = value; }
		}

		/// <summary>
		/// 银行账号
		/// </summary>
		public string BankAccount
		{
			get { return m_BankAccount; }
			set { m_BankAccount = value; }
		}

		/// <summary>
		/// 收款人
		/// </summary>
		public string BankPerson
		{
			get { return m_BankPerson; }
			set { m_BankPerson = value; }
		}

		/// <summary>
		/// 身份证号
		/// </summary>
		public string IdentityCode
		{
			get { return m_IdentityCode; }
			set { m_IdentityCode = value; }
		}

		/// <summary>
		/// 创建时间
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		#endregion

	}
}
