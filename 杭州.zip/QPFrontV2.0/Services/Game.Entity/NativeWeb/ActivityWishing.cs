/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-05-10 09:21:27*/
/*Table:ActivityWishing*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class ActivityWishing
	{
		#region 构造函数
		public ActivityWishing(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "ActivityWishing";

		/// <summary>
		/// 自动编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 用户ID
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 
		/// </summary>
		public const string _WishTo = "WishTo";

		/// <summary>
		/// 
		/// </summary>
		public const string _WishFrom = "WishFrom";

		/// <summary>
		/// 内容
		/// </summary>
		public const string _Content = "Content";

		/// <summary>
		/// 礼品图片
		/// </summary>
		public const string _GiftImg = "GiftImg";

		/// <summary>
		/// 背景
		/// </summary>
		public const string _Backgound = "Backgound";

		/// <summary>
		/// 时间
		/// </summary>
		public const string _CTime = "CTime";

		/// <summary>
		/// 客户IP
		/// </summary>
		public const string _ClientIP = "ClientIP";

		#endregion

		#region 私有变量
		private int m_Pid;//自动编号
		private int m_UserID;//用户ID
		private string m_WishTo;//
		private string m_WishFrom;//
		private string m_Content;//内容
		private int m_GiftImg;//礼品图片
		private int m_Backgound;//背景
		private DateTime m_CTime;//时间
		private string m_ClientIP;//客户IP
		#endregion

		#region 公开属性

		/// <summary>
		/// 自动编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 用户ID
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string WishTo
		{
			get { return m_WishTo; }
			set { m_WishTo = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string WishFrom
		{
			get { return m_WishFrom; }
			set { m_WishFrom = value; }
		}

		/// <summary>
		/// 内容
		/// </summary>
		public string Content
		{
			get { return m_Content; }
			set { m_Content = value; }
		}

		/// <summary>
		/// 礼品图片
		/// </summary>
		public int GiftImg
		{
			get { return m_GiftImg; }
			set { m_GiftImg = value; }
		}

		/// <summary>
		/// 背景
		/// </summary>
		public int Backgound
		{
			get { return m_Backgound; }
			set { m_Backgound = value; }
		}

		/// <summary>
		/// 时间
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		/// <summary>
		/// 客户IP
		/// </summary>
		public string ClientIP
		{
			get { return m_ClientIP; }
			set { m_ClientIP = value; }
		}

		#endregion

	}
}
