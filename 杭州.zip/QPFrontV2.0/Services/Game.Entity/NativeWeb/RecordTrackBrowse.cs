/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-06-10 14:22:22*/
/*Table:RecordTrackBrowse*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class RecordTrackBrowse
	{
		#region 构造函数
		public RecordTrackBrowse(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "RecordTrackBrowse";

		/// <summary>
		/// 主键PID
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 访问时间
		/// </summary>
		public const string _CTime = "CTime";

		/// <summary>
		/// 访问IP
		/// </summary>
		public const string _ClientIP = "ClientIP";

		/// <summary>
		/// 页面地址
		/// </summary>
		public const string _PageUrl = "PageUrl";

		/// <summary>
		/// 当天PV
		/// </summary>
		public const string _PageView = "PageView";

		#endregion

		#region 私有变量
		private int m_Pid;//主键PID
		private int m_UserID;//
		private DateTime m_CTime;//访问时间
		private string m_ClientIP;//访问IP
		private string m_PageUrl;//页面地址
		private int m_PageView;//当天PV
		#endregion

		#region 公开属性

		/// <summary>
		/// 主键PID
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 访问时间
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		/// <summary>
		/// 访问IP
		/// </summary>
		public string ClientIP
		{
			get { return m_ClientIP; }
			set { m_ClientIP = value; }
		}

		/// <summary>
		/// 页面地址
		/// </summary>
		public string PageUrl
		{
			get { return m_PageUrl; }
			set { m_PageUrl = value; }
		}

		/// <summary>
		/// 当天PV
		/// </summary>
		public int PageView
		{
			get { return m_PageView; }
			set { m_PageView = value; }
		}

		#endregion

	}
}
