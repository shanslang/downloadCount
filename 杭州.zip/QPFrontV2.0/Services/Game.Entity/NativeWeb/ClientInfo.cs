﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Entity.NativeWeb
{
    /// <summary>
    /// 客户端信息
    /// </summary>
    public class ClientInfo
    {
        /// <summary>
        /// 完整版 创建时间
        /// </summary>
        public DateTime GameLoaderCreateTime { set; get; }
        /// <summary>
        /// 完整版 版本信息
        /// </summary>
        public string GameLoaderVersion { set; get; }
        /// <summary>
        /// 完整版 文件长度
        /// </summary>
        public long GameLoaderLength { set; get; }
        /// <summary>
        /// 完整版 文件长度 转换格式
        /// </summary>
        public string GameLoaderLengthStr
        {
            get
            {
                return (Convert.ToDouble(this.GameLoaderLength) / Convert.ToDouble(1024 * 1024)).ToString("n2") + "M";
            }
        }
    }
}
