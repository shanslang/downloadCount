/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-06-16 15:49:16*/
/*Table:RecordSpreadUserAudit*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class RecordSpreadUserAudit
	{
		#region 构造函数
		public RecordSpreadUserAudit(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "RecordSpreadUserAudit";

		/// <summary>
		/// 自动编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 推广员Pid
		/// </summary>
		public const string _SpreadUserPid = "SpreadUserPid";

		/// <summary>
		/// 审核人ID
		/// </summary>
		public const string _BaseUserID = "BaseUserID";

		/// <summary>
		/// 审核时间
		/// </summary>
		public const string _AuditDate = "AuditDate";

		/// <summary>
		/// 审核状态: 1、新建 2、审核中 3、审核通过
		/// </summary>
		public const string _AuditStateID = "AuditStateID";

		/// <summary>
		/// (审核备注
		/// </summary>
		public const string _AuditRemark = "AuditRemark";

		#endregion

		#region 私有变量
		private int m_Pid;//自动编号
		private int m_SpreadUserPid;//推广员Pid
		private int m_BaseUserID;//审核人ID
		private DateTime m_AuditDate;//审核时间
		private int m_AuditStateID;//审核状态: 1、新建 2、审核中 3、审核通过
		private string m_AuditRemark;//(审核备注
		#endregion

		#region 公开属性

		/// <summary>
		/// 自动编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 推广员Pid
		/// </summary>
		public int SpreadUserPid
		{
			get { return m_SpreadUserPid; }
			set { m_SpreadUserPid = value; }
		}

		/// <summary>
		/// 审核人ID
		/// </summary>
		public int BaseUserID
		{
			get { return m_BaseUserID; }
			set { m_BaseUserID = value; }
		}

		/// <summary>
		/// 审核时间
		/// </summary>
		public DateTime AuditDate
		{
			get { return m_AuditDate; }
			set { m_AuditDate = value; }
		}

		/// <summary>
		/// 审核状态: 1、新建 2、审核中 3、审核通过
		/// </summary>
		public int AuditStateID
		{
			get { return m_AuditStateID; }
			set { m_AuditStateID = value; }
		}

		/// <summary>
		/// (审核备注
		/// </summary>
		public string AuditRemark
		{
			get { return m_AuditRemark; }
			set { m_AuditRemark = value; }
		}

		#endregion

	}
}
