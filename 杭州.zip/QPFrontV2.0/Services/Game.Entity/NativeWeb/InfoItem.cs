/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2013-11-21 13:58:23*/
/*Table:InfoItem*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class InfoItem
	{
		#region 构造函数
		public InfoItem(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "InfoItem";

		/// <summary>
		/// 
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 
		/// </summary>
		public const string _TopicID = "TopicID";

		/// <summary>
		/// 
		/// </summary>
		public const string _Content = "Content";

		/// <summary>
		/// 
		/// </summary>
		public const string _StateID = "StateID";

		/// <summary>
		/// 
		/// </summary>
		public const string _CTime = "CTime";

		/// <summary>
		/// 
		/// </summary>
		public const string _CUserID = "CUserID";

		/// <summary>
		/// 
		/// </summary>
		public const string _CUserIP = "CUserIP";

		/// <summary>
		/// 
		/// </summary>
		public const string _ETime = "ETime";

		/// <summary>
		/// 
		/// </summary>
		public const string _EUserID = "EUserID";

		/// <summary>
		/// 
		/// </summary>
		public const string _EUserIP = "EUserIP";

		#endregion

		#region 私有变量
		private int m_Pid;//
		private int m_TopicID;//
		private string m_Content;//
		private int m_StateID;//
		private DateTime m_CTime;//
		private int m_CUserID;//
		private string m_CUserIP;//
		private DateTime m_ETime;//
		private int m_EUserID;//
		private string m_EUserIP;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int TopicID
		{
			get { return m_TopicID; }
			set { m_TopicID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string Content
		{
			get { return m_Content; }
			set { m_Content = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int StateID
		{
			get { return m_StateID; }
			set { m_StateID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int CUserID
		{
			get { return m_CUserID; }
			set { m_CUserID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string CUserIP
		{
			get { return m_CUserIP; }
			set { m_CUserIP = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime ETime
		{
			get { return m_ETime; }
			set { m_ETime = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int EUserID
		{
			get { return m_EUserID; }
			set { m_EUserID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string EUserIP
		{
			get { return m_EUserIP; }
			set { m_EUserIP = value; }
		}

		#endregion

	}
}
