/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-06-12 16:05:37*/
/*Table:XGameXYJ*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class XGameXYJ
	{
		#region 构造函数
		public XGameXYJ(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "XGameXYJ";

		/// <summary>
		/// 
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 
		/// </summary>
		public const string _Score = "Score";

		/// <summary>
		/// 
		/// </summary>
		public const string _CTime = "CTime";

		#endregion

		#region 私有变量
		private int m_Pid;//
		private int m_UserID;//
		private long m_Score;//
		private DateTime m_CTime;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public long Score
		{
			get { return m_Score; }
			set { m_Score = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		#endregion

	}
}
