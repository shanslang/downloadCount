/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-03-12 15:39:55*/
/*Table:ActivityInternetcafe*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class ActivityInternetcafe
	{
		#region 构造函数
		public ActivityInternetcafe(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "ActivityInternetcafe";

		/// <summary>
		/// Pid(自动编号)
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// IPAddress(IP地址)
		/// </summary>
		public const string _IPAddress = "IPAddress";

		/// <summary>
		/// Name(网吧名称)
		/// </summary>
		public const string _Name = "Name";

		/// <summary>
		/// Address(网吧地址)
		/// </summary>
		public const string _Address = "Address";

		/// <summary>
		/// DayFreeNum(每天免费次数)
		/// </summary>
		public const string _DayFreeNum = "DayFreeNum";

		/// <summary>
		/// StateID(状态)
		/// </summary>
		public const string _StateID = "StateID";

		/// <summary>
		/// CTime(创建时间)
		/// </summary>
		public const string _CTime = "CTime";

		#endregion

		#region 私有变量
		private int m_Pid;//Pid(自动编号)
		private string m_IPAddress;//IPAddress(IP地址)
		private string m_Name;//Name(网吧名称)
		private string m_Address;//Address(网吧地址)
		private int m_DayFreeNum;//DayFreeNum(每天免费次数)
		private int m_StateID;//StateID(状态)
		private DateTime m_CTime;//CTime(创建时间)
		#endregion

		#region 公开属性

		/// <summary>
		/// Pid(自动编号)
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// IPAddress(IP地址)
		/// </summary>
		public string IPAddress
		{
			get { return m_IPAddress; }
			set { m_IPAddress = value; }
		}

		/// <summary>
		/// Name(网吧名称)
		/// </summary>
		public string Name
		{
			get { return m_Name; }
			set { m_Name = value; }
		}

		/// <summary>
		/// Address(网吧地址)
		/// </summary>
		public string Address
		{
			get { return m_Address; }
			set { m_Address = value; }
		}

		/// <summary>
		/// DayFreeNum(每天免费次数)
		/// </summary>
		public int DayFreeNum
		{
			get { return m_DayFreeNum; }
			set { m_DayFreeNum = value; }
		}

		/// <summary>
		/// StateID(状态)
		/// </summary>
		public int StateID
		{
			get { return m_StateID; }
			set { m_StateID = value; }
		}

		/// <summary>
		/// CTime(创建时间)
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		#endregion

	}
}
