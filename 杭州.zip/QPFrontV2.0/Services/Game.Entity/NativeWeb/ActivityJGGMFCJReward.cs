/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-04-28 14:34:42*/
/*Table:ActivityJGGMFCJReward*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class ActivityJGGMFCJReward
	{
		#region 构造函数
		public ActivityJGGMFCJReward(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "ActivityJGGMFCJReward";

		/// <summary>
		/// 
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 
		/// </summary>
		public const string _Json = "Json";

		/// <summary>
		/// 
		/// </summary>
		public const string _LastUpdateDate = "LastUpdateDate";

		#endregion

		#region 私有变量
		private int m_Pid;//
		private string m_Json;//
		private DateTime m_LastUpdateDate;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string Json
		{
			get { return m_Json; }
			set { m_Json = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime LastUpdateDate
		{
			get { return m_LastUpdateDate; }
			set { m_LastUpdateDate = value; }
		}

		#endregion

	}
}
