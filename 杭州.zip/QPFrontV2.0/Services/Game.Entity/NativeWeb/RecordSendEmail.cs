/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-03-30 11:19:02*/
/*Table:RecordSendEmail*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class RecordSendEmail
	{
		#region 构造函数
		public RecordSendEmail(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "RecordSendEmail";

		/// <summary>
		/// 主键PID
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 用户ID
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 邮件地址
		/// </summary>
		public const string _Email = "Email";

		/// <summary>
		/// 标题
		/// </summary>
		public const string _SendTitle = "SendTitle";

		/// <summary>
		/// 发送内容
		/// </summary>
		public const string _SendContent = "SendContent";

		/// <summary>
		/// 状态ID  0=未发送 1=已发送 2=作废
		/// </summary>
		public const string _StateID = "StateID";

		/// <summary>
		/// 
		/// </summary>
		public const string _CTime = "CTime";

		#endregion

		#region 私有变量
		private int m_Pid;//主键PID
		private int m_UserID;//用户ID
		private string m_Email;//邮件地址
		private string m_SendTitle;//标题
		private string m_SendContent;//发送内容
		private byte m_StateID;//状态ID  0=未发送 1=已发送 2=作废
		private DateTime m_CTime;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 主键PID
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 用户ID
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 邮件地址
		/// </summary>
		public string Email
		{
			get { return m_Email; }
			set { m_Email = value; }
		}

		/// <summary>
		/// 标题
		/// </summary>
		public string SendTitle
		{
			get { return m_SendTitle; }
			set { m_SendTitle = value; }
		}

		/// <summary>
		/// 发送内容
		/// </summary>
		public string SendContent
		{
			get { return m_SendContent; }
			set { m_SendContent = value; }
		}

		/// <summary>
		/// 状态ID  0=未发送 1=已发送 2=作废
		/// </summary>
		public byte StateID
		{
			get { return m_StateID; }
			set { m_StateID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		#endregion

	}
}
