/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-12-30 15:25:29*/
/*Table:SpreadUser*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class SpreadUser
	{
		#region 构造函数
		public SpreadUser(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "SpreadUser";

		/// <summary>
		/// 主键Pid
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 用户ID 和网站注册用户进行关联
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 推广员名称
		/// </summary>
		public const string _Name = "Name";

		/// <summary>
		/// 
		/// </summary>
		public const string _SpreadUserNature = "SpreadUserNature";

		/// <summary>
		/// 0 女 1男
		/// </summary>
		public const string _Sex = "Sex";

		/// <summary>
		/// 联系手机
		/// </summary>
		public const string _Telephone = "Telephone";

		/// <summary>
		/// 联系QQ
		/// </summary>
		public const string _QQ = "QQ";

		/// <summary>
		/// 联系手机
		/// </summary>
		public const string _Email = "Email";

		/// <summary>
		/// 联系地址
		/// </summary>
		public const string _Address = "Address";

		/// <summary>
		/// 邮政编码
		/// </summary>
		public const string _PostCode = "PostCode";

		/// <summary>
		/// 备注
		/// </summary>
		public const string _Remark = "Remark";

		/// <summary>
		/// 状态 1、正常  2、禁用 3、删除
		/// </summary>
		public const string _StateID = "StateID";

		/// <summary>
		/// 审核状态: 0、新建 1、审核通过  2、审核中  3、审核不通过 
		/// </summary>
		public const string _AuditStateID = "AuditStateID";

		/// <summary>
		/// 创建时间
		/// </summary>
		public const string _CTime = "CTime";

		/// <summary>
		/// 编辑时间
		/// </summary>
		public const string _ETime = "ETime";

		/// <summary>
		/// 
		/// </summary>
		public const string _IsCPA = "IsCPA";

		/// <summary>
		/// 
		/// </summary>
		public const string _IsCPS = "IsCPS";

		/// <summary>
		/// 
		/// </summary>
		public const string _CooperationModel = "CooperationModel";

		#endregion

		#region 私有变量
		private int m_Pid;//主键Pid
		private int m_UserID;//用户ID 和网站注册用户进行关联
		private string m_Name;//推广员名称
		private int m_SpreadUserNature;//
		private int m_Sex;//0 女 1男
		private string m_Telephone;//联系手机
		private string m_QQ;//联系QQ
		private string m_Email;//联系手机
		private string m_Address;//联系地址
		private string m_PostCode;//邮政编码
		private string m_Remark;//备注
		private int m_StateID;//状态 1、正常  2、禁用 3、删除
		private int m_AuditStateID;//审核状态: 0、新建 1、审核通过  2、审核中  3、审核不通过 
		private DateTime m_CTime;//创建时间
		private DateTime m_ETime;//编辑时间
		private byte m_IsCPA;//
		private byte m_IsCPS;//
		private string m_CooperationModel;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 主键Pid
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 用户ID 和网站注册用户进行关联
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 推广员名称
		/// </summary>
		public string Name
		{
			get { return m_Name; }
			set { m_Name = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int SpreadUserNature
		{
			get { return m_SpreadUserNature; }
			set { m_SpreadUserNature = value; }
		}

		/// <summary>
		/// 0 女 1男
		/// </summary>
		public int Sex
		{
			get { return m_Sex; }
			set { m_Sex = value; }
		}

		/// <summary>
		/// 联系手机
		/// </summary>
		public string Telephone
		{
			get { return m_Telephone; }
			set { m_Telephone = value; }
		}

		/// <summary>
		/// 联系QQ
		/// </summary>
		public string QQ
		{
			get { return m_QQ; }
			set { m_QQ = value; }
		}

		/// <summary>
		/// 联系手机
		/// </summary>
		public string Email
		{
			get { return m_Email; }
			set { m_Email = value; }
		}

		/// <summary>
		/// 联系地址
		/// </summary>
		public string Address
		{
			get { return m_Address; }
			set { m_Address = value; }
		}

		/// <summary>
		/// 邮政编码
		/// </summary>
		public string PostCode
		{
			get { return m_PostCode; }
			set { m_PostCode = value; }
		}

		/// <summary>
		/// 备注
		/// </summary>
		public string Remark
		{
			get { return m_Remark; }
			set { m_Remark = value; }
		}

		/// <summary>
		/// 状态 1、正常  2、禁用 3、删除
		/// </summary>
		public int StateID
		{
			get { return m_StateID; }
			set { m_StateID = value; }
		}

		/// <summary>
		/// 审核状态: 0、新建 1、审核通过  2、审核中  3、审核不通过 
		/// </summary>
		public int AuditStateID
		{
			get { return m_AuditStateID; }
			set { m_AuditStateID = value; }
		}

		/// <summary>
		/// 创建时间
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		/// <summary>
		/// 编辑时间
		/// </summary>
		public DateTime ETime
		{
			get { return m_ETime; }
			set { m_ETime = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public byte IsCPA
		{
			get { return m_IsCPA; }
			set { m_IsCPA = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public byte IsCPS
		{
			get { return m_IsCPS; }
			set { m_IsCPS = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string CooperationModel
		{
			get { return m_CooperationModel; }
			set { m_CooperationModel = value; }
		}

		#endregion

	}
}
