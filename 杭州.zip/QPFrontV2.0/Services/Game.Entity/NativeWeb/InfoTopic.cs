/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2013-11-18 16:54:49*/
/*Table:InfoTopic*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class InfoTopic
	{
		#region 构造函数
		public InfoTopic(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "InfoTopic";

		/// <summary>
		/// 主键编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 主题类型
		/// </summary>
		public const string _TopicTypeID = "TopicTypeID";

		/// <summary>
		/// 栏目编号
		/// </summary>
		public const string _CataID = "CataID";

		/// <summary>
		/// 回复数量
		/// </summary>
		public const string _ItemNum = "ItemNum";

		/// <summary>
		/// 标题
		/// </summary>
		public const string _Title = "Title";

		/// <summary>
		/// 内容
		/// </summary>
		public const string _Content = "Content";

		/// <summary>
		/// 简介
		/// </summary>
		public const string _Summary = "Summary";

		/// <summary>
		/// 作者
		/// </summary>
		public const string _Author = "Author";

		/// <summary>
		/// 标签
		/// </summary>
		public const string _Tags = "Tags";

		/// <summary>
		/// 点击次数
		/// </summary>
		public const string _Hits = "Hits";

		/// <summary>
		/// 标识
		/// </summary>
		public const string _FlagID = "FlagID";

		/// <summary>
		/// 顶次数
		/// </summary>
		public const string _DiggTop = "DiggTop";

		/// <summary>
		/// 踩次数
		/// </summary>
		public const string _DiggStep = "DiggStep";

		/// <summary>
		/// 记录状态
		/// </summary>
		public const string _StateID = "StateID";

		/// <summary>
		/// 创建人ID
		/// </summary>
		public const string _CUserID = "CUserID";

		/// <summary>
		/// 创建人IP
		/// </summary>
		public const string _CUserIP = "CUserIP";

		/// <summary>
		/// 创建时间
		/// </summary>
		public const string _CTime = "CTime";

		/// <summary>
		/// 编辑人ID
		/// </summary>
		public const string _EUserID = "EUserID";

		/// <summary>
		/// 编辑人IP
		/// </summary>
		public const string _EUserIP = "EUserIP";

		/// <summary>
		/// 编辑时间
		/// </summary>
		public const string _ETime = "ETime";

		#endregion

		#region 私有变量
		private int m_Pid;//主键编号
		private int m_TopicTypeID;//主题类型
		private int m_CataID;//栏目编号
		private int m_ItemNum;//回复数量
		private string m_Title;//标题
		private string m_Content;//内容
		private string m_Summary;//简介
		private string m_Author;//作者
		private string m_Tags;//标签
		private int m_Hits;//点击次数
		private int m_FlagID;//标识
		private int m_DiggTop;//顶次数
		private int m_DiggStep;//踩次数
		private int m_StateID;//记录状态
		private int m_CUserID;//创建人ID
		private string m_CUserIP;//创建人IP
		private DateTime m_CTime;//创建时间
		private int m_EUserID;//编辑人ID
		private string m_EUserIP;//编辑人IP
		private DateTime m_ETime;//编辑时间
		#endregion

		#region 公开属性

		/// <summary>
		/// 主键编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 主题类型
		/// </summary>
		public int TopicTypeID
		{
			get { return m_TopicTypeID; }
			set { m_TopicTypeID = value; }
		}

		/// <summary>
		/// 栏目编号
		/// </summary>
		public int CataID
		{
			get { return m_CataID; }
			set { m_CataID = value; }
		}

		/// <summary>
		/// 回复数量
		/// </summary>
		public int ItemNum
		{
			get { return m_ItemNum; }
			set { m_ItemNum = value; }
		}

		/// <summary>
		/// 标题
		/// </summary>
		public string Title
		{
			get { return m_Title; }
			set { m_Title = value; }
		}

		/// <summary>
		/// 内容
		/// </summary>
		public string Content
		{
			get { return m_Content; }
			set { m_Content = value; }
		}

		/// <summary>
		/// 简介
		/// </summary>
		public string Summary
		{
			get { return m_Summary; }
			set { m_Summary = value; }
		}

		/// <summary>
		/// 作者
		/// </summary>
		public string Author
		{
			get { return m_Author; }
			set { m_Author = value; }
		}

		/// <summary>
		/// 标签
		/// </summary>
		public string Tags
		{
			get { return m_Tags; }
			set { m_Tags = value; }
		}

		/// <summary>
		/// 点击次数
		/// </summary>
		public int Hits
		{
			get { return m_Hits; }
			set { m_Hits = value; }
		}

		/// <summary>
		/// 标识
		/// </summary>
		public int FlagID
		{
			get { return m_FlagID; }
			set { m_FlagID = value; }
		}

		/// <summary>
		/// 顶次数
		/// </summary>
		public int DiggTop
		{
			get { return m_DiggTop; }
			set { m_DiggTop = value; }
		}

		/// <summary>
		/// 踩次数
		/// </summary>
		public int DiggStep
		{
			get { return m_DiggStep; }
			set { m_DiggStep = value; }
		}

		/// <summary>
		/// 记录状态
		/// </summary>
		public int StateID
		{
			get { return m_StateID; }
			set { m_StateID = value; }
		}

		/// <summary>
		/// 创建人ID
		/// </summary>
		public int CUserID
		{
			get { return m_CUserID; }
			set { m_CUserID = value; }
		}

		/// <summary>
		/// 创建人IP
		/// </summary>
		public string CUserIP
		{
			get { return m_CUserIP; }
			set { m_CUserIP = value; }
		}

		/// <summary>
		/// 创建时间
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		/// <summary>
		/// 编辑人ID
		/// </summary>
		public int EUserID
		{
			get { return m_EUserID; }
			set { m_EUserID = value; }
		}

		/// <summary>
		/// 编辑人IP
		/// </summary>
		public string EUserIP
		{
			get { return m_EUserIP; }
			set { m_EUserIP = value; }
		}

		/// <summary>
		/// 编辑时间
		/// </summary>
		public DateTime ETime
		{
			get { return m_ETime; }
			set { m_ETime = value; }
		}

		#endregion

	}
}
