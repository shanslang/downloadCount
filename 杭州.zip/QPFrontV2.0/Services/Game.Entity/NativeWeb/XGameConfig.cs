/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-06-12 16:05:12*/
/*Table:XGameConfig*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class XGameConfig
	{
		#region 构造函数
		public XGameConfig(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "XGameConfig";

		/// <summary>
		/// 主键编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 
		/// </summary>
		public const string _GameName = "GameName";

		/// <summary>
		/// >=会员级别
		/// </summary>
		public const string _AllowMemberOrder = "AllowMemberOrder";

		/// <summary>
		/// 是否手机认证
		/// </summary>
		public const string _AllowAuthTelephone = "AllowAuthTelephone";

		/// <summary>
		/// 每局提交间隔时间 秒为单位
		/// </summary>
		public const string _EveryGameTimespan = "EveryGameTimespan";

		/// <summary>
		/// 每日额定次数功能
		/// </summary>
		public const string _EverydayGameCount = "EverydayGameCount";

		/// <summary>
		/// 每日限定购买次数
		/// </summary>
		public const string _EverydayBuyCount = "EverydayBuyCount";

		/// <summary>
		/// 多倍金币阀门功能
		/// </summary>
		public const string _GoldDouble = "GoldDouble";

		/// <summary>
		/// 金币获取封顶验证
		/// </summary>
		public const string _GoldMax = "GoldMax";

		/// <summary>
		/// 每日排名即时更新
		/// </summary>
		public const string _EveryRankRefreshTime = "EveryRankRefreshTime";

		#endregion

		#region 私有变量
		private int m_Pid;//主键编号
		private string m_GameName;//
		private int m_AllowMemberOrder;//>=会员级别
		private int m_AllowAuthTelephone;//是否手机认证
		private int m_EveryGameTimespan;//每局提交间隔时间 秒为单位
		private int m_EverydayGameCount;//每日额定次数功能
		private int m_EverydayBuyCount;//每日限定购买次数
		private decimal m_GoldDouble;//多倍金币阀门功能
		private long m_GoldMax;//金币获取封顶验证
		private int m_EveryRankRefreshTime;//每日排名即时更新
		#endregion

		#region 公开属性

		/// <summary>
		/// 主键编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string GameName
		{
			get { return m_GameName; }
			set { m_GameName = value; }
		}

		/// <summary>
		/// >=会员级别
		/// </summary>
		public int AllowMemberOrder
		{
			get { return m_AllowMemberOrder; }
			set { m_AllowMemberOrder = value; }
		}

		/// <summary>
		/// 是否手机认证
		/// </summary>
		public int AllowAuthTelephone
		{
			get { return m_AllowAuthTelephone; }
			set { m_AllowAuthTelephone = value; }
		}

		/// <summary>
		/// 每局提交间隔时间 秒为单位
		/// </summary>
		public int EveryGameTimespan
		{
			get { return m_EveryGameTimespan; }
			set { m_EveryGameTimespan = value; }
		}

		/// <summary>
		/// 每日额定次数功能
		/// </summary>
		public int EverydayGameCount
		{
			get { return m_EverydayGameCount; }
			set { m_EverydayGameCount = value; }
		}

		/// <summary>
		/// 每日限定购买次数
		/// </summary>
		public int EverydayBuyCount
		{
			get { return m_EverydayBuyCount; }
			set { m_EverydayBuyCount = value; }
		}

		/// <summary>
		/// 多倍金币阀门功能
		/// </summary>
		public decimal GoldDouble
		{
			get { return m_GoldDouble; }
			set { m_GoldDouble = value; }
		}

		/// <summary>
		/// 金币获取封顶验证
		/// </summary>
		public long GoldMax
		{
			get { return m_GoldMax; }
			set { m_GoldMax = value; }
		}

		/// <summary>
		/// 每日排名即时更新
		/// </summary>
		public int EveryRankRefreshTime
		{
			get { return m_EveryRankRefreshTime; }
			set { m_EveryRankRefreshTime = value; }
		}

		#endregion

	}
}
