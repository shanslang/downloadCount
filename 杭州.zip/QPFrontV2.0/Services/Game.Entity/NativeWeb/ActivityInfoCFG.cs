﻿
using System;
namespace Game.Entity.NativeWeb
{
    /// <summary>
    /// ActivityInfoCFG:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class ActivityInfoCFG
    {
        public ActivityInfoCFG()
        { }
        #region Model
        private int _id;
        private string _title;
        private DateTime _starttime;
        private DateTime _overtime;
        private string _discription = "";
        private string _ruleaddress = "";
        private string _iconName = "";
        private string _iconurl = "";
        private string _IconMd5 = "";
        private string _acturl = "";
        private int _pageHeight = 0;
        private int _pageWidth = 0;
        private int _ruleHeight = 0;
        private int _ruleWidth = 0;
        private int _androidHeight = 0;
        private int _androidWidth = 0;
        private int _androidRuleHeight = 0;
        private int _androidRuleWidth = 0;



        /// <summary>
        /// 
        /// </summary>
        public int Id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 标题
        /// </summary>
        public string Title
        {
            set { _title = value; }
            get { return _title; }
        }
        /// <summary>
        /// 活动开始时间
        /// </summary>
        public DateTime StartTime
        {
            set { _starttime = value; }
            get { return _starttime; }
        }
        /// <summary>
        /// 活动结束时间
        /// </summary>
        public DateTime OverTime
        {
            set { _overtime = value; }
            get { return _overtime; }
        }
        /// <summary>
        /// 描述
        /// </summary>
        public string Discription
        {
            set { _discription = value; }
            get { return _discription; }
        }
        /// <summary>
        /// 规则地址(显示活动规则的网页地址)
        /// </summary>
        public string RuleAddress
        {
            set { _ruleaddress = value; }
            get { return _ruleaddress; }
        }
        /// <summary>
        /// 活动地址(活动页面)
        /// </summary>
        public string ActUrl
        {
            set { _acturl = value; }
            get { return _acturl; }
        }

        /// <summary>
        /// 图片名称
        /// </summary>
        public string IconName
        {
            get { return _iconName; }
            set { _iconName = value; }
        }
        /// <summary>
        /// 图片地址
        /// </summary>
        public string Iconurl
        {
            get { return _iconurl; }
            set { _iconurl = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string IconMd5
        {
            get { return _IconMd5; }
            set { _IconMd5 = value; }
        }
        /// <summary>
        /// 活动页面高度(IOS设备)
        /// </summary>
        public int PageHeight
        {
            get { return _pageHeight; }
            set { _pageHeight = value; }
        }
        /// <summary>
        /// 活动页面宽度(IOS设备)
        /// </summary>
        public int PageWidth
        {
            get { return _pageWidth; }
            set { _pageWidth = value; }
        }
        /// <summary>
        /// 活动规则页面高度(IOS设备)
        /// </summary>
        public int RuleHeight
        {
            get { return _ruleHeight; }
            set { _ruleHeight = value; }
        }
        /// <summary>
        /// 活动规则页面宽度(IOS设备)
        /// </summary>
        public int RuleWidth
        {
            get { return _ruleWidth; }
            set { _ruleWidth = value; }
        }
        /// <summary>
        ///  活动页面高度(Android设备)
        /// </summary>
        public int AndroidHeight
        {
            get { return _androidHeight; }
            set { _androidHeight = value; }
        }
        /// <summary>
        ///  活动页面宽度(Android设备)
        /// </summary>
        public int AndroidWidth
        {
            get { return _androidWidth; }
            set { _androidWidth = value; }
        }
        /// <summary>
        /// 活动规则页面高度(Android设备)
        /// </summary>
        public int AndroidRuleHeight
        {
            get { return _androidRuleHeight; }
            set { _androidRuleHeight = value; }
        }
        /// <summary>
        /// 活动规则页面宽度(Android设备)
        /// </summary>
        public int AndroidRuleWidth
        {
            get { return _androidRuleWidth; }
            set { _androidRuleWidth = value; }
        }
        #endregion Model

    }
}

