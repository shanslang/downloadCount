/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-06-12 16:19:21*/
/*Table:XGamePayCount*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class XGamePayCount
	{
		#region 构造函数
		public XGamePayCount(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "XGamePayCount";

		/// <summary>
		/// 
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 
		/// </summary>
		public const string _XGameConfigPid = "XGameConfigPid";

		/// <summary>
		/// 
		/// </summary>
		public const string _GameCount = "GameCount";

		/// <summary>
		/// 
		/// </summary>
		public const string _CTime = "CTime";

		#endregion

		#region 私有变量
		private int m_UserID;//
		private int m_XGameConfigPid;//
		private int m_GameCount;//
		private DateTime m_CTime;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int XGameConfigPid
		{
			get { return m_XGameConfigPid; }
			set { m_XGameConfigPid = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int GameCount
		{
			get { return m_GameCount; }
			set { m_GameCount = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		#endregion

	}
}
