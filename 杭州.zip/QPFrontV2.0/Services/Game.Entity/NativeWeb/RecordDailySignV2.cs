/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-06-29 13:28:46*/
/*Table:RecordDailySignV2*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class RecordDailySignV2
	{
		#region 构造函数
		public RecordDailySignV2(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "RecordDailySignV2";

		/// <summary>
		/// 自动编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 用户ID
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 签到时间
		/// </summary>
		public const string _SignTime = "SignTime";

		/// <summary>
		/// 
		/// </summary>
		public const string _RepairSignTime = "RepairSignTime";

		/// <summary>
		/// IP地址
		/// </summary>
		public const string _ClientIP = "ClientIP";

		/// <summary>
		/// 奖励金币
		/// </summary>
		public const string _RewardGold = "RewardGold";

		/// <summary>
		/// 奖励奖牌
		/// </summary>
		public const string _RewardMedal = "RewardMedal";

		/// <summary>
		/// 赠送道具Pid
		/// </summary>
		public const string _RewardPropertyPid = "RewardPropertyPid";

		/// <summary>
		/// 道具数量
		/// </summary>
		public const string _RewardPropertyNumber = "RewardPropertyNumber";

		/// <summary>
		/// 会员级别
		/// </summary>
		public const string _RewardMemberOrder = "RewardMemberOrder";

		/// <summary>
		/// 会员天数
		/// </summary>
		public const string _RewardMemberNumber = "RewardMemberNumber";

		#endregion

		#region 私有变量
		private int m_Pid;//自动编号
		private int m_UserID;//用户ID
		private DateTime m_SignTime;//签到时间
		private DateTime m_RepairSignTime;//
		private string m_ClientIP;//IP地址
		private long m_RewardGold;//奖励金币
		private int m_RewardMedal;//奖励奖牌
		private int m_RewardPropertyPid;//赠送道具Pid
		private int m_RewardPropertyNumber;//道具数量
		private int m_RewardMemberOrder;//会员级别
		private int m_RewardMemberNumber;//会员天数
		#endregion

		#region 公开属性

		/// <summary>
		/// 自动编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 用户ID
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 签到时间
		/// </summary>
		public DateTime SignTime
		{
			get { return m_SignTime; }
			set { m_SignTime = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime RepairSignTime
		{
			get { return m_RepairSignTime; }
			set { m_RepairSignTime = value; }
		}

		/// <summary>
		/// IP地址
		/// </summary>
		public string ClientIP
		{
			get { return m_ClientIP; }
			set { m_ClientIP = value; }
		}

		/// <summary>
		/// 奖励金币
		/// </summary>
		public long RewardGold
		{
			get { return m_RewardGold; }
			set { m_RewardGold = value; }
		}

		/// <summary>
		/// 奖励奖牌
		/// </summary>
		public int RewardMedal
		{
			get { return m_RewardMedal; }
			set { m_RewardMedal = value; }
		}

		/// <summary>
		/// 赠送道具Pid
		/// </summary>
		public int RewardPropertyPid
		{
			get { return m_RewardPropertyPid; }
			set { m_RewardPropertyPid = value; }
		}

		/// <summary>
		/// 道具数量
		/// </summary>
		public int RewardPropertyNumber
		{
			get { return m_RewardPropertyNumber; }
			set { m_RewardPropertyNumber = value; }
		}

		/// <summary>
		/// 会员级别
		/// </summary>
		public int RewardMemberOrder
		{
			get { return m_RewardMemberOrder; }
			set { m_RewardMemberOrder = value; }
		}

		/// <summary>
		/// 会员天数
		/// </summary>
		public int RewardMemberNumber
		{
			get { return m_RewardMemberNumber; }
			set { m_RewardMemberNumber = value; }
		}
        /// <summary>
        /// 补签天数
        /// </summary>
        public int Days { set; get; }
		#endregion

	}
}
