/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2013-12-30 10:38:59*/
/*Table:RecordDailySign*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class RecordDailySign
	{
		#region 构造函数
		public RecordDailySign(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "RecordDailySign";

		/// <summary>
		/// 自动编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 用户ID
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 签到时间
		/// </summary>
		public const string _SignTime = "SignTime";

		/// <summary>
		/// 赠送金币
		/// </summary>
		public const string _PresentGold = "PresentGold";

		/// <summary>
		/// IP地址
		/// </summary>
		public const string _ClientIP = "ClientIP";

		#endregion

		#region 私有变量
		private int m_Pid;//自动编号
		private int m_UserID;//用户ID
		private DateTime m_SignTime;//签到时间
		private long m_PresentGold;//赠送金币
		private string m_ClientIP;//IP地址
		#endregion

		#region 公开属性

		/// <summary>
		/// 自动编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 用户ID
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 签到时间
		/// </summary>
		public DateTime SignTime
		{
			get { return m_SignTime; }
			set { m_SignTime = value; }
		}

		/// <summary>
		/// 赠送金币
		/// </summary>
		public long PresentGold
		{
			get { return m_PresentGold; }
			set { m_PresentGold = value; }
		}

		/// <summary>
		/// IP地址
		/// </summary>
		public string ClientIP
		{
			get { return m_ClientIP; }
			set { m_ClientIP = value; }
		}

		#endregion

	}
}
