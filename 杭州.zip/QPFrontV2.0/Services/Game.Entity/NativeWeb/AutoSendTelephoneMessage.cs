/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-12-02 17:50:42*/
/*Table:AutoSendTelephoneMessage*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class AutoSendTelephoneMessage
	{
		#region 构造函数
		public AutoSendTelephoneMessage(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "AutoSendTelephoneMessage";

		/// <summary>
		/// 自动编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 用户标识
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 手机号码
		/// </summary>
		public const string _Telephone = "Telephone";

		/// <summary>
		/// 短信内容
		/// </summary>
		public const string _Content = "Content";

		/// <summary>
		/// 生成时间
		/// </summary>
		public const string _InsertTime = "InsertTime";

		/// <summary>
		/// 发送时间
		/// </summary>
		public const string _SendTime = "SendTime";

		/// <summary>
		/// 发送状态 0=未发送   1=已发送
		/// </summary>
		public const string _Status = "Status";

		/// <summary>
		/// 活动及作用
		/// </summary>
		public const string _UseType = "UseType";

		#endregion

		#region 私有变量
		private int m_Pid;//自动编号
		private int m_UserID;//用户标识
		private string m_Telephone;//手机号码
		private string m_Content;//短信内容
		private DateTime m_InsertTime;//生成时间
		private DateTime m_SendTime;//发送时间
		private byte m_Status;//发送状态 0=未发送   1=已发送
		private byte m_UseType;//活动及作用
		#endregion

		#region 公开属性

		/// <summary>
		/// 自动编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 用户标识
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 手机号码
		/// </summary>
		public string Telephone
		{
			get { return m_Telephone; }
			set { m_Telephone = value; }
		}

		/// <summary>
		/// 短信内容
		/// </summary>
		public string Content
		{
			get { return m_Content; }
			set { m_Content = value; }
		}

		/// <summary>
		/// 生成时间
		/// </summary>
		public DateTime InsertTime
		{
			get { return m_InsertTime; }
			set { m_InsertTime = value; }
		}

		/// <summary>
		/// 发送时间
		/// </summary>
		public DateTime SendTime
		{
			get { return m_SendTime; }
			set { m_SendTime = value; }
		}

		/// <summary>
		/// 发送状态 0=未发送   1=已发送
		/// </summary>
		public byte Status
		{
			get { return m_Status; }
			set { m_Status = value; }
		}

		/// <summary>
		/// 活动及作用
		/// </summary>
		public byte UseType
		{
			get { return m_UseType; }
			set { m_UseType = value; }
		}

		#endregion

	}
}
