/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2013-11-18 16:54:46*/
/*Table:InfoCatalog*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.NativeWeb
{
	public class InfoCatalog
	{
		#region 构造函数
		public InfoCatalog(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "InfoCatalog";

		/// <summary>
		/// 主键编号
		/// </summary>
		public const string _Pid = "Pid";

		/// <summary>
		/// 父编号
		/// </summary>
		public const string _ParentPid = "ParentPid";

		/// <summary>
		/// 栏目名称
		/// </summary>
		public const string _CataName = "CataName";

		/// <summary>
		/// 栏目标题
		/// </summary>
		public const string _CataTitle = "CataTitle";

		/// <summary>
		/// 主题数量
		/// </summary>
		public const string _TopicNum = "TopicNum";

		/// <summary>
		/// 回复数量
		/// </summary>
		public const string _ItemNum = "ItemNum";

		/// <summary>
		/// 排序字段
		/// </summary>
		public const string _OrderID = "OrderID";

		/// <summary>
		/// 标识
		/// </summary>
		public const string _CataFlag = "CataFlag";

		/// <summary>
		/// 索引
		/// </summary>
		public const string _CataIndex = "CataIndex";

		/// <summary>
		/// 记录状态
		/// </summary>
		public const string _StateID = "StateID";

		/// <summary>
		/// 创建时间
		/// </summary>
		public const string _CTime = "CTime";

		/// <summary>
		/// 最后修改时间
		/// </summary>
		public const string _ETime = "ETime";

		#endregion

		#region 私有变量
		private int m_Pid;//主键编号
		private int m_ParentPid;//父编号
		private string m_CataName;//栏目名称
		private string m_CataTitle;//栏目标题
		private int m_TopicNum;//主题数量
		private int m_ItemNum;//回复数量
		private int m_OrderID;//排序字段
		private int m_CataFlag;//标识
		private string m_CataIndex;//索引
		private int m_StateID;//记录状态
		private DateTime m_CTime;//创建时间
		private DateTime m_ETime;//最后修改时间
		#endregion

		#region 公开属性

		/// <summary>
		/// 主键编号
		/// </summary>
		public int Pid
		{
			get { return m_Pid; }
			set { m_Pid = value; }
		}

		/// <summary>
		/// 父编号
		/// </summary>
		public int ParentPid
		{
			get { return m_ParentPid; }
			set { m_ParentPid = value; }
		}

		/// <summary>
		/// 栏目名称
		/// </summary>
		public string CataName
		{
			get { return m_CataName; }
			set { m_CataName = value; }
		}

		/// <summary>
		/// 栏目标题
		/// </summary>
		public string CataTitle
		{
			get { return m_CataTitle; }
			set { m_CataTitle = value; }
		}

		/// <summary>
		/// 主题数量
		/// </summary>
		public int TopicNum
		{
			get { return m_TopicNum; }
			set { m_TopicNum = value; }
		}

		/// <summary>
		/// 回复数量
		/// </summary>
		public int ItemNum
		{
			get { return m_ItemNum; }
			set { m_ItemNum = value; }
		}

		/// <summary>
		/// 排序字段
		/// </summary>
		public int OrderID
		{
			get { return m_OrderID; }
			set { m_OrderID = value; }
		}

		/// <summary>
		/// 标识
		/// </summary>
		public int CataFlag
		{
			get { return m_CataFlag; }
			set { m_CataFlag = value; }
		}

		/// <summary>
		/// 索引
		/// </summary>
		public string CataIndex
		{
			get { return m_CataIndex; }
			set { m_CataIndex = value; }
		}

		/// <summary>
		/// 记录状态
		/// </summary>
		public int StateID
		{
			get { return m_StateID; }
			set { m_StateID = value; }
		}

		/// <summary>
		/// 创建时间
		/// </summary>
		public DateTime CTime
		{
			get { return m_CTime; }
			set { m_CTime = value; }
		}

		/// <summary>
		/// 最后修改时间
		/// </summary>
		public DateTime ETime
		{
			get { return m_ETime; }
			set { m_ETime = value; }
		}

		#endregion

	}
}
