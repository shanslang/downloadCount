﻿/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2014-11-19 15:57:42*/
/*Table:SystemNotice*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Platform
{
    public class SystemNotice
    {
        #region 构造函数
        public SystemNotice() { }
        #endregion

        #region 私有变量
        /// <summary>
        /// 表名
        /// </summary>
        public const string Tablename = "SystemNotice";

        /// <summary>
        /// 
        /// </summary>
        public const string _NID = "NID";

        /// <summary>
        /// 
        /// </summary>
        public const string _GameID = "GameID";

        /// <summary>
        /// 
        /// </summary>
        public const string _ServerID = "ServerID";

        /// <summary>
        /// 
        /// </summary>
        public const string _StartTime = "StartTime";

        /// <summary>
        /// 
        /// </summary>
        public const string _EndTime = "EndTime";

        /// <summary>
        /// 间隔时间（单位秒）0表示只发一次
        /// </summary>
        public const string _TimeSpace = "TimeSpace";

        /// <summary>
        /// 是否在时间段内登录就发送
        /// </summary>
        public const string _IsLoginSend = "IsLoginSend";

        /// <summary>
        /// 
        /// </summary>
        public const string _Info = "Info";

        /// <summary>
        /// 
        /// </summary>
        public const string _LastModify = "LastModify";
        /// <summary>
        /// 
        /// </summary>
        public const string _NoticeName = "NoticeName";

        #endregion

        #region 私有变量
        private int m_NID;//
        private int m_GameID;//
        private int m_ServerID;//
        private DateTime m_StartTime;//
        private DateTime m_EndTime;//
        private int m_TimeSpace;//间隔时间（单位秒）0表示只发一次
        private byte m_IsLoginSend;//是否在时间段内登录就发送
        private string m_Info;//
        private DateTime m_LastModify;//
        private string m_NoticeName; //公告名称
        #endregion

        #region 公开属性

        /// <summary>
        /// 
        /// </summary>
        public int NID
        {
            get { return m_NID; }
            set { m_NID = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int GameID
        {
            get { return m_GameID; }
            set { m_GameID = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int ServerID
        {
            get { return m_ServerID; }
            set { m_ServerID = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public DateTime StartTime
        {
            get { return m_StartTime; }
            set { m_StartTime = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public DateTime EndTime
        {
            get { return m_EndTime; }
            set { m_EndTime = value; }
        }

        /// <summary>
        /// 间隔时间（单位秒）0表示只发一次
        /// </summary>
        public int TimeSpace
        {
            get { return m_TimeSpace; }
            set { m_TimeSpace = value; }
        }

        /// <summary>
        /// 是否在时间段内登录就发送
        /// </summary>
        public byte IsLoginSend
        {
            get { return m_IsLoginSend; }
            set { m_IsLoginSend = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Info
        {
            get { return m_Info; }
            set { m_Info = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public DateTime LastModify
        {
            get { return m_LastModify; }
            set { m_LastModify = value; }
        }
        /// <summary>
        /// 公告名称
        /// </summary>
        public string NoticeName
        {
            get { return m_NoticeName; }
            set { m_NoticeName = value; }
        }
        #endregion

    }
}
