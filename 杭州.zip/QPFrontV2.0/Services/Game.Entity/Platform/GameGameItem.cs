/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-08-18 11:35:33*/
/*Table:GameGameItem*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Platform
{
	public class GameGameItem
	{
		#region 构造函数
		public GameGameItem(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "GameGameItem";

		/// <summary>
		/// 游戏号码
		/// </summary>
		public const string _GameID = "GameID";

		/// <summary>
		/// 游戏名字
		/// </summary>
		public const string _GameName = "GameName";

		/// <summary>
		/// 支持类型
		/// </summary>
		public const string _SuporType = "SuporType";

		/// <summary>
		/// 连接地址
		/// </summary>
		public const string _DataBaseAddr = "DataBaseAddr";

		/// <summary>
		/// 数据库名
		/// </summary>
		public const string _DataBaseName = "DataBaseName";

		/// <summary>
		/// 服务器版本
		/// </summary>
		public const string _ServerVersion = "ServerVersion";

		/// <summary>
		/// 客户端版本
		/// </summary>
		public const string _ClientVersion = "ClientVersion";

		/// <summary>
		/// 
		/// </summary>
		public const string _ImageVersion = "ImageVersion";

		/// <summary>
		/// 
		/// </summary>
		public const string _SoundVersion = "SoundVersion";

		/// <summary>
		/// 服务端名字
		/// </summary>
		public const string _ServerDLLName = "ServerDLLName";

		/// <summary>
		/// 客户端名字
		/// </summary>
		public const string _ClientExeName = "ClientExeName";

		#endregion

		#region 私有变量
		private int m_GameID;//游戏号码
		private string m_GameName;//游戏名字
		private int m_SuporType;//支持类型
		private string m_DataBaseAddr;//连接地址
		private string m_DataBaseName;//数据库名
		private int m_ServerVersion;//服务器版本
		private int m_ClientVersion;//客户端版本
		private int m_ImageVersion;//
		private int m_SoundVersion;//
		private string m_ServerDLLName;//服务端名字
		private string m_ClientExeName;//客户端名字
		#endregion

		#region 公开属性

		/// <summary>
		/// 游戏号码
		/// </summary>
		public int GameID
		{
			get { return m_GameID; }
			set { m_GameID = value; }
		}

		/// <summary>
		/// 游戏名字
		/// </summary>
		public string GameName
		{
			get { return m_GameName; }
			set { m_GameName = value; }
		}

		/// <summary>
		/// 支持类型
		/// </summary>
		public int SuporType
		{
			get { return m_SuporType; }
			set { m_SuporType = value; }
		}

		/// <summary>
		/// 连接地址
		/// </summary>
		public string DataBaseAddr
		{
			get { return m_DataBaseAddr; }
			set { m_DataBaseAddr = value; }
		}

		/// <summary>
		/// 数据库名
		/// </summary>
		public string DataBaseName
		{
			get { return m_DataBaseName; }
			set { m_DataBaseName = value; }
		}

		/// <summary>
		/// 服务器版本
		/// </summary>
		public int ServerVersion
		{
			get { return m_ServerVersion; }
			set { m_ServerVersion = value; }
		}

		/// <summary>
		/// 客户端版本
		/// </summary>
		public int ClientVersion
		{
			get { return m_ClientVersion; }
			set { m_ClientVersion = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int ImageVersion
		{
			get { return m_ImageVersion; }
			set { m_ImageVersion = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int SoundVersion
		{
			get { return m_SoundVersion; }
			set { m_SoundVersion = value; }
		}

		/// <summary>
		/// 服务端名字
		/// </summary>
		public string ServerDLLName
		{
			get { return m_ServerDLLName; }
			set { m_ServerDLLName = value; }
		}

		/// <summary>
		/// 客户端名字
		/// </summary>
		public string ClientExeName
		{
			get { return m_ClientExeName; }
			set { m_ClientExeName = value; }
		}

		#endregion

	}
}
