/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-01-12 11:02:44*/
/*Table:HistoryGameMatchInfo*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Platform
{
	public class HistoryGameMatchInfo
	{
		#region 构造函数
		public HistoryGameMatchInfo(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "HistoryGameMatchInfo";

		/// <summary>
		/// 比赛标识
		/// </summary>
		public const string _MatchID = "MatchID";

		/// <summary>
		/// 比赛名称
		/// </summary>
		public const string _MatchName = "MatchName";

		/// <summary>
		/// 比赛日期
		/// </summary>
		public const string _MatchStartTime = "MatchStartTime";

		/// <summary>
		/// 比赛日期
		/// </summary>
		public const string _MatchEndTime = "MatchEndTime";

		/// <summary>
		/// 扣费类型（0 金币 1奖牌）
		/// </summary>
		public const string _MatchFeetype = "MatchFeetype";

		/// <summary>
		/// 报名费用
		/// </summary>
		public const string _MatchFee = "MatchFee";

		/// <summary>
		/// 初始分数
		/// </summary>
		public const string _MatchInitScore = "MatchInitScore";

		/// <summary>
		/// 淘汰分数
		/// </summary>
		public const string _MatchCullScore = "MatchCullScore";

		/// <summary>
		/// 游戏局数
		/// </summary>
		public const string _MatchPlayCount = "MatchPlayCount";

		/// <summary>
		/// 比赛说明
		/// </summary>
		public const string _MatchAwardContent = "MatchAwardContent";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchContent = "MatchContent";

		/// <summary>
		/// 禁用状态
		/// </summary>
		public const string _Nullity = "Nullity";

		/// <summary>
		/// 新增日期
		/// </summary>
		public const string _CollectDate = "CollectDate";

		/// <summary>
		/// 
		/// </summary>
		public const string _UpperLimitNumber = "UpperLimitNumber";

		/// <summary>
		/// 
		/// </summary>
		public const string _LowLimitNumber = "LowLimitNumber";

		/// <summary>
		/// 
		/// </summary>
		public const string _MemberRequest = "MemberRequest";

		/// <summary>
		/// 
		/// </summary>
		public const string _AttendTicketRequest = "AttendTicketRequest";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchSignTime = "MatchSignTime";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchAwardCounts = "MatchAwardCounts";

		/// <summary>
		/// 
		/// </summary>
		public const string _TotalAttendMatchNumbe = "TotalAttendMatchNumbe";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchNO = "MatchNO";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchIntervalTime = "MatchIntervalTime";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchEffctiveStartTime = "MatchEffctiveStartTime";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchEffctiveEndTime = "MatchEffctiveEndTime";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchCircleTime = "MatchCircleTime";

		/// <summary>
		/// 
		/// </summary>
		public const string _OneMatchGamePeriod = "OneMatchGamePeriod";

		/// <summary>
		/// 
		/// </summary>
		public const string _IsConfigedIPRestrict = "IsConfigedIPRestrict";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchTitle = "MatchTitle";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchRemarkInfo = "MatchRemarkInfo";

		/// <summary>
		/// 
		/// </summary>
		public const string _PropertyKind = "PropertyKind";

		/// <summary>
		/// 
		/// </summary>
		public const string _PropertyNumber = "PropertyNumber";

		#endregion

		#region 私有变量
		private int m_MatchID;//比赛标识
		private string m_MatchName;//比赛名称
		private DateTime m_MatchStartTime;//比赛日期
		private DateTime m_MatchEndTime;//比赛日期
		private int m_MatchFeetype;//扣费类型（0 金币 1奖牌）
		private long m_MatchFee;//报名费用
		private long m_MatchInitScore;//初始分数
		private long m_MatchCullScore;//淘汰分数
		private int m_MatchPlayCount;//游戏局数
		private string m_MatchAwardContent;//比赛说明
		private string m_MatchContent;//
		private byte m_Nullity;//禁用状态
		private DateTime m_CollectDate;//新增日期
		private int m_UpperLimitNumber;//
		private int m_LowLimitNumber;//
		private int m_MemberRequest;//
		private int m_AttendTicketRequest;//
		private int m_MatchSignTime;//
		private int m_MatchAwardCounts;//
		private int m_TotalAttendMatchNumbe;//
		private int m_MatchNO;//
		private int m_MatchIntervalTime;//
		private DateTime m_MatchEffctiveStartTime;//
		private DateTime m_MatchEffctiveEndTime;//
		private long m_MatchCircleTime;//
		private int m_OneMatchGamePeriod;//
		private byte m_IsConfigedIPRestrict;//
		private string m_MatchTitle;//
		private string m_MatchRemarkInfo;//
		private int m_PropertyKind;//
		private int m_PropertyNumber;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 比赛标识
		/// </summary>
		public int MatchID
		{
			get { return m_MatchID; }
			set { m_MatchID = value; }
		}

		/// <summary>
		/// 比赛名称
		/// </summary>
		public string MatchName
		{
			get { return m_MatchName; }
			set { m_MatchName = value; }
		}

		/// <summary>
		/// 比赛日期
		/// </summary>
		public DateTime MatchStartTime
		{
			get { return m_MatchStartTime; }
			set { m_MatchStartTime = value; }
		}

		/// <summary>
		/// 比赛日期
		/// </summary>
		public DateTime MatchEndTime
		{
			get { return m_MatchEndTime; }
			set { m_MatchEndTime = value; }
		}

		/// <summary>
		/// 扣费类型（0 金币 1奖牌）
		/// </summary>
		public int MatchFeetype
		{
			get { return m_MatchFeetype; }
			set { m_MatchFeetype = value; }
		}

		/// <summary>
		/// 报名费用
		/// </summary>
		public long MatchFee
		{
			get { return m_MatchFee; }
			set { m_MatchFee = value; }
		}

		/// <summary>
		/// 初始分数
		/// </summary>
		public long MatchInitScore
		{
			get { return m_MatchInitScore; }
			set { m_MatchInitScore = value; }
		}

		/// <summary>
		/// 淘汰分数
		/// </summary>
		public long MatchCullScore
		{
			get { return m_MatchCullScore; }
			set { m_MatchCullScore = value; }
		}

		/// <summary>
		/// 游戏局数
		/// </summary>
		public int MatchPlayCount
		{
			get { return m_MatchPlayCount; }
			set { m_MatchPlayCount = value; }
		}

		/// <summary>
		/// 比赛说明
		/// </summary>
		public string MatchAwardContent
		{
			get { return m_MatchAwardContent; }
			set { m_MatchAwardContent = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string MatchContent
		{
			get { return m_MatchContent; }
			set { m_MatchContent = value; }
		}

		/// <summary>
		/// 禁用状态
		/// </summary>
		public byte Nullity
		{
			get { return m_Nullity; }
			set { m_Nullity = value; }
		}

		/// <summary>
		/// 新增日期
		/// </summary>
		public DateTime CollectDate
		{
			get { return m_CollectDate; }
			set { m_CollectDate = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int UpperLimitNumber
		{
			get { return m_UpperLimitNumber; }
			set { m_UpperLimitNumber = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int LowLimitNumber
		{
			get { return m_LowLimitNumber; }
			set { m_LowLimitNumber = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int MemberRequest
		{
			get { return m_MemberRequest; }
			set { m_MemberRequest = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int AttendTicketRequest
		{
			get { return m_AttendTicketRequest; }
			set { m_AttendTicketRequest = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int MatchSignTime
		{
			get { return m_MatchSignTime; }
			set { m_MatchSignTime = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int MatchAwardCounts
		{
			get { return m_MatchAwardCounts; }
			set { m_MatchAwardCounts = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int TotalAttendMatchNumbe
		{
			get { return m_TotalAttendMatchNumbe; }
			set { m_TotalAttendMatchNumbe = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int MatchNO
		{
			get { return m_MatchNO; }
			set { m_MatchNO = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int MatchIntervalTime
		{
			get { return m_MatchIntervalTime; }
			set { m_MatchIntervalTime = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime MatchEffctiveStartTime
		{
			get { return m_MatchEffctiveStartTime; }
			set { m_MatchEffctiveStartTime = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public DateTime MatchEffctiveEndTime
		{
			get { return m_MatchEffctiveEndTime; }
			set { m_MatchEffctiveEndTime = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public long MatchCircleTime
		{
			get { return m_MatchCircleTime; }
			set { m_MatchCircleTime = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int OneMatchGamePeriod
		{
			get { return m_OneMatchGamePeriod; }
			set { m_OneMatchGamePeriod = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public byte IsConfigedIPRestrict
		{
			get { return m_IsConfigedIPRestrict; }
			set { m_IsConfigedIPRestrict = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string MatchTitle
		{
			get { return m_MatchTitle; }
			set { m_MatchTitle = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string MatchRemarkInfo
		{
			get { return m_MatchRemarkInfo; }
			set { m_MatchRemarkInfo = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int PropertyKind
		{
			get { return m_PropertyKind; }
			set { m_PropertyKind = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int PropertyNumber
		{
			get { return m_PropertyNumber; }
			set { m_PropertyNumber = value; }
		}

		#endregion

	}
}
