/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-01-14 15:23:13*/
/*Table:MatchAwardConfig*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.Platform
{
	public class MatchAwardConfig
	{
		#region 构造函数
		public MatchAwardConfig(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "MatchAwardConfig";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchID = "MatchID";

		/// <summary>
		/// 
		/// </summary>
		public const string _Rank = "Rank";

		/// <summary>
		/// 
		/// </summary>
		public const string _Gold = "Gold";

		/// <summary>
		/// 
		/// </summary>
		public const string _Medal = "Medal";

		/// <summary>
		/// 
		/// </summary>
		public const string _Property = "Property";

		/// <summary>
		/// 
		/// </summary>
		public const string _PropertyKind = "PropertyKind";

		/// <summary>
		/// 
		/// </summary>
		public const string _PropertyName = "PropertyName";

		#endregion

		#region 私有变量
		private int m_MatchID;//
		private int m_Rank;//
		private int m_Gold;//
		private int m_Medal;//
		private int m_Property;//
		private int m_PropertyKind;//
		private string m_PropertyName;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int MatchID
		{
			get { return m_MatchID; }
			set { m_MatchID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int Rank
		{
			get { return m_Rank; }
			set { m_Rank = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int Gold
		{
			get { return m_Gold; }
			set { m_Gold = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int Medal
		{
			get { return m_Medal; }
			set { m_Medal = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int Property
		{
			get { return m_Property; }
			set { m_Property = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int PropertyKind
		{
			get { return m_PropertyKind; }
			set { m_PropertyKind = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string PropertyName
		{
			get { return m_PropertyName; }
			set { m_PropertyName = value; }
		}

		#endregion

	}
}
