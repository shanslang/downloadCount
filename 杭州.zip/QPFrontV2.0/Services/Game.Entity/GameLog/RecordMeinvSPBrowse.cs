/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-10-23 14:24:56*/
/*Table:RecordMeinvSPBrowse*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.GameLog
{
	public class RecordMeinvSPBrowse
	{
		#region 构造函数
		public RecordMeinvSPBrowse(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "RecordMeinvSPBrowse";

		/// <summary>
		/// 用户标识
		/// </summary>
		public const string _UserID = "UserID";

		/// <summary>
		/// 时间  相对于 1970-01-01 00:00:00   计算的秒数
		/// </summary>
		public const string _DateID = "DateID";

		/// <summary>
		/// 记录插入时间
		/// </summary>
		public const string _InsertTime = "InsertTime";

		#endregion

		#region 私有变量
		private int m_UserID;//用户标识
		private int m_DateID;//时间  相对于 1970-01-01 00:00:00   计算的秒数
		private DateTime m_InsertTime;//记录插入时间
		#endregion

		#region 公开属性

		/// <summary>
		/// 用户标识
		/// </summary>
		public int UserID
		{
			get { return m_UserID; }
			set { m_UserID = value; }
		}

		/// <summary>
		/// 时间  相对于 1970-01-01 00:00:00   计算的秒数
		/// </summary>
		public int DateID
		{
			get { return m_DateID; }
			set { m_DateID = value; }
		}

		/// <summary>
		/// 记录插入时间
		/// </summary>
		public DateTime InsertTime
		{
			get { return m_InsertTime; }
			set { m_InsertTime = value; }
		}

		#endregion

	}
}
