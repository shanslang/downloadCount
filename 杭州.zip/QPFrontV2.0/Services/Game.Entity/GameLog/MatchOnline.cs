/*****************************************************************/
/*Author:xujianbo*/
/*CreateTime:2015-10-14 15:38:52*/
/*Table:MatchOnline*/
/*****************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Game.Entity.GameLog
{
	public class MatchOnline
	{
		#region 构造函数
		public MatchOnline(){}
		#endregion

		#region 私有变量
		/// <summary>
		/// 表名
		/// </summary>
		public const string Tablename = "MatchOnline";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchID = "MatchID";

		/// <summary>
		/// 
		/// </summary>
		public const string _MatchSubID = "MatchSubID";

		/// <summary>
		/// 
		/// </summary>
		public const string _OnlineCount = "OnlineCount";

		#endregion

		#region 私有变量
		private int m_MatchID;//
		private int m_MatchSubID;//
		private int m_OnlineCount;//
		#endregion

		#region 公开属性

		/// <summary>
		/// 
		/// </summary>
		public int MatchID
		{
			get { return m_MatchID; }
			set { m_MatchID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int MatchSubID
		{
			get { return m_MatchSubID; }
			set { m_MatchSubID = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int OnlineCount
		{
			get { return m_OnlineCount; }
			set { m_OnlineCount = value; }
		}

		#endregion

	}
}
