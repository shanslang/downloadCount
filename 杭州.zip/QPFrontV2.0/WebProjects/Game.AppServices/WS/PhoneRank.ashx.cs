﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Text;
using Game.Entity.Treasure;
using Game.Facade;
using Game.Utils;
using System.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Game.AppServices.WS
{
    /// <summary>
    /// Summary description for $codebehindclassname$
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class PhoneRank : IHttpHandler
    {
        private TreasureFacade treasureFacade = new TreasureFacade();
        private AccountsFacade oAccountsFacade = new AccountsFacade();

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            string action = GameRequest.GetQueryString("action");
            switch (action)
            {
                case "getscorerank":
                    GetScoreRank(context);
                    break;
                default:
                    break;
            }
        }

        //获取金币排行榜，前50
        protected void GetScoreRank(HttpContext context)
        {
            IList<RankEntity> listRankEntity = new List<RankEntity>();
            int pageIndex = GameRequest.GetInt("pageindex", 1);
            int pageSize = GameRequest.GetInt("pagesize", 10);
            int userID = GameRequest.GetInt("UserID", 0);
            if (pageIndex <= 0) pageIndex = 1;
            if (pageSize <= 0) pageSize = 10;
            if (pageSize > 50) pageSize = 50;

            //获取用户排行
            string sqlQuery = string.Format("SELECT * FROM (SELECT ROW_NUMBER() OVER (ORDER BY Score DESC) as ChartID,UserID,Score FROM GameScoreInfo) a WHERE UserID={0}", userID);
            DataSet dsUser = treasureFacade.GetDataSetByWhere(sqlQuery);
            int uRank = 0;
            long uScore = 0;
            if (dsUser.Tables[0].Rows.Count != 0)
            {
                uRank = Convert.ToInt32(dsUser.Tables[0].Rows[0]["ChartID"]);
                uScore = Convert.ToInt64(dsUser.Tables[0].Rows[0]["Score"]);
            }
            var user1 = oAccountsFacade.GetUserFullInfoByUserID(userID);
            if (user1 != null)
            {
                listRankEntity.Add(new RankEntity() { NickName = user1.NickName, Score = uScore, Rank = uRank });
            }

            //获取总排行
            //string sqlQuery1 = "select UserID,Score from GameScoreInfo";
            //DataSet ds = treasureFacade.GetList(pageIndex, pageSize, sqlQuery1, null, "Score DESC");

            string sqlQuery1 = "SELECT top 20 ROW_NUMBER() OVER (ORDER BY Score DESC) as ChartID,UserID,Score FROM GameScoreInfo";
            DataSet ds = treasureFacade.GetDataSetByWhere(sqlQuery1);
            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    var user2 = oAccountsFacade.GetUserFullInfoByUserID(Convert.ToInt32(dr["UserID"]));
                    if (user2 != null)
                    {
                        listRankEntity.Add(new RankEntity() { NickName = user2.NickName, Score = Convert.ToInt64(dr["Score"]), Rank = Convert.ToInt32(dr["ChartID"]) });
                    }
                }
            }
            string jsondata = Newtonsoft.Json.JsonConvert.SerializeObject(listRankEntity);

            context.Response.Write(jsondata);
        }

        public class RankEntity
        {
            public string NickName { get; set; }
            public long Score { get; set; }
            public int Rank { get; set; }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
