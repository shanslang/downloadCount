﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Collections;
using System.Text.RegularExpressions;
using Game.Web;

using Game.Entity.NativeWeb;
using Game.Entity.Treasure;
using Game.Entity.Accounts;
using Game.Entity.Task;
using Game.Utils;
using Game.Facade;
using Game.Francis;
using Game.Library;
using System.IO;
using System.Configuration;

namespace Game.AppServices.handler
{
    /// <summary>
    /// webhandler 的摘要说明
    /// </summary>
    public class webhandler : BaseHandler
    {
        TreasureFacade oTreasureFacade = new TreasureFacade();
        NativeWebFacade oNativeWebFacade = new NativeWebFacade();

        #region 用户注册
        /// <summary>
        /// 用户注册
        /// </summary>
        [AjaxMethod(AuthorizationRequired = false)]
        public void Register(string accounts, string nickname, string password, string passwordok, int spreadusergameid, string checkcode, int RegKindID, int RegDeviceType, string externalMsg)
        {
            AccountsFacade oAccountsFacade = new AccountsFacade();

            #region 检查用户名
            if (string.IsNullOrEmpty(accounts))
            {
                throw new Exception("账号不能为空！");
            }
            if (Regex.IsMatch(accounts, "^[a-zA-Z\u4E00-\u9FA5][0-9a-zA-Z\u4E00-\u9FA5_]{3,15}$") == false)
            {
                throw new Exception("用户名由4到16位的数字、字母、汉字、下划线组成，首字母只能为字母或汉字");
            }
            //数据库验证
            Message umsg = oAccountsFacade.IsAccountsExist(accounts);
            if (umsg.Success == false) throw new Exception("该用户名已经被使用,请换其它用户名在试！");
            #endregion

            #region 检查昵称
            if (string.IsNullOrEmpty(nickname.Trim())) throw new Exception("昵称不能为空");
            if (nickname.Trim().Length < 4 || nickname.Trim().Length > 16) throw new Exception("昵称长度只能填写4-16个字符");
            //数据库验证
            bool state = oAccountsFacade.IsNickNameExist(nickname.Trim());
            if (state) throw new Exception("昵称已经被使用,请换其它昵称再试！");
            #endregion

            #region 检查密码
            if (password.Length < 6 || password.Length > 20)
            {
                throw new Exception("密码由6到20位字符组成，可输入数字、字母或符号的组合，不建议使用纯数字、纯字母、纯符号");
            }
            #endregion

            #region 检查确认密码
            if (password != passwordok)
            {
                throw new Exception("两次输入密码不一致！");
            }
            #endregion

            #region 推广员
            string spreaduseraccount = "";
            if (spreadusergameid > 0)
            {
                var spreaduser = oAccountsFacade.GetUserFullInfoByGameID(spreadusergameid);
                if (spreaduser != null)//推荐人处理
                {
                    spreaduseraccount = spreaduser.Accounts;
                }
            }
            #endregion

            #region 验证验证码
            string ckmsg = GlobalParameter.Instance.ValidationCode(checkcode);
            if (!string.IsNullOrEmpty(ckmsg))
            {
                Game.Library.Log.WriteLogInfo("Register", new Exception("信息：验证不通过，账号：" + accounts + "，客户端IP：" + Game.Utils.Utility.UserIP + "，验证码：" + checkcode));
                throw new Exception(ckmsg);
            }
            #endregion

            //初始用户对象
            UserInfo user = new UserInfo();
            user.Accounts = accounts;
            user.Compellation = "";
            user.FaceID = 37;
            user.Gender = 0;
            user.InsurePass = TextEncrypt.EncryptPassword(password);
            user.LastLogonDate = DateTime.Now;
            user.LastLogonIP = GameRequest.GetUserIP();
            user.LogonPass = TextEncrypt.EncryptPassword(password);
            user.NickName = nickname;
            user.PassPortID = "";
            user.RegisterDate = DateTime.Now;
            user.RegisterIP = GameRequest.GetUserIP();
            user.RegKindID = RegKindID;
            user.RegDeviceType = RegDeviceType;
            user.ExternalMsg = externalMsg;
            //注册用户
            Message msg = oAccountsFacade.Register(user, spreaduseraccount, 0, "");
            if (msg.Success)
            {
                int userid = Convert.ToInt32((msg.EntityList[0] as DataSet).Tables[0].Rows[0][0]);
                UserInfo ui = oAccountsFacade.GetUserFullInfoByUserID(userid);
                ui.LogonPass = TextEncrypt.EncryptPassword(password);
                Fetch.SetUserCookie(ui.ToUserTicketInfo());
                //Game.Library.Log.WriteLogInfo("Register", new Exception("信息：注册成功，账号：" + accounts + "，客户端IP：" + Game.Utils.Utility.UserIP + "，验证码：" + checkcode));
                this.CallBackData(true, "注册成功！", null);
            }
            else
            {
                //Game.Library.Log.WriteLogInfo("Register", new Exception("信息：" + msg.Content + "，账号：" + accounts + "，客户端IP：" + Game.Utils.Utility.UserIP + "，验证码：" + checkcode));
                this.CallBackData(false, msg.Content, null);
            }
        }

        #endregion

        #region 重写父类
        protected override void HandlerAuthorizationRequired()
        {
            if (!GlobalParameter.Instance.IsAuthenticated)
            {
                throw new Exception("您还没有登录！");
            }
        }
        #endregion

        #region 每日签到
        ///// <summary>
        ///// 每日签到
        ///// </summary>
        //[AjaxMethod(AuthorizationRequired = true)]
        //public void DailySign()
        //{
        //    this.CallBackData(false, "请刷新页面签到！", 0);
        //    //var user = GlobalParameter.Instance.CurrentLoginUser;
        //    //RecordDailySign oRecordDailySign = new RecordDailySign();
        //    //oRecordDailySign.UserID = user.UserID;
        //    //Message msg = oNativeWebFacade.InsertRecordDailySign(oRecordDailySign);
        //    //if (msg.Success)
        //    //{
        //    //    this.CallBackData(true, msg.Content, DateTime.Now.Day);
        //    //}
        //    //else this.CallBackData(false, msg.Content, msg.ReturnValue);
        //}
        #endregion

        #region 每日签到 2.0
        /// <summary>
        /// 每日签到2.0
        /// </summary>
        [AjaxMethod(AuthorizationRequired = true)]
        public void DailySignV2()
        {
            var user = GlobalParameter.Instance.CurrentLoginUser;
            Message msg = oNativeWebFacade.InsertRecordDailySignV2(new RecordDailySignV2() { UserID = user.UserID, ClientIP = Game.Utils.GameRequest.GetUserIP() });
            if (msg.Success)
            {
                string reward = "恭喜您签到成功，你获得了";
                DataTable dt = (msg.EntityList[0] as DataSet).Tables[1];
                foreach (DataRow item in dt.Rows)
                {
                    reward += item["Name"].ToString() + "x" + Convert.ToInt32(item["Number"]) + "、";
                }
                reward = reward.Trim(new char[] { '、' }) + "。";
                this.CallBackData(true, reward, DateTime.Now.Day);
            }
            else
            {
                this.CallBackData(false, msg.Content, DateTime.Now.Day);
            }
        }
        #endregion

        #region 活动 黄金挖矿
        /// <summary>
        /// 新挖矿
        /// author:francis
        /// createdate:2014-11-08
        /// </summary>
        [AjaxMethod(AuthorizationRequired = true)]
        public void NWaKuang(int kuangtype)
        {
            int state = 0;
            string result = oNativeWebFacade.ActivityForNWaKuang(kuangtype, ref state);
            if (state == 0)
            {
                this.CallBackData(true, result, state);
            }
            else
            {
                if (state == 3) //未绑定手机
                {
                    this.CallBackData(false, "手机认证用户可参与本游戏领取福利，现在在个人信息中绑定手机进行认证可获得额外金币奖励哦！", state);
                }
                else
                {
                    this.CallBackData(false, result, state);
                }
            }
        }
        #endregion

        #region 兑换CDK
        [AjaxMethod(AuthorizationRequired = true)]
        public void ConvertPackageCDKey(string packagecdkey)
        {
            var user = GlobalParameter.Instance.CurrentLoginUser;
            Message msg = oNativeWebFacade.ConvertPackageCDKey(user.UserID, packagecdkey, 0);
            if (msg.Success)
            {
                string result = "兑换成功，您获得";
                DataTable dt = (msg.EntityList[0] as DataSet).Tables[1];
                foreach (DataRow item in dt.Rows)
                {
                    result += item["Name"] + "x" + item["Number"] + "，";
                }
                result = result.Trim('，') + "，欢迎参与本活动。";
                this.CallBackData(true, result, msg.ReturnValue);
            }
            else
            {
                this.CallBackData(false, msg.Content, msg.ReturnValue);
            }
        }
        #endregion
        #region 下载统计

        [AjaxMethod(AuthorizationRequired = false)]
        public void InsertDownLog(int deviceType, int kindID)
        {
            if (oNativeWebFacade.InsertDownLoadLog(deviceType, kindID) > 0)
            {
                this.CallBackData(true, "成功", null);
            }
            else
            {
                this.CallBackData(false, "失败", null);
            }
        }
        #endregion


        #region 获取对战版下载地址
        [AjaxMethod(AuthorizationRequired = false)]
        public void GetAppUrl(int kindID)
        {
            Hashtable htb = new Hashtable();
            if (kindID == 917)
            {
                htb.Add("ios", ConfigurationManager.AppSettings["XLDZBIOSAppurl"].ToString());
                htb.Add("android", ConfigurationManager.AppSettings["XLDZBAndroidAppurl"].ToString());
                this.CallBackData(true, "成功", htb);
            }
            else if (kindID == 916)
            {
                htb.Add("ios", ConfigurationManager.AppSettings["NMIOSAppurl"].ToString());
                htb.Add("android", ConfigurationManager.AppSettings["NMAndroidAppurl"].ToString());
                this.CallBackData(true, "成功", htb);
            }
            else if (kindID == 1918)
            {
                htb.Add("ios", ConfigurationManager.AppSettings["HBIOSAppurl"].ToString());
                htb.Add("android", ConfigurationManager.AppSettings["HBAndroidAppurl"].ToString());
                this.CallBackData(true, "成功", htb);
            }
        }
        #endregion
    }
}