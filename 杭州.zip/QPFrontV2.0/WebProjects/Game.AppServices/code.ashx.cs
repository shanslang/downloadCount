﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Drawing;
using Game.Facade;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Security.Cryptography;
using System.Drawing.Text;

namespace Game.AppServices
{
    /// <summary>
    /// code 的摘要说明
    /// </summary>
    public class code : IHttpHandler, System.Web.SessionState.IRequiresSessionState
    {
        private HttpContext httpContext = null;
        public void ProcessRequest(HttpContext context)
        {
            httpContext = context;
            //context.Response.ContentType = "text/plain";
            //context.Response.Write("Hello World");

            string randomcode = Game.Utils.TextUtility.CreateAuthStr(4, false);
            Game.Utils.SessionState.Set(Fetch.UC_VERIFY_CODE_KEY, randomcode);
            //Utils.Utility.WriteCookie(Fetch.UC_VERIFY_CODE_KEY, Utils.CWHEncryptNet.XorEncrypt(randomcode));
            this.CreateImage(randomcode);

            //string randomcode = "";
            //string expression = this.CreateRandomCode(ref randomcode);
            //Game.Utils.SessionState.Set(Fetch.UC_VERIFY_CODE_KEY, randomcode);
            ////Utils.Utility.WriteCookie(Fetch.UC_VERIFY_CODE_KEY, Utils.CWHEncryptNet.XorEncrypt(randomcode));
            //this.CreateImage(expression);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }


        private Bitmap charbmp = new Bitmap(300, 100);
        private Random random = new Random();

        /// <summary>
        /// 字体
        /// </summary>
        public List<FontFamily> ListFontFamily
        {
            get
            {
                List<FontFamily> result = new List<FontFamily>();
                result.Add(new FontFamily("Arial"));
                result.Add(new FontFamily("Arial Black"));
                result.Add(new FontFamily("Arial Narrow"));
                result.Add(new FontFamily("Verdana"));
                result.Add(new FontFamily("Georgia"));
                //result.Add(new FontFamily("Times New Roman"));
                //result.Add(new FontFamily("Trebuchet MS"));
                //result.Add(new FontFamily("Courier New"));
                //result.Add(new FontFamily("Impact"));
                //result.Add(new FontFamily("Comic Sans MS"));
                //result.Add(new FontFamily("Tahoma"));
                //result.Add(new FontFamily("Courier"));
                //result.Add(new FontFamily("Lucida Sans Unicode"));
                //result.Add(new FontFamily("Lucida Console"));
                //result.Add(new FontFamily("Garamond"));
                //result.Add(new FontFamily("MS Sans Serif"));
                //result.Add(new FontFamily("Bookman Old Style"));

                ////加载特殊字体
                //PrivateFontCollection privateFonts = new PrivateFontCollection();
                //string[] arypath = System.IO.Directory.GetFiles(Server.MapPath("~\\inc\\fonts\\"), "*.ttf", System.IO.SearchOption.TopDirectoryOnly);
                //foreach (string path in arypath)
                //{
                //    privateFonts.AddFontFile(path);//加载路径的字体
                //}
                //foreach (var item in privateFonts.Families)
                //{
                //    result.Add(item);
                //}
                //privateFonts.Dispose();

                return result;
            }
        }
        /// <summary>
        /// 字体样式
        /// </summary>
        private Font font
        {
            get
            {
                return new Font(this.ListFontFamily[Next(0, ListFontFamily.Count)], 60, FontStyle.Regular);
            }
        }
        /// <summary>
        /// 文字颜色
        /// </summary>
        private Color charcolor
        {
            get
            {
                Color[] colors = new Color[] { 
                    Color.FromArgb(255, 102, 102),
                    Color.FromArgb(204, 51, 51),
                    Color.FromArgb(0, 51, 153),
                    Color.FromArgb(0, 153, 204),
                    Color.FromArgb(51, 51, 0),
                    Color.FromArgb(153, 204, 102),
                    Color.FromArgb(153, 204, 0),
                    Color.FromArgb(51, 51, 153),
                    Color.FromArgb(255, 0, 51),
                    Color.FromArgb(0, 51, 0)
                };
                return colors[Next(0, colors.Length)];
            }
        }
        /// <summary>
        /// 干扰线颜色
        /// </summary>
        private Color linecolor
        {
            get
            {
                Color[] colors = new Color[] { 
                    Color.FromArgb(255, 102, 102),
                    Color.FromArgb(204, 51, 51),
                    Color.FromArgb(0, 51, 153),
                    Color.FromArgb(0, 153, 204),
                    Color.FromArgb(51, 51, 0),
                    Color.FromArgb(153, 204, 102),
                    Color.FromArgb(153, 204, 0),
                    Color.FromArgb(51, 51, 153),
                    Color.FromArgb(255, 0, 51),
                    Color.FromArgb(0, 51, 0)
                };
                return colors[Next(0, colors.Length)];
            }
        }

        /// <summary>
        /// 生产随机验证码
        /// </summary>
        /// <param name="result"></param>
        /// <returns></returns>
        private string CreateRandomCode(ref string result)
        {
            string expression = "";
            int snumber = Next(1, 10);
            int enumber = Next(1, 10);
            int oper = Next(1, 4);
            int opert = Next(1, 3);
            switch (oper)
            {
                case 1:// +
                    {
                        expression = snumber + (opert == 1 ? "+" : "加") + enumber + "=？";
                        result = (snumber + enumber).ToString();
                        break;
                    }
                case 2:// -
                    {
                        if (snumber >= enumber)
                        {
                            expression = snumber + (opert == 1 ? "+" : "减") + enumber + "=？";
                            result = (snumber - enumber).ToString();
                        }
                        else
                        {
                            expression = enumber + (opert == 1 ? "+" : "减") + snumber + "=？";
                            result = (enumber - snumber).ToString();
                        }
                        break;
                    }
                case 3:// *
                    {
                        expression = snumber + (opert == 1 ? "+" : "乘") + enumber + "=？";
                        result = (snumber * enumber).ToString();
                        break;
                    }
            }
            return expression;
        }

        /// <summary>
        /// 获得下一个随机数
        /// </summary>
        /// <param name="max">最大值</param>
        /// <returns></returns>
        private int Next(int max)
        {
            return random.Next(max);
        }

        /// <summary>
        /// 获得下一个随机数
        /// </summary>
        /// <param name="min">最小值</param>
        /// <param name="max">最大值</param>
        /// <returns></returns>
        private int Next(int min, int max)
        {
            return random.Next(min, max);
        }

        ///  <summary>
        ///  创建随机码图片
        ///  </summary>
        ///  <param  name="randomcode">随机码</param>
        private void CreateImage(string randomcode)
        {
            int width = 300;
            int height = 100;

            Bitmap bitmap = new Bitmap(width, height, PixelFormat.Format32bppArgb);
            Graphics g = Graphics.FromImage(bitmap);
            Color[] lineColors = new Color[randomcode.Length];
            for (int i = 0; i < randomcode.Length; i++)
            {
                lineColors[i] = linecolor;
            }
            //图片质量
            g.SmoothingMode = SmoothingMode.HighQuality;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.CompositingQuality = CompositingQuality.HighQuality;
            //画背景
            g.Clear(Color.FromArgb(Next(200, 250), Next(200, 250), Next(200, 250)));
            //画背景1
            Brush t = new SolidBrush(Color.FromArgb(Next(200, 250), Next(200, 250), Next(200, 250)));
            GraphicsPath gp = new GraphicsPath();
            gp.AddRectangle(new Rectangle(1, 1, width-2, Next(10, 90)));
            g.FillPath(t, gp);

            ////画图片的背景噪音线  直线
            //for (int i = 0; i < 20; i++)
            //{
            //    int x1 = Next(10, width - 10);
            //    int x2 = Next(10, width - 10);
            //    int y1 = Next(5, height - 5);
            //    int y2 = Next(5, height - 5);
            //    Pen pen = new Pen(Color.FromArgb(Next(0, 256), Next(0, 256), Next(0, 256)), 1);
            //    g.DrawLine(pen, x1, y1, x2, y2);
            //}

            //画图片的背景噪音线  曲线
            PointF[] qxPointFs = new PointF[16];
            for (int i = 0; i <= 15; i++)
            {
                qxPointFs[i] = new Point(i*20, Next(8, 92));
            }
            Pen qxPen = new Pen(lineColors[random.Next(0, lineColors.Length)], 4);
            g.DrawCurve(qxPen, qxPointFs, 0.2F);

            //绘图
            SolidBrush drawBrush = new SolidBrush(Color.FromArgb(Next(100), Next(100), Next(100)));
            Graphics charg = Graphics.FromImage(charbmp);
            float charx = -50;
            for (int i = 0; i < randomcode.Length; i++)
            {
                Matrix m = new Matrix();
                m.Reset();
                m.RotateAt(Next(50) - 25, new PointF(Next(3) + 7, Next(3) + 7));
                charg.Transform = m;

                //文字背景
                charg.Clear(Color.Transparent);
                //文字颜色
                drawBrush.Color = lineColors[i];
                //计算文字的X坐标
                charx = charx + 60 + Next(0, 2);
                PointF drawPoint = new PointF(charx, 0);
                charg.DrawString(randomcode[i].ToString(), font, drawBrush, new PointF(0, 0));
                charg.ResetTransform();
                g.DrawImage(charbmp, drawPoint);
            }
            drawBrush.Dispose();

            
            ////画图片的背景噪音线  曲线
            //for (int i = 0; i < 5; i++)
            //{
            //    int x1 = random.Next(width);
            //    int x2 = random.Next(width);
            //    int y1 = random.Next(height);
            //    int y2 = random.Next(height);
            //    Pen pen = new Pen(lineColors[random.Next(0, lineColors.Length)], 5);
            //    Rectangle rf = new Rectangle(Next(5,50), Next(10,20), width/2, height/2);
            //    g.DrawArc(pen, rf, Next(100,200), Next(100,200));
            //}


            //画边框
            g.DrawRectangle(new Pen(Color.FromArgb(206, 206, 206), 0), 0, 0, bitmap.Width - 1, bitmap.Height - 1);

            //生成图片
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            httpContext.Response.ClearContent();
            httpContext.Response.ContentType = "image/Jpeg";
            httpContext.Response.BinaryWrite(ms.ToArray());

            
            g.Dispose();
            bitmap.Dispose();
        }
    }
}