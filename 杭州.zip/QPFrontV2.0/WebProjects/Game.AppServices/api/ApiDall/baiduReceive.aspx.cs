﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Game.Entity.Treasure;
using Game.Facade;
using Game.Utils;
using Newtonsoft.Json;

namespace Game.AppServices.api.ApiDall
{
    public partial class baiduReceive : System.Web.UI.Page
    {
        private static string appID = Game.Web.Constant.BDAppidXL;//开发者应用ID

        private static string secretkey = Game.Web.Constant.BDSecretkeyXL;//开发者应用秘钥
        protected TreasureFacade oTreasureFacade = new TreasureFacade();
        /// <summary>
        /// 发货通知接收示例
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                var resultCode = 1;
                var resultMsg = string.Empty;
                #region 2.读取POST流方式获取请求参数
                var postData = string.Empty;
                using (var br = new System.IO.BinaryReader(this.Request.InputStream))
                {
                    postData = System.Text.Encoding.UTF8.GetString(br.ReadBytes(int.Parse(this.Request.InputStream.Length.ToString())));
                }
                //解析postData
                Hashtable ht = ConvertKeyValueStrToHashtable(postData);
                var orderSerial = string.Empty;
                if (ht != null && ht.ContainsKey("OrderSerial"))
                    orderSerial = ht["OrderSerial"].ToString();
                var cooperatorOrderSerial = string.Empty;
                if (ht != null && ht.ContainsKey("CooperatorOrderSerial"))
                    cooperatorOrderSerial = ht["CooperatorOrderSerial"].ToString();
                var content = string.Empty;
                if (ht != null && ht.ContainsKey("Content"))
                    content = HttpUtility.UrlDecode(ht["Content"].ToString());//读取POST流的方式需要进行HttpUtility.UrlDecode解码操作
                var sign = string.Empty;
                if (ht != null && ht.ContainsKey("Sign"))
                    sign = ht["Sign"].ToString();
                #endregion
                // Game.Library.Log.WriteLogInfo("百度回调：", new Exception(string.Format("{0}---{1}---{2}--{3}", orderSerial, cooperatorOrderSerial, content, sign)));
                //2.先检测请求数据签名是否合法 
                if (sign != Utility.Encrypt_MD5_UTF8(appID + orderSerial + cooperatorOrderSerial + content + secretkey))
                {
                    resultCode = 1001;//自定义错误信息
                    resultMsg = "签名错误";//自定义错误信息
                    Response.Write(JsonConvert.SerializeObject(new
                    {
                        AppID = appID,
                        ResultCode = resultCode,
                        ResultMsg = resultMsg,
                        Sign = Utility.Encrypt_MD5_UTF8(appID + resultCode + secretkey),
                        Content = string.Empty
                    }
                    ));
                    return;
                }
                //3.解析Content 内容  【BASE64解码--》JSON解析】
                var item = JsonConvert.DeserializeAnonymousType(Utility.Base64StringDecode(content), new ReturnBDDetailInfo
                {
                    UID = 0L,
                    MerchandiseName = string.Empty,
                    OrderMoney = 0,
                    StartDateTime = System.DateTime.Now,
                    BankDateTime = System.DateTime.Now,
                    OrderStatus = 0,
                    StatusMsg = string.Empty,
                    ExtInfo = string.Empty,
                    VoucherMoney = 0 //增加代金券金额获取
                });

                //4.执行业务逻辑处理
                if (item != null)
                {
                    var oOnlineOrder = oTreasureFacade.GetOnlineOrder(cooperatorOrderSerial);
                    if (item.OrderMoney > 0&&item.OrderStatus==1
                                && item.OrderMoney >= oOnlineOrder.OrderAmount
                                && oOnlineOrder.OrderStatus == (int)Game.Type.OnLineOrderStatus.未付款)
                    {
                        oOnlineOrder.ShareID = (int)Game.Type.GlobalShareInfo.BD;//加入充值标识
                        oTreasureFacade.WriteBDRecharge(item, oOnlineOrder);
                        resultCode = 1;
                        resultMsg = "支付成功";
                    }
                    else
                    {
                        resultCode = 0;
                        resultMsg = "支付失败";
                    }

                }
                else
                {
                    resultCode = 0;
                    resultMsg = "支付失败";
                }
                //5.返回成功结果
                Response.Write(JsonConvert.SerializeObject(new
                {
                    AppID = appID,
                    ResultCode = resultCode,
                    ResultMsg = resultMsg,
                    Sign = Utility.Encrypt_MD5_UTF8(appID + resultCode + secretkey),//签名
                    Content = string.Empty
                }
                ));
            }
            catch (Exception ex)
            {
                Game.Library.Log.WriteLogInfo("百度支付：", ex);
                Response.Write(JsonConvert.SerializeObject(new
                {
                    AppID = appID,
                    ResultCode = 0,
                    ResultMsg = "支付失败",
                    Sign = Utility.Encrypt_MD5_UTF8(appID + 0 + secretkey),//签名
                    Content = string.Empty
                }
               ));
            }
        }


        /// <summary>
        /// KeyValue字符串组转Hashtable
        /// </summary>
        /// <param name="keyValueStr">格式如：key1=value1&key2=value2</param>
        /// <param name="connector">keyvalue连接符</param>
        /// <param name="spilt">keyvalue分隔符</param>
        /// <returns></returns>
        public static Hashtable ConvertKeyValueStrToHashtable(string keyValueStr, char connector = '&', char spilt = '=')
        {
            Hashtable ht = null;
            if (!string.IsNullOrEmpty(keyValueStr) && keyValueStr.IndexOf(connector.ToString()) > -1 && keyValueStr.IndexOf(connector.ToString()) > -1)
            {
                ht = new Hashtable();
                foreach (string keyValue in keyValueStr.Split(connector))
                {
                    var kv = keyValue.Split(spilt);
                    if (kv.Length > 1 && !ht.ContainsKey(kv[0]))
                    {
                        ht.Add(kv[0], kv[1]);
                    }
                }
            }
            return ht;
        }
    }
}