﻿using System;
using System.Collections.Generic;
using Game.Entity.Accounts;
using Game.Francis;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Game.Facade.Facade;
using System.Collections;
using System.Data;
using Game.Type;
using System.Text;
using Newtonsoft.Json;

namespace Game.AppServices.api.ApiDall
{
    public partial class PseudoStatic : System.Web.UI.Page
    {
        protected MobileAppFacade oMobileAppFacade = new MobileAppFacade();
        protected void Page_Load(object sender, EventArgs e)
        {
            MainFunction();
        }

        protected void MainFunction()
        {
            HttpResponse response = this.Response;
            try
            {
                string m = this.Request.QueryString["m"].ToString();
                if (m == "1006")
                    MatchDataInfo();
            }
            catch (Exception exception)
            {
                Exception exp = (exception.InnerException != null) ? exception.InnerException : exception;
                Game.Library.Log.WriteLogInfo("PseudoStatic", exp);
                this.ResponseDataFormat = BaseMobileHandlerResponseFormat.JSONObject;
                // this.SetResponseData(false, "出现异常，请联系管理员", null, 0, null);
                this.SetResponseData(false, exp.Message, null, 0, null);
            }
            finally
            {
                response.Clear();
                response.CacheControl = "no-cache";
                response.ContentEncoding = Encoding.UTF8;
                switch (this.ResponseDataFormat)
                {
                    case BaseMobileHandlerResponseFormat.JSON:
                        {
                            response.ContentType = "application/json";
                            response.Write(this.ResponsePackage);
                            break;
                        }
                    case BaseMobileHandlerResponseFormat.JSONObject:
                        {
                            response.ContentType = "application/json";
                            string json = JsonConvert.SerializeObject(this.ResponsePackage);
                            response.Write(json);
                            break;
                        }
                    case BaseMobileHandlerResponseFormat.XML:
                        {
                            response.ContentType = "application/xml";
                            response.Write(this.ResponsePackage);
                            break;
                        }
                    case BaseMobileHandlerResponseFormat.Binary:
                        {
                            response.ContentType = "application/octet-stream";
                            response.BinaryWrite((this.ResponsePackage as byte[]));
                            break;
                        }
                    case BaseMobileHandlerResponseFormat.Text:
                        {
                            response.Write(this.ResponsePackage);
                            break;
                        }
                }
                response.End();
            }

        }

        #region 获取大厅比赛场数据
        private void MatchDataInfo()
        {
            if (this.Request.QueryString["matchid"] != null && this.Request.QueryString["roundid"] != null)
            {
                int paramMatchid = Convert.ToInt32(this.Request.QueryString["matchid"].ToString());
                int paramRoundid = Convert.ToInt32(this.Request.QueryString["roundid"].ToString());
                Message matchmsg = oMobileAppFacade.GetMobileMatchInfo(paramMatchid, paramRoundid);
                List<Hashtable> responseHash = new List<Hashtable>();
                Hashtable hashdata = new Hashtable();
                DateTime time = new DateTime();
                if (matchmsg.Success == true)
                {
                    DataSet ds = matchmsg.EntityList[0] as DataSet;
                    DataTable dt = ds.Tables[0];
                    hashdata.Add("matchid", dt.Rows[0]["MatchID"].ToString());
                    hashdata.Add("roundid", dt.Rows[0]["MatchRoundID"].ToString());
                    hashdata.Add("matchname", dt.Rows[0]["MatchName"].ToString());
                    hashdata.Add("firstreward", dt.Rows[0]["RankOnereward"].ToString());  //第一名奖励
                    hashdata.Add("signcondition", dt.Rows[0]["Cost"].ToString());         //报名费用

                    hashdata.Add("startType", dt.Rows[0]["StartType"].ToString());
                    hashdata.Add("matchType", dt.Rows[0]["MatchType"].ToString());
                    hashdata.Add("userListCount", dt.Rows[0]["UserListCount"].ToString());
                    hashdata.Add("nextMatchID", dt.Rows[0]["NextMatchID"].ToString());
                    hashdata.Add("startCount", dt.Rows[0]["MaxSignCount"].ToString());
                    hashdata.Add("GroupMaskMobile", dt.Rows[0]["GroupMaskMobile"].ToString());
                    hashdata.Add("starttime", Convert.ToDateTime(dt.Rows[0]["NextMatchStart"]).ToString("yyyy-MM-dd HH:mm:ss"));   //开始时间
                    //结束时间(开始时间+GameSec)
                    if (dt.Rows[0]["GameSec"] != DBNull.Value)
                    {
                        time = Convert.ToDateTime(dt.Rows[0]["NextMatchStart"]).AddSeconds(Convert.ToInt32(dt.Rows[0]["GameSec"]));
                        hashdata.Add("endtime", time.ToString("yyyy-MM-dd HH:mm:ss"));
                    }
                    else
                        hashdata.Add("endtime", Convert.ToDateTime(dt.Rows[0]["NextMatchStart"]).ToString("yyyy-MM-dd HH:mm:ss"));
                    //报名时间(开始时间-ValidSignSec)
                    time = Convert.ToDateTime(dt.Rows[0]["NextMatchStart"]).AddSeconds(0 - Convert.ToInt32(dt.Rows[0]["ValidSignSec"]));
                    hashdata.Add("signtime", time.ToString("yyyy-MM-dd HH:mm:ss"));
                    //比赛规则页面 @Francis
                    hashdata.Add("pagematchruleurl",Game.AppServices.Constant.RedirectDomain+"/page/xueliu/notic.aspx?gametype=3");
                    hashdata.Add("pagematchrulewidth", "600");
                    hashdata.Add("pagematchruleheight", "360");

                    if (ds.Tables.Count == 2 && ds.Tables[1].Rows.Count > 0)
                    {
                        List<Hashtable> matchByRoundList = new List<Hashtable>();
                        foreach (DataRow dr in ds.Tables[1].Rows)
                        {
                            Hashtable hashSer = new Hashtable();
                            hashSer.Add("Round", dr["Round"].ToString());
                            hashSer.Add("PlayCount", dr["PlayCount"].ToString());
                            hashSer.Add("DirectRiseRank", dr["DirectRiseRank"].ToString());
                            hashSer.Add("RiseRank", dr["RiseRank"].ToString());
                            hashSer.Add("ScoreFun", dr["ScoreFun"].ToString());
                            matchByRoundList.Add(hashSer);
                        }
                        hashdata.Add("MatchByRound", matchByRoundList);
                    }

                    responseHash.Add(hashdata);
                    this.SetResponseData(true, "成功获取比赛信息！", "", (int)WEBRESULT_CMD_TYPE.获取比赛数据完成, responseHash);
                }
                else
                {
                    this.SetResponseData(false, "没有指定的比赛信息！", "", (int)WEBRESULT_CMD_TYPE.获取比赛数据完成, responseHash);
                }
            }
        }
        #endregion

        #region 变量
        /// <summary>
        /// 返回数据格式 
        /// </summary>
        private BaseMobileHandlerResponseFormat _ResponseDataFormat = BaseMobileHandlerResponseFormat.JSONObject;
        public BaseMobileHandlerResponseFormat ResponseDataFormat
        {
            get { return _ResponseDataFormat; }
            set { _ResponseDataFormat = value; }
        }

        /// <summary>
        /// 返回数据包对象
        /// </summary>
        private object _ResponsePackage = null;
        public object ResponsePackage
        {
            get
            {
                return this._ResponsePackage;
            }
            set
            {
                this._ResponsePackage = value;
            }
        }

        #endregion

        #region 公共方法
        protected void SetResponseData(bool status, string message, string sign, int cmd, object data)
        {
            this.ResponseDataFormat = BaseMobileHandlerResponseFormat.JSONObject;
            Hashtable hashtable = new Hashtable();
            hashtable.Add("cmd", cmd);
            hashtable.Add("sign", sign);
            hashtable.Add("status", status);
            hashtable.Add("message", message);
            hashtable.Add("data", data);
            this.ResponsePackage = hashtable;
        }
          
        #endregion

    }

    /// <summary>
    /// 方法属性
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class MobileMethodAttribute : Attribute
    {
        public MobileMethodAttribute()
        {
            this.AuthorizationRequired = false;
            this.RequestCMD = null;
        }
        public bool AuthorizationRequired { get; set; }
        public string RequestCMD { get; set; }
    }
    /// <summary>
    /// 返回数据格式
    /// </summary>
    public enum BaseMobileHandlerResponseFormat
    {
        JSON = 1,
        JSONObject = 2,
        XML = 3,
        Binary = 4,
        Text = 5,
    }
}