﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Game.Entity.Accounts;
using Game.Entity.Treasure;
using Game.Utils;
using Game.Francis;
using System.Text;
using System.Collections.Generic;
using System.Collections.Specialized;
using Com.Alipay;
using Game.Facade;
using System.IO;

namespace Game.AppServices.api.ApiDall
{
    public partial class payreceive : System.Web.UI.Page
    {
        protected TreasureFacade oTreasureFacade = new TreasureFacade();

        protected void Page_Load(object sender, EventArgs e)
        {
            SortedDictionary<string, string> sPara = GetRequestPost();
            if (sPara.Count > 0)//判断是否有带返回参数
            {
                Notify aliNotify = new Notify();
                bool verifyResult = aliNotify.Verify(sPara, Request.Form["notify_id"], Request.Form["sign"]);

                if (verifyResult)//验证成功
                {
                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    //请在这里加上商户的业务逻辑程序代码
                    //——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
                    //获取支付宝的通知返回参数，可参考技术文档中服务器异步通知参数列表
                    //商户订单号
                    string out_trade_no = Request.Form["out_trade_no"];
                    //支付宝交易号
                    string trade_no = Request.Form["trade_no"];
                    //交易状态
                    string trade_status = Request.Form["trade_status"];

                    //封装支付宝返回结果包
                    ReturnZFBDetailInfo oReturnZFBDetailInfo = new ReturnZFBDetailInfo();
                    oReturnZFBDetailInfo.Is_success = Request.Form["is_success"];
                    oReturnZFBDetailInfo.Sign_type = Request.Form["sign_type"];
                    oReturnZFBDetailInfo.Sign = Request.Form["sign"];
                    oReturnZFBDetailInfo.Out_trade_no = Request.Form["out_trade_no"];
                    oReturnZFBDetailInfo.Subject = Request.Form["subject"];
                    oReturnZFBDetailInfo.Payment_type = Request.Form["payment_type"];
                    oReturnZFBDetailInfo.Exterface = Request.Form["exterface"];
                    oReturnZFBDetailInfo.Trade_no = Request.Form["trade_no"];
                    oReturnZFBDetailInfo.Trade_status = Request.Form["trade_status"];
                    oReturnZFBDetailInfo.Notify_id = Request.Form["notify_id"];
                    oReturnZFBDetailInfo.Notify_time = Convert.ToDateTime(Request.Form["notify_time"]);
                    oReturnZFBDetailInfo.Notify_type = Request.Form["notify_type"];
                    oReturnZFBDetailInfo.Seller_email = Request.Form["seller_email"];
                    oReturnZFBDetailInfo.Buyer_email = Request.Form["buyer_email"];
                    oReturnZFBDetailInfo.Seller_id = Request.Form["seller_id"];
                    oReturnZFBDetailInfo.Buyer_id = Request.Form["buyer_id"];
                    oReturnZFBDetailInfo.Total_fee = Convert.ToDecimal(Request.Form["total_fee"]);
                    oReturnZFBDetailInfo.Body = Request.Form["body"];
                    oReturnZFBDetailInfo.Extra_common_param = Request.Form["extra_common_param"];
                    oReturnZFBDetailInfo.Agent_user_id = Request.Form["agent_user_id"];

                    if (Request.Form["trade_status"] == "TRADE_FINISHED" || Request.Form["trade_status"] == "TRADE_SUCCESS")
                    {
                        var oOnlineOrder = oTreasureFacade.GetOnlineOrder(oReturnZFBDetailInfo.Out_trade_no);
                        if (oReturnZFBDetailInfo.Total_fee > 0
#if !DEBUG
                              && oReturnZFBDetailInfo.Total_fee >= oOnlineOrder.OrderAmount 
#endif

 && oOnlineOrder.OrderStatus == (int)Game.Type.OnLineOrderStatus.未付款)
                        {
                            oOnlineOrder.ShareID = (int)Game.Type.GlobalShareInfo.ZFB;//加入充值标识
                            //更改订单状态
                            oTreasureFacade.WriteZFBRecharge(oReturnZFBDetailInfo, oOnlineOrder);
                        }
                    }
                    Response.Write("success");  //请不要修改或删除 
                }
                else//验证失败
                {
                    StreamReader reader = new StreamReader(Request.InputStream);
                    string json = reader.ReadToEnd();
                    reader.Dispose();
                    Game.Library.Log.WriteLogInfo("支付宝日志", new Exception("支付宝验证失败，发送数据：" + json));
                    Response.Write("fail");
                }
            }
            else
            {
                Response.Write("无通知参数");
            }
        }

        /// <summary>
        /// 获取支付宝POST过来通知消息，并以“参数名=参数值”的形式组成数组
        /// </summary>
        /// <returns>request回来的信息组成的数组</returns>
        public SortedDictionary<string, string> GetRequestPost()
        {
            int i = 0;
            SortedDictionary<string, string> sArray = new SortedDictionary<string, string>();
            NameValueCollection coll;
            //Load Form variables into NameValueCollection variable.
            coll = Request.Form;

            // Get names of all forms into a string array.
            String[] requestItem = coll.AllKeys;

            for (i = 0; i < requestItem.Length; i++)
            {
                sArray.Add(requestItem[i], Request.Form[requestItem[i]]);
            }

            return sArray;
        }
    }
}
