﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Game.AppServices.api
{
    public partial class update : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Game.Utils.GameRequest.GetQueryString("ver").ToString() != "1.0.1" && IsOldVersions("1.0.1121", Game.Utils.GameRequest.GetQueryString("ver").ToString()))
            {  
                Response.End();
                return;
            }
            string name = Game.Utils.GameRequest.GetQueryString("name");
            //Response.Redirect(string.Format("~/Appupdate/res/{0}.manifest?random={1}",name,DateTime.Now.ToString("yyyyMMddHHmmssffff")));
            string fileName = "SJMJ";
            switch (Game.Utils.GameRequest.GetQueryString("gameId"))
            {
                case "918":
                    {
                        fileName = "SJMJ";
                        break;
                    }
                case "916":
                    fileName = "NMMJ";
                    break;
                case "1918":
                    fileName = "HBMJ";
                    break;
                case "801":
                    fileName = "HNMJ";
                    break;
            }
            string serverpath = Server.MapPath(string.Format("~/Upload/mobileupdate/{0}/{1}.manifest", fileName, name));
            byte[] data = null;
            if (File.Exists(serverpath))
            {
                FileStream fs = new FileStream(serverpath, FileMode.Open);
                long len = fs.Length;
                data = new byte[len];
                fs.Read(data, 0, (int)len);
                fs.Close();
            }
            Response.BinaryWrite(data);
            Response.End();
            //http://115.29.14.127:9000/Upload/mobileupdate/OxNew/version.manifest 
            //string hostaddress = System.Web.Configuration.WebConfigurationManager.AppSettings["AppDownloadtDeployurl"].ToString();
            //string httpURL = string.Format(hostaddress + @"/Upload/mobileupdate/{0}/{1}.manifest", fileName, name);
            //byte[] data = null;

            //WebClient MyWebClient = new WebClient();
            //MyWebClient.Credentials = CredentialCache.DefaultCredentials;

            //data = MyWebClient.DownloadData(httpURL);
            //if (File.Exists(serverpath))
            //{
            //    FileStream fs = new FileStream(serverpath, FileMode.Open);
            //    long len = fs.Length;
            //    data = new byte[len];
            //    fs.Read(data, 0, (int)len);
            //    fs.Close();
            ////}
            //Response.BinaryWrite(data);
            //Response.End();


        }

        private bool IsOldVersions(string oldVersion, string newVersion)
        {
            string[] oldVersions = oldVersion.Split('.');
            string[] newVersions = newVersion.Split('.');
            for (int i = 2; i < oldVersions.Length; i++)
            {
                if (Convert.ToInt32(oldVersions[i]) < Convert.ToInt32(newVersions[i]))
                    return false;
            }
            return true;
        }
    }
}