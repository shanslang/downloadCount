﻿using System;
using System.Collections.Generic;
using Game.Facade;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using ICSharpCode.SharpZipLib.Checksums;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.GZip;
using System.IO;
using System.Text;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Game.Facade.Facade;
namespace Game.AppServices.api
{
    public partial class UploadTest : System.Web.UI.Page
    {
        HttpContext context = HttpContext.Current;
        HttpRequest request = HttpContext.Current.Request;
        HttpResponse response = HttpContext.Current.Response;
        Hashtable filesMd5Hashtable = new Hashtable();
        Hashtable filesHashtable = new Hashtable();
        Hashtable versionHashtable = new Hashtable();

        protected NativeWebFacade oNativeWebFacade = new NativeWebFacade();
        protected MobileAppFacade oMobileAppFacade = new MobileAppFacade();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
#if !DEBUG
                if (RequestWebKey != oNativeWebFacade.GetUpLoadDeployKey())
                {
                    response.End();
                    return;
                }
#endif
            }
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (tbVersion.Text.Trim().Length == 0)
            {
                this.labMessage.InnerHtml = "必须填写版本号！";
                return;
            }
            if (fuFilePath.HasFile)
            {
                String filename;
                filename = fuFilePath.FileName;
                string fileExtension = System.IO.Path.GetExtension(filename);
                if (fileExtension == ".zip")
                {
                    filesMd5Hashtable.Clear();
                    filesHashtable.Clear();
                    versionHashtable.Clear();
                    NativeWebFacade oNativeWebFacade = new NativeWebFacade();
                    string timeStamp = string.Format("{0:yyyyMMddHHmmssffff}", DateTime.Now);
                    string savepath = context.Server.MapPath(string.Format("~/Upload/test/{0}/{1}/", GetGameFileName(), timeStamp));
                    filesHashtable.Add("packageUrl", hostaddress + string.Format("/Upload/mobileupdate2/{0}/", GetGameFileName()));
                    filesHashtable.Add("packageFlieName", "_" + timeStamp + ".html");
                    filesHashtable.Add("remoteManifestUrl", hostaddress + "/api/update.aspx?name=project");
                    filesHashtable.Add("remoteVersionUrl", hostaddress + "/api/update.aspx?name=version");
                    UnZipFile(fuFilePath.FileContent, savepath);
                    if (GreatDeployFiles(savepath))
                        this.labMessage.InnerHtml = "上传成功！！";
                }
                else
                    this.labMessage.InnerHtml = "必须上传zip文件！";
            }
            else
            {
                this.labMessage.InnerHtml = "必须上传zip文件！";
            }
        }

        protected void btnInstallPackUpload_Click(object sender, EventArgs e)
        {
            string strChanelID = tbChanelID.Text.Trim();
            if (strChanelID.Length == 0)
            {
                this.labInstallPackMessage.InnerHtml = "必须填写渠道号！";
                return;
            }
            if (tbEngineVersion.Text.Trim().Length == 0)
            {
                this.labInstallPackMessage.InnerHtml = "必须填写引擎版本号！";
                return;
            }
            if (tbDescription.Text.Trim().Length == 0)
            {
                this.labInstallPackMessage.InnerHtml = "必须填写游戏描述！";
                return;
            }
            if (tbUpdateInFo.Text.Trim().Length == 0)
            {
                this.labInstallPackMessage.InnerHtml = "必须填写更新公告！";
                return;
            }
            if (InstallPackFileUpload.HasFile)
            {
                String filename;
                filename = InstallPackFileUpload.FileName;
                string fileExtension = System.IO.Path.GetExtension(filename).ToLower();
                if (strChanelID != "0" && strChanelID != "1")
                {
                    if (fileExtension == ".apk")
                    {
                        NativeWebFacade oNativeWebFacade = new NativeWebFacade();
                        string timeStamp = string.Format("{0:yyyyMMddHHmmssffff}", DateTime.Now);
                        string savepath = context.Server.MapPath(string.Format("~/Upload/test/{0}_android_{1}/{2}/", GetInstallPackFileName(), strChanelID, timeStamp));
                        string downLoadPath = hostaddress + string.Format("/Upload/test/{0}_android_{1}/{2}/", GetInstallPackFileName(), strChanelID, timeStamp) + filename;
                        if (!Directory.Exists(savepath))
                            Directory.CreateDirectory(savepath);
                        InstallPackFileUpload.SaveAs(savepath + filename);
                        oMobileAppFacade.AddGameAppUrlCFG(ddlInstallPackGameId.SelectedValue.Trim(), strChanelID, downLoadPath, tbEngineVersion.Text.Trim(),
                            tbDescription.Text.Trim(), tbUpdateInFo.Text.Trim(), LoadFileMD5(savepath + filename));
                        this.labInstallPackMessage.InnerHtml = "上传成功！！";
                    }
                    else
                        this.labInstallPackMessage.InnerHtml = "必须上传apk文件！";
                }
                else
                {
                    if (fileExtension == ".ipa")
                    {
                        NativeWebFacade oNativeWebFacade = new NativeWebFacade();
                        string timeStamp = string.Format("{0:yyyyMMddHHmmssffff}", DateTime.Now);
                        string savepath = context.Server.MapPath(string.Format("~/Upload/test/{0}_apple_{1}/{2}/", GetInstallPackFileName(), strChanelID, timeStamp));
                        string downLoadPath = hostaddress + string.Format("/Upload/test/{0}_apple_{1}/{2}/", GetInstallPackFileName(), strChanelID, timeStamp) + filename;
                        if (!Directory.Exists(savepath))
                            Directory.CreateDirectory(savepath);
                        InstallPackFileUpload.SaveAs(savepath + filename);
                        oMobileAppFacade.AddGameAppUrlCFG(ddlInstallPackGameId.SelectedValue.Trim(), strChanelID, downLoadPath, tbEngineVersion.Text.Trim(),
                            tbDescription.Text.Trim(), tbUpdateInFo.Text.Trim(), LoadFileMD5(savepath + filename));
                        this.labInstallPackMessage.InnerHtml = "上传成功！！";
                    }
                    else
                        this.labInstallPackMessage.InnerHtml = "必须上传ipa文件！";
                }
            }
            else
            {
                this.labInstallPackMessage.InnerHtml = "必须上传zip文件！";
            }
        }

        private string GetGameFileName()
        {
            switch (ddlGameid.SelectedValue.Trim())
            {
                case "918":
                    return "SJMJ";
                case "9180":
                    return "NEWSJMJ";
                case "916":
                    return "NMMJ";
                case "1918":
                    return "HBMJ";
                case "801":
                    return "HNMJ";
                case "700":
                    return "BDMJ";
                default:
                    return "";
            }
        }

        private string GetInstallPackFileName()
        {
            switch (ddlInstallPackGameId.SelectedValue.Trim())
            {
                case "918":
                    return "SJMJ";
                case "9180":
                    return "NEWSJMJ";
                case "916":
                    return "NMMJ";
                case "1918":
                    return "HBMJ";
                case "801":
                    return "HNMJ";
                case "700":
                    return "BDMJ";
                default:
                    return "";
            }
        }

        private bool GreatDeployFiles(string savepath)
        {
            string dataFile = ReadFile(savepath + "version.ini");
            string[] strDatas = ReadFile(savepath + "version.ini").Split(new char[] { ';', '；' });
            if (strDatas.Length == 3)
            {
                string[] strs = strDatas[0].Split(new char[] { '=', '=' });
                if (strs.Length != 2)
                {
                    this.labMessage.InnerHtml = "version.ini文件格式错误！";
                    return false;
                }
                string strGameid = strs[1].ToString().Trim();
                //判断游戏Id
                if (ddlGameid.SelectedValue.Trim() != strGameid && ddlGameid.SelectedValue != "9180")
                {
                    this.labMessage.InnerHtml = "选择的游戏与version.ini文件配置的游戏不匹配！";
                    return false;
                }

                strs = strDatas[1].Split(new char[] { '=', '=' });
                if (strs.Length != 2)
                {
                    this.labMessage.InnerHtml = "version.ini文件格式错误！";
                    return false;
                }
                string strVer = strs[1].ToString().Trim();
                //判断版本号 
                if (tbVersion.Text.Trim() != strVer)
                {
                    this.labMessage.InnerHtml = "填写的版本号与发布包的版本号不一致！";
                    return false;
                }

                strs = strDatas[2].Split(new char[] { '=', '=' });
                if (strs.Length != 2)
                {
                    this.labMessage.InnerHtml = "version.ini文件格式错误！";
                    return false;
                }
                string restartFlag = strs[1].ToString().Trim();
                //判断版本号 
                //if (tbVersion.Text.Trim() != strVer)
                //{
                //    this.labMessage.InnerHtml = "填写的版本号与发布包的版本号不一致！";
                //    return false;
                //}


                string path = context.Server.MapPath(string.Format("~/Upload/test/{0}/", GetGameFileName()));
                string oldVersion = ReadJson(path + "/version.manifest", "version");
                //if (oldVersion != string.Empty && IsOldVersions(oldVersion, strVer))
                //{
                //    this.labMessage.InnerHtml = "发布包的版本号不是最新的！";
                //    return false;
                //}
                filesHashtable.Add("version", strVer);
                filesHashtable.Add("engineVersion", "3.0");
                filesHashtable.Add("restartFlag", restartFlag);
                WriteFile(path + "version.manifest");
                filesHashtable.Add("assets", filesMd5Hashtable);
                WriteFile(path + "project.manifest");
                return true;
            }
            else
            {
                this.labMessage.InnerHtml = "version.ini文件格式错误！";
                return false;
            }
        }

        private bool IsOldVersions(string oldVersion, string newVersion)
        {
            string[] oldVersions = oldVersion.Split('.');
            string[] newVersions = newVersion.Split('.');
            for (int i = 0; i < oldVersions.Length; i++)
            {
                if (Convert.ToInt32(oldVersions[i]) < Convert.ToInt32(newVersions[i]))
                    return false;
            }
            return true;
        }

        private void WriteFile(string savepath)
        {
            if (File.Exists(savepath))
            {
                File.Delete(savepath);
            }
            FileStream fs = new FileStream(savepath, FileMode.Create);
            //获得字节数组
            byte[] data = System.Text.Encoding.Default.GetBytes(new JavaScriptSerializer().Serialize(filesHashtable));
            //开始写入
            fs.Write(data, 0, data.Length);
            //清空缓冲区、关闭流
            fs.Flush();
            fs.Close();
        }

        /// <summary>
        /// 获取文件MD5
        /// </summary>
        /// <returns></returns>
        private string LoadFileMD5(string filepath)
        {
            try
            {
                if (File.Exists(filepath))
                {
                    FileStream file = new FileStream(filepath, System.IO.FileMode.Open);
                    System.Security.Cryptography.MD5 md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
                    byte[] retVal = md5.ComputeHash(file);
                    file.Close();
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < retVal.Length; i++)
                    {
                        sb.Append(retVal[i].ToString("X2"));
                    }
                    return sb.ToString();
                }
                return "";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private string ReadFile(string filePath)
        {
            if (File.Exists(filePath))
            {
                StreamReader sr = new StreamReader(filePath, Encoding.Default);
                string result = sr.ReadToEnd();
                sr.Close();
                return result;
            }
            else
                return string.Empty;
        }

        private string ReadJson(string filePath, string strKey)
        {
            string jsonText = ReadFile(filePath);
            if (jsonText != string.Empty)
            {
                bool isKey = false;
                JsonReader reader = new JsonTextReader(new StringReader(jsonText));
                while (reader.Read())
                {
                    if (isKey)
                        return reader.Value.ToString().Trim();
                    if (reader.Value != null && reader.Value.ToString() == strKey)
                        isKey = true;
                }
            }
            return "";
        }

        private string hostaddress
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["AppDownloadtDeployurl"].ToString();
            }
        }

        #region 解压
        private void UnZipFile(Stream zipFileStream, string savepath)
        {
            using (ZipInputStream s = new ZipInputStream(zipFileStream))
            {
                ZipEntry theEntry;
                while ((theEntry = s.GetNextEntry()) != null)
                {
                    Console.WriteLine(theEntry.Name);
                    string directoryName = Path.GetDirectoryName(theEntry.Name);
                    string fileName = Path.GetFileName(theEntry.Name);

                    // create directory
                    Directory.CreateDirectory(savepath + directoryName);
                    string newPath = theEntry.Name == "version.ini" ? savepath + theEntry.Name : savepath + theEntry.Name + ".dat";
                    if (fileName != String.Empty)
                    {
                        using (FileStream streamWriter = File.Create(newPath))
                        {
                            int size = 2048;
                            byte[] data = new byte[2048];
                            while (true)
                            {
                                size = s.Read(data, 0, data.Length);
                                if (size > 0)
                                {
                                    streamWriter.Write(data, 0, size);
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                        if (theEntry.Name != "version.ini")
                        {
                            if (!theEntry.Name.Contains("/_") && !theEntry.Name.Contains("/.") && theEntry.Name.Substring(0, 1) != "." && theEntry.Name.Substring(0, 1) != "_")
                            {
                                Hashtable tem = new Hashtable();
                                tem.Add("md5", LoadFileMD5(savepath + theEntry.Name + ".dat"));
                                filesMd5Hashtable.Add(theEntry.Name, tem);
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region 参数设置
        /// <summary>
        /// 登录WebKey
        /// </summary>
        protected string RequestWebKey
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryString("webkey");
            }
        }

        /// <summary>
        /// 返回数据包对象
        /// </summary>
        private object _ResponsePackage = null;
        public object ResponsePackage
        {
            get
            {
                return this._ResponsePackage;
            }
            set
            {
                this._ResponsePackage = value;
            }
        }

        /// <summary>
        /// 返回数据格式 
        /// </summary>
        private BaseMobileHandlerResponseFormat _ResponseDataFormat = BaseMobileHandlerResponseFormat.JSONObject;
        public BaseMobileHandlerResponseFormat ResponseDataFormat
        {
            get { return _ResponseDataFormat; }
            set { _ResponseDataFormat = value; }
        }
        /// <summary>
        /// 返回数据格式
        /// </summary>
        public enum BaseMobileHandlerResponseFormat
        {
            JSON = 1,
            JSONObject = 2,
            XML = 3,
            Binary = 4,
            Text = 5,
        }
        #endregion

    }
}