﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Game.AppServices.api
{
    public partial class downloadmanifest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
#if !DEBUG
                if (Request["key"] != Constant.APIKey)
                {
                    Response.End();
                    return;
                }
#endif          
                WebClient client = new WebClient();
                var downurl = Request["downurl"];
                var path = Request["path"];
                if (downurl != null)
                {
                    if (!Directory.Exists(Server.MapPath(path)))
                        Directory.CreateDirectory(Server.MapPath(path));
                    client.DownloadFile(new Uri(downurl + "project.manifest"), Server.MapPath(path + "project.manifest"));
                    client.DownloadFile(new Uri(downurl + "version.manifest"), Server.MapPath(path + "version.manifest"));
                }
                Response.Write("1");
                Response.End();
            }
        }
    }
}