﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Game.Entity.MobileApp;

namespace Game.AppServices.api
{
    public partial class newmshare : Game.Facade.BasePageMobile
    {
        public GameInfo oGameInfo = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            PageDataBind();
        }

        private void PageDataBind()
        {
            //初始化渠道
            //渠道id
            //#define CHANEL_IOS_APPSTORE         0   //ios AppStore 渠道
            //#define CHANEL_IOS_BREAKOUT         1   //ios越狱 渠道
            //#define CHANEL_ANDROID_OFFICIAL     2   //android官方渠道（百度外卖 － 支付宝）
            //#define CHANEL_ANDROID_360          3   //android360渠道
            //#define CHANEL_ANDROID_UNICOM       4   //android联通渠道
            //#define CHANEL_ANDROID_UNICOM4GCOOPERATION 5   //android联通4g合作渠道（推广使用）
            #region 新的ios商店下载和注册
            if (this.ChanelID == 3)
            {
                Response.Redirect("/page/register/newregister.aspx?gameid=" + GameID, true);
            }
            #endregion
            IList<ChanelQR> listChanelQR = new List<ChanelQR>();
            if (this.ChanelID == 0)
            {
                listChanelQR.Add(new ChanelQR() { GameID = 378, ChanelID = 0, DownUrl = "https://itunes.apple.com/cn/app/xue-liu/id819065969?mt=8" });
                listChanelQR.Add(new ChanelQR() { GameID = 6, ChanelID = 0, DownUrl = "https://itunes.apple.com/cn/app/huo-pin-ying-san-zhang/id795536166?mt=8" });
                listChanelQR.Add(new ChanelQR() { GameID = 27, ChanelID = 0, DownUrl = "https://itunes.apple.com/cn/app/huo-pin-dou-niu/id881710014?mt=8" });
                listChanelQR.Add(new ChanelQR() { GameID = 122, ChanelID = 0, DownUrl = "https://itunes.apple.com/us/app/bai-jia-le-le-fan-tian/id793756816?l=zh&ls=1&mt=8" });
                listChanelQR.Add(new ChanelQR() { GameID = 200, ChanelID = 0, DownUrl = "https://itunes.apple.com/cn/app/da-jia-le-dou-de-zhu/id875224304?mt=8" });
            }
            else if (this.ChanelID > 0)
            {
                Game.Facade.Facade.MobileAppFacade oMobileAppFacade = new Facade.Facade.MobileAppFacade();
                GameAppUrlCFG oGameAppUrlCFG = oMobileAppFacade.GetGameAppUrlCFG(this.GameID, this.ChanelID);
                if (oGameAppUrlCFG != null)
                {
                    listChanelQR.Add(new ChanelQR() { GameID = oGameAppUrlCFG.GameID, ChanelID = oGameAppUrlCFG.ChanelID, DownUrl = oGameAppUrlCFG.AppURL });
                }
            }

            //初始化游戏
            IList<GameInfo> listGameInfo = new List<GameInfo>();
            listGameInfo.Add(new GameInfo() { GameID = 378, GameName = "血流麻将", LogoUrl = "/images/mshare/血流_Icon.jpg", DownCount = 38491 });
            listGameInfo.Add(new GameInfo() { GameID = 6, GameName = "火拼赢三张", LogoUrl = "/images/mshare/火拼赢三张_Icon.jpg", DownCount = 9316 });
            listGameInfo.Add(new GameInfo() { GameID = 27, GameName = "火拼斗牛", LogoUrl = "/images/mshare/火拼斗牛_Icon.jpg", DownCount = 16803 });
            listGameInfo.Add(new GameInfo() { GameID = 122, GameName = "百家乐", LogoUrl = "/images/mshare/百家乐.png", DownCount = 3692 });
            listGameInfo.Add(new GameInfo() { GameID = 200, GameName = "斗地主", LogoUrl = "/images/mshare/斗地主.png", DownCount = 7321 });
            //根据chanelid确定二维码
            foreach (GameInfo item in listGameInfo)
            {
                var oChanelQR = listChanelQR.Where(d => d.GameID == item.GameID && d.ChanelID == this.ChanelID).FirstOrDefault();
                if (oChanelQR != null)
                {
                    item.QrCodeUrl = "http://www.8633.com/qrcode?" + oChanelQR.DownUrl;
                    item.DownUrl = oChanelQR.DownUrl;
                }
            }
            //当前游戏
            oGameInfo = listGameInfo.Where(d => d.GameID == this.GameID).FirstOrDefault();
            if (oGameInfo == null) throw new Exception("无效的游戏ID");
            //移除
            listGameInfo.Remove(oGameInfo);
            //绑定
            this.repList.DataSource = listGameInfo;
            this.repList.DataBind();
        }

        #region 属性
        /// <summary>
        /// 游戏ID， 378 - 血流  6 - 赢三张  27  -牛牛
        /// </summary>
        public int GameID
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryInt("gameid", 0);
            }
        }
        /// <summary>
        /// chanelid： 
        /// CHANEL_IOS_APPSTORE         0   //ios AppStore 渠道
        /// CHANEL_IOS_BREAKOUT         1   //ios越狱 渠道
        /// CHANEL_ANDROID_OFFICIAL     2   //android官方渠道
        /// CHANEL_ANDROID_360          3   //android360渠道
        /// CHANEL_ANDROID_UNICOM       4   //android联通渠道
        /// </summary>
        public int ChanelID
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryInt("chanelid", 0);
            }
        }
        #endregion

        #region 模型
        /// <summary>
        /// 游戏信息
        /// </summary>
        public class GameInfo
        {
            public int GameID { set; get; }
            public string GameName { set; get; }
            public string QrCodeUrl { set; get; }
            public string DownUrl { set; get; }
            public string LogoUrl { set; get; }
            public int DownCount { set; get; }
        }

        /// <summary>
        /// 渠道二维码信息
        /// </summary>
        public class ChanelQR
        {
            public int GameID { set; get; }
            public int ChanelID { set; get; }
            public string DownUrl { set; get; }
        }
        #endregion
    }
}