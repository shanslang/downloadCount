﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Game.Facade.Facade;

namespace Game.AppServices.api
{
    public partial class updatetemp : System.Web.UI.Page
    {
        protected MobileAppFacade oMobileAppFacade = new MobileAppFacade();

        protected void Page_Load(object sender, EventArgs e)
        {
            string name = Game.Utils.GameRequest.GetQueryString("name");
            string gameId = Game.Utils.GameRequest.GetQueryString("gameId");
            //DataSet ds = oMobileAppFacade.GetAppVerfilterList(gameId, Game.Utils.GameRequest.GetQueryString("ver"));
            //if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            //{
            //    Response.End();
            //    return;
            //} 
            string fileName = "SJMJ";
            switch (gameId)
            {
                case "918":
                    {
                        fileName = "SJMJ";
                        break;
                    }
                case "916":
                    fileName = "NMMJ";
                    break;
                case "1918":
                    fileName = "HBMJ";
                    break;
                case "801":
                    fileName = "HNMJ";
                    break;
            }
            string serverpath = Server.MapPath(string.Format("~/Upload/mobileupdatetemp/{0}/{1}.manifest", fileName, name));
            //string path = Server.MapPath("~/App_Data/testip.config");
            //if (File.Exists(path))
            //{
            //    try
            //    {
            //        var listip = SerializationHelper.Deserialize(typeof(List<string>), path) as List<string>;
            //        if (listip.Contains(GameRequest.GetUserIP()))
            //        {
            //            var testpath = Server.MapPath(string.Format("~/Upload/mobileupdatetest/{0}/{1}.manifest", fileName, name));
            //            if (File.Exists(testpath))
            //            {
            //                serverpath = testpath;
            //            }
            //        }
            //    }
            //    catch (Exception)
            //    {

            //    }
            //}
            byte[] data = null;
            if (File.Exists(serverpath))
            {
                FileStream fs = new FileStream(serverpath, FileMode.Open);
                long len = fs.Length;
                data = new byte[len];
                fs.Read(data, 0, (int)len);
                fs.Close();
            }
            Response.BinaryWrite(data);
            Response.End();
        }

        private bool IsOldVersions(string oldVersion, string newVersion)
        {
            string[] oldVersions = oldVersion.Split('.');
            string[] newVersions = newVersion.Split('.');
            for (int i = 2; i < oldVersions.Length; i++)
            {
                if (Convert.ToInt32(oldVersions[i]) < Convert.ToInt32(newVersions[i]))
                    return false;
            }
            return true;
        }
    }
}