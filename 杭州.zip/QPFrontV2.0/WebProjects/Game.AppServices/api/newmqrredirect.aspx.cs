﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Game.AppServices.api
{
    public partial class newmqrredirect : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 游戏ID
        /// </summary>
        protected int GameID
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryInt("gameid", 0);
            }
        }
        /// <summary>
        /// 类型Code  如百度，联通
        /// </summary>
        protected int Code
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryInt("code", 0);
            }
        }
    }
}