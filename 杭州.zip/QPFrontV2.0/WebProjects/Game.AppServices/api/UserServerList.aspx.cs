﻿using Game.Entity.MobileApp;
using Game.Facade.Facade;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Game.AppServices.api
{
    public partial class UserServerList : System.Web.UI.Page
    {
        protected MobileAppFacade oMobileAppFacade = new MobileAppFacade();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request["q"]==null||Request["q"].ToString()!= "f4edea11366d64097260b0c26733bd2e")
                {
                    Response.Write("");
                    Response.End();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int userid = 0;
            int.TryParse(txtuserID.Text, out userid);
            IList<AppServerAddressCFG> datalist = oMobileAppFacade.GetLogonServerAddress(0, userid);  //登陆服务器地址
            if (datalist != null && datalist.Count > 0)
            {
                var generalServer = datalist.Where(n => n.IsDefense == 0).ToList();
                var defenseServer = datalist.Where(n => n.IsDefense == 1).ToList();
                int num = userid / Constant.UserGroup;
                string server = string.Empty;
                if (generalServer.Count > 0)
                {
                    server += generalServer[num % generalServer.Count].LogonServerAddress.ToString()+ "|";
                }
                if (defenseServer.Count > 0)
                {
                    server += defenseServer[num % defenseServer.Count].LogonServerAddress.ToString() + "|";
                }
                txtServer.Text = server;
            }
        }
    }
}