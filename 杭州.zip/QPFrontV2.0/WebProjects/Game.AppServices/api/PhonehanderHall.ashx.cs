﻿using Game.Entity.MobileApp;
using Game.Type;
using Game.Web;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Text;
using Game.Entity.Accounts;
using Game.Francis;
using System.Data;
using Game.Entity.Task;
using System.Xml.Serialization;
using Newtonsoft.Json;
using Game.Utils;
using System.Net;


namespace Game.AppServices.api
{
    /// <summary>
    /// PhonehanderHall 的摘要说明
    /// </summary>
    public class PhonehanderHall : BaseMobileHandler
    {
        Game.Facade.NativeWebFacade nativeWebFacade = new Facade.NativeWebFacade();

        #region 获取大厅地址
        [MobileMethod(RequestCMD = "1001")]
        public void ThehallAddress(string sign, string data)
        {
#if !DEBUG
            this.ValidateSign(sign, data);
#endif
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            int Version = Convert.ToInt32(requestparms["version"]);    //版本号(根据此版本号获取接口地址)
            Hashtable hashtable = new Hashtable();
            #region 判断是指定机器码，是就返回内网服务器地址
            if (requestparms.Keys.Contains("machineid"))
            {
                string machpath = HttpContext.Current.Server.MapPath("~/App_Data/loginmachineid.config");
                if (File.Exists(machpath))
                {
                    try
                    {
                        var listip = SerializationHelper.Deserialize(typeof(List<string>), machpath) as List<string>;
                        if (listip.Contains(requestparms["machineid"].ToString()))
                        {
                            Version = 888;
                        }
                    }
                    catch (Exception)
                    {

                    }
                }
            }

            #endregion
            int userid = Convert.ToInt32(requestparms["userid"]);
            IList<AppServerAddressCFG> datalist = oMobileAppFacade.GetLogonServerAddress(Version, userid);  //登陆服务器地址
            AppVisitAddressCFG datainfo = oMobileAppFacade.GetAppVisitAddress(Version);  //接口访问地址

            if (datalist == null || datalist.Count == 0 || datainfo == null) { this.SetResponseData(false, "版本信息不存在！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取大厅登录地址完成, hashtable); return; }

            string http_web_url = datainfo.Appweb_url;                 //接口请求地址
            string AppFileRec = datainfo.AppFileRec;                   //图片上传地址

            List<Hashtable> serveraddlist = new List<Hashtable>();
            if (datalist != null && datalist.Count > 0)
            {
                if (Constant.UserIDList.Contains(userid.ToString()))
                {
                    Hashtable HsserverList = new Hashtable();
                    HsserverList.Add("serveradd", Constant.ServerIP);
                    HsserverList.Add("serverport", Constant.ServerPort);
                    HsserverList.Add("isdefenserver", 1);
                    serveraddlist.Add(HsserverList);
                }
                else
                {
                    var generalServer = datalist.Where(n => n.IsDefense == 0).ToList();
                    var defenseServer = datalist.Where(n => n.IsDefense == 1).ToList();
                    int num = userid / Constant.UserGroup;
                    if (generalServer.Count > 0)
                    {
                        Hashtable HsserverList = new Hashtable();
                        HsserverList.Add("serveradd", generalServer[num % generalServer.Count].LogonServerAddress.ToString());
                        HsserverList.Add("serverport", generalServer[num % generalServer.Count].LogonServerPort.ToString());
                        HsserverList.Add("isdefenserver", 0);
                        serveraddlist.Add(HsserverList);
                    }
                    if (defenseServer.Count > 0)
                    {
                        Hashtable HsserverList = new Hashtable();
                        HsserverList.Add("serveradd", defenseServer[num % defenseServer.Count].LogonServerAddress.ToString());
                        HsserverList.Add("serverport", defenseServer[num % defenseServer.Count].LogonServerPort.ToString());
                        HsserverList.Add("isdefenserver", 1);
                        serveraddlist.Add(HsserverList);
                    }
                }
            }
            int gameid = 918;
            switch (gameid)
            {
                case 918:
                    hashtable.Add("http_web_url", http_web_url + "/sj/");
                    hashtable.Add("shareUrl", http_web_url + "/down/sj.html");
                    break;
                default:
                    hashtable.Add("http_web_url", http_web_url + "/sj/");
                    hashtable.Add("shareUrl", http_web_url + "/down/sj.html");
                    break;
            }
            hashtable.Add("imgurl", http_web_url);
            hashtable.Add("serveraddlist", serveraddlist);
            this.SetResponseData(true, "", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取大厅登录地址完成, hashtable);
        }

        #endregion
        #region 获取版本信息
        [MobileMethod(RequestCMD = "1047")]
        public void GetAppVersion(string sign, string data)
        {
#if !DEBUG
            this.ValidateSign(sign, data);
#endif

            Dictionary<string, object> requestparms = FormatRequestData(data);
            Hashtable hashtable = new Hashtable();
            if (requestparms.ContainsKey("gameid"))
            {
                string gameID = requestparms["gameid"].ToString();
                string fileName = "SJMJ";
                switch (gameID)
                {
                    case "918":
                        {
                            fileName = "SJMJ";
                            break;
                        }
                    case "916":
                        {
                            fileName = "NMMJ";
                            break;
                        }
                    case "1918":
                        {
                            fileName = "HBMJ";
                            break;
                        }
                }
                string serverpath = HttpContext.Current.Server.MapPath(string.Format("~/Upload/mobileupdate2/{0}", fileName));
                if (requestparms.Keys.Contains("machineid"))
                {
                    string path = HttpContext.Current.Server.MapPath("~/App_Data/testmachineid.config");
                    if (File.Exists(path))
                    {
                        try
                        {
                            var listip = SerializationHelper.Deserialize(typeof(List<string>), path) as List<string>;
                            if (listip.Contains(requestparms["machineid"].ToString()))
                            {
                                var testpath = HttpContext.Current.Server.MapPath(string.Format("~/Upload/mobileupdatetest/{0}", fileName));
                                if (Directory.Exists(testpath))
                                {
                                    serverpath = testpath;
                                }
                            }
                        }
                        catch (Exception)
                        {

                        }
                    }
                }

                DirectoryInfo dir = new DirectoryInfo(serverpath);
                List<DirectoryInfo> list = new List<DirectoryInfo>(dir.GetDirectories());
                if (list.Count > 0)
                {
                    list.Sort(new Comparison<DirectoryInfo>((a, b) =>
                    {

                        return b.CreationTime.CompareTo(a.CreationTime);

                    }));
                    if (File.Exists(list[0].FullName + "/version.ini"))
                    {
                        string[] attritem = File.ReadAllText(list[0].FullName + "/version.ini").Trim().Split(';');
                        foreach (var item in attritem)
                        {
                            string[] sitem = item.Split('=');
                            hashtable.Add(sitem[0], sitem[1]);
                        }
                        this.SetResponseData(true, "获取版本成功！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取版本信息成功, hashtable);
                        return;
                    }

                }
                this.SetResponseData(false, "获取失败！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取版本信息成功, hashtable);

            }
            else
            {
                this.SetResponseData(false, "参数错误！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取版本信息成功, hashtable);
            }
        }
        #endregion
        #region 获取热更新地址

        [MobileMethod(RequestCMD = "1031")]
        public void AppUpdateAddress(string sign, string data)
        {
#if !DEBUG
            this.ValidateSign(sign, data);
#endif
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int Version = Convert.ToInt32(requestparms["version"]);    //版本号(根据此版本号获取接口地址)

            Hashtable hashtable = new Hashtable();

            if (requestparms.ContainsKey("gameid"))
            {
                int GameID = Convert.ToInt32(requestparms["gameid"]);
                if (GameID == 916)
                {
                    HttpContext.Current.Response.Redirect(string.Format("http://nmapp.sanjinmajiang.com//hall/1031?sign={0}&data={1}", sign, data));
                }
                DataSet ds = oMobileAppFacade.GetAppVerfilterList(GameID.ToString(), Version.ToString());
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    this.SetResponseData(false, "版本信息不存在！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取大厅登录地址完成, hashtable);
                    return;
                }
            }
            AppVisitAddressCFG datainfo = oMobileAppFacade.GetAppVisitAddress(Version);  //接口访问地址 
            if (datainfo == null)
            {
                this.SetResponseData(false, "版本信息不存在！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取大厅登录地址完成, hashtable);
                return;
            }
            string updateurl = "update2.aspx";
            if (requestparms.Keys.Contains("machineid"))
            {
                string path = HttpContext.Current.Server.MapPath("~/App_Data/testmachineid.config");
                if (File.Exists(path))
                {
                    try
                    {
                        var listip = SerializationHelper.Deserialize(typeof(List<string>), path) as List<string>;
                        if (listip.Contains(requestparms["machineid"].ToString()))
                        {
                            if (GetstringValue(requestparms, "isFightVerison").ToLower() == "true")
                            {
                                updateurl = "updateBattlettest.aspx";
                            }
                            else
                            {
                                updateurl = "update3.aspx";
                            }
                        }
                    }
                    catch (Exception)
                    {

                    }
                }
            }
            if (updateurl != "update2.aspx")
            {
                hashtable.Add("app_update_url", datainfo.AppUpdate_url.ToLower().Replace("update.aspx", updateurl));
            }
            else
            {
                if (GetstringValue(requestparms, "isFightVerison").ToLower() == "true")
                {
                    hashtable.Add("app_update_url", datainfo.AppUpdate_url.ToLower().Replace("update.aspx", "updateBattlet.aspx"));
                }
                else
                {
                    if (GetIntValue(requestparms, "devicetype") > 16 && GetIntValue(requestparms, "gameid") == 918 && Version != 888 && Version != 889)
                    {
                        hashtable.Add("app_update_url", datainfo.AppUpdate_url.ToLower().Replace("update.aspx", "updatetemp.aspx"));
                    }
                    else
                    {
                        if (GetIntValue(requestparms, "gameid") == 200 && GetIntValue(requestparms, "kernelVersion") < 7)
                        {
                            hashtable.Add("app_update_url", "");
                        }
                        else
                            if (GetIntValue(requestparms, "kernelVersion") == 7 && GetIntValue(requestparms, "gameid") == 918)
                        {
                            hashtable.Add("app_update_url", datainfo.AppUpdate_url.ToLower().Replace("update.aspx", "updateBattlet.aspx"));
                        }
                        else
                        {
                            hashtable.Add("app_update_url", datainfo.AppUpdate_url.ToLower().Replace("update.aspx", updateurl));
                        }
                    }
                }
            }
            hashtable.Add("isenble", datainfo.IsEnble);
            hashtable.Add("http_web_url", datainfo.Appweb_url);
            this.SetResponseData(true, "", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取熱更新地址完成, hashtable);

        }
        #endregion

        #region 手游日志

        [MobileMethod(RequestCMD = "1032")]
        public void AppLog(string sign, string data)
        {
            this.ValidateSign(sign, data);
            try
            {
                byte[] bpath = Convert.FromBase64String(data);
                data = System.Text.ASCIIEncoding.Default.GetString(bpath);
                Dictionary<string, object> requestparms = FormatRequestData(data);
                string userid = requestparms["userid"].ToString();
                string devicetype = requestparms["devicetype"].ToString();
                string version = requestparms["version"].ToString();
                string gameid = requestparms["gameid"].ToString();
                string logdata = requestparms["logdata"].ToString();
                //测试用
                //string userid = HttpContext.Current.Request["userid"].ToString();
                //string devicetype = HttpContext.Current.Request["devicetype"].ToString();
                //string version = HttpContext.Current.Request["version"].ToString();
                //string gameid = HttpContext.Current.Request["gameid"].ToString();
                //string logdata = HttpContext.Current.Request["logdata"].ToString();

                //string savepath = HttpContext.Current.Server.MapPath(string.Format("~/Upload/AppLog/{0}/{1}", gameid, version));

                //if (Directory.Exists(savepath) == false)//如果不存在就创建file文件夹 
                //    Directory.CreateDirectory(savepath);
                if (userid == null || userid == "" || userid.Contains(':'))
                {
                    Library.Log.WriteLogInfo("上传日志错误", new Exception(userid));
                    userid = "0";
                }
                string strMessage = "userid:" + userid + ";devicetype:" + devicetype + ";version:" + version + ";gameid:" + gameid + "\r\n";
                strMessage += "logdata:" + logdata.Replace("::", "::\r\n");
                // Game.Library.Log.WriteLogInfo("手游：" + gameid + "客服端日志", new Exception(strMessage));
                if (requestparms.ContainsKey("codeVersion"))
                {
                    Game.Library.Log.WriteLogInfo("手游：" + gameid + "客服端日志\\" + DateTime.Now.ToString("yyyy-MM-dd") + "\\" + userid + "-" + requestparms["codeVersion"].ToString().Replace('.', '_'), new Exception(strMessage));
                }
                else
                {
                    Game.Library.Log.WriteLogInfo("手游：" + gameid + "客服端日志\\" + DateTime.Now.ToString("yyyy-MM-dd") + "\\" + userid, new Exception(strMessage));
                }
                //向txt里面追加信息
                //StreamWriter sw = new StreamWriter(savepath + "/" + userid + ".txt", true, Encoding.GetEncoding("gb2312"));
                //sw.WriteLine(strMessage);
                //sw.Flush();
                //sw.Close(); 
            }
            catch (Exception e)
            {
                Game.Library.Log.WriteLogInfo("上传日志错误", e);
            }
            Hashtable hashtable = new Hashtable();
            this.SetResponseData(true, "", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.记录手游日志完成, hashtable);

        }


        #endregion

        #region 获取引擎号和地址

        [MobileMethod(RequestCMD = "1035")]
        public void AppEngineAddress(string sign, string data)
        {
            this.ValidateSign(sign, data);
            Dictionary<string, object> requestparms = FormatRequestData(data);

            Hashtable hashtable = new Hashtable();
            if (requestparms.ContainsKey("gameid") && requestparms.ContainsKey("chanelid"))
            {
                if (requestparms["gameid"].ToString() == "916")
                {
                    HttpContext.Current.Response.Redirect(string.Format("http://nmapp.sanjinmajiang.com//hall/1035?sign={0}&data={1}", sign, data));
                }
                DataSet ds = oMobileAppFacade.GetGameAppUrlCFG(Convert.ToInt32(requestparms["gameid"]), Convert.ToInt32(requestparms["chanelid"]), -1);

                string appUrl = string.Empty;
                string engineVersion = string.Empty;
                string updateInFo = string.Empty;
                string apkMD5 = string.Empty;
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    appUrl = ds.Tables[0].Rows[0]["AppURL"].ToString();
                    engineVersion = ds.Tables[0].Rows[0]["EngineVersion"].ToString();
                    if (ds.Tables[0].Rows[0]["UpdateInFo"] != null)
                        updateInFo = ds.Tables[0].Rows[0]["UpdateInFo"].ToString();
                    if (ds.Tables[0].Rows[0]["ApkMD5"] != null)
                        apkMD5 = ds.Tables[0].Rows[0]["ApkMD5"].ToString();
                    hashtable.Add("app_url", appUrl);
                    hashtable.Add("engine_version", engineVersion);
                    hashtable.Add("update_info", updateInFo);
                    hashtable.Add("apk_md5", apkMD5);
                }
            }
            this.SetResponseData(true, "", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取引起号和地址, hashtable);

        }
        #endregion

        #region 兑换CDK
        [MobileMethod(RequestCMD = "1033")]
        public void UserSign(string sign, string data)
        {
            HttpRequest request = HttpContext.Current.Request;
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int UserID = Convert.ToInt32(requestparms["userid"]);
            string packagecdkey = requestparms["packagecdkey"].ToString().Trim();
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            UserInfo oUserInfo = this.ValidateSign(Devicetype, UserID, sign, data);
            int sprederid = 0;
            if (oUserInfo.SpreaderID != 0)
            {
                var spreader = oAccountsFacade.GetUserFullInfoByUserID(oUserInfo.SpreaderID);
                sprederid = spreader.GameID;
            }
            Message msg = nativeWebFacade.ConvertPackageCDKey(UserID, packagecdkey, sprederid);
            string returnMess = msg.Content;
            if (msg.Success)
            {
                string result = "兑换成功！恭喜您获得：";
                DataTable dt = (msg.EntityList[0] as DataSet).Tables[1];
                foreach (DataRow item in dt.Rows)
                {
                    result += "[" + item["Name"] + "]x" + item["Number"] + "，";
                }
                returnMess = result.Trim('，') + "。";
            }
            SetResponseData(msg.Success, returnMess, ValidateResponseKey(Devicetype, UserID, 1), (int)WEBRESULT_CMD_TYPE.兑换CDK完成, 1);
        }
        #endregion

        #region 绑定推广员
        [MobileMethod(RequestCMD = "1038")]
        public void BindSpread(string sign, string data)
        {
            HttpRequest request = HttpContext.Current.Request;
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int UserID = Convert.ToInt32(requestparms["userid"]);
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            int SpreadGameID = Convert.ToInt32(requestparms["spreadgameid"]);
            UserInfo oUserInfo = this.ValidateSign(Devicetype, UserID, sign, data);

            Message msg = nativeWebFacade.BindSpread(UserID, SpreadGameID);
            if (msg.Success)
            {
                SetResponseData(true, msg.Content, ValidateResponseKey(Devicetype, UserID, 0), (int)WEBRESULT_CMD_TYPE.推广员绑定, 0);
            }
            else
            {
                SetResponseData(false, msg.Content, ValidateResponseKey(Devicetype, UserID, 0), (int)WEBRESULT_CMD_TYPE.推广员绑定, 0);
            }
        }
        #endregion

        #region 新版任务系统
        /// <summary>
        /// 新版任务系统
        /// </summary>
        [MobileMethod(RequestCMD = "1041")]
        public void GetNTaskInfo(string sign, string data)
        {
            HttpRequest request = HttpContext.Current.Request;
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int UserID = Convert.ToInt32(requestparms["userid"]);
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            int TaskID = Convert.ToInt32(requestparms["taskid"]);
#if !DEBUG
            UserInfo oUserInfo = this.ValidateSign(Devicetype, UserID, sign, data);
#endif
            var oTaskInfo = oTaskFacade.GetNTaskInfoByTaskIDForMobile(TaskID);
            if (oTaskInfo != null)
            {
                NTaskInfoXml oNTaskInfoXml = new NTaskInfoXml();
                oNTaskInfoXml.TaskId = oTaskInfo.TaskId;
                oNTaskInfoXml.TaskInfoKey = oTaskInfo.TaskInfoKey;
                oNTaskInfoXml.TaskName = oTaskInfo.TaskName;
                oNTaskInfoXml.TaskDesc = oTaskInfo.TaskDesc;
                oNTaskInfoXml.TaskIcon = oTaskInfo.TaskIcon;
                oNTaskInfoXml.TaskSort = oTaskInfo.TaskSort;
                oNTaskInfoXml.TaskGroup = oTaskInfo.TaskGroup;
                oNTaskInfoXml.TaskMask = oTaskInfo.TaskMask;
                oNTaskInfoXml.TaskNextId = oTaskInfo.TaskNextId;
                oNTaskInfoXml.ListNTaskReward = oTaskInfo.ListNTaskReward != null ? oTaskInfo.ListNTaskReward.ToList() : null;
                if (oNTaskInfoXml.ListNTaskReward == null) oNTaskInfoXml.ListNTaskReward = new List<NTaskReward>();
                SetResponseData(true, "获取数据成功！", ValidateResponseKey(Devicetype, UserID, oNTaskInfoXml), (int)WEBRESULT_CMD_TYPE.新版任务系统TaskInfo, oNTaskInfoXml);
            }
            else
            {
                SetResponseData(false, "任务信息不存在！", ValidateResponseKey(Devicetype, UserID, 0), (int)WEBRESULT_CMD_TYPE.新版任务系统TaskInfo, 0);
            }
        }
        /// <summary>
        /// 新版任务系统
        /// </summary>
        [MobileMethod(RequestCMD = "1042")]
        public void GetNTaskGroupInfo(string sign, string data)
        {
            HttpRequest request = HttpContext.Current.Request;
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int UserID = Convert.ToInt32(requestparms["userid"]);
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            UserInfo oUserInfo = this.ValidateSign(Devicetype, UserID, sign, data);

            IList<NTaskGroupInfo> listNTaskGroupInfo = oTaskFacade.GetNTaskGroupInfoList();
            if (listNTaskGroupInfo != null)
            {
                NTaskGroupInfoXml oNTaskGroupInfoXml = new NTaskGroupInfoXml();
                oNTaskGroupInfoXml.ListNTaskGroupInfo = listNTaskGroupInfo != null ? listNTaskGroupInfo.ToList() : null;
                if (oNTaskGroupInfoXml.ListNTaskGroupInfo == null) oNTaskGroupInfoXml.ListNTaskGroupInfo = new List<NTaskGroupInfo>();
                SetResponseData(true, "获取数据成功！", ValidateResponseKey(Devicetype, UserID, oNTaskGroupInfoXml), (int)WEBRESULT_CMD_TYPE.新版任务系统TaskGroupInfo, oNTaskGroupInfoXml);
            }
            else
            {
                SetResponseData(false, "分组信息不存在！", ValidateResponseKey(Devicetype, UserID, 0), (int)WEBRESULT_CMD_TYPE.新版任务系统TaskGroupInfo, 0);
            }
        }
        public class NTaskInfoXml
        {
            /// <summary>
            /// 任务ID
            /// </summary>
            [JsonProperty(PropertyName = "tId")]
            public int TaskId { get; set; }

            /// <summary>
            /// 任务信息Key
            /// </summary>
            [JsonProperty(PropertyName = "tInfoKey")]
            public int TaskInfoKey { get; set; }

            /// <summary>
            /// 任务名
            /// </summary>
            [JsonProperty(PropertyName = "tName")]
            public string TaskName { get; set; }

            /// <summary>
            /// 任务描述
            /// </summary>
            [JsonProperty(PropertyName = "tDesc")]
            public string TaskDesc { get; set; }

            /// <summary>
            /// 任务图标
            /// </summary>
            [JsonProperty(PropertyName = "tIcon")]
            public int TaskIcon { get; set; }

            /// <summary>
            /// 任务排序ID 越小越靠前
            /// </summary>
            [JsonProperty(PropertyName = "tSort")]
            public int TaskSort { get; set; }

            /// <summary>
            /// 任务所属组ID
            /// </summary>
            [JsonProperty(PropertyName = "tGroup")]
            public int TaskGroup { get; set; }

            /// <summary>
            /// 任务显示MASK 参考任务组MASK
            /// </summary>
            [JsonProperty(PropertyName = "tMask")]
            public int TaskMask { get; set; }

            /// <summary>
            /// 子任务ID
            /// </summary>
            [JsonProperty(PropertyName = "tNextId")]
            public int TaskNextId { get; set; }

            /// <summary>
            /// 子任务ID
            /// </summary>
            [JsonProperty(PropertyName = "Rewards")]
            public List<NTaskReward> ListNTaskReward { get; set; }
        }
        public class NTaskGroupInfoXml
        {
            [JsonProperty(PropertyName = "groups")]
            public List<NTaskGroupInfo> ListNTaskGroupInfo { get; set; }
        }
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        protected Dictionary<string, object> FormatRequestData(string data)
        {
            return Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(data);
        }

        #region 账号密码随机生成

        /// <summary>
        /// 随机生账号
        /// </summary>
        /// <param name="WordType">账号类型</param>
        /// <returns></returns>
        private string RandomStr(int WordType)
        {
            string newaccounts = "";
            switch (WordType)
            {

                case 1:  //随机词组
                    StreamReader sr = new StreamReader(HttpContext.Current.Server.MapPath("../App_Data/totleGName.txt"), Encoding.Default);
                    ResetCache();
                    sbCache.Append(sr.ReadToEnd());
                    string[] nametag = sbCache.ToString().Split(',');
                    Random rdm = new Random();
                    int index = rdm.Next(0, nametag.Length);
                    newaccounts = nametag[index];
                    if (oAccountsFacade.IsAccountsExist(newaccounts).Success == false && oAccountsFacade.IsNickNameExist(newaccounts) == false)
                    {
                        return RandomStr(WordType + 1);
                    }
                    else
                    {
                        return newaccounts;
                    }
                case 2:  //随机汉字
                    Encoding gb = Encoding.GetEncoding("gb2312");

                    //调用函数产生4个随机中文汉字编码 
                    object[] bytes = CreateRegionCode(4);

                    //根据汉字编码的字节数组解码出中文汉字 
                    newaccounts = gb.GetString((byte[])Convert.ChangeType(bytes[0], typeof(byte[]))) + gb.GetString((byte[])Convert.ChangeType(bytes[1], typeof(byte[]))) + gb.GetString((byte[])Convert.ChangeType(bytes[2], typeof(byte[]))) + gb.GetString((byte[])Convert.ChangeType(bytes[3], typeof(byte[])));

                    //输出
                    if (oAccountsFacade.IsAccountsExist(newaccounts).Success == false && oAccountsFacade.IsNickNameExist(newaccounts) == false)
                    {
                        return RandomStr(WordType + 1);
                    }
                    else
                    {
                        return newaccounts;
                    }
                default:  //随机字母+数字
                    newaccounts = this.RdmLtter + RdmNum;
                    if (oAccountsFacade.IsAccountsExist(newaccounts).Success == false && oAccountsFacade.IsNickNameExist(newaccounts) == false)
                    {
                        return RandomStr(WordType + 1);
                    }
                    else
                    {
                        return newaccounts;
                    }
            }
        }
        /// <summary>
        /// 随机密码
        /// </summary>
        /// <returns></returns>
        private string RandomPwd()
        {
            #region 随机生成密码
            string str = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~!@#$%^&*()_+";  //字符
            Random r = new Random();
            string result = string.Empty;

            //生成一个8位长的随机字符，具体长度可以自己更改
            for (int i = 0; i < 8; i++)
            {
                int m = r.Next(0, 75);//这里下界是0，随机数可以取到，上界应该是75，因为随机数取不到上界，也就是最大74
                string s = str.Substring(m, 1);
                result += s;
            }
            result = Game.Utils.TextEncrypt.MD5EncryptPassword(result);
            #endregion
            return result;
        }

        /// <summary>
        /// 生成随机账号
        /// </summary>
        /// <param name="strlength"></param>
        /// <returns></returns>
        public static object[] CreateRegionCode(int strlength)
        {
            //定义一个字符串数组储存汉字编码的组成元素 
            string[] rBase = new String[16] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };

            Random rnd = new Random();

            //定义一个object数组用来 
            object[] bytes = new object[strlength];

            /**/
            /*每循环一次产生一个含两个元素的十六进制字节数组，并将其放入bject数组中 
每个汉字有四个区位码组成 
区位码第1位和区位码第2位作为字节数组第一个元素 
区位码第3位和区位码第4位作为字节数组第二个元素 
*/
            for (int i = 0; i < strlength; i++)
            {
                //区位码第1位 
                int r1 = rnd.Next(11, 14);
                string str_r1 = rBase[r1].Trim();

                //区位码第2位 
                rnd = new Random(r1 * unchecked((int)DateTime.Now.Ticks) + i);//更换随机数发生器的 

                //种子避免产生重复值 
                int r2;
                if (r1 == 13)
                {
                    r2 = rnd.Next(0, 7);
                }
                else
                {
                    r2 = rnd.Next(0, 16);
                }
                string str_r2 = rBase[r2].Trim();

                //区位码第3位 
                rnd = new Random(r2 * unchecked((int)DateTime.Now.Ticks) + i);
                int r3 = rnd.Next(10, 16);
                string str_r3 = rBase[r3].Trim();

                //区位码第4位 
                rnd = new Random(r3 * unchecked((int)DateTime.Now.Ticks) + i);
                int r4;
                if (r3 == 10)
                {
                    r4 = rnd.Next(1, 16);
                }
                else if (r3 == 15)
                {
                    r4 = rnd.Next(0, 15);
                }
                else
                {
                    r4 = rnd.Next(0, 16);
                }
                string str_r4 = rBase[r4].Trim();

                //定义两个字节变量存储产生的随机汉字区位码 
                byte byte1 = Convert.ToByte(str_r1 + str_r2, 16);
                byte byte2 = Convert.ToByte(str_r3 + str_r4, 16);
                //将两个字节变量存储在字节数组中 
                byte[] str_r = new byte[] { byte1, byte2 };

                //将产生的一个汉字的字节数组放入object数组中 
                bytes.SetValue(str_r, i);

            }

            return bytes;
        }
        #endregion

        #region 查看手机是否绑定
        [MobileMethod(RequestCMD = "1051")]
        public void ValidatePhone(string sign, string data)
        {
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int UserID = Convert.ToInt32(requestparms["userid"]);
            string PhoneNum = requestparms["mobile"].ToString();
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            UserInfo oUserInfo = this.ValidateSign(Devicetype, UserID, sign, data);
            Hashtable hashtable = new Hashtable();
            //验证手机号码
            if (!Game.Library.Utility.IsMobileNumber(PhoneNum))
            {
                this.SetResponseData(false, "手机号码无效！", ValidateResponseKey(Devicetype, UserID, hashtable), (int)WEBRESULT_CMD_TYPE.验证手机是否可以绑定, hashtable);
                return;
            }
            //验证手机号码是否已绑定
            var state = oAccountsFacade.IsAuthTelephoneOrRegisterAccounts(PhoneNum);
            hashtable.Add("state", state);
            if (state == 0)
            {
                //发送客户端
                this.SetResponseData(true, "手机号码可以绑定", ValidateResponseKey(Devicetype, UserID, hashtable), (int)WEBRESULT_CMD_TYPE.验证手机是否可以绑定, hashtable);
                return;
            }
            else if (state == 1)
            {
                this.SetResponseData(true, "此手机号码已绑定平台账号,请前往登录！", ValidateResponseKey(Devicetype, UserID, hashtable), (int)WEBRESULT_CMD_TYPE.验证手机是否可以绑定, hashtable);
            }
            else if (state == 2)
            {
                this.SetResponseData(true, "此手机号码已绑定其它账号渠道帐号，是否要解绑并绑定至此手机！", ValidateResponseKey(Devicetype, UserID, hashtable), (int)WEBRESULT_CMD_TYPE.验证手机是否可以绑定, hashtable);
            }

        }
        #endregion

        #region 查看该手机号是否可以找回密码
        [MobileMethod(RequestCMD = "1054")]
        public void ValidatePhoneNum(string sign, string data)
        {
#if !DEBUG
            this.ValidateSign(sign, data);
#else
            Game.Library.Log.WriteLogInfo("查看手机是否可以找回密码", new Exception(data));
#endif
            Dictionary<string, object> requestparms = FormatRequestData(data);
            string PhoneNum = requestparms["mobile"].ToString();
            Hashtable hashtable = new Hashtable();
            //验证手机号码
            if (!Game.Library.Utility.IsMobileNumber(PhoneNum))
            {
                this.SetResponseData(false, "手机号码无效！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.查看该手机号是否可以找回密码, hashtable);
                return;
            }
            //验证手机号码是否已绑定
            var state = oAccountsFacade.IsAuthTelephoneOrRegisterAccounts(PhoneNum);
            if (state > 0)
            {
                if (state == 1)
                {
                    this.SetResponseData(true, "该手机可以找回密码！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.查看该手机号是否可以找回密码, hashtable);
                }
                else
                {
                    this.SetResponseData(false, "渠道用户不能找回密码！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.查看该手机号是否可以找回密码, hashtable);
                }
            }
            else
            {
                this.SetResponseData(false, "该手机号码没有绑定任何帐号！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.查看该手机号是否可以找回密码, hashtable);
            }
        }
        #endregion

        #region 发送找回密码验证吗
        [MobileMethod(RequestCMD = "1053")]
        public void SendCode(string sign, string data)
        {
#if !DEBUG
            this.ValidateSign(sign, data);
#else
            Game.Library.Log.WriteLogInfo("发送找回密码验证码", new Exception(data));
#endif
            Dictionary<string, object> requestparms = FormatRequestData(data);
            string PhoneNum = requestparms["mobile"].ToString();
            Hashtable hashtable = new Hashtable();
            //验证手机号码
            if (!Game.Library.Utility.IsMobileNumber(PhoneNum))
            {
                this.SetResponseData(false, "手机号码无效！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.发送找回密码验证码, hashtable);
                return;
            }
            var state = oAccountsFacade.IsAuthTelephoneOrRegisterAccounts(PhoneNum);
            if (state == 0)
            {
                this.SetResponseData(false, "该手机号码没有绑定任何帐号！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.发送找回密码验证码, hashtable);
                return;
            }
            else if (state == 2)
            {
                this.SetResponseData(false, "手机绑定为渠道号码，不能找回密码！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.发送找回密码验证码, hashtable);
                return;
            }
            int userid = oAccountsFacade.GetUserIDByPhone(PhoneNum);
            //验证手机号码是否已绑定
            if (userid > 0)
            {
                try
                {
                    hashtable.Add("userid", userid);
                    //生成短信验证码
                    string smscode = oNativeWebFacade.BuilderCheckCode(Game.Type.AuthUseType.验证手机, userid, PhoneNum, "");
                    //编辑短信内容
                    ResetCache();
                    sbCache.AppendFormat("您的手机号码为:{0}正在{1}，验证码为:{2}。", PhoneNum, "找回密码", smscode);
                    //调用API发送短信
                    //Game.ThirdServices.SMSHelper oSMSOper = new Game.ThirdServices.SMSHelper(Game.Web.Constant.LKSMSAccount, Game.Web.Constant.LKSMSPass, Game.Web.Constant.LKSMSSign);
                    Game.ThirdServices.SMSywwdHelper oSMSOper = new Game.ThirdServices.SMSywwdHelper(Game.Web.Constant.YWWDAccount, Game.Web.Constant.YWWDPass, Game.Web.Constant.YWWDSign);

                    try
                    {
                        oSMSOper.Send(sbCache.ToString(), new List<string>() { PhoneNum });
                    }
                    catch (Exception e)
                    {
                        Game.Library.Log.WriteLogInfo("发送找回密码验证码", e);
                    }
                    this.SetResponseData(true, "发送成功！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.发送找回密码验证码, hashtable);
                }
                catch (Exception e)
                {
                    Game.Library.Log.WriteLogInfo("发送找回密码验证码", e);
                    this.SetResponseData(false, e.Message, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.发送找回密码验证码, hashtable);
                }
            }
            else
            {
                this.SetResponseData(false, "该手机号码没有绑定任何帐号！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.发送找回密码验证码, hashtable);
            }
        }
        #endregion

        #region 找回密码
        [MobileMethod(RequestCMD = "1055")]
        public void GetUserPass(string sign, string data)
        {
#if !DEBUG
            this.ValidateSign(sign, data);
#else
            Game.Library.Log.WriteLogInfo("找回密码", new Exception(data));
#endif
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int UserID = Convert.ToInt32(requestparms["userid"]);
            string PhoneNum = requestparms["mobile"].ToString();
            string password = requestparms["password"].ToString();
            string verificationcode = requestparms["verificationcode"].ToString();
            Hashtable hashtable = new Hashtable();
            try
            {
                Message vmsg = oNativeWebFacade.VerificationCheckCode(Type.AuthUseType.验证手机, UserID, verificationcode, PhoneNum, null);
                if (vmsg.Success)
                {
                    var msg = oAccountsFacade.EditLogonPasswd(UserID, password);
                    if (msg.Success)
                    {
                        oAccountsFacade.EditInsurePasswd(UserID, password);
                        this.SetResponseData(true, "找回成功！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.找回密码成功, hashtable);

                    }
                    else
                    {
                        this.SetResponseData(false, "找回失败！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.找回密码成功, hashtable);
                    }
                }
                else
                {
                    this.SetResponseData(false, "验证码错误！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.找回密码成功, hashtable);
                }

            }
            catch (Exception ex)
            {
                Game.Library.Log.WriteLogInfo("找回密码", ex);
                this.SetResponseData(false, "找回失败！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.找回密码成功, hashtable);
            }
        }
        #endregion

        #region 登录后获取信息
        [MobileMethod(RequestCMD = "1062")]
        public void GetInfo(string sign, string data)
        {
#if !DEBUG
            this.ValidateSign(sign, data);
#else
            Game.Library.Log.WriteLogInfo("获取信息", new Exception(data));
#endif
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int UserID = Convert.ToInt32(requestparms["userid"]);
            Hashtable hashtable = new Hashtable();
            if (oAccountsFacade.IsBindWeixin(UserID))
            {
                hashtable.Add("bindweixin", 1);
            }
            else
            {
                hashtable.Add("bindweixin", 0);
            }
            var cardnum = oAccountsFacade.GetUserPropertybyUserID(UserID);
            hashtable.Add("cardnum", cardnum);
            //获取区域语言
            #region 区域语言
            var json = Get(string.Format("http://ip.taobao.com/service/getIpInfo.php?ip={0}", GameRequest.GetUserIP()), Encoding.UTF8, 500);
            if (!string.IsNullOrEmpty(json))
            {
                var dicjson = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                if (dicjson["code"].ToString() == "0")
                {
                    var dicdata = JsonConvert.DeserializeObject<Dictionary<string, object>>(dicjson["data"].ToString());
                    if (dicdata["region"].ToString() == "湖北省")
                    {
                        hashtable.Add("effectType", 2);
                    }
                    else
                    {
                        hashtable.Add("effectType", 1);
                    }
                }
                else
                {
                    hashtable.Add("effectType", 1);
                }
            }
            else
            {
                hashtable.Add("effectType", 1);
            }
            #endregion
            this.SetResponseData(true, "获取信息成功！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取信息, hashtable);

        }
        #endregion

        #region GET请求
        public string Get(string url, Encoding encode, int timeOutSeconds = 1000)
        {
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.Timeout = timeOutSeconds;
                HttpWebResponse res = (HttpWebResponse)req.GetResponse();
                StreamReader sr = new StreamReader(res.GetResponseStream(), encode);
                string temp = sr.ReadToEnd();
                sr.Close();
                res.Close();
                return temp;
            }
            catch (Exception ex)
            {
                return "";
            }
        }
        #endregion
        #region 排行榜
        [MobileMethod(RequestCMD = "1070")]
        public void GetRankList(string sign, string data)
        {
#if DEBUG
            Game.Library.Log.WriteLogInfo("获取排行", new Exception(data));
#else
            this.ValidateSign(sign, data);
#endif
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int userID = Convert.ToInt32(requestparms["userid"]);
            int type = Convert.ToInt32(requestparms["type"]);
            Hashtable hb = new Hashtable();
            var rankdata = HttpRuntime.Cache.Get("ranklist" + type);
            if (rankdata == null)
            {
                var msg = oAccountsFacade.GetRankList(userID, type);
                if (msg.Success)
                {
                    var dt = (msg.EntityList[0] as DataSet).Tables[0];
                    HttpRuntime.Cache.Insert("ranklist" + type, dt, null, DateTime.Now.AddMinutes(10), TimeSpan.Zero);
                    rankdata = dt;
                }
            }
            List<Hashtable> hashtablelist = new List<Hashtable>();
            var tb = (DataTable)rankdata;
            for (int i = 0; i < (tb.Rows.Count > 100 ? 100 : tb.Rows.Count); i++)
            {
                Hashtable hstable = new Hashtable();
                hstable.Add("userid", tb.Rows[i]["UserID"]);
                hstable.Add("nickname", tb.Rows[i]["NickName"]);
                hstable.Add("faceid", tb.Rows[i]["FaceID"]);
                hstable.Add("score", tb.Rows[i]["Score"]);
                hstable.Add("rank", i + 1);
                hashtablelist.Add(hstable);
            }
            var dr = tb.Select("userid=" + userID);
            if (dr != null && dr.Length > 0)
            {
                hb.Add("rank", tb.Rows.IndexOf(dr[0]) + 1);
                hb.Add("score", dr[0]["score"]);
            }
            else
            {
                hb.Add("rank", -1);
                var score = oAccountsFacade.GetRankScore(userID, type);
                hb.Add("score", score < 0 ? 0 : score);
            }
            hb.Add("rankinfolist", hashtablelist);
            this.SetResponseData(true, "获取信息成功！", ValidateResponseKey(hb), (int)WEBRESULT_CMD_TYPE.获取排行, hb);
        }
        #endregion
    }
}