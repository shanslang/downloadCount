﻿using Game.Entity.Accounts;
using Game.Entity.GameProperty;
using Game.Entity.MobileApp;
using Game.Entity.NativeWeb;
using Game.Entity.Platform;
using Game.Entity.QPMatch;
using Game.Entity.Task;
using Game.Entity.Treasure;
using Game.Facade;
using Game.Francis;
using Game.Type;
using Game.Utils;
using Game.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using Newtonsoft.Json.Linq;
using System.Security.Cryptography;
using System.Xml.Serialization;
using Com.Alipay;
using upacp_sdk_net.com.unionpay.sdk;
using Game.AppServices.wenxinsdk;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Drawing2D;
using Aliyun.Acs.Core;
using Aliyun.Acs.Core.Exceptions;
using Aliyun.Acs.Core.Profile;
using Aliyun.Acs.Dysmsapi.Model.V20170525;

namespace Game.AppServices.api
{
    /// <summary>
    /// Phonehandler 的摘要说明
    /// </summary>
    public class PhonehandlerXL : BaseMobileHandler
    {
        #region 获取大厅地址
        [MobileMethod(RequestCMD = "1001")]
        public void ThehallAddress(string sign, string data)
        {
#if !DEBUG
            this.ValidateSign(sign, data);
#endif

            Dictionary<string, object> requestparms = FormatRequestData(data);
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            int Version = Convert.ToInt32(requestparms["version"]);    //版本号(根据此版本号获取接口地址)
            Hashtable hashtable = new Hashtable();
            IList<AppServerAddressCFG> datalist = oMobileAppFacade.GetLogonServerAddress(Version, 0);  //登陆服务器地址
            AppVisitAddressCFG datainfo = oMobileAppFacade.GetAppVisitAddress(Version);  //接口访问地址
            GameAppIDInfo AppidInfo = oMobileAppFacade.APPIDInfoGet(AppSerType.XL);


            if (datalist == null || datalist.Count == 0 || datainfo == null) { this.SetResponseData(false, "版本信息不存在！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取大厅登录地址完成, hashtable); return; }

            string http_web_url = datainfo.Appweb_url;                 //接口请求地址
            string AppFileRec = datainfo.AppFileRec;                   //图片上传地址

            List<Hashtable> serveraddlist = new List<Hashtable>();
            if (datalist != null && datalist.Count > 0)
            {
                for (int i = 0; i < datalist.Count; i++)
                {
                    Hashtable HshserverList = new Hashtable();
                    HshserverList.Add("serveradd", datalist[i].LogonServerAddress.ToString());
                    HshserverList.Add("serverport", datalist[i].LogonServerPort.ToString());
                    serveraddlist.Add(HshserverList);
                }
                //Hashtable HshserverList = new Hashtable();
                //Random rd = new Random();
                //int i= rd.Next(0, datalist.Count);
                //HshserverList.Add("serveradd", datalist[i].LogonServerAddress.ToString());
                //HshserverList.Add("serverport", datalist[i].LogonServerPort.ToString());
                //serveraddlist.Add(HshserverList);
            }
            hashtable.Add("http_web_url", http_web_url + "/sj/");
            hashtable.Add("imgurl", http_web_url);
            hashtable.Add("up_load_url", AppFileRec);
            hashtable.Add("serveraddlist", serveraddlist);
            hashtable.Add("appid", Devicetype == (int)SigninEquipment.AndroidSignIn ? AppidInfo.Andorid : AppidInfo.APPID);
            if (requestparms.ContainsKey("gameid") && requestparms.ContainsKey("chanelid"))
            {
                DataSet ds = oMobileAppFacade.GetGameAppUrlCFG(Convert.ToInt32(requestparms["gameid"]), Convert.ToInt32(requestparms["chanelid"]), -1);
                string appUrl = string.Empty;
                string apkMD5 = string.Empty;
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    apkMD5 = ds.Tables[0].Rows[0]["ApkMD5"].ToString();
                    appUrl = ds.Tables[0].Rows[0]["AppURL"].ToString();
                }
                if (Convert.ToInt32(requestparms["chanelid"]) == 1)
                {
                    hashtable.Add("app_url", hostaddress.Trim('/') + string.Format("/mshare-{0}-1.html", Convert.ToInt32(requestparms["gameid"])));
                }
                else
                {
                    hashtable.Add("app_url", appUrl);
                }
                hashtable.Add("apk_md5", apkMD5);
            }
            this.SetResponseData(true, "", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取大厅登录地址完成, hashtable);

        }

        #endregion

        #region 一键注册
        /// <summary>
        /// 一键注册
        /// </summary>
        [MobileMethod(RequestCMD = "1002")]
        public void fastReg(string sign, string data)
        {
#if DEBUG
            Game.Library.Log.WriteLogInfo("一键注册", new Exception(data));
#else
            this.ValidateSign(sign, data);
#endif
            Dictionary<string, object> requestparms = FormatRequestData(data);
            string MAC = requestparms["machid"].ToString();
            // Game.Library.Log.WriteLogInfo("RequestMAC", new Exception(MAC));
            int historyUserID = oAccountsFacade.UserMachineInfoGet(MAC, 0, GetIntValue(requestparms, "gameid"));
            UserInfo userfullinfo = null;
            if (historyUserID > 0)
            {
                userfullinfo = oAccountsFacade.GetUserInfoByUserID(historyUserID);
            }
            Hashtable hashtable = new Hashtable();
            if (userfullinfo != null && userfullinfo.UserID > 0)
            {
                hashtable.Add("accounts", userfullinfo.UserID);
                hashtable.Add("password", userfullinfo.LogonPass);
                if (requestparms.Keys.Contains("version"))
                {
                    int version = int.Parse(requestparms["version"].ToString());
                    hashtable.Add("serveraddlist", GetServerList(version, userfullinfo.UserID));
                }
                this.SetResponseData(true, "获取账号信息成功！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.一键注册完成, hashtable);
            }
            else
            {
                string parentAccount = "";
                UserInfo accounts = new UserInfo();
                accounts.Accounts = RandomStr(9);
                accounts.NickName = "AppServicesRegister";
                accounts.LogonPass = Game.Utils.TextEncrypt.MD5EncryptPassword(MAC);
                accounts.InsurePass = accounts.LogonPass;
                accounts.RegisterIP = GameRequest.GetUserIP();
                accounts.Compellation = "";
                accounts.FaceID = 37;
                accounts.Gender = 0;
                accounts.LastLogonDate = DateTime.Now;
                accounts.LastLogonIP = GameRequest.GetUserIP();
                accounts.PassPortID = "";
                accounts.RegisterMachine = MAC;
                accounts.RegisterDate = DateTime.Now;
                accounts.RegKindID = GetIntValue(requestparms, "gameid");
                accounts.RegDeviceType = GetIntValue(requestparms, "devicetype");
                accounts.ExternalMsg = GetstringValue(requestparms, "externalMsg");
                if (requestparms.Keys.Contains("spreader"))
                {
                    var oUserInfo = oAccountsFacade.GetUserFullInfoByGameID(Convert.ToInt32(requestparms["spreader"].ToString()));
                    if (oUserInfo != null)
                    {
                        parentAccount = oUserInfo.Accounts;
                    }
                }
                Message msg = oAccountsFacade.Register(accounts, parentAccount, 0, "");
                if (msg.Success)
                {
                    //MAC地址与用户关联
                    DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                    oAccountsFacade.UserMacthineInsert(Convert.ToInt32(dt.Rows[0]["UserID"]), MAC);

                    hashtable.Add("accounts", dt.Rows[0]["UserID"]);
                    hashtable.Add("password", accounts.LogonPass);
                    if (requestparms.Keys.Contains("version"))
                    {
                        int version = int.Parse(requestparms["version"].ToString());
                        hashtable.Add("serveraddlist", GetServerList(version, int.Parse(dt.Rows[0]["UserID"].ToString())));
                    }

                    this.SetResponseData(msg.Success, msg.Content, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.一键注册完成, hashtable);
                }
                else
                {
                    this.SetResponseData(msg.Success, msg.Content, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.一键注册完成, hashtable);
                }
            }
        }

        #endregion

        #region 用户头像数据信息
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        [MobileMethod(RequestCMD = "1008")]
        public void GetUserFace(string sign, string data)
        {
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int UserID = Convert.ToInt32(requestparms["userid"]);
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            UserInfo userinfo = this.ValidateSign(Devicetype, UserID, sign, data);
            if (userinfo != null && userinfo.UserID > 0)
            {
                string customfacemd5 = "";
                Hashtable hashtable = new Hashtable();
                hashtable.Add("faceid", userinfo.FaceID);
                int customID = userinfo.CustomID;
                AccountsUploadFace Userface = oAccountsFacade.GetUserFaceInfo(userinfo.UserID, userinfo.CustomID);
                if (Userface != null)
                {
                    customfacemd5 = Userface.FileMD5;
                    customID = Userface.CustomId;
                }
                hashtable.Add("customfaceid", customID);
                hashtable.Add("customfacemd5", customfacemd5);
                hashtable.Add("customfaceurl", customID > 0 ? Constant.GameResourcesHost + "/upload/face/" + customID + ".png" : "");

                this.SetResponseData(true, "", ValidateResponseKey(Devicetype, UserID, hashtable), (int)WEBRESULT_CMD_TYPE.获取用户头像数据完成, hashtable);
            }

        }

        #endregion

        #region 公告数据
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        [MobileMethod(RequestCMD = "1015")]
        public void NoticeInfo(string sign, string data)
        {
            this.ValidateSign(sign, data);
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            NoticeCFG datainfo = oMobileAppFacade.AppNoticeInfo();
            Hashtable hashdata = new Hashtable();
            string privacyurl = System.Web.Configuration.WebConfigurationManager.AppSettings["AppPrivacyurl"].ToString(); //服务条款
            string registerurl = System.Web.Configuration.WebConfigurationManager.AppSettings["AppRegister"].ToString(); //注册页面
            //最近一次获奖记录
            string rewordinfo = oMobileAppFacade.AppNoticeReword();

            if (datainfo != null)
            {
                hashdata.Add("nearawardrecoeds", rewordinfo);
                hashdata.Add("noticeurl", hostaddress + datainfo.PageLink + "&gametype=" + (int)Game.Type.MobileApp.NoticeInfoGameType.麻将);
                hashdata.Add("noticewidth", Devicetype == (int)SigninEquipment.AndroidSignIn ? datainfo.AndroidWidth : datainfo.PageWidth);
                hashdata.Add("noticeheight", Devicetype == (int)SigninEquipment.AndroidSignIn ? datainfo.AndroidHeight : datainfo.PageHeight);
                hashdata.Add("privacyurl", hostaddress + privacyurl);
                hashdata.Add("registerurl", hostaddress + registerurl);
                this.SetResponseData(true, "", ValidateResponseKey(hashdata), (int)WEBRESULT_CMD_TYPE.获取登录前公告信息完成, hashdata);
            }
            else
            {
                this.SetResponseData(true, "", ValidateResponseKey(hashdata), (int)WEBRESULT_CMD_TYPE.获取登录前公告信息完成, hashdata);
            }

        }

        #endregion


        #region 获取服务器时间
        [MobileMethod(RequestCMD = "1023")]
        public void ServerTime(string sign, string data)
        {
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            UserInfo ouserinfo = null;
            if (!string.IsNullOrEmpty(requestparms["userid"].ToString()))
            {
                ouserinfo = this.ValidateSign(Devicetype, Convert.ToInt32(requestparms["userid"]), sign, data.ToString());
            }
            Hashtable hashtable = new Hashtable();
            hashtable.Add("year", DateTime.Now.Year);
            hashtable.Add("month", DateTime.Now.Month);
            hashtable.Add("day", DateTime.Now.Day);
            hashtable.Add("hour", DateTime.Now.Hour);
            hashtable.Add("minute", DateTime.Now.Minute);
            hashtable.Add("second", DateTime.Now.Second);
            hashtable.Add("millsecond", DateTime.Now.Millisecond);
            if (ouserinfo != null)
            {
                this.SetResponseData(true, "", ValidateResponseKey(Devicetype, ouserinfo.UserID, hashtable), (int)WEBRESULT_CMD_TYPE.获取服务器时间完成, hashtable);
            }
            else
            {
                this.SetResponseData(true, "", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取服务器时间完成, hashtable);
            }
        }
        #endregion


        #region 根据选择购买的产品ID，生成订单数据
        [MobileMethod(RequestCMD = "1025")]
        public void CreateIOSOrder(string sign, string data)
        {
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int paramUserID = Convert.ToInt32(requestparms["userid"]);
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            int timeSpan = GetIntValue(requestparms, "timespan");
            int serverID = GetIntValue(requestparms, "serverid");
            string paramAppleProductID = requestparms["identifier"].ToString();
            int onlineid = 0;
            //签名验证
            UserInfo oUserInfo = this.ValidateSign(Devicetype, paramUserID, sign, data);


            //参数验证
            if (string.IsNullOrEmpty(paramAppleProductID))
            {
                this.SetResponseData(false, "不能为空！", ValidateResponseKey(Devicetype, paramUserID, null), (int)WEBRESULT_CMD_TYPE.IOS端根据选择购买的产品ID生成订单数据完成, null);
                return;
            }


            if (oMobileAppFacade.RtRepeatBuy(oUserInfo.UserID, paramAppleProductID))
            {
                this.SetResponseData(false, "您之前已购买过此产品！", ValidateResponseKey(Devicetype, paramUserID, null), (int)WEBRESULT_CMD_TYPE.IOS端根据选择购买的产品ID生成订单数据完成, null);
                return;
            }


            //订单信息
            OnLineOrder oOnLineOrder = new OnLineOrder();
            oOnLineOrder.TimeSpan = timeSpan;
            oOnLineOrder.ServerID = serverID;
            oOnLineOrder.KindID = 918;//血流
            if (Devicetype != (int)SigninEquipment.AndroidSignIn) //验证是否为安卓设备
            {
                oOnLineOrder.ShareID = (int)Game.Type.GlobalShareInfo.APPLE;
                oOnLineOrder.OrderID = PayHelper.GetOrderIDByPrefix(Game.Type.GlobalShareInfo.APPLE.ToString());//生成订单号
            }
            else   // Android
            {
                oOnLineOrder.ShareID = (int)Game.Type.GlobalShareInfo.LJ;
                oOnLineOrder.OrderID = PayHelper.GetOrderIDByPrefix(Game.Type.GlobalShareInfo.LJ.ToString());//生成订单号
            }
            oOnLineOrder.OperUserID = oUserInfo.UserID;
            oOnLineOrder.Accounts = oUserInfo.Accounts;
            oOnLineOrder.CardTotal = 1;
            oOnLineOrder.CardTypeID = 1;
            oOnLineOrder.IPAddress = GameRequest.GetUserIP();

            //if (requestparms.Keys.Contains("isneworder") && Convert.ToInt32(requestparms["isneworder"]) == 1)
            //{
            //    lock (sandboxOrderList)
            //    {
            //        sandboxOrderList.Add(oOnLineOrder.OrderID);
            //    }
            //}

            #region 购买会员
            if (paramAppleProductID == "com.hbykrs.YKXLVipBlue7")
            {
                int memberorder = 0;
                int memeberdays = 0;
                switch (paramAppleProductID)
                {
                    case "com.hbykrs.YKXLVipBlueTen": //蓝钻会员10天
                        oOnLineOrder.OrderAmount = 188; //订单金额
                        oOnLineOrder.PayAmount = 188;//实付金额
                        memberorder = (int)Game.Type.MemberLevel.二星会员;
                        memeberdays = 10;
                        break;
                    case "com.hbykrs.YKXLVipBlueNewTen": //蓝钻会员7天
                        oOnLineOrder.OrderAmount = 288; //订单金额
                        oOnLineOrder.PayAmount = 288;//实付金额
                        memberorder = (int)Game.Type.MemberLevel.二星会员;
                        memeberdays = 7;
                        break;
                    case "com.hbykrs.YKXLVipYellowNewTen": //黄钻会员10天
                        oOnLineOrder.OrderAmount = 18; //订单金额
                        oOnLineOrder.PayAmount = 18;//实付金额
                        memberorder = (int)Game.Type.MemberLevel.一星会员;
                        memeberdays = 10;
                        break;
                    case "com.hbykrs.YKXLVipYellowSeven": //黄钻会员7天
                        oOnLineOrder.OrderAmount = 88; //订单金额
                        oOnLineOrder.PayAmount = 88;//实付金额
                        memberorder = (int)Game.Type.MemberLevel.一星会员;
                        memeberdays = 7;
                        break;
                    case "com.hbykrs.YKXLVipBlue3": //蓝钻会员3天道具
                        {
                            oOnLineOrder.OrderAmount = 188; //订单金额
                            oOnLineOrder.PayAmount = 188;//实付金额
                            memberorder = (int)Game.Type.MemberLevel.二星会员;
                            memeberdays = 3;
                            break;
                        }
                    case "com.hbykrs.YKXLVipBlue7": //蓝钻会员7天道具
                        {
                            oOnLineOrder.OrderAmount = 88; //订单金额
                            oOnLineOrder.PayAmount = 88;//实付金额
                            memberorder = (int)Game.Type.MemberLevel.二星会员;
                            memeberdays = 7;
                            break;
                        }
                    case "com.hbykrs.YKXLVipYellow3": //黄钻会员3天道具
                        {
                            oOnLineOrder.OrderAmount = 18; //订单金额
                            oOnLineOrder.PayAmount = 18;//实付金额
                            memberorder = (int)Game.Type.MemberLevel.一星会员;
                            memeberdays = 3;
                            break;
                        }
                    case "com.hbykrs.YKXLVipYellow7": //黄钻会员7天道具
                        {
                            oOnLineOrder.OrderAmount = 88; //订单金额
                            oOnLineOrder.PayAmount = 88;//实付金额
                            memberorder = (int)Game.Type.MemberLevel.一星会员;
                            memeberdays = 7;
                            break;
                        }
                }
                if (memberorder == 0 || memeberdays == 0)
                {
                    this.SetResponseData(false, "无效的产品！", ValidateResponseKey(Devicetype, paramUserID, null), (int)WEBRESULT_CMD_TYPE.IOS端根据选择购买的产品ID生成订单数据完成, null);
                    return;
                }

                //订单用途
                oOnLineOrder.OrderUseType = (int)Game.Type.OrderUseType.购买会员;
                #region 生成订单及明细
                //oOnLineOrder.OrderAmount = 0.01m;
                Message msgRequestOrder = oTreasureFacade.RequestOrder(oOnLineOrder);
                var order = msgRequestOrder.EntityList[0] as OnLineOrder;
                onlineid = order.OnLineID;
                Message msgInsertBuyMemberOrderDetails = oTreasureFacade.InsertBuyMemberOrderDetails1(new BuyMemberOrderDetails1()
                {
                    OrderID = oOnLineOrder.OrderID,
                    MemberOrder = memberorder,
                    MemberDays = memeberdays
                });
                if (!msgInsertBuyMemberOrderDetails.Success)
                {
                    this.SetResponseData(false, "生成会员订单明细失败！", ValidateResponseKey(Devicetype, paramUserID, null), (int)WEBRESULT_CMD_TYPE.IOS端根据选择购买的产品ID生成订单数据完成, null);
                    return;
                }
                #endregion
            }

            // 购买道具
            else if (paramAppleProductID == "com.hbykrs.YKXLWTicket" || paramAppleProductID == "com.hbykrs.YKXLMOTicket" || paramAppleProductID == "com.hbykrs.XLBUQIAN")
            {
                int propertypid = 0;
                int propernumber = 0;
                switch (paramAppleProductID)
                {
                    case "com.hbykrs.YKXLWTicket":  //周赛门票3张
                        {
                            oOnLineOrder.OrderAmount = 6; //订单金额
                            oOnLineOrder.PayAmount = 6;//实付金额
                            propertypid = 8;
                            propernumber = 3;
                            break;
                        }
                    case "com.hbykrs.YKXLMOTicket": //月赛门票1张
                        {
                            oOnLineOrder.OrderAmount = 6; //订单金额
                            oOnLineOrder.PayAmount = 6;//实付金额
                            propertypid = 9;
                            propernumber = 1;
                            break;
                        }
                    case "com.hbykrs.XLBUQIAN":    //补签卡
                        {
                            oOnLineOrder.OrderAmount = 6; //订单金额
                            oOnLineOrder.PayAmount = 6;//实付金额
                            propertypid = 31;
                            propernumber = 6;
                            break;
                        }
                }
                if (propertypid == 0 || propernumber == 0)
                {
                    this.SetResponseData(false, "无效的产品！", ValidateResponseKey(Devicetype, paramUserID, null), (int)WEBRESULT_CMD_TYPE.IOS端根据选择购买的产品ID生成订单数据完成, null);
                    return;
                }

                //订单用途
                oOnLineOrder.OrderUseType = (int)Game.Type.OrderUseType.购买道具;
                #region 生成订单及明细
                //oOnLineOrder.OrderAmount = 0.01m;
                Message msgRequestOrder = oTreasureFacade.RequestOrder(oOnLineOrder);
                var order = msgRequestOrder.EntityList[0] as OnLineOrder;
                onlineid = order.OnLineID;
                Message msgBuyProperDetails = oTreasureFacade.InsertBuyProperDetails(new BuyProperDetails()
                {
                    OrderID = oOnLineOrder.OrderID,
                    ProperPid = propertypid,
                    ProperNumber = propernumber
                });
                if (!msgBuyProperDetails.Success)
                {
                    this.SetResponseData(false, "生成道具订单明细失败！", ValidateResponseKey(Devicetype, paramUserID, null), (int)WEBRESULT_CMD_TYPE.IOS端根据选择购买的产品ID生成订单数据完成, null);
                    return;
                }
                #endregion
            }

            #endregion

            #region

            //充值金币
            else if (paramAppleProductID == "com.hbykrs.XLGOD288" || paramAppleProductID == "com.hbykrs.XLGOD30" ||
              paramAppleProductID == "com.hbykrs.XLGOD488" || paramAppleProductID == "com.hbykrs.XLGOD60" || paramAppleProductID == "com.hbykrs.XLGOD12" || paramAppleProductID == "com.hbykrs.XLGOD6" || paramAppleProductID == "com.hbykrs.XLGOD98")
            {

                //获取金币价值 
                int priceGold = 0;
                if (requestparms.Keys.Contains("isneworder") && Convert.ToInt32(requestparms["isneworder"]) == 1)
                {
                    DataSet ds = oMobileAppFacade.AppProductList(string.Format(" and Identifier='{0}'", paramAppleProductID), "");
                    if (ds != null && ds.Tables.Count > 0) priceGold = Convert.ToInt32(ds.Tables[0].Rows[0]["PriceGold"]);
                    oOnLineOrder.OrderAmount = decimal.Parse((ds.Tables[0].Rows[0]["PriceRMB"].ToString()));
                    oOnLineOrder.PayAmount = decimal.Parse((ds.Tables[0].Rows[0]["PriceRMB"].ToString()));
                }
                else
                {
                    switch (paramAppleProductID)
                    {
                        case "com.hbykrs.XLGOD288":   //288元金币套餐
                            {
                                oOnLineOrder.OrderAmount = 288; //订单金额
                                oOnLineOrder.PayAmount = 288;//实付金额
                                priceGold = 6000000;
                                break;
                            }
                        case "com.hbykrs.XLGOD30": //30元金币套餐
                            {
                                oOnLineOrder.OrderAmount = 30; //订单金额
                                oOnLineOrder.PayAmount = 30;//实付金额
                                priceGold = 750000;
                                break;
                            }
                        case "com.hbykrs.XLGOD488": //488元金币套餐
                            {
                                oOnLineOrder.OrderAmount = 488; //订单金额
                                oOnLineOrder.PayAmount = 488;//实付金额
                                priceGold = 10000000;
                                break;
                            }
                        case "com.hbykrs.XLGOD60"://60元金币套餐
                            {
                                oOnLineOrder.OrderAmount = 60; //订单金额
                                oOnLineOrder.PayAmount = 60;//实付金额
                                priceGold = 1500000;
                                break;
                            }
                        case "com.hbykrs.XLGOD6"://6元金币套餐
                            {
                                oOnLineOrder.OrderAmount = 6; //订单金额
                                oOnLineOrder.PayAmount = 6;//实付金额
                                priceGold = 150000;
                                break;
                            }
                        case "com.hbykrs.XLGOD98"://98元金币套餐
                            {
                                oOnLineOrder.OrderAmount = 98; //订单金额
                                oOnLineOrder.PayAmount = 98;//实付金额
                                priceGold = 2000000;
                                break;
                            }
                    }
                }
                if (oOnLineOrder.OrderAmount == 0 || oOnLineOrder.PayAmount == 0)
                {
                    this.SetResponseData(false, "无效的产品！", ValidateResponseKey(Devicetype, paramUserID, null), (int)WEBRESULT_CMD_TYPE.IOS端根据选择购买的产品ID生成订单数据完成, null);
                    return;
                }

                //订单用途
                oOnLineOrder.OrderUseType = (int)Game.Type.OrderUseType.充值金币;

                #region 生成订单及明细
                //oOnLineOrder.OrderAmount = 0.01m;
                Message msgRequestOrder = oTreasureFacade.RequestOrder(oOnLineOrder);
                var order = msgRequestOrder.EntityList[0] as OnLineOrder;
                onlineid = order.OnLineID;
                Message msgInsertBuyMemberOrderDetails = oTreasureFacade.InsertBuyGoldDetails(new BuyGoldOrderDetails()
                {
                    OrderID = oOnLineOrder.OrderID,
                    PriceGold = priceGold,
                    BuyCount = 1
                });
                if (!msgInsertBuyMemberOrderDetails.Success)
                {
                    this.SetResponseData(false, "生成金币订单明细失败！", ValidateResponseKey(Devicetype, paramUserID, null), (int)WEBRESULT_CMD_TYPE.IOS端根据选择购买的产品ID生成订单数据完成, null);
                    return;
                }
                #endregion
            }
            else
            {
                this.SetResponseData(false, "产品不存在！", ValidateResponseKey(Devicetype, paramUserID, null), (int)WEBRESULT_CMD_TYPE.IOS端根据选择购买的产品ID生成订单数据完成, null);
                return;
            }

            #endregion

            oMobileAppFacade.AppInsertAppBuyHistoty(oUserInfo.UserID, paramAppleProductID, oOnLineOrder.OrderID); //购买记录
            //返回结果集
            Hashtable result = new Hashtable();
            result.Add("orderid", oOnLineOrder.OrderID);
            result.Add("orderamount", Convert.ToInt32(oOnLineOrder.OrderAmount));
            result.Add("approductid", paramAppleProductID);
            result.Add("appletransaction", paramAppleProductID);
            result.Add("orderstatus", 0);
            result.Add("onlineid", onlineid);
            this.SetResponseData(true, "生成订单成功！", ValidateResponseKey(Devicetype, paramUserID, result), (int)WEBRESULT_CMD_TYPE.IOS端根据选择购买的产品ID生成订单数据完成, result);
        }
        #endregion

        #region 验证交易是否完成
        [MobileMethod(RequestCMD = "1026")]
        public void VerificationOrderIsOver(string sign, object data)
        {
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int paramUserID = Convert.ToInt32(requestparms["userid"]);
            int Devicetype = Convert.ToInt32(requestparms["devicetype"]);
            string paramreceipt = Convert.ToString(requestparms["receipt"]); //base64
            string paramOrderID = Convert.ToString(requestparms["orderid"]);
            int kernelVerison = GetIntValue(requestparms, "kernelVerison");
            string paramApproductid = Convert.ToString(requestparms["approductid"]);
#if !DEBUG
            //签名验证
            UserInfo userinfo = this.ValidateSign(Devicetype, paramUserID, sign, data.ToString());
#endif

            //验证订单是否存在
            var oOnlineOrder = oTreasureFacade.GetOnlineOrder(paramOrderID, paramUserID);
            if (oOnlineOrder == null)
            {
                Game.Library.Log.WriteLogInfo("订单不存在", new Exception("orderid:" + paramOrderID + " ;UserID:" + paramUserID.ToString()));
                this.SetResponseData(false, "订单不存在！", ValidateResponseKey(Devicetype, paramUserID, null), (int)WEBRESULT_CMD_TYPE.验证交易是否完成, null);
                return;
            }
            Hashtable responsehs = new Hashtable();
            List<Hashtable> memberinfo = this.xlreturnMemberdata(paramUserID);
            List<Hashtable> userPropinfo = this.xluserProplist(paramUserID, "");
            if (oOnlineOrder.OrderStatus == (int)Game.Type.OnLineOrderStatus.处理完成)
            {
                responsehs.Add("result", 1);
                responsehs.Add("orderid", oOnlineOrder.OrderID);
                responsehs.Add("approductid", paramApproductid);
                responsehs.Add("memberlist", memberinfo);
                responsehs.Add("userproperty", userPropinfo);
                this.SetResponseData(true, "购买成功！", ValidateResponseKey(Devicetype, paramUserID, responsehs), (int)WEBRESULT_CMD_TYPE.验证交易是否完成, responsehs);
            }
            else
            {
                if (Devicetype != (int)SigninEquipment.AndroidSignIn)  //是否为安卓设备
                {
                    Message msg = AppleOrderPay(paramreceipt, oOnlineOrder, paramUserID, kernelVerison);
                    memberinfo = this.xlreturnMemberdata(paramUserID);
                    userPropinfo = this.xluserProplist(paramUserID, "");
                    responsehs.Add("result", msg.Success ? 1 : 0);
                    responsehs.Add("orderid", oOnlineOrder.OrderID);
                    responsehs.Add("approductid", paramApproductid);
                    responsehs.Add("memberlist", memberinfo);
                    responsehs.Add("userproperty", userPropinfo);
                    this.SetResponseData(msg.Success, msg.Content, ValidateResponseKey(Devicetype, paramUserID, responsehs), (int)WEBRESULT_CMD_TYPE.验证交易是否完成, responsehs);
                    return;
                }
                responsehs.Add("result", 0);
                responsehs.Add("orderid", oOnlineOrder.OrderID);
                responsehs.Add("approductid", paramApproductid);
                responsehs.Add("memberlist", memberinfo);
                responsehs.Add("userproperty", userPropinfo);
                this.SetResponseData(false, "未完成！", ValidateResponseKey(Devicetype, paramUserID, responsehs), (int)WEBRESULT_CMD_TYPE.验证交易是否完成, responsehs);
            }
        }
        #endregion

        #region 微信发起第三方支付
        /// <summary>
        /// 微信发起支付请求
        /// </summary> 
        [MobileMethod(RequestCMD = "1059")]
        public void WeixinPayRequest(string sign, string data)
        {
#if DEBUG
            Game.Library.Log.WriteLogInfo("微信发起支付请求", new Exception(data));
#endif
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int paramUserID = Convert.ToInt32(requestparms["userid"]);
            int paramDevicetype = Convert.ToInt32(requestparms["devicetype"]);
            string paramOrderID = Convert.ToString(requestparms["orderid"]);
            //签名验证
            UserInfo oUserInfo = this.ValidateSign(paramDevicetype, paramUserID, sign, data.ToString());

            //int paramUserID = 30349;
            //int paramDevicetype = 0;
            //string paramOrderID = "APPLE20150921114553850164813";
            //UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(paramUserID);

            //验证订单是否存在
            OnLineOrder oOnLineOrder = oTreasureFacade.GetOnlineOrder(paramOrderID, paramUserID);
            if (oOnLineOrder == null) throw new Exception("订单不存在");

            WXHelper oWXHelper = new WXHelper(ConfigurationManager.AppSettings["WEIXIN_MchIdXL"], ConfigurationManager.AppSettings["WEIXIN_KeyXL"], ConfigurationManager.AppSettings["WEIXIN_AppIdXL"], ConfigurationManager.AppSettings["WEIXIN_NotifyUrlXL"]);
            string prepayid = oWXHelper.unifiedorder(paramOrderID, "8633充值包", Convert.ToInt32(oOnLineOrder.OrderAmount * 100));
            if (string.IsNullOrEmpty(prepayid) == false)
            {
                string json = oWXHelper.getappparams(prepayid);
                this.SetResponseData(true, "发起支付成功！", this.ValidateResponseKey(paramDevicetype, paramUserID, json), (int)WEBRESULT_CMD_TYPE.微信发起支付请求, json);
            }
            else
            {
                this.SetResponseData(false, "请求失败，发起微信支付失败！", this.ValidateResponseKey(paramDevicetype, paramUserID, 0), (int)WEBRESULT_CMD_TYPE.微信发起支付请求, 0);
            }
        }
        #endregion

        #region IOS订单支付

        /// <summary>
        /// IOS订单支付
        /// </summary>
        /// <param name="paramreceipt"></param>
        /// <param name="data"></param>
        /// <param name="oOnlineOrder"></param>
        /// <param name="paramUserID"></param>
        private Message AppleOrderPay(string paramreceipt, OnLineOrder oOnlineOrder, int paramUserID, int kernelVerison)
        {
            Message msg = new Message();

            //apple参数
            Dictionary<string, object> rparms = new Dictionary<string, object>();
            rparms.Add("receipt-data", paramreceipt);//base64Decrypt(paramreceipt)
            string body = Newtonsoft.Json.JsonConvert.SerializeObject(rparms);
            //#if DEBUG
            //            string url = Game.AppServices.Constant.APPLEIAPSandboxUrl;
            //#else
            //            string url = Game.AppServices.Constant.APPLEIAPBuyUrl;
            //#endif
            var url = kernelVerison >= Convert.ToInt32(ConfigurationManager.AppSettings["XLkernelVerison"].ToString()) ? Game.AppServices.Constant.APPLEIAPSandboxUrl : Game.AppServices.Constant.APPLEIAPBuyUrl;
            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
            request.Method = "POST";
            request.ContentType = "application/json";
            byte[] databody = System.Text.Encoding.UTF8.GetBytes(body);//发送主体
            using (Stream stream = request.GetRequestStream()) { stream.Write(databody, 0, databody.Length); }
            //获取结果
            StreamReader srdPreview = new StreamReader(request.GetResponse().GetResponseStream());
            string applejson = srdPreview.ReadToEnd();
            srdPreview.Close();
            var results = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(applejson);
            if (Convert.ToInt32(results["status"]) == 0)//苹果返回成功 
            {
                var receipt = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(results["receipt"].ToString());
                //记录苹果返回数据包
                ReturnAppleIAPDetailInfo oReturnAppleIAPDetailInfo = new ReturnAppleIAPDetailInfo();
                oReturnAppleIAPDetailInfo.original_purchase_date_pst = receipt["original_purchase_date_pst"].ToString();
                oReturnAppleIAPDetailInfo.purchase_date_ms = receipt["purchase_date_ms"].ToString();
                oReturnAppleIAPDetailInfo.unique_identifier = receipt["unique_identifier"].ToString();
                oReturnAppleIAPDetailInfo.original_transaction_id = receipt["original_transaction_id"].ToString();
                oReturnAppleIAPDetailInfo.bvrs = receipt["bvrs"].ToString();
                oReturnAppleIAPDetailInfo.transaction_id = receipt["transaction_id"].ToString();
                oReturnAppleIAPDetailInfo.quantity = receipt["quantity"].ToString();
                oReturnAppleIAPDetailInfo.unique_vendor_identifier = receipt["unique_vendor_identifier"].ToString();
                oReturnAppleIAPDetailInfo.item_id = receipt["item_id"].ToString();
                oReturnAppleIAPDetailInfo.product_id = receipt["product_id"].ToString();
                oReturnAppleIAPDetailInfo.purchase_date = receipt["purchase_date"].ToString();
                oReturnAppleIAPDetailInfo.original_purchase_date = receipt["original_purchase_date"].ToString();
                oReturnAppleIAPDetailInfo.purchase_date_pst = receipt["purchase_date_pst"].ToString();
                oReturnAppleIAPDetailInfo.bid = receipt["bid"].ToString();
                oReturnAppleIAPDetailInfo.original_purchase_date_ms = receipt["original_purchase_date_ms"].ToString();
                oReturnAppleIAPDetailInfo.json = applejson;
                oReturnAppleIAPDetailInfo.orderid = oOnlineOrder.OrderID;
                oReturnAppleIAPDetailInfo.orderamount = oOnlineOrder.OrderAmount;
                oReturnAppleIAPDetailInfo.iap_transaction = paramreceipt;

                if (oReturnAppleIAPDetailInfo.bid != "com.hbykrs.SparrowXL")
                {
                    msg.Content = "非法APP操作！"; msg.Success = false;
                    return msg;
                }
                //处理订单
                msg = oTreasureFacade.WriteAppleIAPRecharge(oOnlineOrder.OrderID, Constant.ReleaseVersion, oReturnAppleIAPDetailInfo);

                if (msg.Success)
                {
                    return msg;
                }
                else
                {
                    Game.Library.Log.WriteLogInfo("订单处理", new Exception("单处理失败！" + msg.Content));
                    msg.Content = "订单处理失败！";
                    return msg;
                }
            }
            else
            {
                msg.Content = "IAP验证失败！!";
                msg.Success = false;
                Game.Library.Log.WriteLogInfo("IOS订单支付失败：", new Exception("paramreceipt:" + paramreceipt + ",OnLineOrder:" + oOnlineOrder + ",UserID:" + paramUserID.ToString() + ",result:" + applejson));
            }

            return msg;
        }
        #endregion

        #region DataHelper

        public class SerListresult
        {
            public int serverid { get; set; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        protected Dictionary<string, object> FormatRequestData(string data)
        {
            return Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(data);
        }

        protected Dictionary<string, object> FormatRequestData(object data)
        {
            return Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(data.ToString());
        }
        /// <summary>
        /// 获取用户道具
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        private List<Hashtable> xluserProplist(int userid, string where)
        {
            List<Hashtable> userpropertylist = new List<Hashtable>();
            DataSet ds = oGamePropertyFacade.GetUserPropertyRecordForIOS(userid, where);
            if (ds != null && ds.Tables.Count > 0)
            {
                DataTable dtProp = ds.Tables[0];
                for (int i = 0; i < dtProp.Rows.Count; i++)
                {
                    Hashtable userProphs = new Hashtable();
                    userProphs.Add("pid", dtProp.Rows[i]["PID"].ToString());
                    userProphs.Add("pcount", dtProp.Rows[i]["PCount"].ToString());
                    userProphs.Add("pname", dtProp.Rows[i]["Name"].ToString());
                    userProphs.Add("directions", dtProp.Rows[i]["Explain"].ToString());
                    userProphs.Add("ConvertProductPid", Game.Utils.Utility.StrToInt(dtProp.Rows[i]["ConvertProductPid"], 0));
                    userpropertylist.Add(userProphs);
                }
            }
            return userpropertylist;
        }

        /// <summary>
        /// 重新获取用户会员信息
        /// </summary>
        /// <returns></returns>
        private Hashtable xlreturnMemberdata(int userid, int memberOrder)
        {
            Hashtable resultdata = new Hashtable();
            IList<AccountsMember> oUserMemberInfo = oAccountsFacade.GetAccountsMemberList(string.Format(" AND MemberOrder={0} AND UserID={1}", memberOrder, userid), "");
            if (oUserMemberInfo != null && oUserMemberInfo.Count > 0)
            {
                resultdata.Add("memberorder", oUserMemberInfo[0].MemberOrder);
                resultdata.Add("activestatus", oUserMemberInfo[0].Activation);
                resultdata.Add("memberoveryear", oUserMemberInfo[0].MemberOverDate.Year);
                resultdata.Add("memberovermonth", oUserMemberInfo[0].MemberOverDate.Month);
                resultdata.Add("memberoverday", oUserMemberInfo[0].MemberOverDate.Day);
                resultdata.Add("memberoverhour", oUserMemberInfo[0].MemberOverDate.Hour);
                resultdata.Add("memberoverminute", oUserMemberInfo[0].MemberOverDate.Minute);
                resultdata.Add("memberoversecond", oUserMemberInfo[0].MemberOverDate.Second);
            }
            return resultdata;
        }
        /// <summary>
        /// 重新获取用户会员信息
        /// </summary>
        /// <returns></returns>
        private List<Hashtable> xlreturnMemberdata(int userid)
        {
            List<Hashtable> usermenmberlist = new List<Hashtable>();
            IList<AccountsMember> oUserMemberInfo = oAccountsFacade.GetAccountsMemberList(string.Format(" AND UserID={0}", userid), "");
            if (oUserMemberInfo != null && oUserMemberInfo.Count > 0)
            {
                for (int i = 0; i < oUserMemberInfo.Count; i++)
                {
                    Hashtable resultdata = new Hashtable();
                    resultdata.Add("memberorder", oUserMemberInfo[i].MemberOrder);
                    resultdata.Add("activestatus", oUserMemberInfo[i].Activation);
                    resultdata.Add("memberoveryear", oUserMemberInfo[i].MemberOverDate.Year);
                    resultdata.Add("memberovermonth", oUserMemberInfo[i].MemberOverDate.Month);
                    resultdata.Add("memberoverday", oUserMemberInfo[i].MemberOverDate.Day);
                    resultdata.Add("memberoverhour", oUserMemberInfo[i].MemberOverDate.Hour);
                    resultdata.Add("memberoverminute", oUserMemberInfo[i].MemberOverDate.Minute);
                    resultdata.Add("memberoversecond", oUserMemberInfo[i].MemberOverDate.Second);
                    usermenmberlist.Add(resultdata);
                }

            }
            return usermenmberlist;
        }
        /// <summary>
        /// 格式化活动地址
        /// </summary>
        /// <returns></returns>
        protected string formatActLink(string url, int devicetype, UserInfo user)
        {
            string webkey = "";
            SigninEquipment type = (SigninEquipment)devicetype;
            if (type == SigninEquipment.PCSignIn) { webkey = webkey = user.PCWebKey; }
            if (type != SigninEquipment.PCSignIn) { webkey = webkey = user.IOSWebKey; }
            //switch (type)
            //{
            //    case SigninEquipment.PCSignIn:
            //        webkey = user.PCWebKey;
            //        break;
            //    case SigninEquipment.AndroidSignIn:
            //        webkey = user.AndroidWebKey;
            //        break;
            //    case SigninEquipment.ITouchSignIn:
            //        webkey = user.IOSWebKey;
            //        break;
            //    case SigninEquipment.IPhoneSignIn:
            //        webkey = user.IOSWebKey;
            //        break;
            //    case SigninEquipment.IPadSignIn:
            //        webkey = user.IOSWebKey;
            //        break;
            //    default:
            //        break;
            //}
            return string.Format(url + "&usergameid={0}&webkey={1}&devicetype={2}&random={3}", user.GameID, webkey, Constant.FormatClientDeviceType(type), DateTime.Now.ToString("yyyyMMddHHmmssfff"));

        }



        #region 账号密码随机生成

        /// <summary>
        /// 随机生账号
        /// </summary>
        /// <param name="WordType">账号类型</param>
        /// <returns></returns>
        private string RandomStr(int WordType)
        {
            string newaccounts = "";
            switch (WordType)
            {

                case 1:  //随机词组
                    StreamReader sr = new StreamReader(HttpContext.Current.Server.MapPath("../App_Data/totleGName.txt"), Encoding.Default);
                    ResetCache();
                    sbCache.Append(sr.ReadToEnd());
                    string[] nametag = sbCache.ToString().Split(',');
                    Random rdm = new Random();
                    int index = rdm.Next(0, nametag.Length);
                    newaccounts = nametag[index];
                    if (oAccountsFacade.IsAccountsExist(newaccounts).Success == false && oAccountsFacade.IsNickNameExist(newaccounts) == false)
                    {
                        return RandomStr(WordType + 1);
                    }
                    else
                    {
                        return newaccounts;
                    }
                case 2:  //随机汉字
                    Encoding gb = Encoding.GetEncoding("gb2312");

                    //调用函数产生4个随机中文汉字编码 
                    object[] bytes = CreateRegionCode(4);

                    //根据汉字编码的字节数组解码出中文汉字 
                    newaccounts = gb.GetString((byte[])Convert.ChangeType(bytes[0], typeof(byte[]))) + gb.GetString((byte[])Convert.ChangeType(bytes[1], typeof(byte[]))) + gb.GetString((byte[])Convert.ChangeType(bytes[2], typeof(byte[]))) + gb.GetString((byte[])Convert.ChangeType(bytes[3], typeof(byte[])));

                    //输出
                    if (oAccountsFacade.IsAccountsExist(newaccounts).Success == false && oAccountsFacade.IsNickNameExist(newaccounts) == false)
                    {
                        return RandomStr(WordType + 1);
                    }
                    else
                    {
                        return newaccounts;
                    }
                default:  //随机字母+数字
                    newaccounts = this.RdmLtter + RdmNum9;
                    if (oAccountsFacade.IsAccountsExist(newaccounts).Success == false && oAccountsFacade.IsNickNameExist(newaccounts) == false)
                    {
                        return RandomStr(WordType + 1);
                    }
                    else
                    {
                        return newaccounts;
                    }
            }
        }
        /// <summary>
        /// 随机密码
        /// </summary>
        /// <returns></returns>
        private string RandomPwd()
        {
            #region 随机生成密码
            string str = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~!@#$%^&*()_+";  //字符
            Random r = new Random();
            string result = string.Empty;

            //生成一个8位长的随机字符，具体长度可以自己更改
            for (int i = 0; i < 8; i++)
            {
                int m = r.Next(0, 75);//这里下界是0，随机数可以取到，上界应该是75，因为随机数取不到上界，也就是最大74
                string s = str.Substring(m, 1);
                result += s;
            }
            result = Game.Utils.TextEncrypt.MD5EncryptPassword(result);
            #endregion
            return result;
        }

        /// <summary>
        /// 生成随机账号
        /// </summary>
        /// <param name="strlength"></param>
        /// <returns></returns>
        public static object[] CreateRegionCode(int strlength)
        {
            //定义一个字符串数组储存汉字编码的组成元素 
            string[] rBase = new String[16] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };

            Random rnd = new Random();

            //定义一个object数组用来 
            object[] bytes = new object[strlength];

            /**/
            /*每循环一次产生一个含两个元素的十六进制字节数组，并将其放入bject数组中 
每个汉字有四个区位码组成 
区位码第1位和区位码第2位作为字节数组第一个元素 
区位码第3位和区位码第4位作为字节数组第二个元素 
*/
            for (int i = 0; i < strlength; i++)
            {
                //区位码第1位 
                int r1 = rnd.Next(11, 14);
                string str_r1 = rBase[r1].Trim();

                //区位码第2位 
                rnd = new Random(r1 * unchecked((int)DateTime.Now.Ticks) + i);//更换随机数发生器的 

                //种子避免产生重复值 
                int r2;
                if (r1 == 13)
                {
                    r2 = rnd.Next(0, 7);
                }
                else
                {
                    r2 = rnd.Next(0, 16);
                }
                string str_r2 = rBase[r2].Trim();

                //区位码第3位 
                rnd = new Random(r2 * unchecked((int)DateTime.Now.Ticks) + i);
                int r3 = rnd.Next(10, 16);
                string str_r3 = rBase[r3].Trim();

                //区位码第4位 
                rnd = new Random(r3 * unchecked((int)DateTime.Now.Ticks) + i);
                int r4;
                if (r3 == 10)
                {
                    r4 = rnd.Next(1, 16);
                }
                else if (r3 == 15)
                {
                    r4 = rnd.Next(0, 15);
                }
                else
                {
                    r4 = rnd.Next(0, 16);
                }
                string str_r4 = rBase[r4].Trim();

                //定义两个字节变量存储产生的随机汉字区位码 
                byte byte1 = Convert.ToByte(str_r1 + str_r2, 16);
                byte byte2 = Convert.ToByte(str_r3 + str_r4, 16);
                //将两个字节变量存储在字节数组中 
                byte[] str_r = new byte[] { byte1, byte2 };

                //将产生的一个汉字的字节数组放入object数组中 
                bytes.SetValue(str_r, i);

            }

            return bytes;
        }
        #endregion


        #endregion


        #region 微信一键注册
        [MobileMethod(RequestCMD = "1060")]
        public void WeiXinReg(string sign, string data)
        {
#if DEBUG
            Game.Library.Log.WriteLogInfo("微信一键注册", new Exception(data));
#else
            this.ValidateSign(sign, data);
#endif
            Dictionary<string, object> requestparms = FormatRequestData(data);
            string openid = requestparms["openid"].ToString();
            string MachineID = requestparms["machineid"].ToString();
            string PlatformID = requestparms["platformid"].ToString();
            string DeviceModel = requestparms["devicemodel"].ToString();
            var starttime = DateTime.Now;
            var baseInfoUrl = "https://api.weixin.qq.com/sns/userinfo?access_token=" + requestparms["token"] + "&openid=" + openid;
            var userinfomsg = HttpGet(baseInfoUrl, Encoding.UTF8);
            Game.Library.Log.WriteLogInfo("微信获取信息", new Exception(userinfomsg+"--获取时间："+ (DateTime.Now - starttime).ToString()));
            var dicuserinfo = FormatRequestData(userinfomsg);
            Hashtable hashtable = new Hashtable();
            Message msg = oAccountsFacade.Register(openid, MachineID, Convert.ToInt32(PlatformID), DeviceModel, FiterWeiXin(GetstringValue(dicuserinfo, "nickname")), GetstringValue(dicuserinfo, "unionid"));
            if (msg.Success)
            {
                //MAC地址与用户关联
                DataTable dt = (msg.EntityList[0] as DataSet).Tables[0];
                hashtable.Add("accounts", dt.Rows[0]["UserID"]);
                hashtable.Add("password", dt.Rows[0]["LogonPass"]);
                hashtable.Add("username", dt.Rows[0]["accounts"]);
                if (requestparms.Keys.Contains("version"))
                {
                    int version = int.Parse(requestparms["version"].ToString());
                    hashtable.Add("serveraddlist", GetServerList(version, int.Parse(dt.Rows[0]["UserID"].ToString())));
                }
                Game.Library.Log.WriteLogInfo("微信一键注册时间", new Exception("userid:" + dt.Rows[0]["UserID"].ToString() + ",执行时间：" + (DateTime.Now - starttime).ToString()));
                this.SetResponseData(msg.Success, msg.Content, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.微信注册, hashtable);
            }
            else
            {
                this.SetResponseData(msg.Success, msg.Content, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.微信注册, hashtable);
            }
        }
        public string HttpGet(string url, Encoding encode, int timeOutSeconds = 10)
        {
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; Q312461; .NET CLR 1.0.3705)";
                req.Method = "GET";
                req.Timeout = timeOutSeconds * 1000;

                HttpWebResponse res = (HttpWebResponse)req.GetResponse();
                StreamReader sr = new StreamReader(res.GetResponseStream(), encode);
                string temp = sr.ReadToEnd();
                sr.Close();
                res.Close();
                return temp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region 获取服务器
        List<Hashtable> GetServerList(int version, int userid)
        {
            List<Hashtable> serveraddlist = new List<Hashtable>();
            if (Constant.UserIDList.Contains(userid.ToString()))
            {
                Hashtable HsserverList = new Hashtable();
                HsserverList.Add("serveradd", Constant.ServerIP);
                HsserverList.Add("serverport", Constant.ServerPort);
                HsserverList.Add("isdefenserver", 1);
                serveraddlist.Add(HsserverList);
            }
            else
            {
                IList<AppServerAddressCFG> datalist = oMobileAppFacade.GetLogonServerAddress(version, userid);
                var generalServer = datalist.Where(n => n.IsDefense == 0).ToList();
                var defenseServer = datalist.Where(n => n.IsDefense == 1).ToList();
                int num = userid / Constant.UserGroup;              
                if (generalServer.Count > 0)
                {
                    Hashtable HsserverList = new Hashtable();
                    HsserverList.Add("serveradd", generalServer[num % generalServer.Count].LogonServerAddress.ToString());
                    HsserverList.Add("serverport", generalServer[num % generalServer.Count].LogonServerPort.ToString());
                    HsserverList.Add("isdefenserver", 0);
                    serveraddlist.Add(HsserverList);
                }
                if (defenseServer.Count > 0)
                {
                    Hashtable HsserverList = new Hashtable();
                    HsserverList.Add("serveradd", defenseServer[num % defenseServer.Count].LogonServerAddress.ToString());
                    HsserverList.Add("serverport", defenseServer[num % defenseServer.Count].LogonServerPort.ToString());
                    HsserverList.Add("isdefenserver", 1);
                    serveraddlist.Add(HsserverList);
                }
            }
            return serveraddlist;
        }
        #endregion
        #region 注册
        [MobileMethod(RequestCMD = "1068")]
        public void Register(string sign, string data)
        {
#if DEBUG
            Game.Library.Log.WriteLogInfo("注册", new Exception(data));
#else
            this.ValidateSign(sign, data);
#endif
            Hashtable hashtable = new Hashtable();
            Dictionary<string, object> requestparms = FormatRequestData(data);
            var accounts = requestparms["accounts"].ToString();
            var nickname = requestparms["nickname"].ToString();
            var password = requestparms["password"].ToString();
            var RegDeviceType = Convert.ToInt32(requestparms["devicetype"].ToString());
            string MAC = requestparms["machid"].ToString();
            #region 检查用户名
            if (string.IsNullOrEmpty(accounts))
            {
                throw new Exception("账号不能为空！");
            }
            //数据库验证
            Message umsg = oAccountsFacade.IsAccountsExist(accounts);
            if (umsg.Success == false) throw new Exception("该用户名已经被使用,请换其它用户名在试！");
            #endregion

            #region 检查昵称
            if (string.IsNullOrEmpty(nickname.Trim())) throw new Exception("昵称不能为空");
            #endregion

            //初始用户对象
            UserInfo user = new UserInfo();
            user.Accounts = accounts;
            user.Compellation = "";
            user.FaceID = 1;
            user.Gender = 0;
            user.InsurePass = password;
            user.LastLogonDate = DateTime.Now;
            user.LastLogonIP = GameRequest.GetUserIP();
            user.LogonPass = password;
            user.NickName = nickname;
            user.PassPortID = "";
            user.RegisterDate = DateTime.Now;
            user.RegisterIP = GameRequest.GetUserIP();
            user.RegKindID = 500;
            user.RegisterMachine = MAC;
            user.RegDeviceType = RegDeviceType;
            user.ExternalMsg = "";
            //注册用户
            Message msg = oAccountsFacade.Register(user, "", 0, "");
            if (msg.Success)
            {
                int userid = Convert.ToInt32((msg.EntityList[0] as DataSet).Tables[0].Rows[0][0]);
                hashtable.Add("accounts", userid);
                hashtable.Add("password", user.LogonPass);
                int version = int.Parse(requestparms["version"].ToString());
                hashtable.Add("serveraddlist", GetServerList(version, userid));
                this.SetResponseData(msg.Success, msg.Content, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.注册账号, hashtable);
            }
            else
            {
                this.SetResponseData(msg.Success, msg.Content, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.注册账号, hashtable);
            }
        }
        [MobileMethod(RequestCMD = "1069")]
        public void Login(string sign, string data)
        {
#if DEBUG
            Game.Library.Log.WriteLogInfo("登录", new Exception(data));
#else
            this.ValidateSign(sign, data);
#endif
            Hashtable hashtable = new Hashtable();
            Dictionary<string, object> requestparms = FormatRequestData(data);
            var accounts = requestparms["accounts"].ToString();
            var password = requestparms["password"].ToString();
            UserInfo userinfo = new UserInfo(0, accounts, 0, password);
            userinfo.LastLogonIP = GameRequest.GetUserIP();
            var msg = oAccountsFacade.Logon(accounts, password, true);
            if (msg.Success)
            {
                var user = msg.EntityList[0] as UserInfo;
                hashtable.Add("accounts", user.UserID);
                hashtable.Add("password", password);
                if (requestparms.Keys.Contains("version"))
                {
                    int version = int.Parse(requestparms["version"].ToString());
                    hashtable.Add("serveraddlist", GetServerList(version, user.UserID));
                }
                this.SetResponseData(msg.Success, msg.Content, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取ID, hashtable);
            }
            else
            {
                this.SetResponseData(msg.Success, msg.Content, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取ID, hashtable);
            }
        }
        #endregion
        #region 绑定手机
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        [MobileMethod(RequestCMD = "1009")]
        public void PhoneSendCode(string sign, string data)
        {
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int UserID = Convert.ToInt32(requestparms["userid"]);
            string PhoneNum = requestparms["mobile"].ToString();
#if !DEBUG
            this.ValidateSign(sign, data);
#endif
            Hashtable hashtable = new Hashtable();
            //验证手机号码
            if (!Game.Library.Utility.IsMobileNumber(PhoneNum))
            {
                this.SetResponseData(false, "手机号码无效！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取验证码完成, hashtable);
                return;
            }
            //生成短信验证码
            Message msg = oNativeWebFacade.BuilderCheckCodeFormsg(Game.Type.AuthUseType.验证手机, UserID, PhoneNum, "");
            if (msg.Success == false)
            {
                this.SetResponseData(false, msg.Content, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取验证码完成, hashtable);
                return;
            }
            IClientProfile profile = DefaultProfile.GetProfile("cn-hangzhou", "LTAIbNfcp35ysOPS", "K7aAoFvIMW96ZBXoq35WteNaJe64pn");
            IAcsClient client = new DefaultAcsClient(profile);
            DefaultProfile.AddEndpoint("cn-hangzhou", "cn-hangzhou", "Dysmsapi", "dysmsapi.aliyuncs.com");
            IAcsClient acsClient = new DefaultAcsClient(profile);
            SendSmsRequest request = new SendSmsRequest();
            try
            {
                request.SignName = "牛仔游戏";
                request.TemplateCode = "SMS_136861836";
                request.PhoneNumbers = PhoneNum;

                string sc = "{\"code\":\"" + msg.Content + "\"}";
                request.TemplateParam = sc;
                request.OutId = "yourOutId";
                //请求失败这里会抛ClientException异常
                SendSmsResponse sendSmsResponse = acsClient.GetAcsResponse(request);
                if (sendSmsResponse.Code == "OK")
                {
                    this.SetResponseData(true, "验证码发送成功！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取验证码完成, hashtable);
                }
                else
                {
                    Game.Library.Log.WriteLogInfo("绑定手机", new Exception(sendSmsResponse.Message));
                    this.SetResponseData(false, "服务器发生错误！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取验证码完成, hashtable);
                }
            }
            catch (Exception ex)
            {
                Game.Library.Log.WriteLogInfo("绑定手机", new Exception(ex.Message));
                this.SetResponseData(false, "服务器发生错误！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.获取验证码完成, hashtable);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        [MobileMethod(RequestCMD = "1010")]
        public void PhoneBinding(string sign, string data)
        {
            Dictionary<string, object> requestparms = FormatRequestData(data);
            int UserID = Convert.ToInt32(requestparms["userid"]);
            string PhoneNum = requestparms["mobile"].ToString();
            string verificationcode = requestparms["code"].ToString();
#if !DEBUG
            this.ValidateSign(sign, data);
#endif
            Hashtable hashtable = new Hashtable();
            //验证手机号码
            if (!Game.Library.Utility.IsMobileNumber(PhoneNum))
            {
                this.SetResponseData(false, "手机号码无效", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.绑定手机号码完成, null);
                return;
            }
            try
            {
                 Message msg = oNativeWebFacade.BindPhone(UserID, verificationcode, PhoneNum);

                //发送客户端
                this.SetResponseData(msg.Success, msg.Content, ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.绑定手机号码完成, hashtable);

            }
            catch (Exception exp)
            {
                Game.Library.Log.WriteLogInfo("绑定手机", exp);
                this.SetResponseData(false, "操作失败！", ValidateResponseKey(hashtable), (int)WEBRESULT_CMD_TYPE.绑定手机号码完成, null);

            }
        }
        #endregion
    }
}