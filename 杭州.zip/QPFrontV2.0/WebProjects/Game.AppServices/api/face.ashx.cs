﻿using Game.Entity.Accounts;
using Game.Facade;
using Game.Utils;
using Game.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Game.AppServices.api
{
    /// <summary>
    /// face 的摘要说明
    /// </summary>
    public class face : BaseHandler
    {
        #region 通用处理
        /// <summary>
        /// 响应处理
        /// </summary>
        /// <param name="context"></param>
        public override void ProcessRequest(HttpContext context)
        {
            try
            {
                int userid = GameRequest.GetQueryInt("userid", -1);
                int customid = GameRequest.GetQueryInt("customid", -1);
                if (userid < 0 || customid < 0) return;

                AccountsFacade oAccountsFacade = new AccountsFacade();
                AccountsFace oAccountsFace = oAccountsFacade.GetUserFaceByFaceID(userid, customid);
                if (oAccountsFace == null) return;
                context.Response.AddHeader("Content-Disposition", "attachment;filename=face.txt");
                context.Response.BinaryWrite(oAccountsFace.CustomFace);
            }
            catch (Exception exception)
            {
                Exception exp = (exception.InnerException != null) ? exception.InnerException : exception;
                Game.Library.Log.WriteLogInfo(exp);
            }
            finally
            {
                context.Response.End();
            }
        }
        #endregion
    }
}