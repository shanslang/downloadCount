﻿using Game.Entity.Accounts;
using Game.Facade;
using Game.Francis;
using Game.Type;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace Game.AppServices.api
{
    /// <summary>
    /// RequestFile 的摘要说明
    /// </summary>
    public class RequestFile : IHttpHandler
    {
        HttpContext context = HttpContext.Current;
        HttpRequest request = HttpContext.Current.Request;
        HttpResponse response = HttpContext.Current.Response;
        protected NativeWebFacade oNativeWebFacade = new NativeWebFacade();
        protected AccountsFacade oAccountsFacade = new AccountsFacade();


        public void ProcessRequest(HttpContext context)
        {
            UserInfo oUserinfo = this.Verification();
            if (FileVerification() == false)  //文件格式验证
            {
                this.SetResponseData(false, "请确保为图片文件且大小不得超过10M!", ValidateResponseKey(DeviceType, RequestUserID, null), (int)WEBRESULT_CMD_TYPE.上传用户头像完成, null);
            };
            switch (RequestCode)
            {
                case 1:   //问题反馈图片提交
                    RequestFeedBackAppFiles();
                    break;
                case 2:   //用户头像上传
                    RequestUserFiceAppFiles(oUserinfo);
                    break;
                default:
                    return;
            }
        }
        /// <summary>
        /// 用户自定义头像上传
        /// </summary>
        protected void RequestUserFiceAppFiles(UserInfo Ouser)
        {
            HttpServerUtility server = HttpContext.Current.Server;
            HttpFileCollection file = HttpContext.Current.Request.Files;

            string savepath = ""; string FileMd5 = ""; int newCustomID = 0;
            Message msg = new Message();
            Hashtable responsehs = new Hashtable();
            DataTable dt = new DataTable();

            if (file.Count > 0)
            {
                for (int i = 0; i < file.Count; i++)
                {
                    //修改用户头像数据
                    msg = oAccountsFacade.UploadAccountUserFace(Ouser.UserID, "", 0, false);
                    if (msg != null && msg.Success == true)
                    {
                        dt = (msg.EntityList[0] as DataSet).Tables[0];
                        newCustomID = Convert.ToInt32(dt.Rows[0]["EntityID"]);
                        savepath = context.Server.MapPath(string.Format("~/Upload/face/{0}.png", newCustomID));
                        if (newCustomID > 0)
                        {
                            try
                            {
                                file[i].SaveAs(savepath);        //保存文件
                                FileMd5 = LoadFileMD5(savepath); //获取MD5
                                msg = oAccountsFacade.UploadAccountUserFace(Ouser.UserID, FileMd5, newCustomID, false); //修改MD5
                            }
                            catch (Exception ex)
                            {
                                Game.Library.Log.WriteLogInfo("UserFiceUpload", new Exception("UserID:" + Ouser.UserID + "   " + ex.ToString()));
                                SetResponseData(false, "图片提交出现问题，请联系客服反馈问题！", ValidateResponseKey(DeviceType, RequestUserID, null), (int)WEBRESULT_CMD_TYPE.上传用户头像完成, responsehs);
                            }
                        }
                    }
                }
                dt = (msg.EntityList[0] as DataSet).Tables[0];
                responsehs.Add("userid", Ouser.UserID);
                responsehs.Add("faceid", dt.Rows[0]["FaceID"]);
                responsehs.Add("customfaceid", dt.Rows[0]["CustomID"]);
                if (msg.Success)
                {
                    SetResponseData(msg.Success, "头像修改成功，当前个人信息已变更为新的头像！", ValidateResponseKey(DeviceType, RequestUserID, null), (int)WEBRESULT_CMD_TYPE.上传用户头像完成, responsehs);
                }
                else
                {
                    Game.Library.Log.WriteLogInfo("UserFiceUpload", new Exception("UserID:" + Ouser.UserID + "   操作失败"));
                    SetResponseData(false, "操作失败！ ", ValidateResponseKey(DeviceType, RequestUserID, null), (int)WEBRESULT_CMD_TYPE.上传用户头像完成, responsehs);
                }

            }
            else
            {
                Game.Library.Log.WriteLogInfo("UserFiceUpload", new Exception("UserID:" + Ouser.UserID + "   无图片信息"));
                SetResponseData(false, "图片提交失败，请稍后再次尝试！", ValidateResponseKey(DeviceType, RequestUserID, null), (int)WEBRESULT_CMD_TYPE.上传用户头像完成, responsehs);
            }
        }

        /// <summary>
        /// 问题反馈图片接收
        /// </summary>
        protected void RequestFeedBackAppFiles()
        {
            HttpServerUtility server = HttpContext.Current.Server;
            HttpFileCollection file = HttpContext.Current.Request.Files;

            string savepath = ""; string picname = ""; int feedbackId = 0;
            if (Game.Utils.GameRequest.GetQueryInt("imageid", 0) <= 0) { this.SetResponseData(false, "反馈图片信息上传失败！", ValidateResponseKey(DeviceType, RequestUserID, null), (int)WEBRESULT_CMD_TYPE.游戏反馈完成, null); return; }
            else { feedbackId = Convert.ToInt32(request.QueryString["imageid"]); }
            try
            {
                for (int i = 0; i < file.Count; i++)
                {
                    Guid tempId = Guid.NewGuid();
                    picname = tempId.ToString().Replace("-", "").ToUpper() + ".png";
                    savepath = context.Server.MapPath(string.Format("~/Upload/Image/Feedback/{0}", picname));
                    file[i].SaveAs(savepath);
                }
                if (File.Exists(savepath))
                {
                    oNativeWebFacade.FeedbackSetImage(feedbackId, "/Upload/Image/Feedback/" + picname);
                }
            }
            catch (Exception ex)
            {
                Game.Library.Log.WriteLogInfo("Feedback", ex);
            }
            finally
            {
                if (File.Exists(savepath)) { this.SetResponseData(true, "图片上传成功！", ValidateResponseKey(DeviceType, RequestUserID, null), (int)WEBRESULT_CMD_TYPE.游戏反馈完成, null); }
                else { this.SetResponseData(false, "反馈图片信息上传失败！", ValidateResponseKey(DeviceType, RequestUserID, null), (int)WEBRESULT_CMD_TYPE.游戏反馈完成, null); }
            }
        }

        /// <summary>
        /// 获取文件MD5
        /// </summary>
        /// <returns></returns>
        public string LoadFileMD5(string filepath)
        {
            try
            {
                if (File.Exists(filepath))
                {
                    FileStream file = new FileStream(filepath, System.IO.FileMode.Open);
                    MD5 md5 = new MD5CryptoServiceProvider();
                    byte[] retVal = md5.ComputeHash(file);
                    file.Close();
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < retVal.Length; i++)
                    {
                        sb.Append(retVal[i].ToString("x2"));
                    }
                    return sb.ToString();
                }
                return "";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        /// <summary>
        /// 验证文件格式
        /// </summary>
        /// <returns></returns>
        protected bool FileVerification()
        {
            bool result = true;
            HttpFileCollection file = HttpContext.Current.Request.Files;
            if (file.Count > 0)
            {
                for (int i = 0; i < file.Count; i++)
                {
                    //10兆字节(mb)=10485760字节(b)
                    if (file[i].ContentLength > Constant.APPUploadFileMaxLenth ||
                        (file[i].ContentType.ToLower().Contains("image") == false && file[i].ContentType.ToLower().Contains("png") == false && file[i].ContentType.ToLower().Contains("jpg") == false && file[i].ContentType.ToLower().Contains("jpeg") == false))
                    {
                        result = false;
                        Game.Library.Log.WriteLogInfo("UploadFaceEx", new Exception("UserID:" + RequestUserID + " FileType:" + file[i].ContentType.ToLower()));
                        break;
                    }
                }
                return result;
            }
            Game.Library.Log.WriteLogInfo("UploadFaceEx", new Exception("UserID:" + RequestUserID + " 无文件信息"));
            return false;
        }

        #region 获取参数
        protected int RequestCode
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryInt("code", 0);
            }
        }

        /// <summary>
        /// 用户GameID
        /// </summary>
        protected int RequestUserID
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryInt("userid", 0);
            }
        }
        /// <summary>
        /// 登录WebKey
        /// </summary>
        protected string RequestWebKey
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryString("webkey");
            }
        }
        /// <summary>
        /// 设备类型
        /// </summary>
        protected int DeviceType
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryInt("devicetype", (int)Game.Type.SigninEquipment.IPhoneSignIn);
            }
        }
        #endregion

        #region 验证与签名
        /// <summary>
        /// 身份验证
        /// </summary>
        /// <returns></returns>
        protected UserInfo Verification()
        {
            if (RequestUserID > 0 && string.IsNullOrEmpty(RequestWebKey) == false)
            {
                //验证用户信息
                UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(RequestUserID);
                if (oUserInfo == null)
                {
                    this.SetResponseData(false, "用户无效！！", "", 0, null);
                }
                //验证签名
                string md5key = null;

                if (DeviceType == (int)SigninEquipment.PCSignIn) { md5key = oUserInfo.PCWebKey; };
                if (DeviceType != (int)SigninEquipment.PCSignIn) { md5key = oUserInfo.IOSWebKey; };


                if (md5key == null)
                {
                    this.SetResponseData(false, "设备类型无效！！", "", 0, null);
                }
                if (this.RequestWebKey != md5key.ToLower())
                {
                    this.SetResponseData(false, "用户登陆失败！", "", 0, null);
                }
                return oUserInfo;
            }
            else
            {
                this.SetResponseData(false, "服务器不接受此次请求！！", "", 0, null);
                return null;
            }
        }
        /// <summary>
        /// 验证签名(已登陆)
        /// </summary>
        /// <param name="devicetype">设备类型  0x00=PC 0x40=IOS 0x10=Android</param>
        /// <param name="userid">用户UserID</param>
        /// <param name="sign">客户端签名</param>
        /// <param name="requestdata">客户端发送数据包</param>
        /// <returns></returns>
        protected UserInfo ValidateSign(int devicetype, int userid, string sign, string requestdata)
        {
            //验证用户信息
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            if (oUserInfo == null) this.SetResponseData(false, "用户无效！", "", 0, null);
            //验证签名
            string md5key = null;
            if (devicetype == (int)SigninEquipment.PCSignIn) { md5key = oUserInfo.PCWebKey; };
            if (devicetype != (int)SigninEquipment.PCSignIn) { md5key = oUserInfo.IOSWebKey; };

            if (md5key == null) this.SetResponseData(false, "设备类型无效！！", "", 0, null);
            string signserver = Game.Utils.TextEncrypt.MD5EncryptPassword(md5key + requestdata);
            if (sign.ToLower() != signserver.ToLower())
            {
                // Game.Library.Log.WriteLogInfo("BaseMobileHandler", new Exception("devicetype:" + devicetype + "  WebKey:" + md5key + " requestSign:" + sign + "  signserver:" + signserver + "  requestdata:" + requestdata));
                this.SetResponseData(false, "验证签名无效！！", "", 0, null);
            }
            return oUserInfo;
        }
        /// <summary>
        /// 返回签名(已登陆)
        /// </summary>
        /// <param name="devicetype">SigninEquipment</param>
        /// <param name="userid"></param>
        /// <param name="responsedata"></param>
        /// <returns></returns>
        protected string ValidateResponseKey(int devicetype, int userid, object responsedata)
        {
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            if (oUserInfo == null) this.SetResponseData(false, "用户无效！！", "", 0, null);
            //验证签名
            string md5key = null;
            if (devicetype == (int)SigninEquipment.PCSignIn) { md5key = oUserInfo.PCWebKey; };
            if (devicetype != (int)SigninEquipment.PCSignIn) { md5key = oUserInfo.IOSWebKey; };

            if (md5key == null) this.SetResponseData(false, "设备类型无效！！", "", 0, null);
            responsedata = Newtonsoft.Json.JsonConvert.SerializeObject(responsedata);
            return Game.Utils.TextEncrypt.MD5EncryptPassword(md5key + responsedata);
        }
        #endregion

        #region 参数设置

        /// <summary>
        /// 基础请求
        /// </summary>
        /// <param name="context"></param>
        protected void setProcessRequest(HttpContext context)
        {
            response.Clear();
            response.CacheControl = "no-cache";
            response.ContentEncoding = Encoding.UTF8;
            switch (this.ResponseDataFormat)
            {
                case BaseMobileHandlerResponseFormat.JSON:
                    {
                        response.ContentType = "application/json";
                        response.Write(this.ResponsePackage);
                        break;
                    }
                case BaseMobileHandlerResponseFormat.JSONObject:
                    {
                        response.ContentType = "application/json";
                        string json = JsonConvert.SerializeObject(this.ResponsePackage);
                        response.Write(json);
                        break;
                    }
                case BaseMobileHandlerResponseFormat.XML:
                    {
                        response.ContentType = "application/xml";
                        response.Write(this.ResponsePackage);
                        break;
                    }
                case BaseMobileHandlerResponseFormat.Binary:
                    {
                        response.ContentType = "application/octet-stream";
                        response.BinaryWrite((this.ResponsePackage as byte[]));
                        break;
                    }
                case BaseMobileHandlerResponseFormat.Text:
                    {
                        response.Write(this.ResponsePackage);
                        break;
                    }
            }
            response.End();
        }
        /// <summary>
        /// 返回数据包对象
        /// </summary>
        private object _ResponsePackage = null;
        public object ResponsePackage
        {
            get
            {
                return this._ResponsePackage;
            }
            set
            {
                this._ResponsePackage = value;
            }
        }

        /// <summary>
        /// 设置发送数据包 JSON对象格式专用
        /// </summary>
        /// <param name="status">状态</param>
        /// <param name="message">消息</param>
        /// <param name="sign">数据包签名</param>
        /// <param name="data">数据包</param>
        protected void SetResponseData(bool status, string message, string sign, int cmd, object data)
        {
            this.ResponseDataFormat = BaseMobileHandlerResponseFormat.JSONObject;
            Hashtable hashtable = new Hashtable();
            hashtable.Add("cmd", cmd);
            hashtable.Add("sign", sign);
            hashtable.Add("status", status);
            hashtable.Add("message", message);
            hashtable.Add("data", data);
            this.ResponsePackage = hashtable;
            response.Write(this.ResponsePackage);
            setProcessRequest(context);
        }

        /// <summary>
        /// 返回数据格式 
        /// </summary>
        private BaseMobileHandlerResponseFormat _ResponseDataFormat = BaseMobileHandlerResponseFormat.JSONObject;
        public BaseMobileHandlerResponseFormat ResponseDataFormat
        {
            get { return _ResponseDataFormat; }
            set { _ResponseDataFormat = value; }
        }
        /// <summary>
        /// 返回数据格式
        /// </summary>
        public enum BaseMobileHandlerResponseFormat
        {
            JSON = 1,
            JSONObject = 2,
            XML = 3,
            Binary = 4,
            Text = 5,
        }
        #endregion
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

    }

}