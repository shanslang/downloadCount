﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Game.Facade;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using System.Collections;
using System.Web.Script.Serialization;
namespace Game.AppServices.api
{
    public partial class GameVersionRollback : System.Web.UI.Page
    {
        protected NativeWebFacade oNativeWebFacade = new NativeWebFacade();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
#if !DEBUG
                if (RequestWebKey != oNativeWebFacade.GetUpLoadDeployKey())
                {
                    Response.End();
                    return;
                }
#endif
                bind();
            }
        }
        /// <summary>
        /// 登录WebKey
        /// </summary>
        protected string RequestWebKey
        {
            get
            {
                return Game.Utils.GameRequest.GetQueryString("webkey");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            bind();
        }
        void bind()
        {
            string gamefilename = string.Format("/Upload/mobileupdateBattle/{0}", dpGameName.SelectedValue);
            lblversion.Text = ReadJson(Server.MapPath(gamefilename + "//version.manifest"), "version");
            DirectoryInfo dir = new DirectoryInfo(Server.MapPath(gamefilename));
            List<GameVersion> gameConfigList = new List<GameVersion>();
            foreach (var item in dir.GetDirectories())
            {
                string versioninfo = ReadFile(string.Format("{0}//version.ini", item.FullName));
                string[] strDatas = versioninfo.Split(new char[] { ';', '；' });
                string version = string.Empty;
                string restartFlag = string.Empty;
                if (strDatas.Length == 3)
                {
                    version = strDatas[1].Split(new char[] { '=', '=' })[1];
                    restartFlag = strDatas[2].Split(new char[] { '=', '=' })[1];
                }
                gameConfigList.Add(new GameVersion() { DriectoryName = item.Name, Version = version, RestartFlag = restartFlag });
            }
            repgameversion.DataSource = gameConfigList.OrderByDescending(n => n.DriectoryName);
            repgameversion.DataBind();
        }
        private string ReadFile(string filePath)
        {
            if (File.Exists(filePath))
            {
                StreamReader sr = new StreamReader(filePath, Encoding.Default);
                string result = sr.ReadToEnd();
                sr.Close();
                return result;
            }
            else
                return string.Empty;
        }
        private string ReadJson(string filePath, string strKey)
        {
            string jsonText = ReadFile(filePath);
            if (jsonText != string.Empty)
            {
                bool isKey = false;
                JsonReader reader = new JsonTextReader(new StringReader(jsonText));
                while (reader.Read())
                {
                    if (isKey)
                        return reader.Value.ToString().Trim();
                    if (reader.Value != null && reader.Value.ToString() == strKey)
                        isKey = true;
                }
            }
            return "";
        }
        /// <summary>
        /// 获取文件MD5
        /// </summary>
        /// <returns></returns>
        private string LoadFileMD5(string filepath)
        {
            try
            {
                if (File.Exists(filepath))
                {
                    FileStream file = new FileStream(filepath, System.IO.FileMode.Open);
                    System.Security.Cryptography.MD5 md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
                    byte[] retVal = md5.ComputeHash(file);
                    file.Close();
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < retVal.Length; i++)
                    {
                        sb.Append(retVal[i].ToString("X2"));
                    }
                    return sb.ToString();
                }
                return "";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        private void WriteFile(string savepath, Hashtable filesHashtable)
        {
            if (File.Exists(savepath))
            {
                File.Delete(savepath);
            }
            FileStream fs = new FileStream(savepath, FileMode.Create);
            //获得字节数组
            byte[] data = System.Text.Encoding.Default.GetBytes(new JavaScriptSerializer().Serialize(filesHashtable));
            //开始写入
            fs.Write(data, 0, data.Length);
            //清空缓冲区、关闭流
            fs.Flush();
            fs.Close();
        }
        private string hostaddress
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["AppDownloadtDeployurl"].ToString();
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            string gamefilename = string.Format("/Upload/mobileupdateBattle/{0}/{1}/", dpGameName.SelectedValue, hidfilename.Value);
            DirectoryInfo dir = new DirectoryInfo(Server.MapPath(gamefilename));
            var fileinfo = dir.GetFiles("*", SearchOption.AllDirectories);
            Hashtable filesMd5Hashtable = new Hashtable();
            foreach (var item in fileinfo)
            {
                string name = item.FullName.Replace(Server.MapPath(gamefilename), "").Replace("\\", "/");
                if (name != "version.ini")
                {
                    if (!name.Contains("/_") && !name.Contains("/.") && name.Substring(0, 1) != "." && name.Substring(0, 1) != "_")
                    {
                        Hashtable tem = new Hashtable();
                        tem.Add("md5", LoadFileMD5(item.FullName));
                        filesMd5Hashtable.Add(name.Replace(".dat", ""), tem);
                    }
                }
            }
            string path = Server.MapPath(string.Format("/Upload/mobileupdateBattle/{0}/", dpGameName.SelectedValue));
            Hashtable filesHashtable = new Hashtable();
            filesHashtable.Add("packageUrl", hostaddress + string.Format("/Upload/mobileupdateBattle/{0}/", dpGameName.SelectedValue));
            filesHashtable.Add("packageFlieName", "_" + hidfilename.Value + ".dat");
            filesHashtable.Add("remoteManifestUrl", hostaddress + "/api/update.aspx?name=project");
            filesHashtable.Add("remoteVersionUrl", hostaddress + "/api/update.aspx?name=version");
            filesHashtable.Add("version", hidversion.Value);
            filesHashtable.Add("engineVersion", "3.0");
            filesHashtable.Add("restartFlag", hidrestartFlag.Value);
            WriteFile(path + "version.manifest", filesHashtable);
            filesHashtable.Add("assets", filesMd5Hashtable);
            WriteFile(path + "project.manifest", filesHashtable);
            bind();
        }
    }
    public class GameVersion
    {
        public string DriectoryName { set; get; }
        public string Version { set; get; }
        public string RestartFlag { set; get; }
    }
}