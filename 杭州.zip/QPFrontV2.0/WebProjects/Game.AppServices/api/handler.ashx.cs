﻿using Game.Entity.Accounts;
using Game.Entity.NativeWeb;
using Game.Entity.Treasure;
using Game.Facade;
using Game.Francis;
using Game.Utils;
using Game.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace Game.AppServices.api
{
    /// <summary>
    /// api 的摘要说明
    /// </summary>
    public class handler : BaseHandler
    {
        private TreasureFacade oTreasureFacade = new TreasureFacade();
        private AccountsFacade oAccountsFacade = new AccountsFacade();
        private NativeWebFacade oNativeWebFacade = new NativeWebFacade();
        private GamePropertyFacade oGamePropertyFacade = new GamePropertyFacade();

        #region 通用处理
        /// <summary>
        /// 响应处理
        /// </summary>
        /// <param name="context"></param>
        public override void ProcessRequest(HttpContext context)
        {
            try
            {
                string m = context.Request.QueryString["m"];
                System.Reflection.MethodInfo method = base.GetType().GetMethod(m);
                if (method != null)
                {
                    method.Invoke(this, null);
                }
            }
            catch (Exception exception)
            {
                Exception exp = (exception.InnerException != null) ? exception.InnerException : exception;
                Game.Library.Log.WriteLogInfo(exp);
                string msg = string.Format("处理失败！请联系客服Tel:{0},QQ:{1}", Game.AppServices.Constant.ServicePhone, Game.AppServices.Constant.ServiceQQ);
                this.ResponseClient(false, exp.Message, null);
            }
            finally
            {
                context.Response.End();
            }
        }
        /// <summary>
        /// 回发数据
        /// </summary>
        /// <param name="status"></param>
        /// <param name="message"></param>
        /// <param name="data"></param>
        public void ResponseClient(bool status, string message, object data)
        {
            this.CallBackData(status, message, data);
            HttpResponse response = HttpContext.Current.Response;
            response.CacheControl = "no-cache";
            response.ContentEncoding = System.Text.Encoding.UTF8;
            IsoDateTimeConverter convert = new IsoDateTimeConverter();
            convert.DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
            string s = JsonConvert.SerializeObject(this.ResponsePackage, Formatting.None, convert);
            response.ContentType = "application/json";
            response.Write(s);
        }
        #endregion

        #region 基础验证
        /// <summary>
        /// 验证用户
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        private UserInfo ValidateUser(int userid)
        {
            //验证用户信息
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            if (oUserInfo == null) throw new Exception("用户无效！");
            //返回用户信息
            return oUserInfo;
        }

        /// <summary>
        /// 验证签名
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="sign"></param>
        /// <param name="requestjson"></param>
        private UserInfo ValidateSign(int userid, string sign, string requestjson)
        {

            //验证用户信息
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            if (oUserInfo == null) throw new Exception("用户无效！");
            //验证签名
            string signserver = Game.Utils.TextEncrypt.MD5EncryptPassword(oUserInfo.LogonPass + requestjson);
            if (sign.ToLower() != signserver.ToLower()) throw new Exception("验证签名无效！");
            //返回用户信息
            return oUserInfo;
        }
        #endregion

        #region 获取用户信息
        /// <summary>
        /// 获取用户信息接口
        /// </summary>
        public void getaccountinfo()
        {
            HttpContext context = HttpContext.Current;
            string sign = HttpUtility.UrlDecode(context.Request.Form["sign"]);
            string requestjson = HttpUtility.UrlDecode(context.Request.Form["data"]);
            //parameters
            Dictionary<string, object> requestparms = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(requestjson);
            int paramUserID = Convert.ToInt32(requestparms["UserID"]);
            //验证用户信息
            UserInfo oUserInfo = this.ValidateSign(paramUserID, sign, requestjson);

            Hashtable htResult = new Hashtable();
            htResult.Add("UserID", oUserInfo.UserID);
            htResult.Add("GameID", oUserInfo.GameID);
            htResult.Add("Accounts", oUserInfo.Accounts);
            htResult.Add("NickName", oUserInfo.NickName);
            htResult.Add("Experience", oUserInfo.Experience);
            htResult.Add("Present", oUserInfo.Present);
            if (oUserInfo.GameScoreInfoEx != null)
            {
                htResult.Add("LoveLiness", oUserInfo.GameScoreInfoEx.LoveLiness);
            }
            else
            {
                htResult.Add("LoveLiness", 0);
            }
            htResult.Add("MemberOrder", oUserInfo.MemberOrder);
            htResult.Add("MemberOverDate", oUserInfo.MemberOverDate);
            if (oUserInfo.GameScoreInfo != null)
            {
                htResult.Add("Score", oUserInfo.GameScoreInfo.Score);
                htResult.Add("InsureScore", oUserInfo.GameScoreInfo.InsureScore);
                htResult.Add("WinCount", oUserInfo.GameScoreInfo.WinCount);
                htResult.Add("LostCount", oUserInfo.GameScoreInfo.LostCount);
                htResult.Add("DrawCount", oUserInfo.GameScoreInfo.DrawCount);
                htResult.Add("FleeCount", oUserInfo.GameScoreInfo.FleeCount);
            }
            else
            {
                htResult.Add("Score", 0);
                htResult.Add("InsureScore", 0);
                htResult.Add("WinCount", 0);
                htResult.Add("LostCount", 0);
                htResult.Add("DrawCount", 0);
                htResult.Add("FleeCount", 0);
            }
            if (oUserInfo.UserGoldenBean != null)
            {
                htResult.Add("GoldenBean", oUserInfo.UserGoldenBean.GoldenBean);
            }
            else
            {
                htResult.Add("GoldenBean", 0);
            }
            htResult.Add("AccountsMemberList", oUserInfo.AccountsMemberList);
            if (Game.Library.Utility.IsMobileNumber(oUserInfo.AuthMTelephone))
            {
                htResult.Add("AuthMTelephone", oUserInfo.AuthMTelephone);
            }
            else
            {
                htResult.Add("AuthMTelephone", "0");
            }
            //添加今天是否签到
            IList<RecordDailySign> listRecordDailySign = oNativeWebFacade.GetCurrentMonthDailySignList(oUserInfo.UserID);
            if (listRecordDailySign != null)
            {
                bool issign = listRecordDailySign.Where(d => d.SignTime.ToString("yyyyMMdd") == DateTime.Now.ToString("yyyyMMdd")).Count() > 0;
                htResult.Add("IsSign", issign ? 1 : 0);
            }
            else
            {
                htResult.Add("IsSign", 0);
            }
            //是否打开比赛
            htResult.Add("IsOpenMatch", Constant.IsOpenMatch);
            //是否打开转账 
            htResult.Add("IsOpenTransfer", Constant.IsOpenTransfer);

            this.ResponseClient(true, "获取用户信息成功！", htResult);
        }
        #endregion

        #region 手机验证模块
        /// <summary>
        /// 发送手机短信验证码
        /// </summary>
        public void sendsmscode()
        {
            HttpContext context = HttpContext.Current;
            string sign = HttpUtility.UrlDecode(context.Request.Form["sign"]);
            string requestjson = HttpUtility.UrlDecode(context.Request.Form["data"]);
            //parameters
            Dictionary<string, object> requestparms = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(requestjson);
            int paramUserID = Convert.ToInt32(requestparms["UserID"]);
            string paramMobilePhoneNumber = Convert.ToString(requestparms["MobilePhoneNumber"]);
            //验证用户信息
            UserInfo oUserInfo = this.ValidateSign(paramUserID, sign, requestjson);
            //验证手机号码
            if (!Game.Library.Utility.IsMobileNumber(paramMobilePhoneNumber)) throw new Exception("手机号码无效！");
            //验证手机号码是否已绑定
            if (oAccountsFacade.IsAuthTelephoneExist(paramMobilePhoneNumber)) throw new Exception("此手机号码已绑定其它账号！");
            //生成短信验证码
            string smscode = oNativeWebFacade.BuilderCheckCode(Game.Type.AuthUseType.验证手机, paramUserID, paramMobilePhoneNumber, "");
            //编辑短信内容
            ResetCache();
            sbCache.AppendFormat("您的ID:{0}正在获取手机短信验证码，验证码为:{1}。", oUserInfo.GameID, smscode);
            //调用API发送短信
            try
            {
                Game.ThirdServices.SMSywwdHelper oSMSOper = new Game.ThirdServices.SMSywwdHelper(Game.Web.Constant.YWWDAccount, Game.Web.Constant.YWWDPass, Game.Web.Constant.YWWDSign);
                oSMSOper.Send(sbCache.ToString(), new List<string>() { paramMobilePhoneNumber });
            }
            catch (Exception exp)
            {
                Game.Library.Log.WriteLogInfo("sms", exp);
            }
            //发送客户端
            this.ResponseClient(true, "短信验证码已经下发至你的手机，请注意查收！", null);
        }

        /// <summary>
        /// 验证手机短信验证码
        /// </summary>
        public void checksmscode()
        {
            HttpContext context = HttpContext.Current;
            string sign = HttpUtility.UrlDecode(context.Request.Form["sign"]);
            string requestjson = HttpUtility.UrlDecode(context.Request.Form["data"]);
            //parameters
            Dictionary<string, object> requestparms = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(requestjson);
            int paramUserID = Convert.ToInt32(requestparms["UserID"]);
            string paramMobilePhoneNumber = Convert.ToString(requestparms["MobilePhoneNumber"]);
            string paramSmsCode = Convert.ToString(requestparms["SmsCode"]);
            //验证用户信息
            UserInfo oUserInfo = this.ValidateSign(paramUserID, sign, requestjson);

            //验证手机号码
            if (!Game.Library.Utility.IsMobileNumber(paramMobilePhoneNumber)) throw new Exception("手机号码无效！");
            try
            {
                oNativeWebFacade.AuthTelephone(oUserInfo.UserID, paramMobilePhoneNumber, paramSmsCode);
                //发送客户端
                this.ResponseClient(true, "恭喜您认证成功！", null);
            }
            catch (Exception exp)
            {
                this.ResponseClient(true, exp.Message, null);
            }
        }
        #endregion

        #region 血流内购模块
        /// <summary>
        /// 产生订单
        /// </summary>
        public void xladdrechorder()
        {
            HttpContext context = HttpContext.Current;
            string sign = HttpUtility.UrlDecode(context.Request.Form["sign"]);
            string requestjson = HttpUtility.UrlDecode(context.Request.Form["data"]);
            //parameters
            Dictionary<string, object> requestparms = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(requestjson);
            int paramUserID = Convert.ToInt32(requestparms["UserID"]);
            string paramAppleProductID = Convert.ToString(requestparms["AppleProductID"]);

            //参数验证
            if (string.IsNullOrEmpty(paramAppleProductID)) throw new Exception("产品ID不能为空！");

            //签名验证
            UserInfo oUserInfo = this.ValidateSign(paramUserID, sign, requestjson);

            //订单信息
            OnLineOrder oOnLineOrder = new OnLineOrder();
            oOnLineOrder.ShareID = (int)Game.Type.GlobalShareInfo.APPLE;//服务表示为快钱
            oOnLineOrder.OrderID = PayHelper.GetOrderIDByPrefix(Game.Type.GlobalShareInfo.APPLE.ToString());//生成订单号
            oOnLineOrder.OperUserID = oUserInfo.UserID;
            oOnLineOrder.Accounts = oUserInfo.Accounts;
            oOnLineOrder.CardTotal = 1;
            oOnLineOrder.CardTypeID = 1;
            oOnLineOrder.IPAddress = GameRequest.GetUserIP();

            //com.hbykrs.YKXLWTicket
            //com.hbykrs.YKXLMOTicket
            //黄钻7天      18               10万    com.hbykrs.YKXLVipYellowSeven
            //蓝钻7天      88               120万   com.hbykrs.YKXLVipBlueNewTen
            //黄钻10天    188               400万   com.hbykrs.YKXLVipYellowNewTen
            //蓝钻 10天   288               600万   com.hbykrs.YKXLVipBlueTen

            //购买门票
            if (paramAppleProductID == "com.hbykrs.YKXLWTicket" || paramAppleProductID == "com.hbykrs.YKXLMOTicket")
            {
                int propertypid = 0;
                int propernumber = 0;
                switch (paramAppleProductID)
                {
                    case "com.hbykrs.YKXLWTicket":
                        {
                            oOnLineOrder.OrderAmount = 6; //订单金额
                            oOnLineOrder.PayAmount = 6;//实付金额
                            propertypid = 8;
                            propernumber = 3;
                            break;
                        }
                    case "com.hbykrs.YKXLMOTicket":
                        {
                            oOnLineOrder.OrderAmount = 6; //订单金额
                            oOnLineOrder.PayAmount = 6;//实付金额
                            propertypid = 9;
                            propernumber = 1;
                            break;
                        }
                }
                if (propertypid == 0 || propernumber == 0) throw new Exception("无效的产品！");

                //订单用途
                oOnLineOrder.OrderUseType = (int)Game.Type.OrderUseType.购买道具;
                #region 生成订单及明细
                Message msgRequestOrder = oTreasureFacade.RequestOrder(oOnLineOrder);
                Message msgBuyProperDetails = oTreasureFacade.InsertBuyProperDetails(new BuyProperDetails()
                {
                    OrderID = oOnLineOrder.OrderID,
                    ProperPid = propertypid,
                    ProperNumber = propernumber
                });
                if (!msgBuyProperDetails.Success) throw new Exception("生成道具订单明细失败！");
                #endregion
            }
            //购买会员
            if (paramAppleProductID == "com.hbykrs.YKXLVipYellowSeven" || paramAppleProductID == "com.hbykrs.YKXLVipBlueNewTen" ||
                paramAppleProductID == "com.hbykrs.YKXLVipYellowNewTen" || paramAppleProductID == "com.hbykrs.YKXLVipBlueTen")
            {
                int memberorder = 0;
                int memeberdays = 0;
                switch (paramAppleProductID)
                {
                    case "com.hbykrs.YKXLVipYellowSeven":
                        {
                            oOnLineOrder.OrderAmount = 18; //订单金额
                            oOnLineOrder.PayAmount = 18;//实付金额
                            memberorder = (int)Game.Type.MemberLevel.一星会员;
                            memeberdays = 7;
                            break;
                        }
                    case "com.hbykrs.YKXLVipBlueNewTen":
                        {
                            oOnLineOrder.OrderAmount = 88; //订单金额
                            oOnLineOrder.PayAmount = 88;//实付金额
                            memberorder = (int)Game.Type.MemberLevel.二星会员;
                            memeberdays = 7;
                            break;
                        }
                    case "com.hbykrs.YKXLVipYellowNewTen":
                        {
                            oOnLineOrder.OrderAmount = 188; //订单金额
                            oOnLineOrder.PayAmount = 188;//实付金额
                            memberorder = (int)Game.Type.MemberLevel.一星会员;
                            memeberdays = 10;
                            break;
                        }
                    case "com.hbykrs.YKXLVipBlueTen":
                        {
                            oOnLineOrder.OrderAmount = 288; //订单金额
                            oOnLineOrder.PayAmount = 288;//实付金额
                            memberorder = (int)Game.Type.MemberLevel.二星会员;
                            memeberdays = 10;
                            break;
                        }
                }
                if (memberorder == 0 || memeberdays == 0) throw new Exception("无效的产品！");

                //订单用途
                oOnLineOrder.OrderUseType = (int)Game.Type.OrderUseType.购买会员;
                #region 生成订单及明细
                Message msgRequestOrder = oTreasureFacade.RequestOrder(oOnLineOrder);
                Message msgInsertBuyMemberOrderDetails = oTreasureFacade.InsertBuyMemberOrderDetails1(new BuyMemberOrderDetails1()
                {
                    OrderID = oOnLineOrder.OrderID,
                    MemberOrder = memberorder,
                    MemberDays = memeberdays
                });
                if (!msgInsertBuyMemberOrderDetails.Success) throw new Exception("生成会员订单明细失败！");
                #endregion
            }

            //返回结果集
            Hashtable result = new Hashtable();
            result.Add("OrderID", oOnLineOrder.OrderID);
            result.Add("OrderAmount", oOnLineOrder.OrderAmount);
            result.Add("AppleProductID", paramAppleProductID);
            this.ResponseClient(true, "生成订单成功！", result);
        }
        /// <summary>
        /// 血流处理订单
        /// </summary>
        public void xlprocessrechorder()
        {
            HttpContext context = HttpContext.Current;
            string sign = HttpUtility.UrlDecode(context.Request.Form["sign"]);
            string requestjson = HttpUtility.UrlDecode(context.Request.Form["data"]);
            //parameters
            Dictionary<string, object> requestparms = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(requestjson);
            int paramUserID = Convert.ToInt32(requestparms["UserID"]);
            string paramTransaction = Convert.ToString(requestparms["Transaction"]);
            string paramOrderID = Convert.ToString(requestparms["OrderID"]);

            //签名验证
            UserInfo oUserInfo = this.ValidateSign(paramUserID, sign, requestjson);

            //添加调试日志
            Game.Library.Log.WriteLogInfo("xlpay", new Exception("GameID:" + oUserInfo.GameID + "**********UserID:" + paramUserID + "**********Transaction：" + paramTransaction));

            //验证订单是否存在
            var oOnlineOrder = oTreasureFacade.GetOnlineOrder(paramOrderID);
            if (oOnlineOrder == null) throw new Exception("订单不存在！");
            if (oOnlineOrder.OrderStatus == (int)Game.Type.OnLineOrderStatus.处理完成)
            {
                //重新获取用户信息
                Hashtable resultdata = this.xlreturndata(paramUserID, oOnlineOrder.OrderID);
                if (oOnlineOrder.OrderUseType == (int)Game.Type.OrderUseType.购买会员)
                {
                    this.ResponseClient(true, "充值成功,请点击右上角的房卡查看会员信息！", resultdata);
                }
                else
                {
                    this.ResponseClient(true, "购买成功,请在我的道具里查看！", resultdata);
                }
                return;
            }

            //apple参数
            Dictionary<string, object> rparms = new Dictionary<string, object>();
            rparms.Add("receipt-data", paramTransaction);
            string body = Newtonsoft.Json.JsonConvert.SerializeObject(rparms);
            string url = Game.AppServices.Constant.APPLEIAPBuyUrl;
            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
            request.Method = "POST";
            request.ContentType = "application/json";
            byte[] data = System.Text.Encoding.UTF8.GetBytes(body);//发送主体
            using (Stream stream = request.GetRequestStream()) { stream.Write(data, 0, data.Length); }
            //获取结果
            StreamReader srdPreview = new StreamReader(request.GetResponse().GetResponseStream());
            string applejson = srdPreview.ReadToEnd();
            srdPreview.Close();
            var results = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(applejson);
            if (Convert.ToInt32(results["status"]) == 0)//苹果返回成功
            {
                var receipt = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(results["receipt"].ToString());
                //记录苹果返回数据包
                ReturnAppleIAPDetailInfo oReturnAppleIAPDetailInfo = new ReturnAppleIAPDetailInfo();
                oReturnAppleIAPDetailInfo.original_purchase_date_pst = receipt["original_purchase_date_pst"].ToString();
                oReturnAppleIAPDetailInfo.purchase_date_ms = receipt["purchase_date_ms"].ToString();
                oReturnAppleIAPDetailInfo.unique_identifier = receipt["unique_identifier"].ToString();
                oReturnAppleIAPDetailInfo.original_transaction_id = receipt["original_transaction_id"].ToString();
                oReturnAppleIAPDetailInfo.bvrs = receipt["bvrs"].ToString();
                oReturnAppleIAPDetailInfo.transaction_id = receipt["transaction_id"].ToString();
                oReturnAppleIAPDetailInfo.quantity = receipt["quantity"].ToString();
                oReturnAppleIAPDetailInfo.unique_vendor_identifier = receipt["unique_vendor_identifier"].ToString();
                oReturnAppleIAPDetailInfo.item_id = receipt["item_id"].ToString();
                oReturnAppleIAPDetailInfo.product_id = receipt["product_id"].ToString();
                oReturnAppleIAPDetailInfo.purchase_date = receipt["purchase_date"].ToString();
                oReturnAppleIAPDetailInfo.original_purchase_date = receipt["original_purchase_date"].ToString();
                oReturnAppleIAPDetailInfo.purchase_date_pst = receipt["purchase_date_pst"].ToString();
                oReturnAppleIAPDetailInfo.bid = receipt["bid"].ToString();
                oReturnAppleIAPDetailInfo.original_purchase_date_ms = receipt["original_purchase_date_ms"].ToString();
                oReturnAppleIAPDetailInfo.json = applejson;
                oReturnAppleIAPDetailInfo.orderid = oOnlineOrder.OrderID;
                oReturnAppleIAPDetailInfo.orderamount = oOnlineOrder.OrderAmount;
                oReturnAppleIAPDetailInfo.iap_transaction = paramTransaction;

                if (oReturnAppleIAPDetailInfo.bid != "com.hbykrs.SparrowXL")
                {
                    throw new Exception("非法APP操作！");
                }

                //处理订单
                Message omsg = oTreasureFacade.WriteAppleIAPRecharge(oOnlineOrder.OrderID, Constant.ReleaseVersion, oReturnAppleIAPDetailInfo);
                if (omsg.Success)
                {
                    //重新获取用户信息
                    Hashtable resultdata = this.xlreturndata(paramUserID, oOnlineOrder.OrderID);
                    if (oOnlineOrder.OrderUseType == (int)Game.Type.OrderUseType.购买会员)
                    {
                        this.ResponseClient(true, "充值成功,请点击右上角的房卡查看会员信息！", resultdata);
                    }
                    else
                    {
                        this.ResponseClient(true, "购买成功,请在我的道具里查看！", resultdata);
                    }
                    return;
                }
                else
                {
                    Game.Library.Log.WriteLogInfo(new Exception(omsg.Content));
                    throw new Exception("处理订单失败！");
                }
            }
            else throw new Exception("IAP验证失败！");
        }
        /// <summary>
        /// 重新获取用户信息
        /// </summary>
        /// <returns></returns>
        private Hashtable xlreturndata(int userid, string orderid)
        {
            Hashtable resultdata = new Hashtable();
            var oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(userid);
            if (oUserInfo != null)
            {
                if (oUserInfo.GameScoreInfo != null)
                {
                    resultdata.Add("Score", oUserInfo.GameScoreInfo.Score);
                }
                else
                {
                    resultdata.Add("Score", 0);
                }
                resultdata.Add("MemberOrder", oUserInfo.MemberOrder);
                resultdata.Add("MemberOverDate", oUserInfo.MemberOverDate);
                resultdata.Add("AccountsMemberList", oUserInfo.AccountsMemberList);
                resultdata.Add("OrderID", orderid);
            }
            else throw new Exception("重新获取用户信息失败！");
            return resultdata;
        }
        #endregion

        #region 获取道具门票
        /// <summary>
        /// 获取道具门票
        /// </summary>
        public void getmyticket()
        {
            HttpContext context = HttpContext.Current;
            string sign = HttpUtility.UrlDecode(context.Request.Form["sign"]);
            string requestjson = HttpUtility.UrlDecode(context.Request.Form["data"]);
            //parameters
            Dictionary<string, object> requestparms = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(requestjson);
            int paramUserID = Convert.ToInt32(requestparms["UserID"]);
            //验证用户信息
            UserInfo oUserInfo = this.ValidateSign(paramUserID, sign, requestjson);
            //查询用户门票信息
            DataSet ds = oGamePropertyFacade.GetUserPropertyRecordForIOS(oUserInfo.UserID, "and a.pid in (8,9)");
            this.ResponseClient(true, "获取道具门票成功！", ds.Tables[0]);
        }
        #endregion

        #region 暂时不用
        /// <summary>
        /// 玩家反馈
        /// </summary>
        public void feedback()
        {
            HttpContext context = HttpContext.Current;
            string sign = HttpUtility.UrlDecode(context.Request.Form["sign"]);
            string requestjson = HttpUtility.UrlDecode(context.Request.Form["data"]);
            //parameters
            Dictionary<string, object> requestparms = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(requestjson);
            int paramUserID = Convert.ToInt32(requestparms["UserID"]);
            string paramContent = Convert.ToString(requestparms["Content"]);

            //签名验证
            UserInfo oUserInfo = this.ValidateSign(paramUserID, sign, requestjson);

            //处理反馈
            GameFeedbackInfo info = new GameFeedbackInfo();
            info.Accounts = oUserInfo.Accounts;
            info.FeedbackTitle = TextFilter.FilterScript(paramContent);
            info.FeedbackContent = TextFilter.FilterScript(paramContent);
            info.ClientIP = GameRequest.GetUserIP();
            Message msg = oNativeWebFacade.PublishFeedback(info);
            if (msg.Success)
            {
                this.CallBackData(true, msg.Content, null);
            }
            else
            {
                this.CallBackData(true, msg.Content, null);
            }
        }
        /// <summary>
        /// 斗地主支付验证
        /// </summary>
        public void landpay()
        {
            HttpContext context = HttpContext.Current;

            //byte [] tran = new byte[context.Request.InputStream.Length];
            //context.Request.InputStream.Read(tran, 0, tran.Length);
            string requestjson = HttpUtility.UrlDecode(context.Request.Form["data"]);
            //parameters
            Dictionary<string, object> requestparms = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(requestjson);
            int paramUserID = Convert.ToInt32(requestparms["UserID"]);
            string paramTransaction = Convert.ToString(requestparms["Transaction"]);

            //验证用户信息
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(paramUserID);
            if (oUserInfo == null) throw new Exception("用户无效！");

            //base64 encode
            //byte[] buffer = System.Text.Encoding.ASCII.GetBytes(paramTransaction);
            string encodedReceipt = paramTransaction; //Convert.ToBase64String(buffer);

            //参数
            Dictionary<string, object> rparms = new Dictionary<string, object>();
            rparms.Add("receipt-data", encodedReceipt);
            string body = Newtonsoft.Json.JsonConvert.SerializeObject(rparms);

            //测试地址
            //string url = "https://sandbox.itunes.apple.com/verifyReceipt";
            //正式地址
            //string url = "https://buy.itunes.apple.com/verifyReceipt"
            string url = ApplicationSettings.Get("APPLEIAPBuyUrl");
            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
            request.Method = "POST";
            request.ContentType = "application/json";
            //发送主体
            byte[] data = System.Text.Encoding.UTF8.GetBytes(body);
            using (Stream stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }
            //获取结果
            string applejson = null;
            StreamReader srdPreview = new StreamReader(request.GetResponse().GetResponseStream());
            applejson = srdPreview.ReadToEnd();
            srdPreview.Close();
            var results = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(applejson);
            if (Convert.ToInt32(results["status"]) == 0)//苹果返回成功
            {
                var receipt = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(results["receipt"].ToString());
                string productpid = receipt["product_id"].ToString();

                decimal orderamount = 0;
                #region 产品ＩＤ
                /// 产品ＩＤ
                /// #define Product_ID1         @"com.hbykrs.Jindou12"
                /// #define Product_ID2         @"com.hbykrs.Jindou50"
                /// #define Product_ID3         @"com.hbykrs.Jindou108"
                /// #define Product_ID4         @"com.hbykrs.Jindou208"
                /// #define Product_ID5         @"com.hbykrs.Jindou518"
                /// #define Product_ID6         @"com.hbykrs.Jindou1048"
                switch (productpid)
                {
                    case "com.hbykrs.Jindou12":
                        {
                            orderamount = 12;
                            break;
                        }
                    case "com.hbykrs.Jindou50":
                        {
                            orderamount = 50;
                            break;
                        }
                    case "com.hbykrs.Jindou108":
                        {
                            orderamount = 108;
                            break;
                        }
                    case "com.hbykrs.Jindou208":
                        {
                            orderamount = 208;
                            break;
                        }
                    case "com.hbykrs.Jindou518":
                        {
                            orderamount = 518;
                            break;
                        }
                    case "com.hbykrs.Jindou1048":
                        {
                            orderamount = 1048;
                            break;
                        }
                }
                #endregion
                if (orderamount <= 0) throw new Exception("支付金额错误！");

                #region 充值金豆
                RechOrder oRechOrder = new RechOrder();
                oRechOrder.OrderID = PayHelper.GetOrderIDByPrefix(Game.Type.GlobalShareInfo.APPLE.ToString());//生成订单号
                oRechOrder.UserID = oUserInfo.UserID;
                oRechOrder.OperUserID = oUserInfo.UserID;
                oRechOrder.ShareID = (int)Game.Type.GlobalShareInfo.APPLE;//服务表示为快钱
                oRechOrder.OrderAmount = orderamount;//订单金额
                oRechOrder.DiscountScale = 0;//折扣
                oRechOrder.PayAmount = orderamount;//实付金额
                oRechOrder.OrderStatus = (int)Game.Type.RechOrderStatus.未付款;
                oRechOrder.ClientIP = GameRequest.GetUserIP();
                oRechOrder.ApplyDate = DateTime.Now;

                //生成订单
                Message msgRequestOrder = oTreasureFacade.InsertRechOrder(oRechOrder);
                if (msgRequestOrder.Success)//订单生成成功
                {
                    //处理订单
                    ReturnAppleIAPDetailInfo oReturnAppleIAPDetailInfo = new ReturnAppleIAPDetailInfo();
                    oReturnAppleIAPDetailInfo.original_purchase_date_pst = receipt["original_purchase_date_pst"].ToString();
                    oReturnAppleIAPDetailInfo.purchase_date_ms = receipt["purchase_date_ms"].ToString();
                    oReturnAppleIAPDetailInfo.unique_identifier = receipt["unique_identifier"].ToString();
                    oReturnAppleIAPDetailInfo.original_transaction_id = receipt["original_transaction_id"].ToString();
                    oReturnAppleIAPDetailInfo.bvrs = receipt["bvrs"].ToString();
                    oReturnAppleIAPDetailInfo.transaction_id = receipt["transaction_id"].ToString();
                    oReturnAppleIAPDetailInfo.quantity = receipt["quantity"].ToString();
                    oReturnAppleIAPDetailInfo.unique_vendor_identifier = receipt["unique_vendor_identifier"].ToString();
                    oReturnAppleIAPDetailInfo.item_id = receipt["item_id"].ToString();
                    oReturnAppleIAPDetailInfo.product_id = receipt["product_id"].ToString();
                    oReturnAppleIAPDetailInfo.purchase_date = receipt["purchase_date"].ToString();
                    oReturnAppleIAPDetailInfo.original_purchase_date = receipt["original_purchase_date"].ToString();
                    oReturnAppleIAPDetailInfo.purchase_date_pst = receipt["purchase_date_pst"].ToString();
                    oReturnAppleIAPDetailInfo.bid = receipt["bid"].ToString();
                    oReturnAppleIAPDetailInfo.original_purchase_date_ms = receipt["original_purchase_date_ms"].ToString();
                    oReturnAppleIAPDetailInfo.json = applejson;
                    oReturnAppleIAPDetailInfo.orderid = oRechOrder.OrderID;
                    oReturnAppleIAPDetailInfo.orderamount = orderamount;
                    oReturnAppleIAPDetailInfo.iap_transaction = paramTransaction;

                    Message omsg = oTreasureFacade.WriteAppleIAPRecharge(oRechOrder.OrderID, Constant.ReleaseVersion, oReturnAppleIAPDetailInfo);
                    if (omsg.Success)
                    {
                        //重新获取用户信息
                        oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(paramUserID);
                        Hashtable resultdata = new Hashtable();
                        resultdata.Add("Score", oUserInfo.GameScoreInfo.Score);
                        resultdata.Add("GoldenBean", oUserInfo.UserGoldenBean.GoldenBean);
                        //订单处理成功
                        this.ResponseClient(true, "充值成功，请到银行查收！", resultdata);
                    }
                    else throw new Exception("处理订单失败！");
                }
                else throw new Exception("生成订单失败！");
                #endregion
            }
            else throw new Exception("IAP验证失败！");
        }
        /// <summary>
        /// 兑换金豆为会员和金币
        /// </summary>
        public void convertgoldenbean()
        {
            HttpContext context = HttpContext.Current;
            string sign = HttpUtility.UrlDecode(context.Request.Form["sign"]);
            string requestjson = HttpUtility.UrlDecode(context.Request.Form["data"]);
            //parameters
            Dictionary<string, object> requestparms = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(requestjson);
            int paramUserID = Convert.ToInt32(requestparms["UserID"]);
            int paramGoldenBeanNumber = Convert.ToInt32(requestparms["GoldenBeanNumber"]);

            //验证用户信息
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(paramUserID);
            if (oUserInfo == null) throw new Exception("用户无效！");
            //验证签名
            string signserver = Game.Utils.TextEncrypt.MD5EncryptPassword(oUserInfo.LogonPass + requestjson);
            if (sign.ToLower() != signserver.ToLower()) throw new Exception("验证签名无效！");

            //数据库处理
            //Message msg = oTreasureFacade.ConvertGoldenBeanToMemberAndGold(paramUserID, paramGoldenBeanNumber);
            //if (msg.Success)
            //{
            //    //重新获取用户信息
            //    oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(paramUserID);
            //    Hashtable resultdata = new Hashtable();
            //    resultdata.Add("Score", oUserInfo.GameScoreInfo.Score);
            //    resultdata.Add("GoldenBean", oUserInfo.UserGoldenBean.GoldenBean);
            //    //处理成功
            //    this.ResponseClient(true, msg.Content, resultdata);
            //}
            //else this.ResponseClient(false, msg.Content, null);
        }
        #endregion

        #region 旧版本
        /// <summary>
        /// 血流支付验证
        /// </summary>
        public void xlpay()
        {
            HttpContext context = HttpContext.Current;

            //byte [] tran = new byte[context.Request.InputStream.Length];
            //context.Request.InputStream.Read(tran, 0, tran.Length);
            string requestjson = HttpUtility.UrlDecode(context.Request.Form["data"]);
            //parameters
            Dictionary<string, object> requestparms = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(requestjson);
            int paramUserID = Convert.ToInt32(requestparms["UserID"]);
            string paramTransaction = Convert.ToString(requestparms["Transaction"]);

            //验证用户信息
            UserInfo oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(paramUserID);
            if (oUserInfo == null) throw new Exception("用户无效！");

            //添加调试日志
            Game.Library.Log.WriteLogInfo("xlpay", new Exception("GameID:" + oUserInfo.GameID + "**********UserID:" + paramUserID + "**********Transaction：" + paramTransaction));

            //base64 encode
            //byte[] buffer = System.Text.Encoding.ASCII.GetBytes(paramTransaction);
            string encodedReceipt = paramTransaction; //Convert.ToBase64String(buffer);

            //参数
            Dictionary<string, object> rparms = new Dictionary<string, object>();
            rparms.Add("receipt-data", encodedReceipt);
            string body = Newtonsoft.Json.JsonConvert.SerializeObject(rparms);

            //测试地址
            //string url = "https://sandbox.itunes.apple.com/verifyReceipt";
            //正式地址
            //string url = "https://buy.itunes.apple.com/verifyReceipt"
            string url = Constant.APPLEIAPBuyUrl;
            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
            request.Method = "POST";
            request.ContentType = "application/json";
            //发送主体
            byte[] data = System.Text.Encoding.UTF8.GetBytes(body);
            using (Stream stream = request.GetRequestStream()) { stream.Write(data, 0, data.Length); }
            //获取结果
            string applejson = null;
            StreamReader srdPreview = new StreamReader(request.GetResponse().GetResponseStream());
            applejson = srdPreview.ReadToEnd();
            srdPreview.Close();
            var results = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(applejson);
            if (Convert.ToInt32(results["status"]) == 0)//苹果返回成功
            {
                var receipt = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(results["receipt"].ToString());
                string productpid = receipt["product_id"].ToString();

                int memberorder = 0;
                int memberdays = 0;
                decimal orderamount = 0;
                #region 产品ＩＤ
                /// 产品ＩＤ
                /// #define Product_ID1         @"com.hbykrs.YKXLVipYellow3"
                /// #define Product_ID2         @"com.hbykrs.YKXLVipYellow7"
                /// #define Product_ID3         @"com.hbykrs.YKXLVipBlue3"
                /// #define Product_ID4         @"com.hbykrs.YKXLVipBlue7"
                switch (productpid)
                {
                    case "com.hbykrs.YKXLVipYellow3":
                        {
                            memberorder = (int)Game.Type.MemberLevel.一星会员;
                            memberdays = 3;
                            orderamount = 18;
                            break;
                        }
                    case "com.hbykrs.YKXLVipYellow7":
                        {
                            memberorder = (int)Game.Type.MemberLevel.一星会员;
                            memberdays = 7;
                            orderamount = 88;
                            break;
                        }
                    case "com.hbykrs.YKXLVipBlue3":
                        {
                            memberorder = (int)Game.Type.MemberLevel.二星会员;
                            memberdays = 3;
                            orderamount = 188;
                            break;
                        }
                    case "com.hbykrs.YKXLVipBlue7":
                        {
                            memberorder = (int)Game.Type.MemberLevel.二星会员;
                            memberdays = 7;
                            orderamount = 288;
                            break;
                        }
                }
                #endregion
                if (orderamount <= 0) throw new Exception("支付金额错误！");

                #region 充值会员送金币
                OnLineOrder oOnLineOrder = new OnLineOrder();
                oOnLineOrder.ShareID = (int)Game.Type.GlobalShareInfo.APPLE;//服务表示为快钱
                oOnLineOrder.OrderID = PayHelper.GetOrderIDByPrefix(Game.Type.GlobalShareInfo.APPLE.ToString());//生成订单号
                oOnLineOrder.OperUserID = oUserInfo.UserID;
                oOnLineOrder.Accounts = oUserInfo.Accounts;
                oOnLineOrder.CardTotal = 1;
                oOnLineOrder.CardTypeID = 1;
                oOnLineOrder.OrderAmount = orderamount; //订单金额
                oOnLineOrder.PayAmount = orderamount;//实付金额
                oOnLineOrder.IPAddress = GameRequest.GetUserIP();
                oOnLineOrder.OrderUseType = (int)Game.Type.OrderUseType.购买会员;
                //生成订单
                Message msgRequestOrder = oTreasureFacade.RequestOrder(oOnLineOrder);
                #region 生成订单明细
                Message msgInsertBuyMemberOrderDetails = oTreasureFacade.InsertBuyMemberOrderDetails1(new BuyMemberOrderDetails1()
                {
                    OrderID = oOnLineOrder.OrderID,
                    MemberOrder = memberorder,
                    MemberDays = memberdays
                });
                if (!msgInsertBuyMemberOrderDetails.Success) throw new Exception("生成订单明细失败！");
                #endregion

                if (msgRequestOrder.Success)//订单生成成功
                {
                    //处理订单
                    ReturnAppleIAPDetailInfo oReturnAppleIAPDetailInfo = new ReturnAppleIAPDetailInfo();
                    oReturnAppleIAPDetailInfo.original_purchase_date_pst = receipt["original_purchase_date_pst"].ToString();
                    oReturnAppleIAPDetailInfo.purchase_date_ms = receipt["purchase_date_ms"].ToString();
                    oReturnAppleIAPDetailInfo.unique_identifier = receipt["unique_identifier"].ToString();
                    oReturnAppleIAPDetailInfo.original_transaction_id = receipt["original_transaction_id"].ToString();
                    oReturnAppleIAPDetailInfo.bvrs = receipt["bvrs"].ToString();
                    oReturnAppleIAPDetailInfo.transaction_id = receipt["transaction_id"].ToString();
                    oReturnAppleIAPDetailInfo.quantity = receipt["quantity"].ToString();
                    oReturnAppleIAPDetailInfo.unique_vendor_identifier = receipt["unique_vendor_identifier"].ToString();
                    oReturnAppleIAPDetailInfo.item_id = receipt["item_id"].ToString();
                    oReturnAppleIAPDetailInfo.product_id = receipt["product_id"].ToString();
                    oReturnAppleIAPDetailInfo.purchase_date = receipt["purchase_date"].ToString();
                    oReturnAppleIAPDetailInfo.original_purchase_date = receipt["original_purchase_date"].ToString();
                    oReturnAppleIAPDetailInfo.purchase_date_pst = receipt["purchase_date_pst"].ToString();
                    oReturnAppleIAPDetailInfo.bid = receipt["bid"].ToString();
                    oReturnAppleIAPDetailInfo.original_purchase_date_ms = receipt["original_purchase_date_ms"].ToString();
                    oReturnAppleIAPDetailInfo.json = applejson;
                    oReturnAppleIAPDetailInfo.orderid = oOnLineOrder.OrderID;
                    oReturnAppleIAPDetailInfo.orderamount = orderamount;
                    oReturnAppleIAPDetailInfo.iap_transaction = paramTransaction;

                    if (oReturnAppleIAPDetailInfo.bid != "com.hbykrs.SparrowXL")
                    {
                        throw new Exception("非法APP操作！");
                    }

                    Message omsg = oTreasureFacade.WriteAppleIAPRecharge(oOnLineOrder.OrderID, Constant.ReleaseVersion, oReturnAppleIAPDetailInfo);
                    if (omsg.Success)
                    {
                        //重新获取用户信息
                        oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(paramUserID);
                        Hashtable resultdata = new Hashtable();
                        resultdata.Add("Score", oUserInfo.GameScoreInfo.Score);
                        resultdata.Add("MemberOrder", oUserInfo.MemberOrder);
                        resultdata.Add("MemberOverDate", oUserInfo.MemberOverDate);
                        resultdata.Add("AccountsMemberList", oUserInfo.AccountsMemberList);
                        //订单处理成功
                        this.ResponseClient(true, "充值成功！", resultdata);
                    }
                    else
                    {
                        Game.Library.Log.WriteLogInfo(new Exception(omsg.Content));
                        throw new Exception("处理订单失败！");
                    }
                }
                else
                {
                    Game.Library.Log.WriteLogInfo(new Exception(msgRequestOrder.Content));
                    throw new Exception("生成订单失败！");
                }
                #endregion

                #region 充值金豆
                //RechOrder oRechOrder = new RechOrder();
                //oRechOrder.OrderID = PayHelper.GetOrderIDByPrefix(Game.Type.GlobalShareInfo.APPLE.ToString());//生成订单号
                //oRechOrder.UserID = oUserInfo.UserID;
                //oRechOrder.OperUserID = oUserInfo.UserID;
                //oRechOrder.ShareID = (int)Game.Type.GlobalShareInfo.KQ;//服务表示为快钱
                //oRechOrder.OrderAmount = orderamount;//订单金额
                //oRechOrder.DiscountScale = 0;//折扣
                //oRechOrder.PayAmount = orderamount;//实付金额
                //oRechOrder.OrderStatus = (int)Game.Type.RechOrderStatus.未付款;
                //oRechOrder.ClientIP = GameRequest.GetUserIP();
                //oRechOrder.ApplyDate = DateTime.Now;

                ////生成订单
                //Message msgRequestOrder = oTreasureFacade.InsertRechOrder(oRechOrder);
                //if (msgRequestOrder.Success)//订单生成成功
                //{
                //    //处理订单
                //    ReturnAppleIAPDetailInfo oReturnAppleIAPDetailInfo = new ReturnAppleIAPDetailInfo();
                //    oReturnAppleIAPDetailInfo.original_purchase_date_pst = receipt["original_purchase_date_pst"].ToString();
                //    oReturnAppleIAPDetailInfo.purchase_date_ms = receipt["purchase_date_ms"].ToString();
                //    oReturnAppleIAPDetailInfo.unique_identifier = receipt["unique_identifier"].ToString();
                //    oReturnAppleIAPDetailInfo.original_transaction_id = receipt["original_transaction_id"].ToString();
                //    oReturnAppleIAPDetailInfo.bvrs = receipt["bvrs"].ToString();
                //    oReturnAppleIAPDetailInfo.transaction_id = receipt["transaction_id"].ToString();
                //    oReturnAppleIAPDetailInfo.quantity = receipt["quantity"].ToString();
                //    oReturnAppleIAPDetailInfo.unique_vendor_identifier = receipt["unique_vendor_identifier"].ToString();
                //    oReturnAppleIAPDetailInfo.item_id = receipt["item_id"].ToString();
                //    oReturnAppleIAPDetailInfo.product_id = receipt["product_id"].ToString();
                //    oReturnAppleIAPDetailInfo.purchase_date = receipt["purchase_date"].ToString();
                //    oReturnAppleIAPDetailInfo.original_purchase_date = receipt["original_purchase_date"].ToString();
                //    oReturnAppleIAPDetailInfo.purchase_date_pst = receipt["purchase_date_pst"].ToString();
                //    oReturnAppleIAPDetailInfo.bid = receipt["bid"].ToString();
                //    oReturnAppleIAPDetailInfo.original_purchase_date_ms = receipt["original_purchase_date_ms"].ToString();
                //    oReturnAppleIAPDetailInfo.json = applejson;
                //    oReturnAppleIAPDetailInfo.orderid = oRechOrder.OrderID;
                //    oReturnAppleIAPDetailInfo.orderamount = orderamount;
                //    oReturnAppleIAPDetailInfo.iap_transaction = paramTransaction;

                //    Message omsg = oTreasureFacade.WriteAppleIAPRecharge(oRechOrder.OrderID, oReturnAppleIAPDetailInfo);
                //    if (omsg.Success)
                //    {
                //        //重新获取用户信息
                //        oUserInfo = oAccountsFacade.GetUserFullInfoByUserID(paramUserID);
                //        Hashtable resultdata = new Hashtable();
                //        resultdata.Add("Score", oUserInfo.GameScoreInfo.Score);
                //        resultdata.Add("GoldenBean", oUserInfo.UserGoldenBean.GoldenBean);
                //        //订单处理成功
                //        this.ResponseClient(true, "充值成功，请到银行查收！", resultdata);
                //    }
                //    else throw new Exception("处理订单失败！");
                //}
                //else throw new Exception("生成订单失败！");
                #endregion
            }
            else throw new Exception("IAP验证失败！");
        }
        #endregion
    }
}