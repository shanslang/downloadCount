﻿using Game.Type;
using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Game.AppServices
{
    /// <summary>
    /// 常量类
    /// </summary>
    public static class Constant
    {

        /// <summary>
        /// 苹果IPA支付接口(沙盒)提交地址
        /// </summary>
        public static string APPLEIAPSandboxUrl
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["APPLEIAPSandboxUrl"].ToString();
            }
        }

        /// <summary>
        /// 苹果IPA支付接口(正式)提交地址
        /// </summary>
        public static string APPLEIAPBuyUrl
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["APPLEIAPBuyUrl"].ToString();
            }
        }

        /// <summary>
        /// 客服电话
        /// </summary>
        public static string ServicePhone
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["ServicePhone"].ToString();
            }
        }

        /// <summary>
        /// 客服QQ
        /// </summary>
        public static string ServiceQQ
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["ServiceQQ"].ToString();
            }
        }

        /// <summary>
        /// 跳转域名
        /// </summary>
        public static string RedirectDomain
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["RedirectDomain"].ToString();
            }
        }

        /// <summary>
        /// 是否打开比赛
        /// </summary>
        public static string IsOpenMatch
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["IsOpenMatch"].ToString();
            }
        }

        /// <summary>
        /// 是否打开转账
        /// </summary>
        public static string IsOpenTransfer
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["IsOpenTransfer"].ToString();
            }
        }
        /// <summary>
        /// IOS游戏下载地址
        /// </summary>
        /// <returns></returns>
        public static string IOSGameDownloadLink
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["IOSGameDownload"].ToString();
            }
        }
        /// <summary>
        /// Andorid游戏下载地址
        /// </summary>
        /// <returns></returns>
        public static string AndoridGameDownloadLink
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["AndoridGameDownload"].ToString();
            }
        }
        /// <summary>
        /// 手机认证奖励
        /// </summary>
        /// <returns></returns>
        public static string AuthPhonrReward
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["AuthPhoneReward"].ToString();
            }
        }
        /// <summary>
        /// 文件上传最大限制(默认返回最大10M的限制10485760)
        /// </summary>
        /// <returns></returns>
        public static int APPUploadFileMaxLenth
        {
            get
            {
                return Game.Utils.Utility.StrToInt(System.Configuration.ConfigurationManager.AppSettings["APPUploadFileMaxLenth"].ToString(), 10485760);

            }
        }
        /// <summary>
        /// 资源图片下载地址
        /// </summary>
        /// <returns></returns>
        public static string GameResourcesHost
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["GameResourcesHost"].ToString();
            }
        }


        /// <summary>
        /// 转换客户端传过来的devicetype 返回服务端的devicetype
        /// </summary>
        /// <param name="devicetype"></param>
        /// <returns></returns>
        public static int FormatClientDeviceType(SigninEquipment devicetype)
        {
            if (devicetype == SigninEquipment.PCSignIn) { return (int)DeviceType.PC; }
            if (devicetype != SigninEquipment.PCSignIn) { return (int)DeviceType.IOS; }
            return -1;
            //switch (devicetype)
            //{
            //    case SigninEquipment.PCSignIn:
            //        return (int)DeviceType.PC;
            //    case SigninEquipment.AndroidSignIn:
            //        return (int)DeviceType.Android;
            //    case SigninEquipment.ITouchSignIn:
            //        return (int)DeviceType.IOS;
            //    case SigninEquipment.IPhoneSignIn:
            //        return (int)DeviceType.IOS;
            //    case SigninEquipment.IPadSignIn:
            //        return (int)DeviceType.IOS;
            //    default:
            //        return -1;
            //}
        }
        /// <summary>
        /// 发布版本号
        /// </summary>
        public static string ReleaseVersion
        {
            get
            {
                return "1";
            }
        }

        /// <summary>
        /// 审核版本号
        /// </summary>
        public static string AuditVersion
        {
            get
            {
                return "0";
            }
        }

        #region 棱镜productSecret

        /// <summary>
        /// 棱镜productSecret
        /// </summary>
        public static string LJproductSecretXL
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["productSecretXL"];
            }
        }
        /// <summary>
        /// 棱镜productSecret
        /// </summary>
        public static string LJproductSecretNN
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["productSecretNN"];
            }
        }
        /// <summary>
        /// 棱镜productSecret
        /// </summary>
        public static string productSecretZJH
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["productSecretZJH"];
            }
        }

        #endregion

        #region 微信注册账号key
        public static string WeiXinAppID
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["WeiXinAppID"];
            }
        }
        public static string WeiXinSecret
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["WeiXinSecret"];
            }
        }
        public static string NMWeiXinAppID
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["NMWeiXinAppID"];
            }
        }
        public static string NMWeiXinSecret
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["NMWeiXinSecret"];
            }
        }
        public static string HBWeiXinAppID
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["HBWeiXinAppID"];
            }
        }
        public static string HBWeiXinSecret
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["HBWeiXinSecret"];
            }
        }
        public static string FileUpload
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["FileUpload"];
            }
        }
        public static string APIKey
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["APIKey"];
            }
        }

        public static int UserGroup
        {
            get
            {
                int num = 200;
                int.TryParse(System.Configuration.ConfigurationManager.AppSettings["UserGroup"], out num);
                return num;
            }
        }
        public static string ServerIP
        {
            get
            {

                return System.Configuration.ConfigurationManager.AppSettings["serverip"];
            }
        }
        public static string ServerPort
        {
            get
            {

                return System.Configuration.ConfigurationManager.AppSettings["serverport"];
            }
        }
        public static string UserIDList
        {
            get
            {

                return System.Configuration.ConfigurationManager.AppSettings["useridlist"];
            }
        }
        #endregion
    }
}
