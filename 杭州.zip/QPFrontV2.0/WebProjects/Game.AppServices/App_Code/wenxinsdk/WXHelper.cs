﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml;
using Game.Facade;
using upacp_sdk_net.com.unionpay.sdk;

namespace Game.AppServices.wenxinsdk
{
    public class WXHelper
    {
        public WXHelper(string mchID,string key,string appID,string notifyUrl)
        {
            MchId = mchID;
            Key = key;
            AppId = appID;
            NotifyUrl = notifyUrl;
        }

        #region 属性
        /// <summary>
        /// 商户ID，身份标识，在微信发送的邮件中查看。
        /// </summary>
        private string MchId { set; get; }

        /// <summary>
        /// 商户支付秘钥Key。登录微信商户后台，进入栏目【账户设置】【密码安全】【API安全】【API秘钥】
        /// </summary>
        private string Key { set; get; }

        /// <summary>
        /// 微信公众号身份的唯一标识。审核通过后，在微信发送的邮件中查看。
        /// </summary>
        private string AppId { set; get; }

        /// <summary>
        /// JSAPI接口中获取openid,审核后在公众平台开启开发模式后可查看。
        /// </summary>
        private string NotifyUrl { set; get; }
        #endregion

        #region 公共
        /// <summary>
        /// 整合参数
        /// </summary>
        /// <param name="parms"></param>
        /// <returns></returns>
        public string getparmstodictionary(Dictionary<string, string> parms)
        {
            var parmsTemp = parms.OrderBy(d => d.Key);
            string result = "";
            foreach (KeyValuePair<string, string> item in parmsTemp)
            {
                if (!string.IsNullOrEmpty(item.Value) && item.Key != "sign")
                {
                    result += string.Format("{0}={1}&", item.Key, item.Value);
                }
            }
            result = result.Trim('&');
            return result;
        }
        /// <summary>
        /// 装换xml到字典
        /// </summary>
        /// <param name="doc"></param>
        /// <returns></returns>
        public Dictionary<string, string> getxmltodictionary(string xml)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            Dictionary<string, string> collection = new Dictionary<string, string>();
            foreach (XmlElement element in doc.DocumentElement.ChildNodes)
            {
                string key = element.Name;
                string value = element.InnerText;
                if (value != "")
                {
                    collection.Add(key, value);
                }
            }
            return collection;
        }
        /// <summary>
        /// 整合发送xml
        /// </summary>
        /// <param name="parms"></param>
        /// <returns></returns>
        public string getpostdata(Dictionary<string, string> parms)
        {
            var parmsTemp = parms.OrderBy(d => d.Key);
            string result = "<xml>";
            foreach (KeyValuePair<string, string> item in parmsTemp)
            {
                if (Regex.IsMatch(item.Value, @"^[0-9.]$"))
                {
                    result += string.Format("<{0}>{1}</{0}>", item.Key, item.Value);
                }
                else
                {
                    result += string.Format("<{0}><![CDATA[{1}]]></{0}>", item.Key, item.Value);
                }
            }
            result += "</xml>";
            return result;
        }
        /// <summary>
        /// 获取密钥签名
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public string getsign(Dictionary<string, string> parms)
        {
            string input = this.getparmstodictionary(parms);
            string result = input + "&key=" + Key;
            result = getmd5(result);
            result = result.ToUpper();
            return result;
        }

        /// <summary>
        /// md5
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public string getmd5(string input)
        {
            string result = "";
            System.Security.Cryptography.MD5 md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] data = Encoding.UTF8.GetBytes(input);
            byte[] bytes = md5.ComputeHash(data, 0, data.Length);
            System.Text.StringBuilder sb = new System.Text.StringBuilder(32);
            for (int i = 0; i < bytes.Length; i++)
            {
                sb.Append(bytes[i].ToString("x").PadLeft(2, '0'));
            }
            result = sb.ToString();
            return result;
        }
        /// <summary>
        /// 转换编码
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public string urlencode(string str)
        {
            StringBuilder builder = new StringBuilder();
            foreach (char c in str)
            {
                if (HttpUtility.UrlEncode(c.ToString()).Length > 1)
                {
                    builder.Append(HttpUtility.UrlEncode(c.ToString(), Encoding.UTF8));
                }
                else
                {
                    builder.Append(c);
                }
            }
            return builder.ToString();
        }
        /// <summary>
        /// 发送数据请求
        /// </summary>
        /// <param name="url"></param>
        /// <param name="postdata"></param>
        /// <returns></returns>
        public string requestpost(string url, string postdata)
        {
            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postdata);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = data.Length;
            using (Stream stream = request.GetRequestStream()) { stream.Write(data, 0, data.Length); }
            var sm = (request.GetResponse() as HttpWebResponse).GetResponseStream();
            StreamReader sr = new StreamReader(sm, Encoding.UTF8);
            string resultdata = string.Empty;
            while (sr.Peek() > -1) resultdata += sr.ReadLine();
            return resultdata;
        }
        /// <summary>
        /// 获取本地IP地址信息
        /// </summary>
        public string getlocalip()
        {
            ///获取本地的IP地址
            string AddressIP = string.Empty;
            foreach (IPAddress _IPAddress in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
            {
                if (_IPAddress.AddressFamily.ToString() == "InterNetwork")
                {
                    AddressIP = _IPAddress.ToString();
                }
            }
            return AddressIP;
        }
        /// <summary>
        /// 生成时间戳，标准北京时间，时区为东八区，自1970年1月1日 0点0分0秒以来的秒数
        /// @return 时间戳
        /// </summary>
        /// <returns></returns>
        public string GenerateTimeStamp()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds).ToString();
        }

        /// <summary>
        /// 生成随机串，随机串包含字母或数字
        /// * @return 随机串
        /// </summary>
        /// <returns></returns>
        public string GenerateNonceStr()
        {
            return Guid.NewGuid().ToString().Replace("-", "");
        }
        #endregion

        #region 业务处理

        /// <summary>
        /// 统一支付接口
        /// </summary>
        /// <param name="orderid">订单号</param>
        /// <param name="amount">交易金额</param>
        /// <param name="openid">openid</param>
        /// <returns>预支付ID prepay_id</returns>
        public string unifiedorder(string orderid, string productremark, int amount)
        {
            string prepayid = null;
            string url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
            Dictionary<string, string> parms = new Dictionary<string, string>();
            parms.Add("appid", AppId);
            parms.Add("mch_id", MchId);
            parms.Add("device_info", "");
            parms.Add("nonce_str", DateTime.Now.ToString("yyyyMMddHHmmssffff"));
            parms.Add("body", productremark);
            parms.Add("attach", "");
            parms.Add("out_trade_no", orderid);
#if DEBUG
            parms.Add("total_fee", "1");
#else
            parms.Add("total_fee", amount.ToString());
#endif

            parms.Add("spbill_create_ip", getlocalip());
            parms.Add("time_start", DateTime.Now.ToString("yyyyMMddHHmmss"));
            parms.Add("time_expire", DateTime.Now.AddMinutes(10).ToString("yyyyMMddHHmmss"));
            parms.Add("goods_tag", "");
            parms.Add("notify_url", NotifyUrl);
            parms.Add("trade_type", "APP");
            parms.Add("openid", "");
            parms.Add("product_id", "");

            //获取签名
            string sign = this.getsign(parms);
            parms.Add("sign", sign);

            //获取xml发送包
            string postdata = this.getpostdata(parms);

            //发送请求
            string resultdata = this.requestpost(url, postdata);

            //装换字典类型
            var listdata = this.getxmltodictionary(resultdata);

            //结果筛选
            if (listdata["return_code"] != "SUCCESS") return prepayid;
            if (listdata["result_code"] != "SUCCESS") return prepayid;
            if (listdata["trade_type"] == "APP")
            {
                prepayid = listdata["prepay_id"];
            }
            return prepayid;
        }

        /// <summary>
        /// 返回app请求参数
        /// </summary>
        /// <param name="prepayid"></param>
        /// <returns></returns>
        public string getappparams(string prepayid)
        {
            Dictionary<string, string> parms = new Dictionary<string, string>();
            parms.Add("appid", AppId);
            parms.Add("partnerid", MchId);
            parms.Add("prepayid", prepayid);
            parms.Add("package", "Sign=WXPay");
            parms.Add("timestamp", GenerateTimeStamp());
            parms.Add("noncestr", GenerateNonceStr());

            //获取签名
            string sign = this.getsign(parms);
            parms.Add("sign", sign);

            return Newtonsoft.Json.JsonConvert.SerializeObject(parms);
        }

        /// <summary>
        /// 处理通知
        /// </summary>
        public void processnotify()
        {
            bool returncode = false;
            string returnmsg = "";
            var request = HttpContext.Current.Request;
            var response = HttpContext.Current.Response;

            try
            {
                StreamReader sr = new StreamReader(request.InputStream, Encoding.UTF8);
                string resultdata = string.Empty;
                while (sr.Peek() > -1) resultdata += sr.ReadLine();

                // "appid":"wxcaee33d2d9beb0df",
                // "bank_type":"CMB_CREDIT",
                // "cash_fee":"1",
                // "fee_type":"CNY",
                // "is_subscribe":"Y",
                // "mch_id":"10031895",
                // "nonce_str":"201501051643443622",
                // "openid":"olUvot99U2FZqliUNw46xVkMAi_E",
                // "out_trade_no":"WX20150105164344336540872",
                // "result_code":"SUCCESS",
                // "return_code":"SUCCESS",
                // "sign":"DF15A8A31D92799A49832D785E964870",
                // "time_end":"20150105164711",
                // "total_fee":"1",
                // "trade_type":"NATIVE",
                // "transaction_id":"1007040791201501050009382816"
                //string json = "{\"appid\":\"wxcaee33d2d9beb0df\",\"bank_type\":\"CMB_CREDIT\",\"cash_fee\":\"1\",\"fee_type\":\"CNY\",\"is_subscribe\":\"Y\",\"mch_id\":\"10031895\",\"nonce_str\":\"201501051643443622\",\"openid\":\"olUvot99U2FZqliUNw46xVkMAi_E\",\"out_trade_no\":\"WX20150105164344336540872\",\"result_code\":\"SUCCESS\",\"return_code\":\"SUCCESS\",\"sign\":\"DF15A8A31D92799A49832D785E964870\",\"time_end\":\"20150105164711\",\"total_fee\":\"1\",\"trade_type\":\"NATIVE\",\"transaction_id\":\"1007040791201501050009382816\"}";
                //var listdata = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
                // 装换字典类型
                var listdata = this.getxmltodictionary(resultdata);

                if (listdata["return_code"] != "SUCCESS") return;
                if (listdata["result_code"] != "SUCCESS") return;

                string sign = listdata["sign"];
                string signserver = this.getsign(listdata);
                if (sign == signserver)//签名验证通过
                {
                    TreasureFacade oTreasureFacade = new TreasureFacade();
                    string orderid = listdata["out_trade_no"].ToString();
                    decimal amount = Convert.ToDecimal(listdata["total_fee"]) / 100;
                    var oOnlineOrder = oTreasureFacade.GetOnlineOrder(orderid);
                    if (amount > 0
#if !DEBUG
                                && amount >= oOnlineOrder.OrderAmount
#endif
 && oOnlineOrder.OrderStatus == (int)Game.Type.OnLineOrderStatus.未付款)
                    {
                        oOnlineOrder.ShareID = (int)Game.Type.GlobalShareInfo.WX;
                        oTreasureFacade.WriteVnetRecharge(oOnlineOrder);//暂没有加入微信充值记录，用互联星空处理订单
                    }
                }
                else
                {
                    returncode = false;
                    returnmsg = "签名不正确！";
                }
            }
            catch
            {
                returncode = false;
                returnmsg = "服务器处理发生异常！";
            }
            finally
            {
                //Game.Library.Log.WriteLogInfo("wx", new Exception(returnmsg));

                Dictionary<string, string> result = new Dictionary<string, string>();
                result.Add("return_code", returncode ? "SUCCESS" : "FAIL");
                result.Add("return_msg", returnmsg);
                string xml = this.getpostdata(result);
                response.Write(xml);
                response.End();
            }
        }
        #endregion
    }

    //public static class WXConfig
    //{
    //    /// <summary>
    //    /// 商户ID，身份标识，在微信发送的邮件中查看。
    //    /// </summary>
    //    public static string MchId
    //    {
    //        get
    //        {
    //            return "1305571401";
    //        }
    //    }

    //    /// <summary>
    //    /// 商户支付秘钥Key。登录微信商户后台，进入栏目【账户设置】【密码安全】【API安全】【API秘钥】
    //    /// </summary>
    //    public static string Key
    //    {
    //        get
    //        {
    //            return "E7F7E5F3559F160FDAED315408F0CC41";
    //        }
    //    }

    //    /// <summary>
    //    /// 微信公众号身份的唯一标识。审核通过后，在微信发送的邮件中查看。
    //    /// </summary>
    //    public static string AppId
    //    {
    //        get
    //        {
    //            return "wx33982ed711ecf872";
    //        }
    //    }

    //    ///// <summary>
    //    ///// JSAPI接口中获取openid,审核后在公众平台开启开发模式后可查看。
    //    ///// </summary>
    //    //public static string AppSecret
    //    //{
    //    //    get
    //    //    {
    //    //        return "d4624c36b6795d1d99dcf0547af5443d";
    //    //    }
    //    //}

    //    /// <summary>
    //    /// JSAPI接口中获取openid,审核后在公众平台开启开发模式后可查看。
    //    /// </summary>
    //    public static string NotifyUrl
    //    {
    //        get
    //        {
    //            return "http://115.29.14.127:9999/api/weixin/payreceive.aspx";
    //        }
    //    }
    //}
}