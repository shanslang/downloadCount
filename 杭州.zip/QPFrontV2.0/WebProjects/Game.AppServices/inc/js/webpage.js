﻿(function (window, $, undefined) {
    var _pageName = "", _pageData = {}, _isPageDataInitialized = false;
    var XJWebPage = function () { };
    XJWebPage.prototype = {
        initialize: function (pageName, pageData) {
            if (!_isPageDataInitialized) {
                _isPageDataInitialized = true;
                _pageName = pageName;
                _pageData = pageData;
            }
        },
        getPageData: function (name) {
            return _pageData[name];
        },
        ajaxWeb: function (m, data, callback) {
            $.ajax({
                type: "POST",
                url: "/handler/webhandler.ashx?m=" + m,
                data: JSON.stringify(data),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                cache: false,
                success: callback,
                error: function (XMLHttpRequest, textStatus, errorThrown) { }
            })
        },
        isNullOrEmpty: function (str) {
            if (typeof str != "string") {
                return str === null;
            }
            if (str === null) {
                return true;
            }
            return str.length === 0;
        },
        isNullOrWhiteSpace: function (str) {
            if (typeof str != "string") {
                return str === null;
            }
            if (str === null) {
                return true;
            }
            var i = 0;
            while (i < str.length) {
                if (str.charAt(i) === " ") {
                    i++;
                } else {
                    return false;
                }
            }
            return true;
        },
        winopen: function (url, target) {
            window.open(url, target);
        },
        //检查是否为数字
        isNumeric: function (a) {
            if (a == "" || a == null) return false;
            var reg = /^\/d+(\/.{1}\/d+)?$/
            return reg.test(a);
        },
        //检查是否为整数
        isInteger: function (a) {
            if (a == "" || a == null) return false;
            var reg = /^-?\/d+$/
            return reg.test(a);
        },
        //检查是否为正整数
        isPositiveInteger: function (a) {
            if (a == "" || a == null) return false;
            var reg = /^[0-9]*$/
            return reg.test(a);
        },
        //检查非正浮点数（负浮点数 + 0）
        isFloatNotPositive: function (a) {
            if (a == "" || a == null) return false;
            var reg = /^((-\d+(\.\d+)?)|(0+(\.0+)?))$/
            return reg.test(a);
        },
        //检查非负浮点数（正浮点数 + 0）
        isFloatNotNegative: function (a) {
            if (a == "" || a == null) return false;
            var reg = /^\d+(\.\d+)?$/
            return reg.test(a);
        }
    };
    // 导出类型
    window.thisPage = new XJWebPage();
})(window, jQuery);


